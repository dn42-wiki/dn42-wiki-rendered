<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'Buzzster-Trust-Services.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Buzzster-Trust-Services</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Buzzster-Trust-Services</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/Buzzster-Trust-Services.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/Buzzster-Trust-Services.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Buzzster-Trust-Services
  </h1>
	<div class="breadcrumb"></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="buzzster-trust-services" href="#buzzster-trust-services"></a>Buzzster Trust Services</h1>

<p>buzzster.dn42 is signed by an internally maintained CA that is only allowed to sign *.buzzster.dn42 domains.</p>

<p>The CA certificate (<a href="https://buzzster.dn42/ca/buzzster-ca.pem">dn42</a>):</p>

<pre class="highlight"><code>Certificate:
    Data:
        Version: 3 (0x2)
        Serial Number:
            7c:2e:70:2a:7e:0f:6b:93:aa:51:fb:e7:c5:94:0e:58:bb:a7:87:8c
        Signature Algorithm: sha256WithRSAEncryption
        Issuer: O = Buzzster Trust Services, CN = WR1
        Validity
            Not Before: Jul  8 21:49:07 2025 GMT
            Not After : Jul  6 21:49:07 2035 GMT
        Subject: O = Buzzster Trust Services, CN = WR1
        Subject Public Key Info:
            Public Key Algorithm: rsaEncryption
                RSA Public-Key: (4096 bit)
                Modulus:
                    00:ec:b1:65:aa:9f:15:b9:c2:18:e1:fb:6f:e9:e9:
                    45:40:e6:6f:cb:31:53:09:e2:6b:fa:e2:ef:78:84:
                    b4:a4:32:5d:94:81:d5:cd:5d:1b:5d:86:3e:8f:48:
                    ba:d5:ea:2b:ae:94:81:0a:79:56:07:dd:e1:7f:56:
                    f3:63:93:24:64:0f:e2:fa:e3:17:20:89:d3:d2:6d:
                    b6:6b:02:fa:85:44:de:76:c7:1c:04:ad:5e:b0:b7:
                    b5:ee:f7:bf:9c:d1:15:2d:f0:b5:87:88:7c:f1:3c:
                    9a:7d:ef:88:d5:ea:b0:2e:bd:e9:71:70:92:83:3f:
                    67:43:70:86:7c:45:45:71:65:73:d7:f3:bc:f9:6e:
                    a6:9a:91:20:62:58:d0:cf:77:f8:81:2d:03:5e:4e:
                    82:4b:cb:f8:a1:37:2b:52:42:bb:e8:5a:4c:7c:eb:
                    31:da:98:bf:bf:57:f6:69:93:d3:08:0a:af:c6:87:
                    d3:93:2b:a4:78:94:2a:82:44:3f:28:e1:13:1a:0b:
                    d6:64:3d:30:e4:06:a4:11:06:c9:88:ce:be:27:26:
                    95:20:c3:91:38:4d:4f:c5:0d:73:90:23:0e:ee:58:
                    10:4f:ff:eb:d4:5f:19:70:79:02:12:fd:b4:79:c7:
                    fd:0a:94:f3:d8:6d:f6:af:e0:f9:68:ee:34:be:23:
                    d5:c4:d0:9e:af:16:b9:43:8f:4e:42:db:00:c1:66:
                    79:5f:01:f8:83:42:ff:4d:da:4b:28:ef:6e:b5:bf:
                    28:32:31:f5:56:bc:ea:5d:a9:8b:03:63:84:1e:01:
                    97:6f:6b:8f:5b:d5:d6:3b:88:e3:40:56:3d:8a:dd:
                    29:82:7f:19:a9:49:c0:62:9a:5d:c2:dd:d3:49:af:
                    87:fb:d4:41:65:f2:50:54:6f:9b:4a:62:b5:61:ee:
                    0f:e0:e7:d3:81:b2:59:8f:30:e6:0b:c9:e9:8b:16:
                    4b:bd:d4:d0:a1:39:1a:b9:43:a4:70:a6:01:de:03:
                    0d:19:72:f6:91:2d:3f:ab:6a:03:82:05:3b:4a:09:
                    df:42:d5:2e:19:88:48:0b:fa:da:c6:78:99:76:3d:
                    75:71:68:93:74:f0:c8:85:fb:34:fa:7e:d5:de:20:
                    88:d7:cc:8c:4d:fa:a9:70:22:c7:88:b5:9d:6c:94:
                    ef:76:5c:c6:de:b1:bf:e3:91:4e:29:a6:f4:46:ab:
                    c9:75:13:bf:9a:37:a4:26:84:cd:0e:8c:16:fd:6b:
                    b4:1a:bb:d7:62:c6:90:5c:d7:7d:cc:0d:f0:83:21:
                    5e:09:e7:e1:02:c9:41:7e:9e:8d:71:ac:a0:85:77:
                    70:e6:bd:0a:34:5c:38:11:65:83:bf:a5:75:48:66:
                    d5:89:67
                Exponent: 65537 (0x10001)
        X509v3 extensions:
            X509v3 Subject Key Identifier: 
                8A:DF:E7:C9:3E:E5:73:2C:7C:21:D6:C8:4E:40:60:02:87:8B:F8:F3
            X509v3 Authority Key Identifier: 
                keyid:8A:DF:E7:C9:3E:E5:73:2C:7C:21:D6:C8:4E:40:60:02:87:8B:F8:F3

            X509v3 Basic Constraints: critical
                CA:TRUE
    Signature Algorithm: sha256WithRSAEncryption
         8f:0b:3c:56:06:42:ce:aa:48:86:1b:cd:20:57:41:36:04:b6:
         e7:bc:2a:b4:65:35:ec:ea:66:3a:f0:e3:75:ab:81:ea:0c:97:
         4d:1b:d1:af:c1:c5:26:8e:ce:1c:b9:97:d1:e5:58:d7:8a:74:
         5e:80:d0:9f:c6:64:4f:58:ba:42:b0:6e:e7:f4:36:b2:c1:c8:
         92:6b:76:33:3d:7b:b3:f8:d5:82:28:35:ef:f7:e6:92:2f:9b:
         fa:10:55:d5:92:be:50:d2:c5:ac:6b:d3:4c:d9:1a:02:5c:34:
         b1:54:b4:ab:48:5b:fc:a7:17:b7:df:85:f3:2e:a6:00:02:e4:
         39:0d:f5:94:ee:e1:6c:ad:74:e0:27:3b:84:d2:9e:a7:a7:1d:
         e3:dc:9e:67:a4:9b:61:6c:c4:63:5b:5c:86:4f:1b:e1:c3:96:
         44:1d:f0:95:4e:92:d0:20:68:35:08:4b:fc:76:84:ee:7c:2d:
         4c:90:25:4e:b3:c8:66:28:fa:92:cd:cd:7b:26:a4:a4:8e:31:
         78:0a:49:ce:52:33:98:55:3b:e3:6c:f6:4e:47:f6:f7:95:0d:
         f7:29:16:f1:6e:7a:c4:34:27:63:9b:83:47:d5:7e:e6:eb:3a:
         2c:b1:b1:9d:4c:e4:63:3f:0e:54:3d:74:37:46:3d:37:18:1c:
         91:be:12:73:8f:88:06:06:2e:2f:da:a1:f8:dc:4d:d8:d9:b6:
         00:66:1f:e5:4d:aa:b3:a8:f2:9f:9c:52:e0:43:dd:cd:e4:ff:
         26:23:82:84:62:1a:13:f8:5b:b9:e1:57:f6:dc:7b:aa:e4:f9:
         8b:c1:4b:7e:cb:42:b1:42:de:2e:48:41:77:08:8a:22:63:56:
         68:c3:1b:87:0d:90:26:05:a8:b2:7d:75:81:66:e4:21:29:1a:
         dc:a3:78:c9:28:a2:ec:4f:08:fc:4c:91:57:93:0f:46:1a:5d:
         92:4e:13:ea:aa:3b:71:1f:80:47:36:bc:e3:66:ee:55:97:1e:
         2b:d4:b3:f4:03:26:83:aa:0f:69:ad:13:55:60:41:7e:e3:88:
         31:d2:5d:50:c8:e1:55:80:8a:af:08:db:18:75:30:4d:f5:bf:
         66:ba:b1:95:f8:e2:86:6e:2a:80:18:41:66:9e:3d:bc:b2:3d:
         09:64:ae:03:45:4e:c1:f5:38:e9:2b:af:8c:0e:4b:bc:86:a6:
         95:54:63:07:e2:20:12:c6:cc:d4:73:87:8d:d9:5c:f5:a8:d0:
         2a:f7:0b:75:e6:c5:87:68:8b:a6:50:07:7b:9a:36:91:13:9f:
         77:01:8a:81:1a:78:dc:3f:be:b8:4c:57:1b:9c:62:f5:95:c5:
         ae:97:0c:0b:e6:f0:7c:af
-----BEGIN CERTIFICATE-----
MIIFQTCCAymgAwIBAgIUfC5wKn4Pa5OqUfvnxZQOWLunh4wwDQYJKoZIhvcNAQEL
BQAwMDEgMB4GA1UECgwXQnV6enN0ZXIgVHJ1c3QgU2VydmljZXMxDDAKBgNVBAMM
A1dSMTAeFw0yNTA3MDgyMTQ5MDdaFw0zNTA3MDYyMTQ5MDdaMDAxIDAeBgNVBAoM
F0J1enpzdGVyIFRydXN0IFNlcnZpY2VzMQwwCgYDVQQDDANXUjEwggIiMA0GCSqG
SIb3DQEBAQUAA4ICDwAwggIKAoICAQDssWWqnxW5whjh+2/p6UVA5m/LMVMJ4mv6
4u94hLSkMl2UgdXNXRtdhj6PSLrV6iuulIEKeVYH3eF/VvNjkyRkD+L64xcgidPS
bbZrAvqFRN52xxwErV6wt7Xu97+c0RUt8LWHiHzxPJp974jV6rAuvelxcJKDP2dD
cIZ8RUVxZXPX87z5bqaakSBiWNDPd/iBLQNeToJLy/ihNytSQrvoWkx86zHamL+/
V/Zpk9MICq/Gh9OTK6R4lCqCRD8o4RMaC9ZkPTDkBqQRBsmIzr4nJpUgw5E4TU/F
DXOQIw7uWBBP/+vUXxlweQIS/bR5x/0KlPPYbfav4Plo7jS+I9XE0J6vFrlDj05C
2wDBZnlfAfiDQv9N2kso7261vygyMfVWvOpdqYsDY4QeAZdva49b1dY7iONAVj2K
3SmCfxmpScBiml3C3dNJr4f71EFl8lBUb5tKYrVh7g/g59OBslmPMOYLyemLFku9
1NChORq5Q6RwpgHeAw0ZcvaRLT+ragOCBTtKCd9C1S4ZiEgL+trGeJl2PXVxaJN0
8MiF+zT6ftXeIIjXzIxN+qlwIseItZ1slO92XMbesb/jkU4ppvRGq8l1E7+aN6Qm
hM0OjBb9a7Qau9dixpBc133MDfCDIV4J5+ECyUF+no1xrKCFd3DmvQo0XDgRZYO/
pXVIZtWJZwIDAQABo1MwUTAdBgNVHQ4EFgQUit/nyT7lcyx8IdbITkBgAoeL+PMw
HwYDVR0jBBgwFoAUit/nyT7lcyx8IdbITkBgAoeL+PMwDwYDVR0TAQH/BAUwAwEB
/zANBgkqhkiG9w0BAQsFAAOCAgEAjws8VgZCzqpIhhvNIFdBNgS257wqtGU17Opm
OvDjdauB6gyXTRvRr8HFJo7OHLmX0eVY14p0XoDQn8ZkT1i6QrBu5/Q2ssHIkmt2
Mz17s/jVgig17/fmki+b+hBV1ZK+UNLFrGvTTNkaAlw0sVS0q0hb/KcXt9+F8y6m
AALkOQ31lO7hbK104Cc7hNKep6cd49yeZ6SbYWzEY1tchk8b4cOWRB3wlU6S0CBo
NQhL/HaE7nwtTJAlTrPIZij6ks3NeyakpI4xeApJzlIzmFU742z2Tkf295UN9ykW
8W56xDQnY5uDR9V+5us6LLGxnUzkYz8OVD10N0Y9Nxgckb4Sc4+IBgYuL9qh+NxN
2Nm2AGYf5U2qs6jyn5xS4EPdzeT/JiOChGIaE/hbueFX9tx7quT5i8FLfstCsULe
LkhBdwiKImNWaMMbhw2QJgWosn11gWbkISka3KN4ySii7E8I/EyRV5MPRhpdkk4T
6qo7cR+ARza842buVZceK9Sz9AMmg6oPaa0TVWBBfuOIMdJdUMjhVYCKrwjbGHUw
TfW/Zrqxlfjihm4qgBhBZp49vLI9CWSuA0VOwfU46SuvjA5LvIamlVRjB+IgEsbM
1HOHjdlc9ajQKvcLdebFh2iLplAHe5o2kROfdwGKgRp43D++uExXG5xi9ZXFrpcM
C+bwfK8=
-----END CERTIFICATE-----</code></pre>

<h2><a class="anchor" id="importing-the-certificate" href="#importing-the-certificate"></a>Importing the certificate</h2>

<ul>
  <li>cacert have a comprehensive FAQ on how to import your own root certificates in <a href="http://wiki.cacert.org/FAQ/BrowserClients">browsers</a> and <a href="http://wiki.cacert.org/FAQ/ImportRootCert">other software</a>
</li>
</ul>

<h4><a class="anchor" id="manual-installation" href="#manual-installation"></a>Manual Installation</h4>

<pre class="highlight"><code><span class="nv">$ </span><span class="nb">mkdir</span> /usr/share/ca-certificates/extra
<span class="nv">$ </span><span class="nb">cat</span> <span class="o">&gt;</span> /usr/share/ca-certificates/extra/buzzster.crt <span class="o">&lt;&lt;</span><span class="no">EOF</span><span class="sh">
-----BEGIN CERTIFICATE-----
MIIFQTCCAymgAwIBAgIUfC5wKn4Pa5OqUfvnxZQOWLunh4wwDQYJKoZIhvcNAQEL
BQAwMDEgMB4GA1UECgwXQnV6enN0ZXIgVHJ1c3QgU2VydmljZXMxDDAKBgNVBAMM
A1dSMTAeFw0yNTA3MDgyMTQ5MDdaFw0zNTA3MDYyMTQ5MDdaMDAxIDAeBgNVBAoM
F0J1enpzdGVyIFRydXN0IFNlcnZpY2VzMQwwCgYDVQQDDANXUjEwggIiMA0GCSqG
SIb3DQEBAQUAA4ICDwAwggIKAoICAQDssWWqnxW5whjh+2/p6UVA5m/LMVMJ4mv6
4u94hLSkMl2UgdXNXRtdhj6PSLrV6iuulIEKeVYH3eF/VvNjkyRkD+L64xcgidPS
bbZrAvqFRN52xxwErV6wt7Xu97+c0RUt8LWHiHzxPJp974jV6rAuvelxcJKDP2dD
cIZ8RUVxZXPX87z5bqaakSBiWNDPd/iBLQNeToJLy/ihNytSQrvoWkx86zHamL+/
V/Zpk9MICq/Gh9OTK6R4lCqCRD8o4RMaC9ZkPTDkBqQRBsmIzr4nJpUgw5E4TU/F
DXOQIw7uWBBP/+vUXxlweQIS/bR5x/0KlPPYbfav4Plo7jS+I9XE0J6vFrlDj05C
2wDBZnlfAfiDQv9N2kso7261vygyMfVWvOpdqYsDY4QeAZdva49b1dY7iONAVj2K
3SmCfxmpScBiml3C3dNJr4f71EFl8lBUb5tKYrVh7g/g59OBslmPMOYLyemLFku9
1NChORq5Q6RwpgHeAw0ZcvaRLT+ragOCBTtKCd9C1S4ZiEgL+trGeJl2PXVxaJN0
8MiF+zT6ftXeIIjXzIxN+qlwIseItZ1slO92XMbesb/jkU4ppvRGq8l1E7+aN6Qm
hM0OjBb9a7Qau9dixpBc133MDfCDIV4J5+ECyUF+no1xrKCFd3DmvQo0XDgRZYO/
pXVIZtWJZwIDAQABo1MwUTAdBgNVHQ4EFgQUit/nyT7lcyx8IdbITkBgAoeL+PMw
HwYDVR0jBBgwFoAUit/nyT7lcyx8IdbITkBgAoeL+PMwDwYDVR0TAQH/BAUwAwEB
/zANBgkqhkiG9w0BAQsFAAOCAgEAjws8VgZCzqpIhhvNIFdBNgS257wqtGU17Opm
OvDjdauB6gyXTRvRr8HFJo7OHLmX0eVY14p0XoDQn8ZkT1i6QrBu5/Q2ssHIkmt2
Mz17s/jVgig17/fmki+b+hBV1ZK+UNLFrGvTTNkaAlw0sVS0q0hb/KcXt9+F8y6m
AALkOQ31lO7hbK104Cc7hNKep6cd49yeZ6SbYWzEY1tchk8b4cOWRB3wlU6S0CBo
NQhL/HaE7nwtTJAlTrPIZij6ks3NeyakpI4xeApJzlIzmFU742z2Tkf295UN9ykW
8W56xDQnY5uDR9V+5us6LLGxnUzkYz8OVD10N0Y9Nxgckb4Sc4+IBgYuL9qh+NxN
2Nm2AGYf5U2qs6jyn5xS4EPdzeT/JiOChGIaE/hbueFX9tx7quT5i8FLfstCsULe
LkhBdwiKImNWaMMbhw2QJgWosn11gWbkISka3KN4ySii7E8I/EyRV5MPRhpdkk4T
6qo7cR+ARza842buVZceK9Sz9AMmg6oPaa0TVWBBfuOIMdJdUMjhVYCKrwjbGHUw
TfW/Zrqxlfjihm4qgBhBZp49vLI9CWSuA0VOwfU46SuvjA5LvIamlVRjB+IgEsbM
1HOHjdlc9ajQKvcLdebFh2iLplAHe5o2kROfdwGKgRp43D++uExXG5xi9ZXFrpcM
C+bwfK8=
-----END CERTIFICATE-----
</span><span class="no">EOF
</span><span class="nv">$ </span><span class="nb">echo</span> <span class="s2">"extra/buzzster.crt"</span> <span class="o">&gt;&gt;</span> /etc/ca-certificates.conf
<span class="nv">$ </span>update-ca-certificates</code></pre>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
      <li><a href="/Links" rel="nofollow">Links</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
      <li><a href="/howto/GeoFeed" rel="nofollow">GeoFeed</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/DNS" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">RPKI</a></li>
      <li><a href="/services/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
      <li><a href="/services/Registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
      <li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
    </ul>
  </li>
  <li>Historical
    <ul>
      <li><a href="/historical/Bird" rel="nofollow">Bird 1</a></li>
      <li><a href="/historical/Quagga" rel="nofollow">Quagga</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://hedgedoc.dn42.eu" rel="nofollow">HedgeDoc</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="Buzzster-Trust-Services.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/Buzzster-Trust-Services.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
