<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'historical/Bird.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Bird</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Bird</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/historical/Bird.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/historical/Bird.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Bird
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/historical/">historical</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <p>Bird is a commonly used BGP daemon.  This page provides configuration and help to run Bird for dn42.
Compared to quagga, bird supports multiple routing tables, which is useful, if you also plan to peer with other federated networks such as freifunk. In the following a working configuration for dn42 is shown. If you 
want to learn the practical details behind routing protocols in bird, see the following <a href="https://github.com/knorrie/network-examples">guide</a></p>

<p><strong>Bird 1.6.x will be EOL by the end of 2023, it's recommended to upgrade to 2.13.</strong></p>

<h1><a class="anchor" id="debian" href="#debian"></a>Debian</h1>
<p>In the Debian release cycle the bird packages may become outdated at times, if that is the case you should use the official bird package repository maintained by the developers of nic.cz.</p>

<p>This is not necessary for Debian Stretch, which currently ships the most recent version (1.6.3) in this repositories.</p>

<pre class="highlight"><code><span class="nb">echo</span> <span class="s2">"deb http://deb.debian.org/debian buster-backports main"</span> <span class="o">&gt;</span> /etc/apt/sources.list.d/buster-backports.list
apt update
apt <span class="nb">install </span>bird</code></pre>

<h1><a class="anchor" id="example-configuration" href="#example-configuration"></a>Example configuration</h1>

<p>Note: This file covers the configuration of Bird 1.x. For an example configuration of Bird 2.x see <a href="/howto/Bird2">howto/Bird2</a></p>

<ul>
  <li>Replace <code>&lt;AS&gt;</code> with your Autonomous System Number (only the digits)</li>
  <li>Replace <code>&lt;GATEWAY_IP&gt;</code> with your gateway ip (the internal dn42 ip address you use on the host, where dn42 is running)</li>
  <li>Replace <code>&lt;SUBNET&gt;</code> with your registered dn42 subnet</li>
  <li>Replace <code>&lt;PEER_IP&gt;</code> with the ip of your peer who is connected with you using your favorite vpn protocol (openvpn, ipsec, tinc, …)</li>
  <li>Replace <code>&lt;PEER_AS&gt;</code> the Autonomous System Number of your peer (only the digits)</li>
  <li>Replace <code>&lt;PEER_NAME&gt;</code> a self chosen name for your peer</li>
</ul>

<h2><a class="anchor" id="ipv6" href="#ipv6"></a>IPv6</h2>

<pre class="highlight"><code><span class="c">#/etc/bird/bird6.conf
</span><span class="n">protocol</span> <span class="n">device</span> {
  <span class="n">scan</span> <span class="n">time</span> <span class="m">10</span>;
}

<span class="c"># local configuration
######################
</span>
<span class="n">include</span> <span class="s2">"/etc/bird/local6.conf"</span>;

<span class="c"># filter helpers
#################
</span>
<span class="c">##include "/etc/bird/filter6.conf";
</span>
<span class="c"># Kernel routing tables
########################
</span>

/*
    <span class="n">krt_prefsrc</span> <span class="n">defines</span> <span class="n">the</span> <span class="n">source</span> <span class="n">address</span> <span class="n">for</span> <span class="n">outgoing</span> <span class="n">connections</span>.
    <span class="n">On</span> <span class="n">Linux</span>, <span class="n">this</span> <span class="n">causes</span> <span class="n">the</span> <span class="s2">"src"</span> <span class="n">attribute</span> <span class="n">of</span> <span class="n">a</span> <span class="n">route</span> <span class="n">to</span> <span class="n">be</span> <span class="n">set</span>.

    <span class="n">Without</span> <span class="n">this</span> <span class="n">option</span> <span class="n">outgoing</span> <span class="n">connections</span> <span class="n">would</span> <span class="n">use</span> <span class="n">the</span> <span class="n">peering</span> <span class="n">IP</span> <span class="n">which</span>
    <span class="n">would</span> <span class="n">cause</span> <span class="n">packet</span> <span class="n">loss</span> <span class="n">if</span> <span class="n">some</span> <span class="n">peering</span> <span class="n">disconnects</span> <span class="n">but</span> <span class="n">the</span> <span class="n">interface</span>
    <span class="n">is</span> <span class="n">still</span> <span class="n">available</span>. (<span class="n">The</span> <span class="n">route</span> <span class="n">would</span> <span class="n">still</span> <span class="n">exist</span> <span class="n">and</span> <span class="n">thus</span> <span class="n">route</span> <span class="n">through</span>
    <span class="n">the</span> <span class="n">TUN</span>/<span class="n">TAP</span> <span class="n">interface</span> <span class="n">but</span> <span class="n">the</span> <span class="n">VPN</span> <span class="n">daemon</span> <span class="n">would</span> <span class="n">simply</span> <span class="n">drop</span> <span class="n">the</span> <span class="n">packet</span>.)
*/
<span class="n">protocol</span> <span class="n">kernel</span> {
  <span class="n">scan</span> <span class="n">time</span> <span class="m">20</span>;
  <span class="n">import</span> <span class="n">none</span>;
  <span class="n">export</span> <span class="n">filter</span> {
    <span class="n">if</span> <span class="n">source</span> = <span class="n">RTS_STATIC</span> <span class="n">then</span> <span class="n">reject</span>;
    <span class="n">krt_prefsrc</span> = <span class="n">OWNIP</span>;
    <span class="n">accept</span>;
  };
}

<span class="c"># static routes
################
</span>
<span class="n">protocol</span> <span class="n">static</span> {
  <span class="n">route</span> &lt;<span class="n">SUBNET</span>&gt; <span class="n">reject</span>;
  <span class="n">import</span> <span class="n">all</span>;
  <span class="n">export</span> <span class="n">none</span>;
}

<span class="n">template</span> <span class="n">bgp</span> <span class="n">dnpeers</span> {
  <span class="n">local</span> <span class="n">as</span> <span class="n">OWNAS</span>;
  <span class="n">path</span> <span class="n">metric</span> <span class="m">1</span>;
  <span class="n">import</span> <span class="n">keep</span> <span class="n">filtered</span>;
  <span class="n">import</span> <span class="n">filter</span> {
    <span class="n">if</span> <span class="n">is_valid_network</span>() &amp;&amp; !<span class="n">is_self_net</span>() <span class="n">then</span> {
      <span class="n">accept</span>;
    }
    <span class="n">reject</span>;
  };
  <span class="n">export</span> <span class="n">filter</span> {
    <span class="n">if</span> <span class="n">is_valid_network</span>() &amp;&amp; <span class="n">source</span> ~ [<span class="n">RTS_STATIC</span>, <span class="n">RTS_BGP</span>] <span class="n">then</span> {
      <span class="n">accept</span>;
    }
    <span class="n">reject</span>;
  };
  <span class="n">import</span> <span class="n">limit</span> <span class="m">1000</span> <span class="n">action</span> <span class="n">block</span>;
}

<span class="n">include</span> <span class="s2">"/etc/bird/peers6/*"</span>;</code></pre>

<pre class="highlight"><code><span class="c"># /etc/bird/local6.conf
# should be a unique identifier, use same id as for ipv4
</span><span class="n">router</span> <span class="n">id</span> &lt;<span class="n">GATEWAY_IP</span>&gt;;

<span class="n">define</span> <span class="n">OWNAS</span> =  &lt;<span class="n">AS</span>&gt;;
<span class="n">define</span> <span class="n">OWNIP</span> = &lt;<span class="n">GATEWAY_IP</span>&gt;;

<span class="n">function</span> <span class="n">is_self_net</span>() {
  <span class="n">return</span> <span class="n">net</span> ~ [&lt;<span class="n">SUBNET</span>&gt;+];
}

<span class="n">function</span> <span class="n">is_valid_network</span>() {
  <span class="n">return</span> <span class="n">net</span> ~ [
    <span class="n">fd00</span>::/<span class="m">8</span>{<span class="m">44</span>,<span class="m">64</span>} <span class="c"># ULA address space as per RFC 4193
</span>  ];
}</code></pre>

<pre class="highlight"><code><span class="c"># /etc/bird/peers6/&lt;PEER_NAME&gt;
</span><span class="n">protocol</span> <span class="n">bgp</span> &lt;<span class="n">PEER_NAME</span>&gt; <span class="n">from</span> <span class="n">dnpeers</span> {
  <span class="n">neighbor</span> &lt;<span class="n">PEERING_IP</span>&gt; <span class="n">as</span> &lt;<span class="n">PEER_AS</span>&gt;;
  <span class="c"># if you use link-local ipv6 addresses for peering using the following
</span>  <span class="c"># neighbor &lt;PEERING_IP&gt; % '&lt;INTERFACE_NAME&gt;' as &lt;PEER_AS&gt;;
</span>};</code></pre>

<h3><a class="anchor" id="ipv4" href="#ipv4"></a>IPv4</h3>

<pre class="highlight"><code><span class="c"># /etc/bird/bird.conf
# Device status
</span><span class="n">protocol</span> <span class="n">device</span> {
  <span class="n">scan</span> <span class="n">time</span> <span class="m">10</span>; <span class="c"># recheck every 10 seconds
</span>}

<span class="n">protocol</span> <span class="n">static</span> {
  <span class="c"># Static routes to announce your own range(s) in dn42
</span>  <span class="n">route</span> &lt;<span class="n">SUBNET</span>&gt; <span class="n">reject</span>;
  <span class="n">import</span> <span class="n">all</span>;
  <span class="n">export</span> <span class="n">none</span>;
};

<span class="c"># local configuration
######################
</span>
<span class="c"># keeping router specific in a seperate file, 
# so this configuration can be reused on multiple routers in your network
</span><span class="n">include</span> <span class="s2">"/etc/bird/local4.conf"</span>;

<span class="c"># filter helpers
#################
</span>
<span class="c">##include "/etc/bird/filter4.conf";
</span>
<span class="c"># Kernel routing tables
########################
</span>
/*
    <span class="n">krt_prefsrc</span> <span class="n">defines</span> <span class="n">the</span> <span class="n">source</span> <span class="n">address</span> <span class="n">for</span> <span class="n">outgoing</span> <span class="n">connections</span>.
    <span class="n">On</span> <span class="n">Linux</span>, <span class="n">this</span> <span class="n">causes</span> <span class="n">the</span> <span class="s2">"src"</span> <span class="n">attribute</span> <span class="n">of</span> <span class="n">a</span> <span class="n">route</span> <span class="n">to</span> <span class="n">be</span> <span class="n">set</span>.

    <span class="n">Without</span> <span class="n">this</span> <span class="n">option</span> <span class="n">outgoing</span> <span class="n">connections</span> <span class="n">would</span> <span class="n">use</span> <span class="n">the</span> <span class="n">peering</span> <span class="n">IP</span> <span class="n">which</span>
    <span class="n">would</span> <span class="n">cause</span> <span class="n">packet</span> <span class="n">loss</span> <span class="n">if</span> <span class="n">some</span> <span class="n">peering</span> <span class="n">disconnects</span> <span class="n">but</span> <span class="n">the</span> <span class="n">interface</span>
    <span class="n">is</span> <span class="n">still</span> <span class="n">available</span>. (<span class="n">The</span> <span class="n">route</span> <span class="n">would</span> <span class="n">still</span> <span class="n">exist</span> <span class="n">and</span> <span class="n">thus</span> <span class="n">route</span> <span class="n">through</span>
    <span class="n">the</span> <span class="n">TUN</span>/<span class="n">TAP</span> <span class="n">interface</span> <span class="n">but</span> <span class="n">the</span> <span class="n">VPN</span> <span class="n">daemon</span> <span class="n">would</span> <span class="n">simply</span> <span class="n">drop</span> <span class="n">the</span> <span class="n">packet</span>.)
*/
<span class="n">protocol</span> <span class="n">kernel</span> {
  <span class="n">scan</span> <span class="n">time</span> <span class="m">20</span>;
  <span class="n">import</span> <span class="n">none</span>;
  <span class="n">export</span> <span class="n">filter</span> {    
    <span class="n">if</span> <span class="n">source</span> = <span class="n">RTS_STATIC</span> <span class="n">then</span> <span class="n">reject</span>;
    <span class="n">krt_prefsrc</span> = <span class="n">OWNIP</span>;
    <span class="n">accept</span>;
  };
};
<span class="c"># DN42
#######
</span>
<span class="n">template</span> <span class="n">bgp</span> <span class="n">dnpeers</span> {
  <span class="n">local</span> <span class="n">as</span> <span class="n">OWNAS</span>;
  <span class="c"># metric is the number of hops between us and the peer
</span>  <span class="n">path</span> <span class="n">metric</span> <span class="m">1</span>;
  <span class="c"># this lines allows debugging filter rules
</span>  <span class="c"># filtered routes can be looked up in birdc using the "show route filtered" command
</span>  <span class="n">import</span> <span class="n">keep</span> <span class="n">filtered</span>;
  <span class="n">import</span> <span class="n">filter</span> {
    <span class="c"># accept every subnet, except our own advertised subnet
</span>    <span class="c"># filtering is important, because some guys try to advertise routes like 0.0.0.0
</span>    <span class="n">if</span> <span class="n">is_valid_network</span>() &amp;&amp; !<span class="n">is_self_net</span>() <span class="n">then</span> {
      <span class="n">accept</span>;
    }
    <span class="n">reject</span>;
  };
  <span class="n">export</span> <span class="n">filter</span> {
    <span class="c"># here we export the whole net
</span>    <span class="n">if</span> <span class="n">is_valid_network</span>() &amp;&amp; <span class="n">source</span> ~ [<span class="n">RTS_STATIC</span>, <span class="n">RTS_BGP</span>] <span class="n">then</span> {
      <span class="n">accept</span>;
    }
    <span class="n">reject</span>;
  };
  <span class="n">import</span> <span class="n">limit</span> <span class="m">1000</span> <span class="n">action</span> <span class="n">block</span>;
  <span class="c">#source address OWNIP;
</span>};

<span class="n">include</span> <span class="s2">"/etc/bird/peers4/*"</span>;</code></pre>

<pre class="highlight"><code><span class="c">#/etc/bird/local4.conf
# should be a unique identifier, &lt;GATEWAY_IP&gt; is what most people use.
</span><span class="n">router</span> <span class="n">id</span> &lt;<span class="n">GATEWAY_IP</span>&gt;;

<span class="n">define</span> <span class="n">OWNAS</span> =  &lt;<span class="n">AS</span>&gt;;
<span class="n">define</span> <span class="n">OWNIP</span> = &lt;<span class="n">GATEWAY_IP</span>&gt;;

<span class="n">function</span> <span class="n">is_self_net</span>() {
  <span class="n">return</span> <span class="n">net</span> ~ [&lt;<span class="n">SUBNET</span>&gt;+];
}

<span class="n">function</span> <span class="n">is_valid_network</span>() {
  <span class="n">return</span> <span class="n">net</span> ~ [
    <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">0</span>/<span class="m">14</span>{<span class="m">21</span>,<span class="m">29</span>}, <span class="c"># dn42
</span>    <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">0</span>/<span class="m">24</span>{<span class="m">28</span>,<span class="m">32</span>}, <span class="c"># dn42 Anycast
</span>    <span class="m">172</span>.<span class="m">21</span>.<span class="m">0</span>.<span class="m">0</span>/<span class="m">24</span>{<span class="m">28</span>,<span class="m">32</span>}, <span class="c"># dn42 Anycast
</span>    <span class="m">172</span>.<span class="m">22</span>.<span class="m">0</span>.<span class="m">0</span>/<span class="m">24</span>{<span class="m">28</span>,<span class="m">32</span>}, <span class="c"># dn42 Anycast
</span>    <span class="m">172</span>.<span class="m">23</span>.<span class="m">0</span>.<span class="m">0</span>/<span class="m">24</span>{<span class="m">28</span>,<span class="m">32</span>}, <span class="c"># dn42 Anycast
</span>    <span class="m">172</span>.<span class="m">31</span>.<span class="m">0</span>.<span class="m">0</span>/<span class="m">16</span>+,       <span class="c"># ChaosVPN
</span>    <span class="m">10</span>.<span class="m">100</span>.<span class="m">0</span>.<span class="m">0</span>/<span class="m">14</span>+,       <span class="c"># ChaosVPN
</span>    <span class="m">10</span>.<span class="m">127</span>.<span class="m">0</span>.<span class="m">0</span>/<span class="m">16</span>{<span class="m">16</span>,<span class="m">32</span>}, <span class="c"># neonetwork
</span>    <span class="m">10</span>.<span class="m">0</span>.<span class="m">0</span>.<span class="m">0</span>/<span class="m">8</span>{<span class="m">15</span>,<span class="m">24</span>}     <span class="c"># Freifunk.net
</span>  ];
}</code></pre>

<pre class="highlight"><code><span class="c"># /etc/bird/peers4/&lt;PEER_NAME&gt;
</span><span class="n">protocol</span> <span class="n">bgp</span> &lt;<span class="n">PEER_NAME</span>&gt; <span class="n">from</span> <span class="n">dnpeers</span> {
  <span class="n">neighbor</span> &lt;<span class="n">PEERING_IP</span>&gt; <span class="n">as</span> &lt;<span class="n">PEER_AS</span>&gt;;
};</code></pre>

<h1><a class="anchor" id="bird-communities" href="#bird-communities"></a>Bird communities</h1>

<p>Communities can be used to prioritize traffic based on different flags, in DN42 we are using communities to prioritize based on latency, bandwidth and encryption. It is really easy to get started with communities and we encourage all of you to get the basic configuration done and to mark your peerings with the correct flags for improved routing.
More information can be found <a href="/howto/BGP-communities">here</a>.</p>

<h1><a class="anchor" id="route-origin-authorization" href="#route-origin-authorization"></a>Route Origin Authorization</h1>

<p>Route Origin Authorizations should be used in BIRD to authenticate prefix announcements. These check the originating AS and validate that they are allowed to advertise a prefix.</p>

<h2><a class="anchor" id="roa-tables" href="#roa-tables"></a>ROA Tables</h2>

<p>The ROA table can be generated from the registry directly or you can use pre-built ROA tables.</p>

<h3><a class="anchor" id="updating-roa-tables" href="#updating-roa-tables"></a>Updating ROA tables</h3>

<p>You can add cron entries to periodically update the tables:</p>

<pre class="highlight"><code>*/<span class="m">15</span> * * * * <span class="n">curl</span> -<span class="n">sfSLR</span> {-<span class="n">o</span>,-<span class="n">z</span>}/<span class="n">var</span>/<span class="n">lib</span>/<span class="n">bird</span>/<span class="n">bird6_roa_dn42</span>.<span class="n">conf</span> <span class="n">https</span>://<span class="n">dn42</span>.<span class="n">burble</span>.<span class="n">com</span>/<span class="n">roa</span>/<span class="n">dn42_roa_bird1_6</span>.<span class="n">conf</span> &amp;&amp; <span class="n">chronic</span> <span class="n">birdc6</span> <span class="n">configure</span>
*/<span class="m">15</span> * * * * <span class="n">curl</span> -<span class="n">sfSLR</span> {-<span class="n">o</span>,-<span class="n">z</span>}/<span class="n">var</span>/<span class="n">lib</span>/<span class="n">bird</span>/<span class="n">bird_roa_dn42</span>.<span class="n">conf</span> <span class="n">https</span>://<span class="n">dn42</span>.<span class="n">burble</span>.<span class="n">com</span>/<span class="n">roa</span>/<span class="n">dn42_roa_bird1_4</span>.<span class="n">conf</span> &amp;&amp; <span class="n">chronic</span> <span class="n">birdc</span> <span class="n">configure</span></code></pre>

<p>Debian version:</p>

<pre class="highlight"><code>*/<span class="m">15</span> * * * * <span class="n">curl</span> -<span class="n">sfSLR</span> -<span class="n">o</span>/<span class="n">var</span>/<span class="n">lib</span>/<span class="n">bird</span>/<span class="n">bird6_roa_dn42</span>.<span class="n">conf</span> -<span class="n">z</span>/<span class="n">var</span>/<span class="n">lib</span>/<span class="n">bird</span>/<span class="n">bird6_roa_dn42</span>.<span class="n">conf</span> <span class="n">https</span>://<span class="n">dn42</span>.<span class="n">burble</span>.<span class="n">com</span>/<span class="n">roa</span>/<span class="n">dn42_roa_bird1_6</span>.<span class="n">conf</span> &amp;&amp; /<span class="n">usr</span>/<span class="n">sbin</span>/<span class="n">birdc6</span> <span class="n">configure</span>
*/<span class="m">15</span> * * * * <span class="n">curl</span> -<span class="n">sfSLR</span> -<span class="n">o</span>/<span class="n">var</span>/<span class="n">lib</span>/<span class="n">bird</span>/<span class="n">bird_roa_dn42</span>.<span class="n">conf</span> -<span class="n">z</span>/<span class="n">var</span>/<span class="n">lib</span>/<span class="n">bird</span>/<span class="n">bird_roa_dn42</span>.<span class="n">conf</span> <span class="n">https</span>://<span class="n">dn42</span>.<span class="n">burble</span>.<span class="n">com</span>/<span class="n">roa</span>/<span class="n">dn42_roa_bird1_4</span>.<span class="n">conf</span> &amp;&amp; /<span class="n">usr</span>/<span class="n">sbin</span>/<span class="n">birdc</span> <span class="n">configure</span></code></pre>

<p>then create the directory to make sure curls can save the files:</p>

<pre class="highlight"><code><span class="nb">mkdir</span> <span class="nt">-p</span> /var/lib/bird/</code></pre>

<p>Or use a systemd timer: (check the commands before copy-pasting)</p>

<pre class="highlight"><code><span class="c"># /etc/systemd/system/dn42-roa.service
</span>[<span class="n">Unit</span>]
<span class="n">Description</span>=<span class="n">Update</span> <span class="n">DN42</span> <span class="n">ROA</span>

[<span class="n">Service</span>]
<span class="n">Type</span>=<span class="n">oneshot</span>
<span class="n">ExecStart</span>=<span class="n">curl</span> -<span class="n">sfSLR</span> -<span class="n">o</span> /<span class="n">etc</span>/<span class="n">bird</span>/<span class="n">roa_dn42</span>.<span class="n">conf</span> -<span class="n">z</span> /<span class="n">etc</span>/<span class="n">bird</span>/<span class="n">roa_dn42</span>.<span class="n">conf</span> <span class="n">https</span>://<span class="n">dn42</span>.<span class="n">burble</span>.<span class="n">com</span>/<span class="n">roa</span>/<span class="n">dn42_roa_bird2_4</span>.<span class="n">conf</span>
<span class="n">ExecStart</span>=<span class="n">curl</span> -<span class="n">sfSLR</span> -<span class="n">o</span> /<span class="n">etc</span>/<span class="n">bird</span>/<span class="n">roa_dn42_v6</span>.<span class="n">conf</span> -<span class="n">z</span> /<span class="n">etc</span>/<span class="n">bird</span>/<span class="n">roa_dn42_v6</span>.<span class="n">conf</span> <span class="n">https</span>://<span class="n">dn42</span>.<span class="n">burble</span>.<span class="n">com</span>/<span class="n">roa</span>/<span class="n">dn42_roa_bird2_6</span>.<span class="n">conf</span>
<span class="n">ExecStart</span>=<span class="n">birdc</span> <span class="n">configure</span></code></pre>

<pre class="highlight"><code><span class="c"># /etc/systemd/system/dn42-roa.timer
</span>[<span class="n">Unit</span>]
<span class="n">Description</span>=<span class="n">Update</span> <span class="n">DN42</span> <span class="n">ROA</span> <span class="n">periodically</span>

[<span class="n">Timer</span>]
<span class="n">OnBootSec</span>=<span class="m">2</span><span class="n">m</span>
<span class="n">OnUnitActiveSec</span>=<span class="m">15</span><span class="n">m</span>
<span class="n">AccuracySec</span>=<span class="m">1</span><span class="n">m</span>

[<span class="n">Install</span>]
<span class="n">WantedBy</span>=<span class="n">timers</span>.<span class="n">target</span></code></pre>

<p>then enable and start the timer with <code>systemctl enable --now dn42-roa.timer</code>.</p>

<p>More advanced script with error checking:
</p><pre class="highlight"><code><span class="c">#!/bin/bash</span>
<span class="nv">roa4URL</span><span class="o">=</span><span class="s2">""</span>
<span class="nv">roa6URL</span><span class="o">=</span><span class="s2">""</span>

<span class="nv">roa4FILE</span><span class="o">=</span><span class="s2">"/etc/bird/roa/roa_dn42.conf"</span>
<span class="nv">roa6FILE</span><span class="o">=</span><span class="s2">"/etc/bird/roa/roa_dn42_v6.conf"</span>

<span class="nb">cp</span> <span class="s2">"</span><span class="k">${</span><span class="nv">roa4FILE</span><span class="k">}</span><span class="s2">"</span> <span class="s2">"</span><span class="k">${</span><span class="nv">roa4FILE</span><span class="k">}</span><span class="s2">.old"</span>
<span class="nb">cp</span> <span class="s2">"</span><span class="k">${</span><span class="nv">roa6FILE</span><span class="k">}</span><span class="s2">"</span> <span class="s2">"</span><span class="k">${</span><span class="nv">roa6FILE</span><span class="k">}</span><span class="s2">.old"</span>

<span class="k">if </span>curl <span class="nt">-f</span> <span class="nt">-o</span> <span class="s2">"</span><span class="k">${</span><span class="nv">roa4FILE</span><span class="k">}</span><span class="s2">.new"</span> <span class="s2">"</span><span class="k">${</span><span class="nv">roa4URL</span><span class="k">}</span><span class="s2">;"</span> <span class="p">;</span><span class="k">then
    </span><span class="nb">mv</span> <span class="s2">"</span><span class="k">${</span><span class="nv">roa4FILE</span><span class="k">}</span><span class="s2">.new"</span> <span class="s2">"</span><span class="k">${</span><span class="nv">roa4FILE</span><span class="k">}</span><span class="s2">"</span>
<span class="k">fi

if </span>curl <span class="nt">-f</span> <span class="nt">-o</span> <span class="s2">"</span><span class="k">${</span><span class="nv">roa6FILE</span><span class="k">}</span><span class="s2">.new"</span> <span class="s2">"</span><span class="k">${</span><span class="nv">roa6URL</span><span class="k">}</span><span class="s2">;"</span> <span class="p">;</span><span class="k">then
    </span><span class="nb">mv</span> <span class="s2">"</span><span class="k">${</span><span class="nv">roa6FILE</span><span class="k">}</span><span class="s2">.new"</span> <span class="s2">"</span><span class="k">${</span><span class="nv">roa6FILE</span><span class="k">}</span><span class="s2">"</span>
<span class="k">fi

if </span>birdc configure <span class="p">;</span> <span class="k">then
    </span><span class="nb">rm</span> <span class="s2">"</span><span class="k">${</span><span class="nv">roa4FILE</span><span class="k">}</span><span class="s2">.old"</span>
    <span class="nb">rm</span> <span class="s2">"</span><span class="k">${</span><span class="nv">roa6FILE</span><span class="k">}</span><span class="s2">.old"</span>
<span class="k">else
    </span><span class="nb">mv</span> <span class="s2">"</span><span class="k">${</span><span class="nv">roa4FILE</span><span class="k">}</span><span class="s2">.old"</span> <span class="s2">"</span><span class="k">${</span><span class="nv">roa4FILE</span><span class="k">}</span><span class="s2">"</span>
    <span class="nb">mv</span> <span class="s2">"</span><span class="k">${</span><span class="nv">roa6FILE</span><span class="k">}</span><span class="s2">.old"</span> <span class="s2">"</span><span class="k">${</span><span class="nv">roa6FILE</span><span class="k">}</span><span class="s2">"</span>
<span class="k">fi</span></code></pre>

<h3><a class="anchor" id="use-rpki-roa-in-bird2" href="#use-rpki-roa-in-bird2"></a>Use RPKI ROA in bird2</h3>

<ul>
  <li>Download  gortr</li>
</ul>

<p><a href="https://github.com/cloudflare/gortr/releases">https://github.com/cloudflare/gortr/releases</a></p>

<ul>
  <li>Run gortr.</li>
</ul>

<pre class="highlight"><code>./gortr <span class="nt">-verify</span><span class="o">=</span><span class="nb">false</span> <span class="nt">-checktime</span><span class="o">=</span><span class="nb">false</span> <span class="nt">-cache</span><span class="o">=</span>https://dn42.burble.com/roa/dn42_roa_46.json</code></pre>

<ul>
  <li>Run with docker</li>
</ul>

<pre class="highlight"><code>docker pull cloudflare/gortr</code></pre>

<pre class="highlight"><code>docker run <span class="nt">--name</span> dn42rpki <span class="nt">-p</span> 8282:8282 <span class="nt">--restart</span><span class="o">=</span>always <span class="nt">-d</span> cloudflare/gortr <span class="nt">-verify</span><span class="o">=</span><span class="nb">false</span> <span class="nt">-checktime</span><span class="o">=</span><span class="nb">false</span> <span class="nt">-cache</span><span class="o">=</span>https://dn42.burble.com/roa/dn42_roa_46.json</code></pre>

<ul>
  <li>Add this to your bird configure file,other ROA protocol must removed.</li>
</ul>

<pre class="highlight"><code><span class="n">protocol</span> <span class="n">rpki</span> <span class="n">rpki_dn42</span>{
  <span class="n">roa4</span> { <span class="n">table</span> <span class="n">dn42_roa</span>; };
  <span class="n">roa6</span> { <span class="n">table</span> <span class="n">dn42_roa_v6</span>; };

  <span class="n">remote</span> <span class="s2">"&lt;your rpki server ip or domain&gt;"</span> <span class="n">port</span> <span class="m">8282</span>;

  <span class="n">retry</span> <span class="n">keep</span> <span class="m">90</span>;
  <span class="n">refresh</span> <span class="n">keep</span> <span class="m">900</span>;
  <span class="n">expire</span> <span class="n">keep</span> <span class="m">172800</span>;
}</code></pre>

<h2><a class="anchor" id="filter-configuration" href="#filter-configuration"></a>Filter configuration</h2>

<p>In your import filter add the following to reject invalid routes:</p>

<pre class="highlight"><code><span class="n">if</span> (<span class="n">roa_check</span>(<span class="n">dn42_roa</span>, <span class="n">net</span>, <span class="n">bgp_path</span>.<span class="n">last</span>) != <span class="n">ROA_VALID</span>) <span class="n">then</span> {
   <span class="n">print</span> <span class="s2">"[dn42] ROA check failed for "</span>, <span class="n">net</span>, <span class="s2">" ASN "</span>, <span class="n">bgp_path</span>.<span class="n">last</span>;
   <span class="n">reject</span>;
}</code></pre>

<p>Also, define your ROA table with:</p>

<pre class="highlight"><code><span class="n">roa</span> <span class="n">table</span> <span class="n">dn42_roa</span> {
    <span class="n">include</span> <span class="s2">"/var/lib/bird/bird_roa_dn42.conf"</span>;
};</code></pre>

<p><strong>NOTE</strong>: Make sure you setup ROA checks for both bird and bird6 (for IPv6).</p>

<h1><a class="anchor" id="useful-bird-commmands" href="#useful-bird-commmands"></a>Useful bird commmands</h1>

<p>bird can be remote controlled via the <code>birdc</code> command. Here is a list of useful bird commands:</p>

<pre class="highlight"><code><span class="nv">$ </span>birdc
BIRD 1.4.5 ready.
bird&gt; configure <span class="c"># reload configuration</span>
Reading configuration from /etc/bird.conf
Reconfigured
bird&gt; show  ? <span class="c"># Completions work either by pressing tab or pressing '?'</span>
show bfd ...                                   Show information about BFD protocol
show interfaces                                Show network interfaces
show memory                                    Show memory usage
show ospf ...                                  Show information about OSPF protocol
show protocols <span class="o">[</span>&lt;protocol&gt; | <span class="s2">"&lt;pattern&gt;"</span><span class="o">]</span>      Show routing protocols
show roa ...                                   Show ROA table
show route ...                                 Show routing table
show static <span class="o">[</span>&lt;name&gt;]                           Show details of static protocol
show status                                    Show router status
show symbols ...                               Show all known symbolic names
bird&gt; show protocols <span class="c"># this command shows your peering status</span>
name     proto    table    state  since       info
device1  Device   master   up     07:20:25    
kernel1  Kernel   master   up     07:20:25    
chelnok  BGP      master   up     07:20:29    Established   
hax404   BGP      master   up     07:20:26    Established     
static1  Static   master   up     07:20:25
bird&gt; show protocols all chelnok <span class="c"># show verbose peering status for peering with chelnok</span>
bird&gt; show route <span class="k">for </span>172.22.141.181 <span class="c"># show possible routes to internal.dn42</span>
172.22.141.0/24    via 172.23.67.1 on tobee <span class="o">[</span>tobee 07:20:30] <span class="k">*</span> <span class="o">(</span>100<span class="o">)</span> <span class="o">[</span>AS64737i]
                   via 172.23.64.1 on chelnok <span class="o">[</span>chelnok 07:20:29] <span class="o">(</span>100<span class="o">)</span> <span class="o">[</span>AS64737i]
                   via 172.23.136.65 on hax404 <span class="o">[</span>hax404 07:20:26] <span class="o">(</span>100<span class="o">)</span> <span class="o">[</span>AS64737i]
bird&gt; show route filtered <span class="c"># shows routed filtered out by rules</span>
172.23.245.1/32    via 172.23.64.1 on chelnok <span class="o">[</span>chelnok 21:26:18] <span class="k">*</span> <span class="o">(</span>100<span class="o">)</span> <span class="o">[</span>AS76175i]
172.22.247.128/32  via 172.23.64.1 on chelnok <span class="o">[</span>chelnok 21:26:18] <span class="k">*</span> <span class="o">(</span>100<span class="o">)</span> <span class="o">[</span>AS76175i]
172.22.227.1/32    via 172.23.64.1 on chelnok <span class="o">[</span>chelnok 21:26:18] <span class="k">*</span> <span class="o">(</span>100<span class="o">)</span> <span class="o">[</span>AS76115i]
172.23.196.75/32   via 172.23.64.1 on chelnok <span class="o">[</span>chelnok 21:26:18] <span class="k">*</span> <span class="o">(</span>100<span class="o">)</span> <span class="o">[</span>AS76115i]
172.22.41.241/32   via 172.23.64.1 on chelnok <span class="o">[</span>chelnok 21:26:18] <span class="k">*</span> <span class="o">(</span>100<span class="o">)</span> <span class="o">[</span>AS76115i]
172.22.249.4/30    via 172.23.64.1 on chelnok <span class="o">[</span>chelnok 21:26:18] <span class="k">*</span> <span class="o">(</span>100<span class="o">)</span> <span class="o">[</span>AS4242420002i]
172.22.255.133/32  via 172.23.64.1 on chelnok <span class="o">[</span>chelnok 21:26:18] <span class="k">*</span> <span class="o">(</span>100<span class="o">)</span> <span class="o">[</span>AS64654i]
bird&gt; show route protocol &lt;somepeer&gt; <span class="c"># shows the route they export to you</span>
bird&gt; show route <span class="nb">export</span> &lt;somepeer&gt; <span class="c"># shows the route you export to someone</span>
...</code></pre>

<h1><a class="anchor" id="external-links" href="#external-links"></a>External Links</h1>
<ul>
  <li>detailed bird configuration from Mic92: <a href="https://github.com/Mic92/bird-dn42">https://github.com/Mic92/bird-dn42</a>
</li>
  <li>more bird commands: <a href="https://bird.network.cz/?get_doc&amp;v=20&amp;f=bird-4.html">https://bird.network.cz/?get_doc&amp;v=20&amp;f=bird-4.html</a>
</li>
</ul>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/DNS" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">RPKI</a></li>
      <li><a href="/services/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
      <li><a href="/services/Registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
      <li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
    </ul>
  </li>
  <li>Historical
    <ul>
      <li><a href="/historical/Bird" rel="nofollow">Bird 1</a></li>
      <li><a href="/historical/Quagga" rel="nofollow">Quagga</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://hedgedoc.dn42.eu" rel="nofollow">HedgeDoc</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>
</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="historical/Bird.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/historical/Bird.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
