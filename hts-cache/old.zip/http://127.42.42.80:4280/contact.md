<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'contact.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>contact</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>contact</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/contact.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/contact.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    contact
  </h1>
	<div class="breadcrumb"></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="contact" href="#contact"></a>Contact</h1>

<p>Members of the dn42 network mostly communicate via IRC or the mailing list.</p>

<p>If you would like to contact an individual network operator, you will find contact information in the <a href="/services/Whois">Whois</a> registry.</p>

<h2><a class="anchor" id="mailing-list" href="#mailing-list"></a>Mailing list</h2>

<ul>
  <li>is at: dn42 /at/ groups.io,</li>
  <li>send a mail to dn42+subscribe /at/ groups.io to subscribe</li>
  <li>has <a href="https://groups.io/g/dn42">archive</a>
</li>
</ul>

<h2><a class="anchor" id="irc" href="#irc"></a>IRC</h2>

<p>See <a href="/services/IRC">IRC</a>.</p>

<h2><a class="anchor" id="telegram" href="#telegram"></a>Telegram</h2>

<ul>
  <li><a href="https://t.me/dn42dn42">english only, maintained by SUNNET-MNT</a></li>
  <li><a href="https://t.me/Dn42Chat">bilingual, Chinese&amp;English, maintained by BILL-MNT</a></li>
  <li><a href="https://t.me/dn42es">spanish, maintained by BUZZ-MNT</a></li>
  <li><a href="https://t.me/dn42dev">bilingual, Russia&amp;English, maintained by NAOMU-MNT</a></li>
</ul>

<h2><a class="anchor" id="matrix" href="#matrix"></a>Matrix</h2>

<ul>
  <li><a href="https://matrix.to/#/#dn42:hackint.org">sync with hackint IRC</a></li>
  <li><a href="https://matrix.to/#/#dn424242:matrix.org">bilingual, Chinese&amp;English, maintained by SESS-MNT</a></li>
</ul>

<h2><a class="anchor" id="web" href="#web"></a>Web</h2>

<p>There are currently multiple decentralized mirrors and domains for the DN42 wiki available:</p>

<ul>
  <li>
<a href="https://wiki.dn42.us">dn42.us</a> maintained by xuu</li>
  <li>
<a href="https://dn42.dev">dn42.dev</a> / <a href="https://wiki.burble.dn42">wiki.burble.dn42</a> maintained by Burble</li>
  <li>
<a href="https://dn42.eu">dn42.eu</a> maintained by Nurtic-vibe</li>
  <li>
<a href="https://dn42.pp.ua">dn42.pp.ua</a> maintained by Androw</li>
  <li>
<a href="https://dn42.wiki">dn42.wiki</a> maintained by DannyAAM</li>
  <li><a href="https://dn42.de">dn42.de (ipv6 only)</a></li>
  <li>
<a href="https://dn42.cc">dn42.cc</a> maintained by LARE (uses <a href="https://git.dn42.dev/wiki/wiki-ng">wiki-ng</a>)</li>
  <li>
<a href="https://dn42.jp">dn42.jp</a> maintained by IEDON (uses <a href="https://git.dn42.dev/wiki/dn42-wiki-go">dn42-wiki-go</a>)</li>
</ul>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="contact.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/contact.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
