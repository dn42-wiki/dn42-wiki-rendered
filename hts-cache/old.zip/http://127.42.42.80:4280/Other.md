<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'Other.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Other</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Other</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/Other.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/Other.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Other
  </h1>
	<div class="breadcrumb"></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="other-dark-overlay-networks" href="#other-dark-overlay-networks"></a>Other Dark / Overlay Networks</h1>

<h2><a class="anchor" id="other-lists" href="#other-lists"></a>Other Lists</h2>

<ul>
  <li><a href="https://en.wikipedia.org/wiki/List_of_wireless_community_networks_by_region">https://en.wikipedia.org/wiki/List_of_wireless_community_networks_by_region</a></li>
  <li><a href="https://en.wikipedia.org/wiki/Darknet_(networking)">https://en.wikipedia.org/wiki/Darknet_(networking)</a></li>
  <li><a href="https://en.wikipedia.org/wiki/Category:Anonymity_networks">https://en.wikipedia.org/wiki/Category:Anonymity_networks</a></li>
  <li><a href="http://anonet2.biz/List%20of%20Anonymous%20Networks">http://anonet2.biz/List%20of%20Anonymous%20Networks</a></li>
  <li><a href="https://en.wikipedia.org/wiki/Anonymous_P2P">https://en.wikipedia.org/wiki/Anonymous_P2P</a></li>
</ul>

<h2><a class="anchor" id="anonymity" href="#anonymity"></a>Anonymity</h2>

<ul>
  <li>
<strong>Tor</strong> (The onion router) is an anonymity network that also features a darknet - its "hidden services". It's the most popular instance of a darknet.</li>
</ul>

<h2><a class="anchor" id="p2p-f2f-warez" href="#p2p-f2f-warez"></a>P2P / F2F / Warez</h2>

<ul>
  <li>
<strong>I2P</strong> (Invisible Internet Project) is another overlay network that features a darknet whose sites are called "Eepsites".</li>
  <li>
<strong>Freenet</strong> is a popular darknet (friend-to-friend) by default; since version 0.7 it can run as a "opennet" (connecting to untrusted users).</li>
  <li>
<strong>yggdrasil</strong> is a new experimental compact routing scheme. It is designed to be a future-proof and decentralised alternative to the structured routing protocols commonly used today on the Internet, as well as an enabling technology for future large-scale mesh networks.</li>
  <li>
<strong>RetroShare</strong> can be run as a darknet (friend-to-friend) by default to perform anonymous file transfers if DHT and Discovery features are disabled.</li>
  <li>
<strong>GNUnet</strong> is a darknet if the "F2F (network) topology" option is enabled.</li>
  <li>
<strong>Syndie</strong> is software used to publish distributed forums over the anonymous networks of I2P, Tor and Freenet.</li>
  <li>OneSwarm can be run as a darknet for friend-to-friend file-sharing.</li>
  <li>
<strong>Tribler</strong> can be run as a darknet for file-sharing.</li>
</ul>

<h2><a class="anchor" id="bgp-routed-ip" href="#bgp-routed-ip"></a>BGP Routed IP</h2>

<ul>
  <li><strong>DN42</strong></li>
  <li><strong>ChaosVPN</strong></li>
  <li><strong>Anonet</strong></li>
  <li><strong>router.city</strong></li>
</ul>

<h2><a class="anchor" id="wireless" href="#wireless"></a>Wireless</h2>

<ul>
  <li><strong>Freifunk</strong></li>
</ul>

<h2><a class="anchor" id="unknown" href="#unknown"></a>Unknown</h2>

<ul>
  <li><strong>Netsukuku</strong></li>
  <li><strong>Agora</strong></li>
</ul>

<h2><a class="anchor" id="babel" href="#babel"></a>Babel</h2>

<ul>
  <li><strong>CRXN</strong></li>
</ul>

<h2><a class="anchor" id="anonet" href="#anonet"></a>AnoNet</h2>
<p>A wiki page dedicated to the AnoNet Network: <a href="http://wiki.qontrol.nl/Anonet">http://wiki.qontrol.nl/Anonet</a></p>

<h2><a class="anchor" id="tinc-clouds" href="#tinc-clouds"></a>TINC Clouds</h2>

<blockquote>
  <p>This information is a caryover from the original dn42 wiki. most is unsubstantiated and probably invalid now. Included here for historical reasons. Keys and other parameters can be found in the registry under <code>tinc-key</code> and <code>tinc-keyset</code></p>
</blockquote>

<pre class="highlight"><code>first tinc cloud 
================

ipv4: 172.22.255.176/28
ipv6: fd04:de02:7af9::/64 

IP              IPv6                    User         Host         ASN
--------------  ----------------------  ---------    -----------  -----
172.22.255.177                          downhill     geekhabitat  64655
172.22.255.178  fd04:de02:7af9::178/64  Martin89     martin89     64713
172.22.255.179  fd04:de02:7af9::179/64  welterde     hex          64738
172.22.255.180  fd04:de02:7af9::180/64  Vutral       vger         64787
172.22.255.181  fd04:de02:7af9::181/64         --- free ---
172.22.255.182  fd04:de02:7af9::182/64  mnl          aphrodite    64758
172.22.255.183                          UFO          ufoathome    64766
172.22.255.184  fd04:de02:7af9::184/64  ariel        shack        64714
172.22.255.185                          lowkey       cerberus?    65023
172.22.255.186  fd04:de02:7af9::186/64  schrodinger  crux         64664
172.22.255.187  fd04:de02:7af9::187/64  deelkar      deelkar      64827
172.22.255.188                          nospoonuser  nospoonuser  64756
172.22.255.189  fd04:de02:7af9::189/64         --- free ---
172.22.255.190  fd04:de02:7af9::190/64  liameph      meph?        64790
172.22.255.194  fd04:de02:7af9::194/64  merlin       noc          64831
172.22.255.195  fd04:de02:7af9::195/64  stephanj     stephanj     64674
--------------  ----------------------  ---------    -----------  -----

IPv6                                     User      Host      ASN
---------------------------------------  --------  --------  -----
fd04:de02:7af9:0000:dead:0000:fca0:1/64  dodger78  dodger78  64672
---------------------------------------  --------  --------  -----

second tinc cloud 
=================
(opened because the ipv4 range above is full)

ipv4: 172.22.255.160/28
ipv6: fd04:de02:7af9::/64

IP              IPv6                 User         Host         ASN
--------------  -------------------  ---------    -----------  -----
172.22.255.161  fd04:de02:7af9::161  uves         spline       64733
172.22.255.162  fd04:de02:7af9::162  petrus       beta         64751
--------------  -------------------  ---------    -----------  -----</code></pre>


	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/Policies" rel="nofollow">Policies</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
      <li><a href="/Links" rel="nofollow">Links</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
      <li><a href="/howto/GeoFeed" rel="nofollow">GeoFeed</a></li>
      <li><a href="/howto/Telephony-Asterisk" rel="nofollow">Telephony (Asterisk)</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/dns/Overview" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">ROA + RPKI</a></li>
      <li><a href="/services/exchanges/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Pingables" rel="nofollow">Pingables</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/ca/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="Other.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/Other.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
