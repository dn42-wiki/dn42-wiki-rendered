<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'Links.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Links</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Links</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/Links.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/Links.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Links
  </h1>
	<div class="breadcrumb"></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <p>This is a small list of links. Some of them are informative, some educational, some funny and some entertaining. You know a link you want to share? Then edit the page and add it!</p>

<h2><a class="anchor" id="other-networks" href="#other-networks"></a>Other Networks</h2>
<p><a href="/Other">List of other Overlay Networks</a></p>

<h2><a class="anchor" id="books" href="#books"></a>Books</h2>
<ul>
  <li><a href="https://github.com/gsahinpi/acm361/raw/master/Computer%20Networks%20-%20A%20Tanenbaum%20-%205th%20edition.pdf">Computer Networks -Tanenbaum</a></li>
</ul>

<h2><a class="anchor" id="tutorials" href="#tutorials"></a>Tutorials</h2>
<ul>
  <li><a href="https://jlu5.com/blog/dn42-multiple-servers-ibgp-igps">Multiple servers on dn42: iBGP and IGPs</a></li>
  <li><a href="https://github.com/knorrie/network-examples">Network Examples</a></li>
  <li><a href="https://bgpfilterguide.nlnog.net/">BGP Filter Guides</a></li>
  <li><a href="https://www.bgp4all.com/pfs/workshops/start">BGP4All workshops</a></li>
</ul>

<h2><a class="anchor" id="examples-and-blogs" href="#examples-and-blogs"></a>Examples and Blogs</h2>
<ul>
  <li><a href="https://lantian.pub/en/page/dn42/">lantian's blog</a></li>
  <li><a href="https://github.com/jlu5/ansible-dn42">jlu5's dn42 config</a></li>
</ul>

<h2><a class="anchor" id="videos" href="#videos"></a>Videos</h2>
<h3><a class="anchor" id="english" href="#english"></a>English</h3>
<ul>
  <li><a href="https://www.youtube.com/watch?v=oKyhrbG3sjI">BGP Tutorial Massimiliano Stucchi, Tom Smyth </a></li>
  <li>
<a href="https://media.ccc.de/v/denog13-12617-local-pref-considered-evil">local-pref considered evil </a>
    <h3><a class="anchor" id="german" href="#german"></a>German</h3>
  </li>
  <li><a href="https://media.ccc.de/v/routingdays16-18-network_ip_basics">Network / IP Basics OSI-Modell und Protokolle im Überblick</a></li>
  <li><a href="https://media.ccc.de/v/routingdays16-14-ibgp_fundamentals">iBGP Fundamentals BGP im internen Netzwerk.</a></li>
  <li><a href="https://media.ccc.de/v/routingdays16-10-e_bgp_fundamentals">(e)BGP Fundamentals Route selection, AS path, prefix, metrics and state machine</a></li>
</ul>

<h2><a class="anchor" id="funny" href="#funny"></a>Funny</h2>
<ul>
  <li><a href="https://ipv6bingo.com/">ipv6bingo</a></li>
</ul>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="Links.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/Links.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
