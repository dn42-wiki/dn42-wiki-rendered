<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'FAQ.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>FAQ</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>FAQ</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/FAQ.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/FAQ.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    FAQ
  </h1>
	<div class="breadcrumb"></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h2><a class="anchor" id="how-do-i-connect-to-dn42" href="#how-do-i-connect-to-dn42"></a>How do I connect to DN42?</h2>

<p>We have a <a href="/howto/Getting-Started">page</a> for that!</p>

<h3><a class="anchor" id="what-bgp-daemon-should-i-use" href="#what-bgp-daemon-should-i-use"></a>What BGP daemon should I use?</h3>

<p>This is really up to you: that's the magic of open protocols.</p>

<p>Many users run Bird or FRRouting in a VPS, but there is a variety of BGP implementations in use across the network and some networks even run hardware routers or experimental software. DN42 is a great place to try out and get familiar with your implementation of choice in a live network.</p>

<h3><a class="anchor" id="can-i-connect-to-dn42-from-home-through-my-isp" href="#can-i-connect-to-dn42-from-home-through-my-isp"></a>Can I connect to DN42 from home through my ISP?</h3>

<p>Sure. As long as you have a 24/7 connection, can configure VPN tunnels and run BGP then you can connect to DN42. Do let your peers know if you have a dynamic IP address and you may also want to consider preventing transit traffic through your network if you have a relatively slow connection.</p>

<p>Many users do use a virtual private server (VPS) for connecting to DN42. A VPS is a relatively cheap option that  is always on and which (typically) provides a faster, more stable connection than your home. VPS have another advantage that if you mess something up, you won't break your home access to the internet.</p>

<h3><a class="anchor" id="does-the-registry-use-monotone-or-git" href="#does-the-registry-use-monotone-or-git"></a>Does the registry use monotone or git?</h3>

<p>The DN42 registry used to be maintained in monotone, but was moved to git following resource and performance
issues. There may still be references back to monotone in some of the documentation, but the registry location is now:</p>

<p><a href="https://git.dn42.dev/dn42/registry">https://git.dn42.dev/dn42/registry</a></p>

<h3><a class="anchor" id="can-i-use-windows-to-clone-and-update-the-registry" href="#can-i-use-windows-to-clone-and-update-the-registry"></a>Can I use Windows to clone and update the registry ?</h3>

<p>No. The registry includes IPv6 resources but NTFS does not support having a <code>:</code> in filenames.</p>

<p>A simple workaround is to use a non-Windows VM to do your changes, or use the <a href="https://docs.microsoft.com/en-us/windows/wsl/install-win10">Windows Subsystem for Linux</a> when working with the registry.</p>

<h3><a class="anchor" id="can-i-reuse-my-public-as-number-ipv4-ipv6" href="#can-i-reuse-my-public-as-number-ipv4-ipv6"></a>Can I reuse my public AS number/IPv4/IPv6?</h3>

<p>AS number: Yes, see AS206633/AS205532 for example</p>

<p>IP: Probably no. Globally routable IPs are not supported in DN42; whilst in theory they could be announced, there are filters in place used by almost all networks which prevent that, and some networks will filter traffic to the private DN42 range only to enhance security. It's literally impossible to convince the whole of dn42 to lift those filters.</p>

<p>If you'd like to explore dn42 without too many changes to your network, you could announce both IPv6 GUA and ULA addresses to your network. IPv6 has a specified source address selection process which means that a host will always use an ULA address to talk to ULA destinations and a GUA address to talk to GUA destination.</p>

<h3><a class="anchor" id="what-about-ipv6-in-dn42" href="#what-about-ipv6-in-dn42"></a>What about IPv6 in dn42?</h3>

<p>DN42 supports IPv6 and some users do run IPv6 only networks. DN42 uses the "Unique Local Address" range (ULA, <em>fd00::/8</em>) defined by <a href="https://tools.ietf.org/html/rfc4193">RFC 4193</a>.</p>

<h3><a class="anchor" id="why-are-you-using-asn-in-the-76100-76199-range" href="#why-are-you-using-asn-in-the-76100-76199-range"></a>Why are you using ASN in the 76100-76199 range?</h3>

<p>DN42 now uses ASNs in the 4242420000-4242429999 range, but the 76100-76199 range was used historically, and there are still a very small number of networks using legacy ASNs that have not migrated.</p>

<p>Previously, DN42 has used a two other ASN ranges:</p>

<p>We used to assign ASN in the 64600-64855 range, where you would get ASN 64600+X if you had 172.22.X.0/24. Once the address range was extended to include additional blocks, this process was obsoleted. Another issue with the private ASN range 64512-65534 was that other projects are also using it (for instance, Freifunk, Anonet, etc), which can lead to conflicts.</p>

<p>Prior to using ASNs in the new private ASN range 4200000000-4294967294 (<a href="http://tools.ietf.org/html/rfc6996">RFC6996</a>) Some ASNs were allocated from the <a href="http://www.iana.org/assignments/as-numbers/as-numbers.xhtml">ASN reserved block</a> in the 76100-76199 range.</p>

<h3><a class="anchor" id="why-can-t-my-docker-containers-connect-to-other-dn42-hosts" href="#why-can-t-my-docker-containers-connect-to-other-dn42-hosts"></a>Why can't my Docker containers connect to other DN42 hosts?</h3>

<p>By default, Docker overlaps with the entire DN42 range and then some. (172.16.0.0/12 == 172.16.0.0 - 172.31.255.255)</p>

<p>In order to prevent this, you need to supply a different subnet range to the Docker daemon. This can be done by creating or updating <code>/etc/docker/daemon.json</code> with something along the following (this will use 192.168.128.0/18 == 192.168.128.0 - 192.168.191.255)
</p><pre class="highlight"><code><span class="p">{</span><span class="w">
  </span><span class="nl">"default-address-pools"</span><span class="w"> </span><span class="p">:</span><span class="w"> </span><span class="p">[</span><span class="w">
    </span><span class="p">{</span><span class="w">
      </span><span class="nl">"base"</span><span class="w"> </span><span class="p">:</span><span class="w"> </span><span class="s2">"192.168.128.0/18"</span><span class="p">,</span><span class="w">
      </span><span class="nl">"size"</span><span class="w"> </span><span class="p">:</span><span class="w"> </span><span class="mi">24</span><span class="w">
    </span><span class="p">}</span><span class="w">
  </span><span class="p">]</span><span class="w">
</span><span class="p">}</span></code></pre>
Note, I (@bri / AS4242422825) have only tested this with Docker version 23.0.0, build e92dd87. But it should work with any current version. I don't know how Swarm etc. networking works, this might need additional tweaking for other versions. (Referenced from <a href="https://straz.to/2021-09-08-docker-address-pools/">https://straz.to/2021-09-08-docker-address-pools/</a> and <a href="https://docs.docker.com/network/bridge/">https://docs.docker.com/network/bridge/</a> — I used this to get my <code>thelounge</code> container to connect to hackint.dn42.)

<p>Another possible solution is to instead create a config-only docker network covering the DN42 range:
</p><pre class="highlight"><code>docker network create dn42 <span class="nt">--subnet</span> 172.20.0.0/14 <span class="nt">--config-only</span></code></pre>
This way Docker won't allocate addresses from this range for its <a href="https://github.com/docker/docs/issues/8663#issuecomment-956438889">default networks</a>.

<h3><a class="anchor" id="can-i-update-the-wiki" href="#can-i-update-the-wiki"></a>Can I update the wiki?</h3>

<p>Yes, the wiki can be edited when browsing to <a href="https://wiki.dn42">wiki.dn42</a>.</p>

<p>After you have registered and set up SSH key authentication,
you can also clone and push to the
<a href="https://git.dn42.dev/wiki/wiki">git repository</a> directly.</p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/Policies" rel="nofollow">Policies</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
      <li><a href="/Links" rel="nofollow">Links</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
      <li><a href="/howto/GeoFeed" rel="nofollow">GeoFeed</a></li>
      <li><a href="/howto/Telephony-Asterisk" rel="nofollow">Telephony (Asterisk)</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/dns/Overview" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">ROA + RPKI</a></li>
      <li><a href="/services/exchanges/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Pingables" rel="nofollow">Pingables</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/ca/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>, <a href="https://iedon.net/post/24" rel="nofollow">IEDON-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>, <a href="https://dn42.jp/" rel="nofollow">dn42.jp</a> (wiki-go)</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="FAQ.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/FAQ.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
