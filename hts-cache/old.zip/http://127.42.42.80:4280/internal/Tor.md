<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'internal/Tor.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Tor</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Tor</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/internal/Tor.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/internal/Tor.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Tor
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/internal/">internal</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="tor-network" href="#tor-network"></a>Tor network</h1>

<p><a href="https://torproject.org/">Tor</a> is free software and an open network that helps you defend against traffic analysis, a form of network surveillance that threatens personal freedom and privacy, confidential business activities and relationships, and state security.</p>

<h2><a class="anchor" id="bridges" href="#bridges"></a>Bridges</h2>

<p>Tor bridges allow for the Tor client to connect to a specific IP address and validate the fingerprint to permit safe connections into the Tor network for networks that do not directly access the public Internet, for example hosts that only have dn42 connections. The following bridges are currently available for use:</p>

<table>
  <thead>
    <tr>
      <th>Name</th>
      <th>Bandwidth</th>
      <th>Contact</th>
      <th>Protocol</th>
      <th>Fingerprint</th>
      <th>Info</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>tor.napshome.dn42:8443</td>
      <td>3000KB/s+</td>
      <td>bjackson@napshome.net</td>
      <td>obfs4</td>
      <td>71C924A772F69451FE97FE5A9025DEDDEF3DB664</td>
      <td> </td>
    </tr>
    <tr>
      <td>tor.napshome.dn42:9001</td>
      <td>3000KB/s+</td>
      <td>bjackson@napshome.net</td>
      <td>plain</td>
      <td>71C924A772F69451FE97FE5A9025DEDDEF3DB664</td>
      <td> </td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="anycast" href="#anycast"></a>Anycast</h2>

<p>There is an anycast address, 172.22.0.94 and fd42:d42:d42:9001::1 aka tor.dn42, that provides the following services:</p>

<table>
  <thead>
    <tr>
      <th>Service</th>
      <th>Port</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>ORPort</td>
      <td>9001/tcp</td>
    </tr>
    <tr>
      <td>DirPort</td>
      <td>9030/tcp</td>
    </tr>
    <tr>
      <td>SOCKS</td>
      <td>9050/tcp</td>
    </tr>
  </tbody>
</table>

<p>It should be noted that the host providing the SOCKS services is able to see <em>all</em> of the traffic going through it, you will not be protected for the portion of the journey between your machine and the Tor service. There is also no guarantee that the SOCKS proxy even provides a Tor service, it may simply just be a SOCKS proxy and you have no means by which to verify it.</p>

<p>There is also unfortunately no means by which to tell Tor to use a specific IP address as the entry point for a plain relay and while in theory you could connect to the ORPort and have a safe connection to Tor, there is no configuration option available for this.</p>

<h2><a class="anchor" id="socks-proxies" href="#socks-proxies"></a>SOCKS Proxies</h2>

<p><em>Note that the same warnings above also apply to the following proxies.</em></p>

<table>
  <thead>
    <tr>
      <th>Proxy URL</th>
      <th>Bandwidth</th>
      <th>Contact</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>socks5://tor.napshome.dn42:9050</td>
      <td>100+ Mbit/s</td>
      <td>Napsterbater</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="dns-proxy-tor-hidden-services" href="#dns-proxy-tor-hidden-services"></a>DNS Proxy - Tor Hidden Services</h2>

<p><em>Note that the same warnings above also apply to the following proxies.</em></p>

<p>See <a href="https://blog.benjojo.co.uk/post/tor-onions-to-v6-with-iptables-proxy">https://blog.benjojo.co.uk/post/tor-onions-to-v6-with-iptables-proxy</a> for more details</p>

<table>
  <thead>
    <tr>
      <th>Suffix Change</th>
      <th>Bandwidth</th>
      <th>Contact</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>.onion -&gt; .onion.dns42 (IPv6 Mapping)</td>
      <td>1000 Mbit/s</td>
      <td>TheQ</td>
    </tr>
    <tr>
      <td>.onion -&gt; .oni.dns42 (IPv6 Mapping)</td>
      <td>1000 Mbit/s</td>
      <td>TheQ</td>
    </tr>
  </tbody>
</table>


	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="internal/Tor.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/internal/Tor.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
