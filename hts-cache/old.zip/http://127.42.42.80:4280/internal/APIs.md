<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'internal/APIs.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>APIs</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>APIs</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/internal/APIs.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/internal/APIs.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    APIs
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/internal/">internal</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="application-programming-interfaces-apis" href="#application-programming-interfaces-apis"></a>Application Programming Interfaces (APIs)</h1>
<p>This page can be useful if you are trying to automate something or if you are trying to retrieve data programmatically.</p>

<h2><a class="anchor" id="what-is-my-ip" href="#what-is-my-ip"></a>What is my IP</h2>
<ul>
  <li>myip.dn42:
    <ul>
      <li>ipv4+ipv6: <a href="http://myip.dn42/">myip.dn42</a>
</li>
      <li>ipv4 only: <a href="http://v4.myip.dn42/">v4.myip.dn42</a> or <a href="http://172.20.0.81">172.20.0.81</a>
</li>
      <li>ipv6 only: <a href="http://v6.myip.dn42/">v6.myip.dn42</a> or <a href="http://[fd42:d42:d42:81::1]/">fd42:d42:d42:81::1</a>
</li>
      <li>API endpoints:
        <ul>
          <li>/raw: return your IP address as plain text</li>
          <li>/api: JSON with your IP plus the details of the server you reached (location, ASN, etc.)</li>
        </ul>
      </li>
    </ul>
  </li>
  <li>
<a href="https://myip.launchpadx.dn42">myip.launchpadx.dn42</a> with geolocation provided by <a href="https://github.com/Xe-iu/dn42-geoip">DN42-Geoip</a> and autonomous system info provided by <a href="https://github.com/rdp-studio/dn42-geoasn">DN42-GeoASN</a>
    <ul>
      <li>API endpoints:
        <ul>
          <li>Geolocation API
            <ul>
              <li>IPv4: v4.myip.launchpadx.dn42</li>
              <li>IPv6: v6.myip.launchpadx.dn42</li>
              <li>Dual-stack: api.myip.launchpadx.dn42</li>
              <li><a href="https://github.com/Xe-iu/dn42-geoip/blob/main/api/README.md">API documentation</a></li>
            </ul>
          </li>
          <li>ASN API
            <ul>
              <li>IPv4: asn4.myip.launchpadx.dn42</li>
              <li>IPv6: asn6.myip.launchpadx.dn42</li>
              <li>Dual-stack: asn.myip.launchpadx.dn42</li>
            </ul>
          </li>
        </ul>
      </li>
    </ul>
  </li>
  <li>
<a href="http://whatismyip.dn42">whatismyip.dn42</a>
    <ul>
      <li>API endpoints:
        <ul>
          <li>IPv4: <a href="http://ipv4.whatismyip.dn42:8080/ipinfo">http://ipv4.whatismyip.dn42:8080/ipinfo</a>
</li>
          <li>IPv6: <a href="http://ipv6.whatismyip.dn42:8080/ipinfo">http://ipv6.whatismyip.dn42:8080/ipinfo</a>
</li>
        </ul>
      </li>
    </ul>
  </li>
</ul>

<h2><a class="anchor" id="other-network-related" href="#other-network-related"></a>Other network-related</h2>

<ul>
  <li>Cloudflare-like cdn-cgi/trace: <a href="https://map.jerry.dn42/cdn-cgi/trace">map.jerry.dn42/cdn-cgi/trace</a>
</li>
</ul>

<h3><a class="anchor" id="map-dn42-api-services" href="#map-dn42-api-services"></a>Map.dn42 API Services</h3>

<p>Data refreshes whenever the collector provides a new MRT file, generally every 10-15 minutes.</p>

<table>
  <thead>
    <tr>
      <th>API</th>
      <th>URL</th>
      <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><code>/map</code></td>
      <td>
<a href="https://map.dn42/map">https://map.dn42/map</a> <br /> <a href="https://api.iedon.com/dn42/map">https://api.iedon.com/dn42/map</a>
</td>
      <td>Raw binary map data, <a href="https://iedon.net/post/4">See binary format</a>
</td>
    </tr>
    <tr>
      <td><code>/map?type=json</code></td>
      <td>
<a href="https://map.dn42/map?type=json">https://map.dn42/map?type=json</a> <br /> <a href="https://api.iedon.com/dn42/map?type=json">https://api.iedon.com/dn42/map?type=json</a>
</td>
      <td>Raw map data, in JSON</td>
    </tr>
    <tr>
      <td><code>/asn/{asn}</code></td>
      <td>
<a href="https://map.dn42/asn/4242422189">https://map.dn42/asn/4242422189</a> <br /> <a href="https://api.iedon.com/dn42/asn/4242422189">https://api.iedon.com/dn42/asn/4242422189</a>
</td>
      <td>Real-time node information from the map, including WHOIS data, in JSON</td>
    </tr>
    <tr>
      <td><code>/ranking</code></td>
      <td>
<a href="https://map.dn42/ranking">https://map.dn42/ranking</a> <br /> <a href="https://api.iedon.com/dn42/ranking">https://api.iedon.com/dn42/ranking</a>
</td>
      <td>DN42 Global Ranking, based on the map.dn42 index</td>
    </tr>
    <tr>
      <td><code>/myip/[raw｜api]</code></td>
      <td>
<a href="https://map.dn42/myip/">https://map.dn42/myip/</a> <br /> <a href="https://map.dn42/myip/api">https://map.dn42/myip/api</a> <br /> <a href="https://map.dn42/myip/raw">https://map.dn42/myip/raw</a>
</td>
      <td>What's My IP instance by map.dn42, including <code>netname</code> and <code>country</code> information if available</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="asn-authentication-solution" href="#asn-authentication-solution"></a>ASN Authentication Solution</h2>
<p>Authenticate your users by having them verify their ASN ownership with KIOUBIT-MNT using their registry-provided methods in an automated way. An example of this is the automatic peering system for the Kioubit Network.
<a href="https://dn42.g-load.eu/about/authentication-services/">Documentation</a></p>

<h2><a class="anchor" id="registry-rest-api" href="#registry-rest-api"></a>Registry REST API</h2>

<p><a href="https://git.burble.com/burble.dn42/dn42regsrv">dn42regsrv</a> is a REST API for the DN42 registry that provides a bridge between interactive applications and the registry.</p>

<p>As well as the main REST API to the DN42 registry, the server can also generate ROA tables and provides a small web application for exploring registry data.</p>

<p>A public instance of the API and associated explorer web app is available at the following URLs:</p>

<p><a href="https://explorer.burble.com/">https://explorer.burble.com/</a> (public internet link)<br />
<a href="https://explorer.burble.dn42/">https://explorer.burble.dn42/</a> (DN42 link)</p>

<p><a href="https://explorer.dn42.pebkac.gr/">https://explorer.dn42.pebkac.gr/</a> (public internet link)<br />
<a href="https://explorer.pebkac.dn42/">https://explorer.pebkac.dn42/</a> (DN42 link)</p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/Policies" rel="nofollow">Policies</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
      <li><a href="/Links" rel="nofollow">Links</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
      <li><a href="/howto/GeoFeed" rel="nofollow">GeoFeed</a></li>
      <li><a href="/howto/telephony42-Asterisk" rel="nofollow">Telephony42 (Asterisk)</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/dns/Overview" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">ROA + RPKI</a></li>
      <li><a href="/services/exchanges/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Pingables" rel="nofollow">Pingables</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/ca/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>, <a href="https://iedon.net/post/24" rel="nofollow">IEDON-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>, <a href="https://dn42.jp/" rel="nofollow">dn42.jp</a> (wiki-go)</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="internal/APIs.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/internal/APIs.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
