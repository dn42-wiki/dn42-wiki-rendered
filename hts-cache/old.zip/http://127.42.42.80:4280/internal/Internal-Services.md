<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-309be032396e783b13a47df58f389b7c8e11c2b2d42640560b874f677c25f6e5.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">

  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'internal/Internal-Services.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-f05401ee374f0c7f48fc2bc08e30b4f4db705861fd5895ed70998683b383bfb5.js" type="text/javascript"></script>
  

  <title>Internal-Services</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Internal-Services</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/internal/Internal-Services.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <a class="btn btn-sm" id="minibutton-home" href="/">
      Home
    </a>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/overview"
          id="minibutton-overview"
        >
          Overview
        </a>

        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/latest_changes"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </a>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          href="/gollum/history/internal/Internal-Services.md/"
          id="minibutton-history"
        >
          History
        </a>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Internal-Services
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/internal/">internal</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="internal-services" href="#internal-services"></a>Internal services</h1>

<p>You are asked to show some creativity in terms of network usage and content. ;)</p>

<h2><a class="anchor" id="search-engine" href="#search-engine"></a>Search engine</h2>

<p>There is a search engine at <a href="https://search.dn42">search.dn42</a> that can also be used to discover services and content. It attempts to index all sites on DN42.</p>

<h2><a class="anchor" id="certificate-authority" href="#certificate-authority"></a>Certificate Authority</h2>

<p>xuu is maintaining an <a href="/services/Certificate-Authority">certificate authority</a> for internal services.</p>

<p>n0emis maintains an <a href="https://acme.dn42">ACME server</a> (with accompanying CA), compatible with any LetsEncrypt client like Certbot, Dehydrated or Caddy.</p>

<h2><a class="anchor" id="network-related" href="#network-related"></a>Network-related</h2>

<ul>
<li>See <a href="/services/Looking-Glasses">Looking Glasses</a> for more network diagnostic tools</li>
<li>Realtime network map: <a href="http://map.dn42/">map.dn42</a> (DN42) or <a href="https://map42.0x7f.cc">map42.0x7f.cc</a>, <a href="https://map.kuu.moe">map.kuu.moe</a> (IANA) <em>(Note: This is a direct copy of nixnodes map with some fixes and new functions since original map is no longer get maintained. This map is currently using MRT dump from GRC as source. We will pull new dumps from GRC every 15 minutes.)</em>
</li>
<li>Network Information Service: <a href="http://info.nia.dn42">info.nia.dn42</a> (DN42) or <a href="https://bgp42.strexp.net">bgp42.strexp.net</a> (IANA). Main functions including <em>network information</em>, <em>network map (from map.dn42, require WebGL)</em>, <em>network ranking (based on centrality)</em>, <em>ROA alerting</em> and <em>path finder</em>.</li>
<li>Yet Another network map: <a href="https://map.jerry.dn42/">map.jerry.dn42</a> (DN42) or <a href="https://map.meson.cc">map.meson.cc</a> (via clearnet) <em>(uses MRT dump as source, updated every 15 minutes.)</em>
</li>
<li>DN42 IP address lookup tool: <a href="https://dn42.g-load.eu/lookup/">dn42.g-load.eu/lookup</a>
</li>
<li>New DNS System monitoring: <a href="https://grafana.burble.com/d/E4iCaHoWk/dn42-dns-status?orgId=1&amp;refresh=1m">grafana.burble.com/d/E4iCaHoWk/dn42-dns-status</a>
</li>
<li>whatsmyip:

<ul>
<li>ipv4+ipv6: <a href="http://myip.dn42/">myip.dn42</a>
</li>
<li>ipv4 only: <a href="http://v4.myip.dn42/">v4.myip.dn42</a> or <a href="http://172.20.0.81">172.20.0.81</a>
</li>
<li>ipv6 only: <a href="http://v6.myip.dn42/">v6.myip.dn42</a> or <a href="http://%5Bfd42:d42:d42:81::1%5D/">fd42:d42:d42:81::1</a>
</li>
<li>API endpoints:

<ul>
<li>/raw: return your IP address as plain text</li>
<li>/api: JSON with your IP plus the details of the server you reached (location, ASN, etc.)</li>
</ul>
</li>
</ul>
</li>
<li>Route Graphs: <a href="http://routegraphs.highdef.dn42">routegraphs.highdef.dn42</a> (DN42), <a href="https://routegraphs.highdef.network">routegraphs.highdef.network</a> (clearnet) - graph reachability from ASes to specific prefixes, using data from the dn42 GRC</li>
<li>BGP flap detector (FlapAlertedPro by Kioubit) hosted by AS4242422092: <a href="https://flaps.pebkac.dn42">https://flaps.pebkac.dn42</a>
</li>
</ul>

<h3><a class="anchor" id="geoip-services" href="#geoip-services"></a>GeoIP Services</h3>

<p><a href="http://map.dn42/">map.dn42</a> provides a simple GeoIP service. This service uses rDNS records and country field in aut-num objects as a reference, currently designed for fun :P</p>

<h4><a class="anchor" id="api" href="#api"></a>API</h4>

<p>Results are in JSON format.</p>

<pre class="highlight"><code>http://ipip.map.dn42/whois?ip=[DN42_IP]&amp;lang=en
http://ipip.map.dn42/whois?asn=AS[DN42_ASN]</code></pre>

<h4><a class="anchor" id="client" href="#client"></a>Client</h4>

<p>There is a client software using above apis to provide GeoIP-based traceroute.
It is a modified IPIP.NET Best Trace software with DN42 support injection.</p>

<p>Windows only, no virus scan report available, but our DLL source is provided with the modified client. It's highly recommended to run this tool in a sandbox.</p>

<p><strong>Since the original software is not open source, so use it at your own risk.</strong></p>

<p>Preview: <a href="http://img.dn42/images/GEOTRACE42.jpg">http://img.dn42/images/GEOTRACE42.jpg</a><br />
Link: <a href="http://map.dn42/BestTrace42.zip">http://map.dn42/BestTrace42.zip</a></p>

<h3><a class="anchor" id="asn-authentication-solution" href="#asn-authentication-solution"></a>ASN Authentication Solution</h3>

<p>Authenticate your users by having them verify their ASN ownership with KIOUBIT-MNT using their registry-provided methods in an automated way. An example of this is the automatic peering system for the Kioubit Network.
To use the service, please message Kioubit on IRC to have your domain activated and receive the required documentation.</p>

<h2><a class="anchor" id="irc" href="#irc"></a>IRC</h2>

<table>
<thead>
<tr>
<th align="left">Hostname / IP</th>
<th align="left">SSL</th>
<th align="left">Remarks</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left">irc.hackint.dn42</td>
<td align="left">Yes</td>
<td align="left">DN42</td>
</tr>
<tr>
<td align="left">irc.hackint.hack/dn42</td>
<td align="left">Yes</td>
<td align="left">ChaosVPN</td>
</tr>
<tr>
<td align="left">irc.dn42</td>
<td align="left">Yes</td>
<td align="left">Internal IRC</td>
</tr>
<tr>
<td align="left">irc.ty3r0x.dn42</td>
<td align="left">Yes</td>
<td align="left">BonoboNET (ty3r0x.bnet)</td>
</tr>
<tr>
<td align="left">irc.catgirls.dn42</td>
<td align="left">Yes</td>
<td align="left">Karx IRC, clearnet karx.xyz/6697, dn42 v6 only</td>
</tr>
</tbody>
</table>

<h3><a class="anchor" id="clients" href="#clients"></a>Clients</h3>

<table>
<thead>
<tr>
<th align="left">Hostname / IP</th>
<th align="left">Remarks</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left"><a href="https://lounge.burble.dn42">https://lounge.burble.dn42</a></td>
<td align="left">
<a href="https://thelounge.chat/">thelounge</a> for lurking on #dn42, see <a href="https://dn42.burble.com/services/internal/#loungeburbledn42">burble.dn42 services</a>.</td>
</tr>
<tr>
<td align="left"><a href="https://irc.pebkac.dn42">https://irc.pebkac.dn42</a></td>
<td align="left">
<a href="https://thelounge.chat/">thelounge</a> for lurking on #dn42, ask TOMKAP-DN42 for an account</td>
</tr>
</tbody>
</table>

<h2><a class="anchor" id="images-e-books-videos-and-other-media" href="#images-e-books-videos-and-other-media"></a>Images, E-Books, Videos and other Media</h2>

<table>
<thead>
<tr>
<th align="left">Hostname / IP</th>
<th align="left">Remarks</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left"><a href="http://j.munsternet.dn42">http://j.munsternet.dn42</a></td>
<td align="left">Jellyfin instance with movies and TV shows (test).</td>
</tr>
</tbody>
</table>

<h2><a class="anchor" id="radio-and-video-streaming" href="#radio-and-video-streaming"></a>Radio and Video Streaming</h2>

<table>
<thead>
<tr>
<th align="left">Hostname / IP</th>
<th align="left">Remarks</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left"><a href="https://live.jerry.dn42/">https://live.jerry.dn42/</a></td>
<td align="left">Live audio stream powered by mpd</td>
</tr>
<tr>
<td align="left"><a href="https://dn42:dn42@tv.munsternet.dn42/playlist">https://dn42:dn42@tv.munsternet.dn42/playlist</a></td>
<td align="left">TV Channels Streaming</td>
</tr>
<tr>
<td align="left"><a href="http://icy.jones.dn42">http://icy.jones.dn42</a></td>
<td align="left">Home grown Icecast Radio covering a number of genres (HLS &amp; Player coming soon [ish]!)</td>
</tr>
<tr>
<td align="left"><a href="http://webdj.nop.dn42/">http://webdj.nop.dn42/</a></td>
<td align="left">controller for Multicast stream: rtp://172.23.199.110@232.2.3.2:1234/</td>
</tr>
<tr>
<td align="left"><a href="https://sdr.pebkac.dn42/">https://sdr.pebkac.dn42/</a></td>
<td align="left">OpenWebRX SDR Receiver, FM/VHF/UHF Analog &amp; Digital</td>
</tr>
</tbody>
</table>

<h2><a class="anchor" id="file-sharing" href="#file-sharing"></a>File Sharing</h2>

<h3><a class="anchor" id="ftp-http" href="#ftp-http"></a>FTP / HTTP</h3>

<p><strong>FIXME</strong>: Please add info about (approximate) bandwidth of the servers.</p>

<p>Repository Mirrors are listed on another page: <a href="/services/Repository-Mirrors">Repository Mirrors</a></p>

<table>
<thead>
<tr>
<th align="left">Hostname / IP</th>
<th>Remarks</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left"><a href="http://files.nop.dn42">http://files.nop.dn42</a></td>
<td>download only, max 1Mbit/s</td>
</tr>
<tr>
<td align="left"><a href="http://rfc-editor.dn42">http://rfc-editor.dn42</a></td>
<td>download only, max 1Mbit/s</td>
</tr>
<tr>
<td align="left"><a href="http://freertr.dn42/">http://freertr.dn42/</a></td>
<td>freeRouter main site</td>
</tr>
<tr>
<td align="left"><a href="http://sources.nop.dn42">http://sources.nop.dn42</a></td>
<td>freeRouter source tree</td>
</tr>
<tr>
<td align="left"><a href="http://rtros.nop.dn42/">http://rtros.nop.dn42/</a></td>
<td>freeRouter distribution</td>
</tr>
</tbody>
</table>

<h2><a class="anchor" id="vpn" href="#vpn"></a>VPN</h2>

<p>DN42 Network Access over Automatic Wireguard VPN Service (IPv6 only, fd00::/8)
provided by TheQ at <a href="https://dn42.0011.de/vpnusers">https://dn42.0011.de/vpnusers</a></p>

<h2><a class="anchor" id="proxies" href="#proxies"></a>Proxies</h2>

<p>See <a href="http://wiki.hamburg.ccc.de/ChaosVPN:Proxy">http://wiki.hamburg.ccc.de/ChaosVPN:Proxy</a></p>

<h3><a class="anchor" id="telegram" href="#telegram"></a>Telegram</h3>

<p>A MTProxy server is available at <a href="https://t.me/proxy?server=mtp.jerry.dn42&amp;port=8044&amp;secret=ee1419944c0a129dbba2beb2636fcf361a616e64726f69642e676f6f676c65736f757263652e636f6d">mtp.jerry.dn42:8044</a>.</p>

<h2><a class="anchor" id="ntp" href="#ntp"></a>NTP</h2>

<table>
<thead>
<tr>
<th align="left">Hostname / IP</th>
<th align="left">Remarks</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left">*.burble.dn42</td>
<td align="left">All burble.dn42 nodes provide NTP over clearnet and DN42. See also <a href="https://dn42.burble.com/services/public/">burble.dn42 public services</a>
</td>
</tr>
</tbody>
</table>

<h2><a class="anchor" id="gaming" href="#gaming"></a>Gaming</h2>

<table>
<thead>
<tr>
<th align="left">Hostname / IP</th>
<th align="left">Game</th>
<th align="left">Remarks</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left">yuan.nia.dn42 (172.20.168.244)</td>
<td align="left">Genshi Impact (Unofficial)</td>
<td align="left">Latest development branch, Scripts included, Optimized for CN, Not stable yet</td>
</tr>
<tr>
<td align="left">mc.nico.dn42</td>
<td align="left">Minecraft</td>
<td align="left">1.16.5, <a href="https://bbs.dn42/d/17-modded-116-minecraft-server">Forge Modded</a>, IPv4 &amp; IPv6, Central US Server</td>
</tr>
<tr>
<td align="left">mc.jerry.dn42 &amp; jerry.dn42</td>
<td align="left">Minecraft</td>
<td align="left">latest, IPv4 &amp; IPv6</td>
</tr>
<tr>
<td align="left">mc.razuritta.dn42</td>
<td align="left">Minecraft</td>
<td align="left">latest(1.19.4 atm), IPv4 and IPv6, map at <a href="https://mcmap.razuritta.dn42/">https://mcmap.razuritta.dn42/</a>
</td>
</tr>
<tr>
<td align="left">mc.northrend.dn42 (172.20.222.240)</td>
<td align="left">Minecraft</td>
<td align="left">latest, IPv4 only</td>
</tr>
<tr>
<td align="left">redtrap.northrend.dn42 (172.20.222.252)</td>
<td align="left">Minecraft</td>
<td align="left">RedTrap DN42 Bridge, 1.8.8 - 1.19, IPv4 only</td>
</tr>
<tr>
<td align="left">ttd.jerry.dn42</td>
<td align="left">OpenTTD</td>
<td align="left">latest, IPv4 &amp; IPv6</td>
</tr>
<tr>
<td align="left">stk.jerry.dn42:2759, stk.jerry.neo:2759</td>
<td align="left">SuperTuxKart</td>
<td align="left">latest, IPv4 only</td>
</tr>
<tr>
<td align="left">stk2.jerry.dn42:2759, stk2.jerry.neo:2759</td>
<td align="left">SuperTuxKart</td>
<td align="left">latest, IPv4 &amp; IPv6</td>
</tr>
<tr>
<td align="left">factorio.catgirls.dn42 (IPv6 only)</td>
<td align="left">factorio</td>
<td align="left">Still in testing, expect downtime</td>
</tr>
<tr>
<td align="left">The burble.dn42 shell servers include a number of classic text games, see <a href="https://dn42.burble.com/services/shell/#classic-games">shell access</a>
</td>
<td align="left">Various</td>
<td align="left">Log in to the shell servers for more</td>
</tr>
<tr>
<td align="left">telnet tetris.dn42</td>
<td align="left">tetris in your terminal</td>
<td align="left">other games available on request, ping mc36 @ irc</td>
</tr>
<tr>
<td align="left"><a href="https://clicker.burble.dn42/">https://clicker.burble.dn42/</a></td>
<td align="left">Clicker/Idle</td>
<td align="left">Waste your time away with a dn42 themed browser based idle game</td>
</tr>
<tr>
<td align="left"><a href="https://monkic.mk16.de/">monkic.mk16.de</a></td>
<td align="left">Monkic (Game in German)</td>
<td align="left"></td>
</tr>
</tbody>
</table>

<h2><a class="anchor" id="voice-chat" href="#voice-chat"></a>Voice chat</h2>

<table>
<thead>
<tr>
<th align="left">Hostname / IP</th>
<th align="left">Remarks</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left">mumble://ty3r0x.dn42:64738</td>
<td align="left">Ty3r0X's Lair (men's club)</td>
</tr>
</tbody>
</table>

<h2><a class="anchor" id="voip-sip-endpoints" href="#voip-sip-endpoints"></a>VOIP/SIP Endpoints</h2>

<ul>
<li>burble.dn42 runs an <a href="https://dn42.burble.com/services/public/#voip">asterisk based VOIP service</a> with various test extensions and real hardware modems for dialing in to dn42</li>
<li>jerry.dn42 also runs an <a href="https://blog.jerry.dn42/dn42#Services_pbx">asterisk based VOIP service</a> with live radio (see live.jerry.dn42 above), whois service, conference room and software modems for dialing in to dn42</li>
</ul>

<h2><a class="anchor" id="challenges" href="#challenges"></a>Challenges</h2>

<p>Test out your skills with online challenges</p>

<table>
<thead>
<tr>
<th align="left">Start here</th>
<th align="left">Remarks</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left"><a href="https://burble.dn42/services/ping/">https://burble.dn42/services/ping/</a></td>
<td align="left">burble.dn42 ping challenge</td>
</tr>
<tr>
<td align="left"><a href="http://kioubit.dn42/challenge/">http://kioubit.dn42/challenge/</a></td>
<td align="left">Kioubit.dn42 challenge</td>
</tr>
</tbody>
</table>

<h2><a class="anchor" id="shell" href="#shell"></a>Shell</h2>

<p>Providers of shell access:</p>

<table>
<thead>
<tr>
<th align="left">Person</th>
<th align="left">Hostname</th>
<th align="left">Net</th>
<th align="left">Description</th>
<th align="left">Contact</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left">mc36</td>
<td align="left"><code>telnet test.nop.dn42</code></td>
<td align="left">dn42 only</td>
<td align="left">looking glass</td>
<td align="left">-</td>
</tr>
<tr>
<td align="left">JerryXiao</td>
<td align="left"><code>ssh lg@lg.jerry.dn42</code></td>
<td align="left">dn42 and icvpn</td>
<td align="left">looking glass</td>
<td align="left">-</td>
</tr>
<tr>
<td align="left">burble</td>
<td align="left">
<code>ssh &lt;mntner&gt;@shell.fr-rbx1.burble.dn42</code> <br /> <code>ssh &lt;mntner&gt;@shell.ca-bhs2.burble.dn42</code>
</td>
<td align="left">dn42</td>
<td align="left">Full shell account</td>
<td align="left">See below</td>
</tr>
</tbody>
</table>

<h3><a class="anchor" id="burble-dn42-shell-access" href="#burble-dn42-shell-access"></a>burble.dn42 shell access</h3>

<p>Full shell accounts are available for all dn42 users. Usernames are
constructed using the MNTNER name, lowercased and without the '-MNT' suffix. SSH public keys are imported automatically from the registry or alternatively, a password can be used instead.</p>

<p>See also the <a href="https://dn42.burble.com/services/shell/">burble.dn42 website</a> for more details.</p>

<h2><a class="anchor" id="personal-network-blogs-websites" href="#personal-network-blogs-websites"></a>Personal/network/blogs websites</h2>

<table>
<thead>
<tr>
<th>Website</th>
<th>Description</th>
</tr>
</thead>
<tbody>
<tr>
<td><a href="https://burble.dn42/">https://burble.dn42/</a></td>
<td>burble.dn42 website</td>
</tr>
<tr>
<td><a href="http://www.marlinc.dn42/">http://www.marlinc.dn42/</a></td>
<td>Marlinc website</td>
</tr>
<tr>
<td><a href="https://mk16de.bandura.dn42/">https://mk16de.bandura.dn42/</a></td>
<td>Marek's site</td>
</tr>
<tr>
<td><a href="http://lpnet0.dn42/">http://lpnet0.dn42/</a></td>
<td>LAUNCHPAD-NETWORK official website</td>
</tr>
</tbody>
</table>

<h2><a class="anchor" id="pastebins" href="#pastebins"></a>Pastebins</h2>

<table>
<thead>
<tr>
<th>Hostname / IP</th>
<th>Remarks</th>
</tr>
</thead>
<tbody>
<tr>
<td><a href="http://paste.nop.dn42">http://paste.nop.dn42</a></td>
<td>yet another paste service</td>
</tr>
<tr>
<td><a href="https://p.pebkac.dn42/">https://p.pebkac.dn42/</a></td>
<td>PasteBin Service (Netcat/Bash CLI Client)</td>
</tr>
</tbody>
</table>

<h2><a class="anchor" id="forums-message-boards" href="#forums-message-boards"></a>Forums / Message boards</h2>

<table>
<thead>
<tr>
<th>Hostname / IP</th>
<th>Remarks</th>
</tr>
</thead>
<tbody>
<tr>
<td><a href="https://urandom.catgirls.dn42/">https://urandom.catgirls.dn42/</a></td>
<td>Message board</td>
</tr>
</tbody>
</table>

<h2><a class="anchor" id="misc" href="#misc"></a>Misc</h2>

<table>
<thead>
<tr>
<th>Hostname / IP</th>
<th>Remarks</th>
</tr>
</thead>
<tbody>
<tr>
<td>
<a href="http://wiki.dn42">http://wiki.dn42</a>, <a href="http://internal.dn42">http://internal.dn42</a>
</td>
<td>This wiki!  Git Repo hosted on git.dn42</td>
</tr>
<tr>
<td><a href="http://www.nop.dn42/">http://www.nop.dn42/</a></td>
<td>Basic "whatismyip" service</td>
</tr>
<tr>
<td><a href="http://fun.nop.dn42/">http://fun.nop.dn42/</a></td>
<td>some funny images and videos</td>
</tr>
<tr>
<td><a href="http://pvrp.nop.dn42/">http://pvrp.nop.dn42/</a></td>
<td>a path vector igp main site</td>
</tr>
<tr>
<td><a href="http://lsrp.nop.dn42">http://lsrp.nop.dn42</a></td>
<td>a link state igp main site</td>
</tr>
<tr>
<td><a href="http://hwp0rn.nop.dn42">http://hwp0rn.nop.dn42</a></td>
<td>girls with switches and routers, a hwpr0n.se mirror</td>
</tr>
<tr>
<td><a href="http://ix.nop.dn42">http://ix.nop.dn42</a></td>
<td>mcast-ix main site</td>
</tr>
<tr>
<td><a href="http://mpls.dn42/">http://mpls.dn42/</a></td>
<td>a brief description of MPLS technology</td>
</tr>
<tr>
<td>
<a href="https://draw.bandura.dn42/">dn42</a>,<a href="http://draw.bandura.neo/">NeoNetwork</a>, <a href="http://draw.bandura.crxn/">CRXN</a>
</td>
<td>Excalidraw instance</td>
</tr>
</tbody>
</table>

<h2><a class="anchor" id="usenet-servers-news" href="#usenet-servers-news"></a>Usenet Servers / News</h2>

<p>There are some News Servers available <a href="/services/News">here</a></p>

<h2><a class="anchor" id="e-mail" href="#e-mail"></a>E-Mail</h2>

<p>There is a list of E-Mail providers <a href="/services/E-Mail-Providers">here</a></p>

<h1><a class="anchor" id="other-networks" href="#other-networks"></a>Other networks</h1>

<p><strong><a href="/Other">List of other Overlay Networks</a></strong></p>

<h2><a class="anchor" id="public-internet" href="#public-internet"></a>Public Internet</h2>

<ul>
<li>
<a href="https://mirror.frubar.net">https://mirror.frubar.net</a> 100MBit</li>
<li><a href="https://frucman.frubar.net">https://frucman.frubar.net</a></li>
</ul>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
<li>
<p><a href="/Home" rel="nofollow">Home</a></p>

<ul>
<li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
<li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
<li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
<li><a href="/howto/Bird-communities" rel="nofollow">BGP communities</a></li>
<li><a href="/FAQ" rel="nofollow">FAQ</a></li>
</ul>
</li>
<li>
<p>How-To</p>

<ul>
<li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
<li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
<li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
<li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
<li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
<li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
<li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
<li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
<li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
<li>
<a href="/howto/Bird" rel="nofollow">Bird</a> / <a href="/howto/Bird2" rel="nofollow">Bird2</a>
</li>
<li><a href="/howto/Quagga" rel="nofollow">Quagga</a></li>
<li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
<li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
<li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
<li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
<li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
<li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
<li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
<li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
</ul>
</li>
<li>
<p>Services</p>

<ul>
<li><a href="/services/IRC" rel="nofollow">IRC</a></li>
<li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
<li><a href="/services/DNS" rel="nofollow">DNS</a></li>
<li><a href="/services/IX2" rel="nofollow">IX</a></li>
<li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
<li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
<li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
<li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
<li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
<li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
<li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
</ul>
</li>
<li>
<p>Internal</p>

<ul>
<li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
<li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
<li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
<li>
<a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a><br />
</li>
<li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
</ul>
</li>
<li>
<p>External Tools</p>

<ul>
<li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
<li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
</ul>
</li>
</ul>

<hr />

	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p>Hosted by: <a href="mailto:xuu@sour.is" rel="nofollow">xuu</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">nurtic-vibe</a>, <a href="mailto:tom@xcv.vc" rel="nofollow">toBee</a>, <a href="mailto:dn42@burble.com" rel="nofollow">burble</a> | Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a></p>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="internal/Internal-Services.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/internal/Internal-Services.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
