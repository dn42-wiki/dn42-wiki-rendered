<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'internal/Internal-Services.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Internal-Services</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Internal-Services</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/internal/Internal-Services.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/internal/Internal-Services.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Internal-Services
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/internal/">internal</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="internal-services" href="#internal-services"></a>Internal services</h1>

<p>You are asked to show some creativity in terms of network usage and content.
View a list of <a href="/internal/Ideas">service ideas</a> and <a href="/internal/Historical-Services">historical services</a>.</p>

<h2><a class="anchor" id="search-engines-discovery" href="#search-engines-discovery"></a>Search engines &amp; Discovery</h2>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Hostname / IP</th>
      <th style="text-align:left;">ICANN</th>
      <th style="text-align:left;">Internal</th>
      <th style="text-align:left;">Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;"><a href="https://baaka.dn42">baaka.dn42</a></td>
      <td style="text-align:left;"> </td>
      <td style="text-align:left;">X</td>
      <td style="text-align:left;">SearXNG instance with the metadata source being <a href="https://yacy.baka.dn42">yacy.baka.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://search.androw.dn42">search.androw.dn42</a></td>
      <td style="text-align:left;">X</td>
      <td style="text-align:left;"> </td>
      <td style="text-align:left;">SearXNG instance</td>
    </tr>
  </tbody>
</table>

<ul>
  <li>
<a href="https://discover.dn42">Discover.DN42</a> is a visual, bot-curated index of active websites within the DN42 network.</li>
</ul>

<h2><a class="anchor" id="certificate-authority" href="#certificate-authority"></a>Certificate Authority</h2>

<p>See this <a href="/services/ca/Certificate-Authority">page</a> for the main certificate authority.</p>

<h2><a class="anchor" id="network-related" href="#network-related"></a>Network-related</h2>

<h3><a class="anchor" id="general" href="#general"></a>General</h3>

<ul>
  <li>
<del>Network Information Service: <a href="https://bgp42.strexp.net">bgp42.strexp.net</a> (via IANA). Main functions include <em>network information</em>, <em>network map (from map.dn42, requires WebGL)</em>, <em>network ranking (based on centrality)</em>, <em>ROA alerting</em> and <em>path finder</em>.</del> (deprecated but still partially functional)
    <ul>
      <li>The service has now been split into several sub-sites, further functional migrations are currently underway:</li>
      <li>Registry Viewer (IP Blocks): <a href="https://registry42.strexp.net">registry42.strexp.net (via IANA)</a> (requires WebGL)</li>
      <li>Map Viewer: <a href="https://map42.strexp.net">map42.strexp.net (via IANA)</a> (requires WebGL, requires GPU)</li>
      <li>ISP Viewer: <a href="https://isp42.strexp.net">isp42.strexp.net (via IANA)</a>
</li>
      <li>Registry Timeline: <a href="https://timeline42.strexp.net">timeline42.strexp.net (via IANA)</a>
</li>
    </ul>
  </li>
  <li>Various DN42-related tools: <a href="https://dn42.g-load.eu/toolbox/">dn42.g-load.eu/toolbox/</a>
</li>
</ul>

<h3><a class="anchor" id="looking-glasses" href="#looking-glasses"></a>Looking glasses</h3>
<p>See <a href="/services/Looking-Glasses">Looking Glasses</a>.</p>

<h3><a class="anchor" id="what-is-my-ip" href="#what-is-my-ip"></a>What is my IP</h3>
<ul>
  <li>myip.dn42 anycasted service:
    <ul>
      <li>ipv4+ipv6: <a href="http://myip.dn42/">myip.dn42</a>
</li>
      <li>ipv4 only: <a href="http://v4.myip.dn42/">v4.myip.dn42</a> or <a href="http://172.20.0.81">172.20.0.81</a>
</li>
      <li>ipv6 only: <a href="http://v6.myip.dn42/">v6.myip.dn42</a> or <a href="http://[fd42:d42:d42:81::1]/">fd42:d42:d42:81::1</a>
</li>
    </ul>
  </li>
  <li><a href="http://whatismyip.dn42">whatismyip.dn42</a></li>
</ul>

<h3><a class="anchor" id="interactive-maps" href="#interactive-maps"></a>Interactive Maps</h3>
<ul>
  <li>Realtime network map: <a href="https://map.dn42/">map.dn42</a> (DN42) or <a href="https://map.iedon.net">map.iedon.net</a> (via clearnet) <em>(This map currently uses MRT dumps from GRC as its source. It refreshes whenever the collector provides a new MRT file, generally every 10-15 minutes.)</em>
</li>
  <li>Yet Another network map: <a href="https://map.jerry.dn42/">map.jerry.dn42</a> (DN42) or <a href="https://map.meson.cc">map.meson.cc</a> (via clearnet) <em>(uses MRT dump as source, updated every 15 minutes.)</em>
</li>
  <li>3D IP-based network graph (revived yay), created by traceroute all hosts, updated per day <a href="https://dn42.jh0project.dn42/map">dn42.jh0project.dn42/map</a> (DN42), <a href="https://dn42.jh0project.com/map">dn42.jh0project.com/map</a> (clearnet)</li>
</ul>

<h3><a class="anchor" id="bgp-analysis-and-explorers" href="#bgp-analysis-and-explorers"></a>BGP Analysis and explorers</h3>
<ul>
  <li>
<a href="https://anomalies.dn42">Anomalies.dn42</a> is a debugging tool that analyzes BGP routing data to identify ASes that may be inadvertently adding or removing geographic communities (region/country) from foreign prefixes.</li>
  <li>Route Graphs: <a href="http://routegraphs.highdef.dn42">routegraphs.highdef.dn42</a> (DN42), <a href="https://routegraphs.highdef.network">routegraphs.highdef.network</a> (clearnet) - graph reachability from ASes to specific prefixes, using data from the dn42 GRC</li>
  <li>DN42 Explorer: <a href="https://explorer.nedifinita.com">explorer.nedifinita.com</a>. BGP routing, topology, and registry explorer. Provides an IPv4 interactive map, AS connectivity, prefix status, and rankings.</li>
</ul>

<h3><a class="anchor" id="health-status" href="#health-status"></a>Health &amp; Status</h3>
<ul>
  <li>DNS System monitoring: <a href="https://grafana.burble.com/d/E4iCaHoWk/dn42-dns-status?orgId=1&amp;refresh=1m">grafana.burble.com/d/E4iCaHoWk/dn42-dns-status</a>
</li>
  <li>DNS monitor for all DN42 domains <a href="https://dns-monitor.gensokyo.dn42">dns-monitor.gensokyo.dn42</a> (Web: IPv6 Only, Data: IPv4/IPv6)</li>
</ul>

<h3><a class="anchor" id="speedtest" href="#speedtest"></a>Speedtest</h3>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Operator</th>
      <th style="text-align:left;">Location</th>
      <th style="text-align:left;">Max Speed</th>
      <th>Link</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">Burble</td>
      <td style="text-align:left;">Anycast</td>
      <td style="text-align:left;">Unknown</td>
      <td><a href="https://speedtest.burble.dn42/">speedtest.burble.dn42</a></td>
    </tr>
    <tr>
      <td style="text-align:left;">Kioubit</td>
      <td style="text-align:left;">Nuremberg, Germany</td>
      <td style="text-align:left;">400 Mbps</td>
      <td><a href="https://kioubit.dn42/speedtest/">kioubit.dn42/speedtest/</a></td>
    </tr>
    <tr>
      <td style="text-align:left;">Routedbits</td>
      <td style="text-align:left;">Multiple</td>
      <td style="text-align:left;">Unknown</td>
      <td><a href="https://dn42.routedbits.io/nodes">dn42.routedbits.io/nodes</a></td>
    </tr>
    <tr>
      <td style="text-align:left;">vr18</td>
      <td style="text-align:left;">Unknown</td>
      <td style="text-align:left;">100/20 Mbps</td>
      <td><a href="http://speed.vr18.dn42/">speed.vr18.dn42/</a></td>
    </tr>
    <tr>
      <td style="text-align:left;">NOT-MNT</td>
      <td style="text-align:left;">Athens</td>
      <td style="text-align:left;">500/1000Mbps</td>
      <td><a href="https://speedtest.not.dn42/">speedtest.not.dn42/</a></td>
    </tr>
    <tr>
      <td style="text-align:left;">Gensokyo</td>
      <td style="text-align:left;">Wuhan, China</td>
      <td style="text-align:left;">U:50Mbps/D:1Gbps</td>
      <td><a href="https://speed.gensokyo.dn42">speed.gensokyo.dn42</a></td>
    </tr>
    <tr>
      <td style="text-align:left;">Bingxin</td>
      <td style="text-align:left;">Global</td>
      <td style="text-align:left;">200Mbps - 5Gbps</td>
      <td><a href="https://speedtest.baka.dn42">speedtest.baka.dn42</a></td>
    </tr>
    <tr>
      <td style="text-align:left;">VCONET-MNT</td>
      <td style="text-align:left;">Amsterdam, Netherlands</td>
      <td style="text-align:left;">10Gbps</td>
      <td><a href="https://speed.vc.dn42">speed.vc.dn42</a></td>
    </tr>
    <tr>
      <td style="text-align:left;">CowGL</td>
      <td style="text-align:left;">Taichung, Taiwan</td>
      <td style="text-align:left;">100/350 Mbps</td>
      <td>
<code>iperf3 -c txg.cow.dn42 -p 8964</code> <br /> home network, please do not abuse :(</td>
    </tr>
    <tr>
      <td style="text-align:left;">ANDREW-MNT</td>
      <td style="text-align:left;">New Orleans + Tallulah (LA), USA; London, UK (anycast)</td>
      <td style="text-align:left;">5Gbps (NOLA) / 2Gbps (LON) / 1Gbps (TLH)</td>
      <td>
<code>iperf3 -c iperf.andrew.dn42 -p 5201</code> or <a href="https://speed.andrew.dn42">speed.andrew.dn42</a> — nearest site answers; per-node: <code>{nola,london,tallulah}.iperf.andrew.dn42</code>
</td>
    </tr>
    <tr>
      <td style="text-align:left;">Gabriel GGR</td>
      <td style="text-align:left;">Curitiba, Brazil</td>
      <td style="text-align:left;">250/500 Mbps</td>
      <td><a href="http://speed.gabrielggr.dn42">speed.gabrielggr.dn42</a></td>
    </tr>
    <tr>
      <td style="text-align:left;">NETBOT</td>
      <td style="text-align:left;">Italy</td>
      <td style="text-align:left;">800 Mbps</td>
      <td><code>iperf3 -c speed.netbot.dn42</code></td>
    </tr>
    <tr>
      <td style="text-align:left;">SessX6cf</td>
      <td style="text-align:left;">APAC</td>
      <td style="text-align:left;">1-10 Gbps</td>
      <td><a href="https://speedtest.sess.dn42/">https://speedtest.sess.dn42/</a></td>
    </tr>
    <tr>
      <td style="text-align:left;">CODECATCH-MNT (AS4242420972)</td>
      <td style="text-align:left;">Not specified</td>
      <td style="text-align:left;">3.5 Gbps</td>
      <td>
<code>iperf3 -c 172.23.29.2 -p 5201</code> <br /> IPv6: <code>iperf3 -6 -c fd97:33ef:121a:1::2 -p 5201</code>
</td>
    </tr>
  </tbody>
</table>

<h3><a class="anchor" id="flapalerted-instances" href="#flapalerted-instances"></a>FlapAlerted instances</h3>

<table>
  <thead>
    <tr>
      <th>URL</th>
      <th>Operator</th>
      <th>Note</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><a href="https://flaps.pebkac.dn42">flaps.pebkac.dn42</a></td>
      <td>AS4242422092</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://dn42.g-load.eu/flapAlerted/">https://dn42.g-load.eu/flapAlerted/</a></td>
      <td>AS4242423914</td>
      <td>Limited HTTP API</td>
    </tr>
    <tr>
      <td>
<a href="https://bandura.dn42/flapalertedpro/">https://bandura.dn42/flapalertedpro/</a>, <a href="https://mk16.de/flapalertedpro/">https://mk16.de/flapalertedpro/</a>
</td>
      <td>AS4242422923</td>
      <td> </td>
    </tr>
    <tr>
      <td>
<a href="https://flappyroutes.be0ba.dn42/">https://flappyroutes.be0ba.dn42/</a>, <a href="https://flappyroutes.dn42.tcp80.org/">https://flappyroutes.dn42.tcp80.org/</a>
</td>
      <td>AS4242420224</td>
      <td> </td>
    </tr>
    <tr>
      <td>
<a href="https://fa.badaimweeb.dn42/">https://fa.badaimweeb.dn42/</a>, <a href="https://dn42-fa.badaimweeb.me/">https://dn42-fa.badaimweeb.me/</a>
</td>
      <td>AS4242423797</td>
      <td> </td>
    </tr>
    <tr>
      <td>
<a href="https://flaps.lpnet0.dn42/">https://flaps.lpnet0.dn42/</a>, <a href="https://dn42-flaps.launchpadx.top/">https://dn42-flaps.launchpadx.top/</a>
</td>
      <td>AS4242423702</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://flapalerted.lantian.pub/">https://flapalerted.lantian.pub/</a></td>
      <td>AS4242422547</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://flaps.iedon.net/">https://flaps.iedon.net/</a></td>
      <td>AS4242422189</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://flap-dn42.baka.pub/">https://flap-dn42.baka.pub/</a></td>
      <td>AS4242423374</td>
      <td> </td>
    </tr>
    <tr>
      <td>
<a href="https://flap.nia.dn42/">flap.nia.dn42</a>, <a href="https://flap42.strexp.net/">flap42.strexp.net</a>
</td>
      <td>AS4242421331</td>
      <td> </td>
    </tr>
    <tr>
      <td>
<a href="https://flap-data.nia.dn42/">flap-data.nia.dn42</a>, <a href="https://flap42-data.strexp.net/">flap42-data.strexp.net</a>
</td>
      <td>AS4242421331</td>
      <td>aggregated data of most instances</td>
    </tr>
    <tr>
      <td>
<a href="https://flaps.cowgl.tech">https://flaps.cowgl.tech</a>, <a href="https://flaps.cowgl.dn42">https://flaps.cowgl.dn42</a>
</td>
      <td>AS4242423999</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://flapalerted.nedifinita.com">flapalerted.nedifinita.com</a></td>
      <td>AS4242420454</td>
      <td> </td>
    </tr>
    <tr>
      <td>
<a href="https://flap.sess.dn42/">https://flap.sess.dn42/</a> <a href="https://flap42.xhustudio.eu.org/">https://flap42.xhustudio.eu.org/</a>
</td>
      <td>AS4242422466</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="flap-dn42.ruinet.work">flap-dn42.ruinet.work</a></td>
      <td>AS211575</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://flaps.mashiro.dn42/">https://flaps.mashiro.dn42/</a></td>
      <td>AS4242420214</td>
      <td> </td>
    </tr>
    <tr>
      <td>
<a href="https://flap.defelo.dn42/">https://flap.defelo.dn42/</a>, <a href="https://flap-dn42.defelo.de/">https://flap-dn42.defelo.de/</a>
</td>
      <td>AS4242422357</td>
      <td> </td>
    </tr>
    <tr>
      <td>
<a href="https://flaps.s6v.dn42">https://flaps.s6v.dn42</a>, <a href="https://flaps.dn42.s6v.net/">https://flaps.dn42.s6v.net/</a>
</td>
      <td>AS4242423432</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://flap.fennec.dn42/">https://flap.fennec.dn42/</a></td>
      <td>AS4242420132</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://flap.maiyun.dn42/">https://flap.maiyun.dn42/</a></td>
      <td>AS4242420893</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://flap.headscarf175.net/">https://flap.headscarf175.net/</a></td>
      <td>AS4242420842</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://flapalerted.tes286.top/">https://flapalerted.tes286.top/</a></td>
      <td>AS4242420078</td>
      <td> </td>
    </tr>
  </tbody>
</table>

<h3><a class="anchor" id="asn-authentication-solution" href="#asn-authentication-solution"></a>ASN Authentication Solution</h3>

<p>Authenticate your users by having them verify their ASN ownership with following services using their registry-provided methods in an automated way. Some examples of this are the automatic peering system for the <a href="https://dn42.g-load.eu">Kioubit Network</a> and <a href="https://iedon.net">iEdon-Net</a>.</p>

<table>
  <thead>
    <tr>
      <th>Service</th>
      <th>Type</th>
      <th>Whitelist</th>
      <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Kioubit Authentication Services (4242423914)</td>
      <td>Custom, OAuth2.0/OpenID Connect</td>
      <td>No</td>
      <td><a href="https://dn42.g-load.eu/about/authentication-services/">Link</a></td>
    </tr>
    <tr>
      <td>OAuth.dn42 (4242422189)</td>
      <td>OAuth2.0/OpenID Connect</td>
      <td>No</td>
      <td><a href="https://iedon.net/post/27">Link</a></td>
    </tr>
    <tr>
      <td>HExpNetwork WebAuth (4242420298)</td>
      <td>OAuth2.0/OpenID Connect</td>
      <td>No</td>
      <td><a href="https://auth42.hexpnet.work/doc.html">Link</a></td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="irc" href="#irc"></a>IRC</h2>

<p>See the <a href="/services/IRC">primary IRC page</a>.</p>

<p>Other servers:</p>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Hostname / IP</th>
      <th style="text-align:left;">SSL</th>
      <th style="text-align:left;">Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">irc.dn42</td>
      <td style="text-align:left;">Yes</td>
      <td style="text-align:left;">Internal IRC</td>
    </tr>
    <tr>
      <td style="text-align:left;">irc.ty3r0x.dn42</td>
      <td style="text-align:left;">Yes</td>
      <td style="text-align:left;">BonoboNET (ty3r0x.bnet)</td>
    </tr>
    <tr>
      <td style="text-align:left;">irc.catgirls.dn42</td>
      <td style="text-align:left;">Yes</td>
      <td style="text-align:left;">Karx IRC, clearnet karx.xyz/6697, dn42 v6 only</td>
    </tr>
    <tr>
      <td style="text-align:left;">irc.replirc.dn42</td>
      <td style="text-align:left;">Yes</td>
      <td style="text-align:left;">ReplIRC (started in 2022 on Replit (but no longer uses Replit), uses Solanum for servers), self-signed certificates</td>
    </tr>
  </tbody>
</table>

<h3><a class="anchor" id="clients" href="#clients"></a>Clients</h3>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Hostname / IP</th>
      <th style="text-align:left;">Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;"><a href="https://lounge.burble.dn42">https://lounge.burble.dn42</a></td>
      <td style="text-align:left;">
<a href="https://thelounge.chat/">thelounge</a> for lurking on #dn42, see <a href="https://dn42.burble.com/services/internal/#loungeburbledn42">burble.dn42 services</a>.</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://irc.pebkac.dn42">https://irc.pebkac.dn42</a></td>
      <td style="text-align:left;">
<a href="https://thelounge.chat/">thelounge</a> for lurking on #dn42, ask TOMKAP-DN42 for an account</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="images-e-books-videos-and-other-media" href="#images-e-books-videos-and-other-media"></a>Images, E-Books, Videos and other Media</h2>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Hostname / IP</th>
      <th style="text-align:left;">Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;"><a href="http://j.munsternet.dn42">http://j.munsternet.dn42</a></td>
      <td style="text-align:left;">Jellyfin instance with movies and TV shows (test).</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://miyuzaki.dn42">http://miyuzaki.dn42</a></td>
      <td style="text-align:left;">Jellyfin instance containing Korean Variety Shows</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://emby.pmman.dn42">https://emby.pmman.dn42</a></td>
      <td style="text-align:left;">Emby instance containing Anime/Movies/TV shows with Chinese subtitles</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://e621ng.dn42">https://e621ng.dn42</a></td>
      <td style="text-align:left;">Just e621ng, contains bunch of nsfw</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://wiki.gensokyo.dn42">https://wiki.gensokyo.dn42</a></td>
      <td style="text-align:left;">Mirrors of some wikimedia sites and other wikis</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="radio-and-video-streaming" href="#radio-and-video-streaming"></a>Radio and Video Streaming</h2>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Hostname / IP</th>
      <th style="text-align:left;">Remarks</th>
      <th> </th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;"><a href="https://tube.buzzster.dn42/">https://tube.buzzster.dn42/</a></td>
      <td style="text-align:left;">A youtube like platform on DN42</td>
      <td> </td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://live.jerry.dn42/">https://live.jerry.dn42/</a></td>
      <td style="text-align:left;">Live audio stream powered by mpd</td>
      <td> </td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://radio.vr18.dn42/">http://radio.vr18.dn42/</a></td>
      <td style="text-align:left;">Online radio by vr18</td>
      <td> </td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://dn42:dn42@tv.munsternet.dn42/playlist">https://dn42:dn42@tv.munsternet.dn42/playlist</a></td>
      <td style="text-align:left;">TV Channels Streaming</td>
      <td> </td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://icy.jones.dn42">http://icy.jones.dn42</a></td>
      <td style="text-align:left;">Homegrown Icecast Radio covering a number of genres (HLS &amp; Player coming soon [ish]!)</td>
      <td> </td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://radio.vrpnet.dn42">https://radio.vrpnet.dn42</a></td>
      <td style="text-align:left;">Online radio by Pi3rrot on VRPNET, using Icecast&amp;Liquidsoap</td>
      <td> </td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://webdj.nop.dn42/">http://webdj.nop.dn42/</a></td>
      <td style="text-align:left;">controller for Multicast stream: rtp://172.23.199.110@232.2.3.2:1234/</td>
      <td> </td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://sdr1.maiyun.dn42/">http://sdr1.maiyun.dn42/</a></td>
      <td style="text-align:left;">KiwiSDR HF SDR Receiver (aka clearnet <a href="https://kiwisdr.kk6uc.org/">https://kiwisdr.kk6uc.org/</a>)</td>
      <td> </td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://sdr.pebkac.dn42/">https://sdr.pebkac.dn42/</a></td>
      <td style="text-align:left;">OpenWebRX SDR Receiver, FM/VHF/UHF Analog &amp; Digital (ask TOMKAP-DN42 for an account)</td>
      <td> </td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://adsb.androw.dn42/">https://adsb.androw.dn42/</a></td>
      <td style="text-align:left;">ADS-B Receiver located in Paris</td>
      <td> </td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://kz.dn42:8888/6MusicProxy/index.m3u8">http://kz.dn42:8888/6MusicProxy/index.m3u8</a></td>
      <td style="text-align:left;">BBC Radio 6 Music Proxy service (320kbps AAC streams over HLS)</td>
      <td> </td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://radio.baka.dn42">https://radio.baka.dn42</a></td>
      <td style="text-align:left;">24/7 Non-Stop Radio! Online Radio by Bingxin</td>
      <td> </td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://radio.cowgl.dn42">https://radio.cowgl.dn42</a></td>
      <td style="text-align:left;">Online Radio by CowGL</td>
      <td> </td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://radio.leziblog.dn42">https://radio.leziblog.dn42</a></td>
      <td style="text-align:left;">Online Radio by <a href="mailto:lezi@leziblog.dn42">LeZi</a>
</td>
      <td> </td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://sess.dn42/radio.html">https://sess.dn42/radio.html</a></td>
      <td style="text-align:left;">SESS.DN42 Freedom Music Radio. Online Radio by <a href="mailto:sess@sess.dn42">SessX6cf</a>
</td>
      <td> </td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://radio.hikari.dn42">https://radio.hikari.dn42</a></td>
      <td style="text-align:left;">Online Radio by Hikari, using Icecast &amp; Liquidsoap</td>
      <td> </td>
    </tr>
    <tr>
      <td style="text-align:left;">
<a href="https://radio.mashiro.dn42">https://radio.mashiro.dn42</a>, Clearnet: <a href="https://radio.origincode.me">https://radio.origincode.me</a>
</td>
      <td style="text-align:left;">FrontieRadio Presented by COMPLEXE, powered by MPD and IceCast</td>
      <td> </td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://radio.vc.dn42">http://radio.vc.dn42</a></td>
      <td style="text-align:left;">Online Radio by VConet, using mpd &amp; Icecast.</td>
      <td> </td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://radio.gatuno.dn42:8000/hyrule">http://radio.gatuno.dn42:8000/hyrule</a></td>
      <td style="text-align:left;">Mirror radio of radiohyrule.com</td>
      <td> </td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="file-sharing" href="#file-sharing"></a>File Sharing</h2>

<h3><a class="anchor" id="repository-mirrors" href="#repository-mirrors"></a>Repository Mirrors</h3>
<p>See <a href="/internal/Repository-Mirrors">Repository Mirrors</a>.</p>

<h3><a class="anchor" id="ftp-http" href="#ftp-http"></a>FTP / HTTP</h3>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Hostname / IP</th>
      <th>Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;"><a href="http://files.nop.dn42">http://files.nop.dn42</a></td>
      <td>download only, max 1Mbit/s</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://rfc-editor.dn42">http://rfc-editor.dn42</a></td>
      <td>download only, max 1Mbit/s</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://freertr.dn42/">http://freertr.dn42/</a></td>
      <td>freeRouter main site</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://sources.nop.dn42">http://sources.nop.dn42</a></td>
      <td>freeRouter source tree</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://rtros.nop.dn42/">http://rtros.nop.dn42/</a></td>
      <td>freeRouter distribution</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://file.tlmc.nas.gensokyo.dn42">https://file.tlmc.nas.gensokyo.dn42</a></td>
      <td>Touhou Lossless Music Collection (TLMC)</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://radio.sess.dn42/files/">https://radio.sess.dn42/files/</a></td>
      <td>Music files of <a href="https://radio.sess.dn42">radio.sess.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:left;">&lt;fdc1:acc:cc8::6&gt; Port: 2222</td>
      <td>SFTP, Linux ISOs mirrored from distrowatch.com &amp; FOSS Torrents.  Also has eXo games collection from retro-exo.com.  Connect on the commandline with &lt;sftp -P 2222 dn42@[fdc1:acc:cc8::6]&gt; (p/w dn42)</td>
    </tr>
  </tbody>
</table>

<h3><a class="anchor" id="rsync" href="#rsync"></a>Rsync</h3>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Hostname / IP</th>
      <th>Bandwidth</th>
      <th>Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">rsync://nas.gensokyo.dn42/tlmc</td>
      <td>Not specified</td>
      <td>Touhou Lossless Music Collection (TLMC)</td>
    </tr>
    <tr>
      <td style="text-align:left;">rsync://rsync.mirrors.leziblog.dn42/majnet</td>
      <td>50Mbps</td>
      <td>maimai chart resources on MajdataNET</td>
    </tr>
    <tr>
      <td style="text-align:left;">rsync://rsync.mirrors.leziblog.dn42/ubuntu</td>
      <td>50Mbps</td>
      <td>Ubuntu mirror repository</td>
    </tr>
    <tr>
      <td style="text-align:left;">rsync://rsync.mirrors.leziblog.dn42/ubuntu-ports</td>
      <td>50Mbps</td>
      <td>Ubuntu Ports mirror repository</td>
    </tr>
    <tr>
      <td style="text-align:left;">rsync://rsync.mirrors.leziblog.dn42/openwrt</td>
      <td>50Mbps</td>
      <td>OpenWrt mirror repository</td>
    </tr>
  </tbody>
</table>

<h3><a class="anchor" id="bittorrent" href="#bittorrent"></a>BitTorrent</h3>

<h4><a class="anchor" id="tracker" href="#tracker"></a>Tracker</h4>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Hostname / IP</th>
      <th>Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;"><a href="http://tracker.leziblog.dn42/announce">http://tracker.leziblog.dn42/announce</a></td>
      <td>Maintained by <a href="mailto:lezi@leziblog.dn42">LeZi</a>
</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://tracker.leziblog.dn42/announce">https://tracker.leziblog.dn42/announce</a></td>
      <td>Maintained by <a href="mailto:lezi@leziblog.dn42">LeZi</a>
</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://tracker.pmman.dn42/announce">http://tracker.pmman.dn42/announce</a></td>
      <td>Listening on both IANA and DN42,maintained by <a href="mailto:me@pmman.tech">pmman</a>
</td>
    </tr>
  </tbody>
</table>

<h4><a class="anchor" id="dht-bootstrap" href="#dht-bootstrap"></a>DHT Bootstrap</h4>

<ul>
  <li>dht.leziblog.dn42:6881</li>
</ul>

<h2><a class="anchor" id="source-code-hosting" href="#source-code-hosting"></a>Source Code Hosting</h2>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Hostname / IP</th>
      <th style="text-align:left;">Maintainer</th>
      <th style="text-align:left;">Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">gitlab.dn42</td>
      <td style="text-align:left;"><a href="mailto:lezi@leziblog.dn42">LeZi</a></td>
      <td style="text-align:left;">Open registration (dn42 TLD email required), rolling backups, internal dn42 runner available.</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="tor-network" href="#tor-network"></a>Tor network</h2>

<p>See <a href="/internal/Tor">Tor</a>.</p>

<h2><a class="anchor" id="vpn" href="#vpn"></a>VPN</h2>

<p>DN42 Network Access over Automatic Wireguard VPN Service (IPv6 only, fd00::/8)
provided by AS4242422712 at <a href="https://vpn-service.dn42.nuku.de/">https://vpn-service.dn42.nuku.de/</a></p>

<h2><a class="anchor" id="proxies" href="#proxies"></a>Proxies</h2>

<p>See <a href="http://wiki.hamburg.ccc.de/ChaosVPN:Proxy">http://wiki.hamburg.ccc.de/ChaosVPN:Proxy</a></p>

<h3><a class="anchor" id="telegram" href="#telegram"></a>Telegram</h3>

<h4><a class="anchor" id="mtproxy" href="#mtproxy"></a>MTProxy</h4>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">IP</th>
      <th style="text-align:left;">Secret</th>
      <th style="text-align:left;">Provider</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;"><a href="https://t.me/proxy?server=mtp.jerry.dn42&amp;port=8044&amp;secret=ee1419944c0a129dbba2beb2636fcf361a616e64726f69642e676f6f676c65736f757263652e636f6d">mtp.jerry.dn42:8044</a></td>
      <td style="text-align:left;"><code>ee1419944c0a129dbba2beb2636fcf361a616e64726f69642e676f6f676c65736f757263652e636f6d</code></td>
      <td style="text-align:left;">JERRY-MNT</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://t.me/proxy?server=172.20.54.58&amp;port=8101&amp;secret=de5ba4a48126705a60add5e1cacbbd4b">172.20.54.58:8101</a></td>
      <td style="text-align:left;"><code>de5ba4a48126705a60add5e1cacbbd4b</code></td>
      <td style="text-align:left;">LAUNCHPAD-MNT</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://t.me/proxy?server=mtproxy.nia.dn42&amp;port=18888&amp;secret=ee883e80a9be6c9eb3e4a08553ad7dd12d646e34322e646576">mtproxy.nia.dn42:18888</a></td>
      <td style="text-align:left;"><code>ee883e80a9be6c9eb3e4a08553ad7dd12d646e34322e646576</code></td>
      <td style="text-align:left;">NIA-MNT</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="ntp" href="#ntp"></a>NTP</h2>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Hostname / IP</th>
      <th style="text-align:center;">Stratum</th>
      <th style="text-align:left;">Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">*.burble.dn42</td>
      <td style="text-align:center;"> </td>
      <td style="text-align:left;">All burble.dn42 nodes provide NTP over clearnet and DN42. See also <a href="https://dn42.burble.com/services/public/">burble.dn42 public services</a>
</td>
    </tr>
    <tr>
      <td style="text-align:left;">ntp.cow.dn42</td>
      <td style="text-align:center;">S2</td>
      <td style="text-align:left;">Operated by AS4242423999, anycast on all nodes</td>
    </tr>
    <tr>
      <td style="text-align:left;">ntp.grmml.dn42</td>
      <td style="text-align:center;">S2</td>
      <td style="text-align:left;">Operated by AS4242420123, EU Nodes, DNS RR</td>
    </tr>
    <tr>
      <td style="text-align:left;">pool.ntp.dn42</td>
      <td style="text-align:center;">S1/S2/S3/S4</td>
      <td style="text-align:left;">Project NTP Pool 42. See also <a href="https://ntp.dn42/">ntp.dn42</a>
</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="nntp-usenet-style-newsgroups" href="#nntp-usenet-style-newsgroups"></a>NNTP (Usenet Style Newsgroups)</h2>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Hostname / IP</th>
      <th style="text-align:left;">Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">nntp.shiva.dn42</td>
      <td style="text-align:left;">Good old fashioned newsgroups, Usenet style. September never ends! HTTP site with server rules and config at <a href="http://nntp.shiva.dn42">http://nntp.shiva.dn42</a>
</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="gaming" href="#gaming"></a>Gaming</h2>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Hostname / IP</th>
      <th style="text-align:left;">Game</th>
      <th style="text-align:left;">Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;"><a href="http://nethack.chofstede.dn42">nethack.chofstede.dn42</a></td>
      <td style="text-align:left;">Nethack</td>
      <td style="text-align:left;">New NetHack 5.0 via SSH <a href="http://nethack.chofstede.dn42/?p=connect">how to connect</a>
</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://yggdrasil.dn42">https://yggdrasil.dn42</a></td>
      <td style="text-align:left;">Minecraft</td>
      <td style="text-align:left;">
<a href="https://github.com/yushijinhun/authlib-injector">Authlib-Injector</a> compatible authencation service</td>
    </tr>
    <tr>
      <td style="text-align:left;">172.20.210.193</td>
      <td style="text-align:left;">Minecraft</td>
      <td style="text-align:left;">Vanilla Server - latest(1.21.4)</td>
    </tr>
    <tr>
      <td style="text-align:left;">mc.jerry.dn42 &amp; jerry.dn42</td>
      <td style="text-align:left;">Minecraft</td>
      <td style="text-align:left;">latest, IPv4 &amp; IPv6</td>
    </tr>
    <tr>
      <td style="text-align:left;">mc.razu.neo (formerly mc.razuritta.dn42)</td>
      <td style="text-align:left;">Minecraft</td>
      <td style="text-align:left;">latest(1.21.11 atm), IPv4+IPv6</td>
    </tr>
    <tr>
      <td style="text-align:left;">mc.licen777.dn42 (172.23.197.197 &amp; fde8:2e18:e127::300)</td>
      <td style="text-align:left;">Minecraft</td>
      <td style="text-align:left;">1.16.5-1.21.5, (/gm 1, Cracked)</td>
    </tr>
    <tr>
      <td style="text-align:left;">sess.dn42</td>
      <td style="text-align:left;">Minecraft</td>
      <td style="text-align:left;">Vanilla, 1.21.11, IPv4 &amp; IPv6</td>
    </tr>
    <tr>
      <td style="text-align:left;">cowgl.dn42</td>
      <td style="text-align:left;">Minecraft</td>
      <td style="text-align:left;">Minigames server, 1.7.2-latest, online mode, dn42 authorization on the way™</td>
    </tr>
    <tr>
      <td style="text-align:left;">yzynetwork.dn42</td>
      <td style="text-align:left;">Minecraft</td>
      <td style="text-align:left;">latest, online mode, survival</td>
    </tr>
    <tr>
      <td style="text-align:left;">mc.xiaoxi654.dn42</td>
      <td style="text-align:left;">Minecraft</td>
      <td style="text-align:left;">26.2 Vanilla, as test environment,using <a href="https://yggdrasil.dn42">yggdrasil.dn42</a> for authorization</td>
    </tr>
    <tr>
      <td style="text-align:left;">ttd.jerry.dn42</td>
      <td style="text-align:left;">OpenTTD</td>
      <td style="text-align:left;">latest, IPv4 &amp; IPv6</td>
    </tr>
    <tr>
      <td style="text-align:left;">stk.jerry.dn42:2759, stk.jerry.neo:2759</td>
      <td style="text-align:left;">SuperTuxKart</td>
      <td style="text-align:left;">latest, IPv4 only</td>
    </tr>
    <tr>
      <td style="text-align:left;">stk2.jerry.dn42:2759, stk2.jerry.neo:2759</td>
      <td style="text-align:left;">SuperTuxKart</td>
      <td style="text-align:left;">latest, IPv4 &amp; IPv6</td>
    </tr>
    <tr>
      <td style="text-align:left;">factorio.catgirls.dn42 (IPv6 only)</td>
      <td style="text-align:left;">factorio</td>
      <td style="text-align:left;">Still in testing, expect downtime</td>
    </tr>
    <tr>
      <td style="text-align:left;">The burble.dn42 shell servers include a number of classic text games, see <a href="https://dn42.burble.com/services/shell/#classic-games">shell access</a>
</td>
      <td style="text-align:left;">Various</td>
      <td style="text-align:left;">Log in to the shell servers for more</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://clicker.burble.dn42/">https://clicker.burble.dn42/</a></td>
      <td style="text-align:left;">Clicker/Idle</td>
      <td style="text-align:left;">Waste your time away with a dn42-themed browser-based idle game</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://dn42dle.burble.dn42/">https://dn42dle.burble.dn42/</a></td>
      <td style="text-align:left;">Word Game</td>
      <td style="text-align:left;">A familiar word game played over DNS, see the website for details instructions</td>
    </tr>
    <tr>
      <td style="text-align:left;">telnet tetris.dn42</td>
      <td style="text-align:left;">tetris in your terminal</td>
      <td style="text-align:left;">other games available on request, ping mc36 @ irc</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://2048.dn42">2048.dn42</a></td>
      <td style="text-align:left;">2048</td>
      <td style="text-align:left;">Join the numbers and get to the 2048 tile!</td>
    </tr>
    <tr>
      <td style="text-align:left;">
<a href="https://monkic.mk16.de/">monkic.mk16.de</a>, <a href="https://monkic.bandura.dn42/">dn42</a>
</td>
      <td style="text-align:left;">Monkic (Game in German)</td>
      <td style="text-align:left;"> </td>
    </tr>
    <tr>
      <td style="text-align:left;">yobanirot.dn42:7591</td>
      <td style="text-align:left;">Minecraft and Minetest</td>
      <td style="text-align:left;">One more "tech" minecraft server, mods <a href="http://yobanirot.dn42/mods.zip">here</a>
</td>
    </tr>
    <tr>
      <td style="text-align:left;">yobanirot.dn42:27015</td>
      <td style="text-align:left;">CS 1.6</td>
      <td style="text-align:left;"> </td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://taiko.furry.dn42">http://taiko.furry.dn42/</a></td>
      <td style="text-align:left;">Taiko Web</td>
      <td style="text-align:left;"> </td>
    </tr>
    <tr>
      <td style="text-align:left;">172.23.77.38:27031</td>
      <td style="text-align:left;">Quake Live Server</td>
      <td style="text-align:left;">IPv4 only, connect with console using IP Address and Port #</td>
    </tr>
    <tr>
      <td style="text-align:left;">gc.rui.dn42:8443</td>
      <td style="text-align:left;">Genshin Impact Private Server OSREL4.6</td>
      <td style="text-align:left;">Contact ruifeng@ruinet.work or Telegram @justruiqwq for resources.</td>
    </tr>
    <tr>
      <td style="text-align:left;">mc.gensokyo.dn42</td>
      <td style="text-align:left;">Minecraft</td>
      <td style="text-align:left;">IPv6 Only</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="voice-chat" href="#voice-chat"></a>Voice chat</h2>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Hostname / IP</th>
      <th style="text-align:left;">Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">mumble://ty3r0x.dn42:64738</td>
      <td style="text-align:left;">Ty3r0X's Lair (men's club)</td>
    </tr>
    <tr>
      <td style="text-align:left;">mumble://yzynetwork.dn42:64738</td>
      <td style="text-align:left;">Mainly Chinese-speaking, but everyone is welcome.</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="voip-sip" href="#voip-sip"></a>VOIP/SIP</h2>

<ul>
  <li>burble.dn42 runs an <a href="https://dn42.burble.com/services/public/#voip">asterisk based VOIP service</a> with various test extensions and real hardware modems for dialing in to dn42</li>
  <li>jerry.dn42 also runs an <a href="https://blog.jerry.dn42/dn42#Services_pbx">asterisk based VOIP service</a> with live radio (see live.jerry.dn42 above), whois service, conference room and software modems for dialing in to dn42</li>
  <li>gensokyo.dn42 runs asterisk based VOIP services.
    <ul>
      <li>WebRTC based soft-phone: <a href="https://phone.gensokyo.dn42">phone.gensokyo.dn42</a>, default caller ID: WebRTC Demo ({src ip}) &lt;+042408039910&gt;</li>
      <li>PSTN to DN42 proxy gateway (+1 424 242 9915), default caller ID: Gensokyo Tele42 Proxy for {src num} &lt;+042408038100&gt;</li>
      <li>Web fax sender: <a href="https://fax.gensokyo.dn42/tx/">fax.gensokyo.dn42/tx/</a>
</li>
      <li>Web fax receiver: <a href="https://fax.gensokyo.dn42/rx/">fax.gensokyo.dn42/rx/</a>
</li>
    </ul>
  </li>
  <li>
<a href="https://yp.dn42">yp.dn42</a>: YellowPage for telephony42. Editable if login with oauth.dn42 or iEdon Auth42.
    <ul>
      <li>PDF telephone directory book at <a href="https://yp.dn42/books/">yp.dn42/books/</a>
</li>
    </ul>
  </li>
  <li>
<a href="http://gabrielggr.dn42">gabrielggr.dn42</a> runs an echo test on +04222222.</li>
</ul>

<h2><a class="anchor" id="challenges" href="#challenges"></a>Challenges</h2>

<p>Test out your skills with online challenges</p>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Start here</th>
      <th style="text-align:left;">Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;"><a href="https://burble.dn42/services/ping/">https://burble.dn42/services/ping/</a></td>
      <td style="text-align:left;">burble.dn42 ping challenge</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://kioubit.dn42/challenge/ch1/">http://kioubit.dn42/challenge/ch1/</a></td>
      <td style="text-align:left;">Kioubit.dn42 challenge 1</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://kioubit.dn42/challenge/ch2/">http://kioubit.dn42/challenge/ch2/</a></td>
      <td style="text-align:left;">Kioubit.dn42 challenge 2</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://exam.edu.dn42/?topic=dn42">https://exam.edu.dn42/?topic=dn42</a></td>
      <td style="text-align:left;">Online test center, quizzes for testing your network skills! Run by NEXUS-MNT</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="virtual-machines" href="#virtual-machines"></a>Virtual machines</h2>

<p>Virtual machine providers are listed <a href="/internal/Virtual-Machines">here</a>.</p>

<h2><a class="anchor" id="shell" href="#shell"></a>Shell</h2>

<p>Providers of shell access:</p>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Person</th>
      <th style="text-align:left;">Hostname</th>
      <th style="text-align:left;">Net</th>
      <th style="text-align:left;">Description</th>
      <th style="text-align:left;">Contact</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">mc36</td>
      <td style="text-align:left;"><code>telnet test.nop.dn42</code></td>
      <td style="text-align:left;">dn42 only</td>
      <td style="text-align:left;">looking glass</td>
      <td style="text-align:left;">-</td>
    </tr>
    <tr>
      <td style="text-align:left;">JerryXiao</td>
      <td style="text-align:left;"><code>ssh lg@lg.jerry.dn42</code></td>
      <td style="text-align:left;">dn42 and icvpn</td>
      <td style="text-align:left;">looking glass</td>
      <td style="text-align:left;">-</td>
    </tr>
    <tr>
      <td style="text-align:left;">burble</td>
      <td style="text-align:left;">
<code>ssh &lt;mntner&gt;@shell.fr-rbx1.burble.dn42</code> <br /> <code>ssh &lt;mntner&gt;@shell.ca-bhs1.burble.dn42</code>
</td>
      <td style="text-align:left;">dn42</td>
      <td style="text-align:left;">Full shell account</td>
      <td style="text-align:left;">See below</td>
    </tr>
  </tbody>
</table>

<h3><a class="anchor" id="burble-dn42-shell-access" href="#burble-dn42-shell-access"></a>burble.dn42 shell access</h3>

<p>Full shell accounts are available for all dn42 users. Usernames are
constructed using the MNTNER name, lowercased and without the '-MNT' suffix. SSH public keys are imported automatically from the registry or alternatively, a password can be used instead.</p>

<p>See also the <a href="https://dn42.burble.com/services/shell/">burble.dn42 website</a> for more details.</p>

<h2><a class="anchor" id="personal-network-blogs-websites" href="#personal-network-blogs-websites"></a>Personal/network/blogs websites</h2>

<table>
  <thead>
    <tr>
      <th>Website</th>
      <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><a href="https://burble.dn42/">https://burble.dn42/</a></td>
      <td>burble.dn42 website</td>
    </tr>
    <tr>
      <td><a href="http://www.marlinc.dn42/">http://www.marlinc.dn42/</a></td>
      <td>Marlinc website</td>
    </tr>
    <tr>
      <td><a href="http://vr18.dn42/">http://vr18.dn42/</a></td>
      <td>vr18.dn42 website</td>
    </tr>
    <tr>
      <td><a href="https://mk16de.bandura.dn42/">https://mk16de.bandura.dn42/</a></td>
      <td>Marek's site</td>
    </tr>
    <tr>
      <td><a href="http://blog.sherpherd.dn42/">http://blog.sherpherd.dn42/</a></td>
      <td>Hawkins' Homepage</td>
    </tr>
    <tr>
      <td><a href="https://20plays.dn42/">https://20plays.dn42/</a></td>
      <td>20plays' website</td>
    </tr>
    <tr>
      <td><a href="https://mdr.dn42/">https://mdr.dn42/</a></td>
      <td>Mark Dastmalchi-Round's website (clearnet mirror)</td>
    </tr>
    <tr>
      <td><a href="https://tupo-nain.dn42">https://tupo-nain.dn42</a></td>
      <td>NAAIN's website</td>
    </tr>
    <tr>
      <td><a href="https://darkpoint.dn42">https://darkpoint.dn42</a></td>
      <td>AS4242420150 Darkpoint website</td>
    </tr>
    <tr>
      <td><a href="https://baka.dn42">https://baka.dn42</a></td>
      <td>Baka.Pub DN42 website (clearnet mirror)</td>
    </tr>
    <tr>
      <td><a href="https://sess.dn42">https://sess.dn42</a></td>
      <td>SessNetwork dn42 website</td>
    </tr>
    <tr>
      <td><a href="https://franta.dn42">https://franta.dn42</a></td>
      <td>Franta's website (clearnet mirror)</td>
    </tr>
    <tr>
      <td><a href="https://busrzi.dn42">https://busrzi.dn42</a></td>
      <td>Simple visitor counter service</td>
    </tr>
    <tr>
      <td><a href="https://fennec.dn42">https://fennec.dn42</a></td>
      <td>FennecNet/Kit's dn42 website</td>
    </tr>
    <tr>
      <td><a href="https://yzynetwork.dn42">https://yzynetwork.dn42</a></td>
      <td>YZYNetwork.dn42 website</td>
    </tr>
    <tr>
      <td><a href="https://nexus.dn42">https://nexus.dn42</a></td>
      <td>qiuxin's personal blog</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="pastebins" href="#pastebins"></a>Pastebins</h2>

<table>
  <thead>
    <tr>
      <th>Hostname / IP</th>
      <th>Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><a href="http://paste.nop.dn42">http://paste.nop.dn42</a></td>
      <td>yet another paste service</td>
    </tr>
    <tr>
      <td><a href="https://p.pebkac.dn42/">https://p.pebkac.dn42/</a></td>
      <td>PasteBin Service (Netcat/Bash CLI Client)</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="forums-message-boards" href="#forums-message-boards"></a>Forums / Message boards</h2>

<table>
  <thead>
    <tr>
      <th>Hostname / IP</th>
      <th>Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><a href="https://urandom.catgirls.dn42/">https://urandom.catgirls.dn42/</a></td>
      <td>Message board</td>
    </tr>
    <tr>
      <td>
<a href="https://bbs.nicholascw.dn42">https://bbs.nicholascw.dn42</a>, <a href="https://dn42bbs.0b1.me">https://dn42bbs.0b1.me</a> via Clearnet</td>
      <td>A general BBS powered by Flarum for virtually any topic. Maintained by nicholascw. Previously under bbs.dn42.</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="fediverse-instances" href="#fediverse-instances"></a>Fediverse instances</h2>

<table>
  <thead>
    <tr>
      <th>Hostname</th>
      <th>Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><a href="https://social.gensokyo.dn42">https://social.gensokyo.dn42</a></td>
      <td>GoToSocial, Register available via gitlab.dn42 or oauth.dn42</td>
    </tr>
    <tr>
      <td><a href="https://social.fennec.dn42">https://social.fennec.dn42</a></td>
      <td>Mastodon Glitch-Soc, login/register via Kioubit auth</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="e-mail" href="#e-mail"></a>E-Mail</h2>

<p>There is a list of E-Mail providers <a href="/internal/E-Mail-Providers">here</a></p>

<h2><a class="anchor" id="misc" href="#misc"></a>Misc</h2>

<table>
  <thead>
    <tr>
      <th>Hostname / IP</th>
      <th>Remarks</th>
      <th> </th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>
<a href="http://wiki.dn42">http://wiki.dn42</a>, <a href="http://internal.dn42">http://internal.dn42</a>
</td>
      <td>This wiki! Git Repo hosted on git.dn42</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="http://www.nop.dn42/">http://www.nop.dn42/</a></td>
      <td>Basic "whatismyip" service</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="http://fun.nop.dn42/">http://fun.nop.dn42/</a></td>
      <td>some funny images and videos</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="http://pvrp.nop.dn42/">http://pvrp.nop.dn42/</a></td>
      <td>a path vector igp main site</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="http://lsrp.nop.dn42">http://lsrp.nop.dn42</a></td>
      <td>a link state igp main site</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="http://hwp0rn.nop.dn42">http://hwp0rn.nop.dn42</a></td>
      <td>girls with switches and routers, a hwpr0n.se mirror</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="http://ix.nop.dn42">http://ix.nop.dn42</a></td>
      <td>mcast-ix main site</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="http://mpls.dn42/">http://mpls.dn42/</a></td>
      <td>a brief description of MPLS technology</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="http://it.vr18.dn42/">http://it.vr18.dn42/</a></td>
      <td>handy tools for developers</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://ntfy.weil-isso.dn42">https://ntfy.weil-isso.dn42</a></td>
      <td>NTFY (Push Notify via REST-API)</td>
      <td> </td>
    </tr>
    <tr>
      <td>kms.weil-isso.dn42 (Port 1688)</td>
      <td>Key Management Server (with Auto-Activation) for any Windows/Office (LAB AND TEST Purposes only)</td>
      <td> </td>
    </tr>
    <tr>
      <td>ad-01.bakabaka9.dn42</td>
      <td>Key Management Server (with Offical Windows Srv KMS Host Server) Only can Active Office 2016 all version (TEST Purposes only)</td>
      <td> </td>
    </tr>
    <tr>
      <td>anycast.zookeeper.immibis.dn42 (port 2181)</td>
      <td>Apache Zookeeper cluster (requires a client certificate for access - on request)</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://coin.dn42">https://coin.dn42</a></td>
      <td>Cryptocurrency</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://mempool.dn42">https://mempool.dn42</a></td>
      <td>Bitcoin explorer</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="http://whatismyip.dn42/">http://whatismyip.dn42/</a></td>
      <td>dn42 IPv4 and IPv6 whatismyip service</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://keyserver.nia.dn42">https://keyserver.nia.dn42</a></td>
      <td>Hockeypuck OpenPGP Server</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://pgp.ens18.dn42">https://pgp.ens18.dn42</a></td>
      <td>Hockeypuck OpenPGP Server (pgp.asia)</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://scam.dn42/">https://scam.dn42/</a></td>
      <td>Scummy bank</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://syncthing-discover.gensokyo.dn42">https://syncthing-discover.gensokyo.dn42</a></td>
      <td>Syncthing Discover Server</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://mx.dn42">https://mx.dn42</a></td>
      <td>Matrix IM Server maintained by COMPLEXE, ask @COMPL_EXE on Telegram / E-Mail self@origincode.me / @i:origincode.me on clearnet Matrix for registration requests, unofficial chat room #dn42:mx.dn42</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://mtf.dn42/">https://mtf.dn42/</a></td>
      <td>MtF Wiki</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://osm.nia.dn42/">https://osm.nia.dn42/</a></td>
      <td>OpenStreetMap Viewer (update period: 1 month) (IPv6 Only)</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="http://nat64.dn42/">http://nat64.dn42/</a></td>
      <td>Public NAT64+DNS64 Service by Unixeno (IPv6 -&gt; IPv4)</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://time.dn42/">https://time.dn42/</a></td>
      <td>a clock, basically time.is but in dn42</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://totp.sess.dn42/">https://totp.sess.dn42/</a></td>
      <td>TOTP Token Generator in browser</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://chat.dn42">https://chat.dn42</a></td>
      <td>WebRTC-based chat and direct point-to-point file transferring</td>
      <td> </td>
    </tr>
    <tr>
      <td><a href="https://nenaebalovo.dn42">https://nenaebalovo.dn42</a></td>
      <td>Even in DN42 we have casino! integrated with scam.dn42(scummy bank)</td>
      <td> </td>
    </tr>
    <tr>
      <td>syncplay.gensokyo.dn42:8999</td>
      <td>SyncPlay Server (TLS On)</td>
      <td> </td>
    </tr>
    <tr>
      <td>172.21.66.1:5900</td>
      <td>PixelFlut server, 172.21.66.1:1234 to control</td>
      <td> </td>
    </tr>
  </tbody>
</table>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="internal/Internal-Services.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/internal/Internal-Services.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
