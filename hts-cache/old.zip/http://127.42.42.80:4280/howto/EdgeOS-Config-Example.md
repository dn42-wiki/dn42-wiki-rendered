<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/EdgeOS-Config-Example.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>EdgeOS-Config-Example</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>EdgeOS-Config-Example</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/EdgeOS-Config-Example.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/EdgeOS-Config-Example.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    EdgeOS-Config-Example
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="edgerouter-lite-dn42-config-example" href="#edgerouter-lite-dn42-config-example"></a>EdgeRouter Lite DN42 config example</h1>
<p>This is the config I (Felicitus) am running on an Ubiquiti EdgeRouter Lite (AS76197).</p>

<h2><a class="anchor" id="features" href="#features"></a>Features</h2>

<ul>
  <li>dn42 DNS</li>
  <li>"classic" OpenVPN P2P (including the common "comp-lzo" option)</li>
  <li>BGP</li>
  <li>Some traffic-shaping rules for my very slow 3mbit DSL uplink</li>
  <li>2 internal: One DN42 network (172.22.117.128/25 for me and my servers as well as a NAT 192.168.42.10/24 for my parents, so that they're save from dn42 - that network is NOT announced to dn42).</li>
  <li>Firewall to protect my NAS server and monitoring</li>
</ul>

<h2><a class="anchor" id="upcoming" href="#upcoming"></a>Upcoming</h2>

<ul>
  <li>AICCU integration (SIXXS), probably not possible with the config, so <code>apt-get install aiccu</code> should do the trick</li>
  <li>dn42 IPv6 routing (probably)</li>
</ul>

<p>Ask me if you want to know if I have implemented those items already.</p>

<h1><a class="anchor" id="configuration" href="#configuration"></a>Configuration</h1>

<pre class="highlight"><code><span class="n">firewall</span> {
    <span class="n">all</span>-<span class="n">ping</span> <span class="n">enable</span>
    <span class="n">broadcast</span>-<span class="n">ping</span> <span class="n">disable</span>
    <span class="n">conntrack</span>-<span class="n">expect</span>-<span class="n">table</span>-<span class="n">size</span> <span class="m">4096</span>
    <span class="n">conntrack</span>-<span class="n">hash</span>-<span class="n">size</span> <span class="m">4096</span>
    <span class="n">conntrack</span>-<span class="n">table</span>-<span class="n">size</span> <span class="m">32768</span>
    <span class="n">conntrack</span>-<span class="n">tcp</span>-<span class="n">loose</span> <span class="n">enable</span>
    <span class="n">ipv6</span>-<span class="n">name</span> <span class="n">ROUTER_V6</span> {
        <span class="n">default</span>-<span class="n">action</span> <span class="n">drop</span>
        <span class="n">rule</span> <span class="m">1</span> {
            <span class="n">action</span> <span class="n">drop</span>
            <span class="n">destination</span> {
                <span class="n">port</span> <span class="m">22</span>
            }
            <span class="n">protocol</span> <span class="n">tcp</span>
        }
    }
    <span class="n">ipv6</span>-<span class="n">name</span> <span class="n">WAN_IN_V6</span> {
        <span class="n">default</span>-<span class="n">action</span> <span class="n">drop</span>
        <span class="n">enable</span>-<span class="n">default</span>-<span class="n">log</span>
        <span class="n">rule</span> <span class="m">3</span> {
            <span class="n">action</span> <span class="n">drop</span>
            <span class="n">destination</span> {
                <span class="n">port</span> <span class="m">22</span>
            }
            <span class="n">protocol</span> <span class="n">tcp</span>
        }
    }
    <span class="n">ipv6</span>-<span class="n">receive</span>-<span class="n">redirects</span> <span class="n">disable</span>
    <span class="n">ipv6</span>-<span class="n">src</span>-<span class="n">route</span> <span class="n">disable</span>
    <span class="n">ip</span>-<span class="n">src</span>-<span class="n">route</span> <span class="n">disable</span>
    <span class="n">log</span>-<span class="n">martians</span> <span class="n">enable</span>
    <span class="n">name</span> <span class="n">DN42</span> {
        <span class="n">default</span>-<span class="n">action</span> <span class="n">drop</span>
        <span class="n">rule</span> <span class="m">100</span> {
            <span class="n">action</span> <span class="n">drop</span>
            <span class="n">destination</span> {
                <span class="n">address</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">117</span>.<span class="m">181</span>
            }
            <span class="n">source</span> {
                <span class="n">address</span> !<span class="m">172</span>.<span class="m">22</span>.<span class="m">117</span>.<span class="m">128</span>/<span class="m">25</span>
            }
        }
        <span class="n">rule</span> <span class="m">101</span> {
            <span class="n">action</span> <span class="n">drop</span>
            <span class="n">destination</span> {
                <span class="n">address</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">117</span>.<span class="m">182</span>
            }
            <span class="n">source</span> {
                <span class="n">address</span> !<span class="m">172</span>.<span class="m">22</span>.<span class="m">117</span>.<span class="m">128</span>/<span class="m">25</span>
            }
        }
        <span class="n">rule</span> <span class="m">102</span> {
            <span class="n">action</span> <span class="n">drop</span>
            <span class="n">destination</span> {
                <span class="n">address</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">117</span>.<span class="m">183</span>
            }
            <span class="n">source</span> {
                <span class="n">address</span> !<span class="m">172</span>.<span class="m">22</span>.<span class="m">117</span>.<span class="m">128</span>/<span class="m">25</span>
            }
        }
    }
    <span class="n">name</span> <span class="n">ROUTER_V4</span> {
        <span class="n">default</span>-<span class="n">action</span> <span class="n">accept</span>
        <span class="n">rule</span> <span class="m">2</span> {
            <span class="n">action</span> <span class="n">accept</span>
            <span class="n">protocol</span> <span class="n">icmp</span>
        }
        <span class="n">rule</span> <span class="m">10</span> {
            <span class="n">action</span> <span class="n">drop</span>
            <span class="n">destination</span> {
                <span class="n">port</span> <span class="m">22</span>
            }
            <span class="n">protocol</span> <span class="n">tcp</span>
        }
    }
    <span class="n">name</span> <span class="n">WAN_IN_V4</span> {
        <span class="n">default</span>-<span class="n">action</span> <span class="n">drop</span>
        <span class="n">enable</span>-<span class="n">default</span>-<span class="n">log</span>
        <span class="n">rule</span> <span class="m">1</span> {
            <span class="n">action</span> <span class="n">accept</span>
            <span class="n">description</span> <span class="s2">"allow established connections"</span>
            <span class="n">protocol</span> <span class="n">all</span>
            <span class="n">state</span> {
                <span class="n">established</span> <span class="n">enable</span>
                <span class="n">related</span> <span class="n">enable</span>
            }
        }
        <span class="n">rule</span> <span class="m">2</span> {
            <span class="n">action</span> <span class="n">drop</span>
            <span class="n">state</span> {
                <span class="n">invalid</span> <span class="n">enable</span>
            }
        }
        <span class="n">rule</span> <span class="m">3</span> {
            <span class="n">action</span> <span class="n">drop</span>
            <span class="n">destination</span> {
                <span class="n">port</span> <span class="m">22</span>
            }
            <span class="n">protocol</span> <span class="n">tcp</span>
        }
    }
    <span class="n">receive</span>-<span class="n">redirects</span> <span class="n">disable</span>
    <span class="n">send</span>-<span class="n">redirects</span> <span class="n">enable</span>
    <span class="n">source</span>-<span class="n">validation</span> <span class="n">disable</span>
    <span class="n">syn</span>-<span class="n">cookies</span> <span class="n">enable</span>
}
<span class="n">interfaces</span> {
    <span class="n">ethernet</span> <span class="n">eth0</span> {
        <span class="n">duplex</span> <span class="n">auto</span>
        <span class="n">firewall</span> {
            <span class="n">in</span> {
                <span class="n">name</span> <span class="n">WAN_IN_V4</span>
            }
        }
        <span class="n">pppoe</span> <span class="m">0</span> {
            <span class="n">default</span>-<span class="n">route</span> <span class="n">auto</span>
            <span class="n">firewall</span> {
                <span class="n">local</span> {
                    <span class="n">ipv6</span>-<span class="n">name</span> <span class="n">ROUTER_V6</span>
                    <span class="n">name</span> <span class="n">ROUTER_V4</span>
                }
            }
            <span class="n">mtu</span> <span class="m">1492</span>
            <span class="n">name</span>-<span class="n">server</span> <span class="n">auto</span>
            <span class="n">password</span> <span class="m">12345678</span>
            <span class="n">traffic</span>-<span class="n">policy</span> {
            }
            <span class="n">user</span>-<span class="n">id</span> <span class="n">some</span>-<span class="n">t</span>-<span class="n">online</span>-<span class="n">crap</span>@<span class="n">t</span>-<span class="n">online</span>.<span class="n">de</span>
        }
        <span class="n">speed</span> <span class="n">auto</span>
    }
    <span class="n">ethernet</span> <span class="n">eth1</span> {
        <span class="n">address</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">117</span>.<span class="m">254</span>/<span class="m">25</span>
        <span class="n">duplex</span> <span class="n">auto</span>
        <span class="n">speed</span> <span class="n">auto</span>
        <span class="n">traffic</span>-<span class="n">policy</span> {
        }
    }
    <span class="n">ethernet</span> <span class="n">eth2</span> {
        <span class="n">address</span> <span class="m">192</span>.<span class="m">168</span>.<span class="m">42</span>.<span class="m">1</span>/<span class="m">24</span>
        <span class="n">duplex</span> <span class="n">auto</span>
        <span class="n">speed</span> <span class="n">auto</span>
    }
    <span class="n">loopback</span> <span class="n">lo</span> {
    }
    <span class="n">openvpn</span> <span class="n">vtun0</span> {
        <span class="n">local</span>-<span class="n">address</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">117</span>.<span class="m">254</span> {
            <span class="n">subnet</span>-<span class="n">mask</span> <span class="m">255</span>.<span class="m">255</span>.<span class="m">255</span>.<span class="m">128</span>
        }
        <span class="n">local</span>-<span class="n">port</span> <span class="m">33121</span>
        <span class="n">mode</span> <span class="n">site</span>-<span class="n">to</span>-<span class="n">site</span>
        <span class="n">openvpn</span>-<span class="n">option</span> --<span class="n">comp</span>-<span class="n">lzo</span>
        <span class="n">protocol</span> <span class="n">udp</span>
        <span class="n">remote</span>-<span class="n">address</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">117</span>.<span class="m">1</span>
        <span class="n">remote</span>-<span class="n">host</span> <span class="m">5</span>.<span class="m">9</span>.<span class="m">33</span>.<span class="m">163</span>
        <span class="n">remote</span>-<span class="n">port</span> <span class="m">33121</span>
        <span class="n">shared</span>-<span class="n">secret</span>-<span class="n">key</span>-<span class="n">file</span> /<span class="n">config</span>/<span class="n">auth</span>/<span class="n">felihome</span>.<span class="n">key</span>
    }
}
<span class="n">policy</span> {
    <span class="n">prefix</span>-<span class="n">list</span> <span class="n">vpn</span>-<span class="n">in</span> {
        <span class="n">rule</span> <span class="m">10</span> {
            <span class="n">action</span> <span class="n">permit</span>
            <span class="n">ge</span> <span class="m">22</span>
            <span class="n">le</span> <span class="m">28</span>
            <span class="n">prefix</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">0</span>.<span class="m">0</span>/<span class="m">15</span>
        }
    }
}
<span class="n">protocols</span> {
    <span class="n">bgp</span> <span class="m">76197</span> {
        <span class="n">neighbor</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">117</span>.<span class="m">1</span> {
            <span class="n">description</span> <span class="n">feli</span>-<span class="n">server</span>
            <span class="n">peer</span>-<span class="n">group</span> <span class="n">dn42</span>
            <span class="n">remote</span>-<span class="n">as</span> <span class="m">64717</span>
        }
        <span class="n">network</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">117</span>.<span class="m">128</span>/<span class="m">25</span> {
        }
        <span class="n">peer</span>-<span class="n">group</span> <span class="n">dn42</span> {
            <span class="n">soft</span>-<span class="n">reconfiguration</span> {
                <span class="n">inbound</span>
            }
        }
    }
}
<span class="n">service</span> {
    <span class="n">dhcp</span>-<span class="n">server</span> {
        <span class="n">disabled</span> <span class="n">false</span>
        <span class="n">dynamic</span>-<span class="n">dns</span>-<span class="n">update</span> {
            <span class="n">enable</span> <span class="n">true</span>
        }
        <span class="n">shared</span>-<span class="n">network</span>-<span class="n">name</span> <span class="n">int</span> {
            <span class="n">authoritative</span> <span class="n">disable</span>
            <span class="n">subnet</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">117</span>.<span class="m">128</span>/<span class="m">25</span> {
                <span class="n">default</span>-<span class="n">router</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">117</span>.<span class="m">254</span>
                <span class="n">dns</span>-<span class="n">server</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">117</span>.<span class="m">254</span>
                <span class="n">domain</span>-<span class="n">name</span> <span class="n">feli</span>-<span class="n">home</span>.<span class="n">felicitus</span>.<span class="n">org</span>
                <span class="n">lease</span> <span class="m">86400</span>
                <span class="n">start</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">117</span>.<span class="m">129</span> {
                    <span class="n">stop</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">117</span>.<span class="m">150</span>
                }
                <span class="n">static</span>-<span class="n">mapping</span> <span class="n">monitoring</span> {
                    <span class="n">ip</span>-<span class="n">address</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">117</span>.<span class="m">183</span>
                    <span class="n">mac</span>-<span class="n">address</span> <span class="m">52</span>:<span class="m">54</span>:<span class="m">00</span>:<span class="m">20</span>:<span class="n">df</span>:<span class="m">46</span>
                }
                <span class="n">static</span>-<span class="n">mapping</span> <span class="n">nas</span> {
                    <span class="n">ip</span>-<span class="n">address</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">117</span>.<span class="m">181</span>
                    <span class="n">mac</span>-<span class="n">address</span> <span class="n">e8</span>:<span class="m">39</span>:<span class="m">35</span>:<span class="n">ee</span>:<span class="m">22</span>:<span class="m">7</span><span class="n">b</span>
                }
            }
        }
        <span class="n">shared</span>-<span class="n">network</span>-<span class="n">name</span> <span class="n">nat</span> {
            <span class="n">authoritative</span> <span class="n">disable</span>
            <span class="n">subnet</span> <span class="m">192</span>.<span class="m">168</span>.<span class="m">42</span>.<span class="m">0</span>/<span class="m">24</span> {
                <span class="n">default</span>-<span class="n">router</span> <span class="m">192</span>.<span class="m">168</span>.<span class="m">42</span>.<span class="m">1</span>
                <span class="n">dns</span>-<span class="n">server</span> <span class="m">8</span>.<span class="m">8</span>.<span class="m">8</span>.<span class="m">8</span>
                <span class="n">dns</span>-<span class="n">server</span> <span class="m">8</span>.<span class="m">8</span>.<span class="m">4</span>.<span class="m">4</span>
                <span class="n">lease</span> <span class="m">86400</span>
                <span class="n">start</span> <span class="m">192</span>.<span class="m">168</span>.<span class="m">42</span>.<span class="m">10</span> {
                    <span class="n">stop</span> <span class="m">192</span>.<span class="m">168</span>.<span class="m">42</span>.<span class="m">100</span>
                }
            }
        }
    }
    <span class="n">dns</span> {
        <span class="n">forwarding</span> {
            <span class="n">cache</span>-<span class="n">size</span> <span class="m">150</span>
            <span class="n">listen</span>-<span class="n">on</span> <span class="n">eth1</span>
            <span class="n">listen</span>-<span class="n">on</span> <span class="n">eth2</span>
            <span class="n">name</span>-<span class="n">server</span> <span class="m">8</span>.<span class="m">8</span>.<span class="m">8</span>.<span class="m">8</span>
            <span class="n">name</span>-<span class="n">server</span> <span class="m">8</span>.<span class="m">8</span>.<span class="m">4</span>.<span class="m">4</span>
            <span class="n">options</span> <span class="n">server</span>=/<span class="n">dn42</span>/<span class="m">172</span>.<span class="m">23</span>.<span class="m">0</span>.<span class="m">53</span>
            <span class="n">options</span> <span class="n">server</span>=/<span class="m">22</span>.<span class="m">172</span>.<span class="n">in</span>-<span class="n">addr</span>.<span class="n">arpa</span>/<span class="m">172</span>.<span class="m">23</span>.<span class="m">0</span>.<span class="m">53</span>
            <span class="n">options</span> <span class="n">server</span>=/<span class="m">23</span>.<span class="m">172</span>.<span class="n">in</span>-<span class="n">addr</span>.<span class="n">arpa</span>/<span class="m">172</span>.<span class="m">23</span>.<span class="m">0</span>.<span class="m">53</span>
            <span class="n">options</span> <span class="n">rebind</span>-<span class="n">domain</span>-<span class="n">ok</span>=/<span class="n">dn42</span>/
        }
    }
    <span class="n">nat</span> {
        <span class="n">rule</span> <span class="m">6000</span> {
            <span class="n">outbound</span>-<span class="n">interface</span> <span class="n">pppoe0</span>
            <span class="n">type</span> <span class="n">masquerade</span>
        }
        <span class="n">rule</span> <span class="m">7000</span> {
            <span class="n">outbound</span>-<span class="n">interface</span> <span class="n">eth2</span>
            <span class="n">type</span> <span class="n">masquerade</span>
        }
    }
    <span class="n">ssh</span> {
        <span class="n">port</span> <span class="m">22</span>
        <span class="n">protocol</span>-<span class="n">version</span> <span class="n">v2</span>
    }
    <span class="n">upnp</span> {
        <span class="n">listen</span>-<span class="n">on</span> <span class="n">eth1</span> {
            <span class="n">outbound</span>-<span class="n">interface</span> <span class="n">pppoe0</span>
        }
        <span class="n">listen</span>-<span class="n">on</span> <span class="n">eth2</span> {
            <span class="n">outbound</span>-<span class="n">interface</span> <span class="n">pppoe0</span>
        }
    }
}
<span class="n">system</span> {
    <span class="n">host</span>-<span class="n">name</span> <span class="n">ubnt</span>
    <span class="n">login</span> {
        <span class="n">user</span> <span class="n">felicitus</span> {
            <span class="n">authentication</span> {
                <span class="n">encrypted</span>-<span class="n">password</span> <span class="n">errnope</span>
                <span class="n">plaintext</span>-<span class="n">password</span> <span class="s2">""</span>
                <span class="n">public</span>-<span class="n">keys</span> <span class="n">felicitus</span>@<span class="n">felicitus</span>.<span class="n">org</span> {
                    <span class="n">key</span> <span class="n">AAAAB3NzaC1yc2EAAAADAQABAAABAQDPTSLjSY</span>/<span class="n">Be1XJ</span>/<span class="n">klAwLiM1pKSvmbdcOgtgDB6nPcHkgX6JZu7g</span>/<span class="n">Kejfuk4qIKL8GYYUQt7DlGY6n2u5rChWE</span>/<span class="m">6</span><span class="n">KZJzXcUwS3pXk4LZ5KydWp7ihfvyRtUOBgKkRa1zQv</span>+<span class="m">6</span><span class="n">KCH9WyR</span>++<span class="n">ArwVTP8KSkrmDe6k7NWAjZqOuIJHG</span>/<span class="n">AbEyTBapTJYjObZ0AM7wlwcB</span>+<span class="n">oRM1BfZCP0Y</span>+<span class="n">PIP2eGJS7Pyb32pITNKk3JuFXgAvbj5OeRrwtpZ9S</span>+/<span class="m">7</span><span class="n">wIpaUVODPzrVmbC7vOXu</span>/<span class="m">2</span><span class="n">KJ9aY2BmxUsxRbrvWMmWNiuE0YPt</span>/<span class="m">7</span><span class="n">lUroK4pH3md3lWRcGUS</span>/<span class="n">uYvhug7yG1yB81nyI15</span>
                    <span class="n">type</span> <span class="n">ssh</span>-<span class="n">rsa</span>
                }
            }
            <span class="n">level</span> <span class="n">admin</span>
        }
    }
    <span class="n">name</span>-<span class="n">server</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">117</span>.<span class="m">254</span>
    <span class="n">ntp</span> {
        <span class="n">server</span> <span class="m">0</span>.<span class="n">ubnt</span>.<span class="n">pool</span>.<span class="n">ntp</span>.<span class="n">org</span> {
        }
        <span class="n">server</span> <span class="m">1</span>.<span class="n">ubnt</span>.<span class="n">pool</span>.<span class="n">ntp</span>.<span class="n">org</span> {
        }
        <span class="n">server</span> <span class="m">2</span>.<span class="n">ubnt</span>.<span class="n">pool</span>.<span class="n">ntp</span>.<span class="n">org</span> {
        }
        <span class="n">server</span> <span class="m">3</span>.<span class="n">ubnt</span>.<span class="n">pool</span>.<span class="n">ntp</span>.<span class="n">org</span> {
        }
    }
    <span class="n">syslog</span> {
        <span class="n">global</span> {
            <span class="n">facility</span> <span class="n">all</span> {
                <span class="n">level</span> <span class="n">notice</span>
            }
            <span class="n">facility</span> <span class="n">protocols</span> {
                <span class="n">level</span> <span class="n">debug</span>
            }
        }
    }
    <span class="n">time</span>-<span class="n">zone</span> <span class="n">UTC</span>
}
<span class="n">traffic</span>-<span class="n">policy</span> {
    <span class="n">shaper</span> <span class="n">client</span>-<span class="n">up</span>-<span class="n">s</span> {
        <span class="n">bandwidth</span> <span class="m">30</span><span class="n">kbit</span>
        <span class="n">class</span> <span class="m">20</span> {
            <span class="n">bandwidth</span> <span class="m">100</span>%
            <span class="n">burst</span> <span class="m">6</span><span class="n">k</span>
            <span class="n">match</span> <span class="n">TCPACK</span> {
                <span class="n">ip</span> {
                    <span class="n">protocol</span> <span class="n">tcp</span>
                }
                <span class="n">mark</span> <span class="m">225</span>
            }
            <span class="n">priority</span> <span class="m">5</span>
            <span class="n">queue</span>-<span class="n">limit</span> <span class="m">65</span>
            <span class="n">queue</span>-<span class="n">type</span> <span class="n">fair</span>-<span class="n">queue</span>
        }
        <span class="n">class</span> <span class="m">30</span> {
            <span class="n">bandwidth</span> <span class="m">5</span>%
            <span class="n">burst</span> <span class="m">15</span><span class="n">k</span>
            <span class="n">ceiling</span> <span class="m">20</span>%
            <span class="n">match</span> <span class="n">ssh</span> {
                <span class="n">ip</span> {
                    <span class="n">destination</span> {
                        <span class="n">port</span> <span class="m">22</span>
                    }
                    <span class="n">dscp</span> <span class="n">lowdelay</span>
                    <span class="n">protocol</span> <span class="n">tcp</span>
                }
            }
            <span class="n">match</span> <span class="n">ssh</span>-<span class="n">ipv6</span> {
                <span class="n">ipv6</span> {
                    <span class="n">destination</span> {
                        <span class="n">port</span> <span class="m">22</span>
                    }
                    <span class="n">protocol</span> <span class="n">tcp</span>
                }
            }
            <span class="n">priority</span> <span class="m">6</span>
            <span class="n">queue</span>-<span class="n">limit</span> <span class="m">10</span>
            <span class="n">queue</span>-<span class="n">type</span> <span class="n">fair</span>-<span class="n">queue</span>
        }
        <span class="n">default</span> {
            <span class="n">bandwidth</span> <span class="m">95</span>%
            <span class="n">burst</span> <span class="m">15</span><span class="n">k</span>
            <span class="n">ceiling</span> <span class="m">100</span>%
            <span class="n">priority</span> <span class="m">2</span>
            <span class="n">queue</span>-<span class="n">limit</span> <span class="m">13</span>
            <span class="n">queue</span>-<span class="n">type</span> <span class="n">fair</span>-<span class="n">queue</span>
        }
    }
}


/* <span class="n">Warning</span>: <span class="n">Do</span> <span class="n">not</span> <span class="n">remove</span> <span class="n">the</span> <span class="n">following</span> <span class="n">line</span>. */
/* === <span class="n">vyatta</span>-<span class="n">config</span>-<span class="n">version</span>: <span class="s2">"config-management@1:dhcp-relay@1:dhcp-server@4:firewall@4:ipsec@3:nat@3:qos@1:quagga@2:system@4:ubnt-pptp@1:ubnt-util@1:vrrp@1:webgui@1:webproxy@1:zone-policy@1"</span> === */
/* <span class="n">Release</span> <span class="n">version</span>: <span class="n">v1</span>.<span class="m">3</span>.<span class="m">0</span>.<span class="m">4605130</span>.<span class="m">131011</span>.<span class="m">1754</span> */</code></pre>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/EdgeOS-Config-Example.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/EdgeOS-Config-Example.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
