<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-309be032396e783b13a47df58f389b7c8e11c2b2d42640560b874f677c25f6e5.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">

  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/wireguard.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-f05401ee374f0c7f48fc2bc08e30b4f4db705861fd5895ed70998683b383bfb5.js" type="text/javascript"></script>
  

  <title>wireguard</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>wireguard</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/wireguard.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <a class="btn btn-sm" id="minibutton-home" href="/">
      Home
    </a>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/overview"
          id="minibutton-overview"
        >
          Overview
        </a>

        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/latest_changes"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </a>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          href="/gollum/history/howto/wireguard.md/"
          id="minibutton-history"
        >
          History
        </a>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    wireguard
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <p>To quote the <a href="https://www.wireguard.io/">homepage</a>:</p>

<blockquote>
<p>WireGuard is an extremely simple yet fast and modern VPN that utilizes state-of-the-art cryptography. It aims to be faster, simpler, leaner, and more useful than IPSec, while avoiding the massive headache. It intends to be considerably more performant than OpenVPN. WireGuard is designed as a general purpose VPN for running on embedded interfaces and super computers alike, fit for many different circumstances. Initially released for the Linux kernel, it plans to be cross-platform and widely deployable. It is currently under heavy development, but already it might be regarded as the most secure, easiest to use, and simplest VPN solution in the industry.</p>
</blockquote>

<h1><a class="anchor" id="example-configuration-for-dn42" href="#example-configuration-for-dn42"></a>Example configuration for dn42</h1>

<p>Wireguard is a Layer3 VPN. In theory it allows multiple peers to be served with one interface/port, but it does internal routing based on the peer's public key. This means you will need one interface per peering on dn42
to allow your BGP daemon instead to do routing. This approach is comparable to <a href="/howto/openvpn">OpenVPN p2p tunnels</a>.</p>

<p>First generate on each peer public and private keys.</p>

<pre class="highlight"><code>$ wg genkey | tee privatekey | wg pubkey &gt; publickey</code></pre>

<h2><a class="anchor" id="configuration" href="#configuration"></a>Configuration</h2>

<pre class="highlight"><code># tunnel.conf
[Interface]
PrivateKey = &lt;private_key&gt;
ListenPort = &lt;YOUR_LOCAL_UDP_PORT&gt;

[Peer]
PublicKey = &lt;public_key_of_your_peer&gt;
# OPTIONAL, its also possible to define a pre-shared key for additional security
PresharedKey = &lt;pre-shared key&gt;
# at least one peer needs to provide this one
Endpoint = &lt;end_point_hostname_or_ip:port&gt;
# in theory this could be restricted to dn42 networks,
# however it is easier to do this with iptables/bgp filters/routing table 
# instead just like for openvpn-based peerings
AllowedIPs = 0.0.0.0/0,::/0</code></pre>

<h2><a class="anchor" id="configure-tunnel" href="#configure-tunnel"></a>Configure tunnel:</h2>

<p>Wireguard comes with its own interface type. 
It supports link-local addresses for IPv6 and single /32 addresses for IPv4, which can be used for peering.</p>

<pre class="highlight"><code>$ ip link add dev &lt;interface_name&gt; type wireguard
$ wg setconf &lt;interface_name&gt; tunnel.conf
# both side pick a different link-local ipv6 address
$ ip addr add fe80::&lt;some_random_suffix&gt;/64 dev &lt;interface_name&gt;
# choose the first ip from your subnet and the second one from the peer
$ ip addr add 172.xx.xx.xx/32 peer 172.xx.xx.xx/32 dev &lt;interface_name&gt;
$ ip link set &lt;interface_name&gt; up</code></pre>



<p>Maybe you should check the MTU to your peer with e.g. <code>ping -s 1472 &lt;end_point_hostname_or_ip&gt;</code>. If your output looks like <code>From gateway.local (192.168.0.1) icmp_seq=1 Frag needed and DF set (mtu = 1440)</code> substract <code>80</code> from the MTU and set it via <code>ip link set dev &lt;interface_name&gt; mtu &lt;calculated_mtu&gt;</code></p>

<h2><a class="anchor" id="testing" href="#testing"></a>Testing</h2>

<pre class="highlight"><code>ping fe80::&lt;your_peers_suffix&gt;%&lt;interface_name&gt;</code></pre>

<p>(For older iputils, use <code>ping6</code>.)</p>

<p>Afterwards configure your <a href="/howto/Bird">BGP session</a> as usual</p>

<h2><a class="anchor" id="debugging" href="#debugging"></a>Debugging</h2>

<p>The wireguard kernel module on linux has support for enabling dynamic debugging. This can be useful to help track down some problems, e.g. if public keys don't match. </p>

<p>Debug messages are logged via dmesg and can be enabled using:</p>

<pre class="highlight"><code><span class="nv">$ </span><span class="nb">echo</span> <span class="s1">'module wireguard +p'</span> <span class="o">&gt;</span> /sys/kernel/debug/dynamic_debug/control</code></pre>

<p>To disable debug:</p>

<pre class="highlight"><code><span class="nv">$ </span><span class="nb">echo</span> <span class="s1">'module wireguard -p'</span> <span class="o">&gt;</span> /sys/kernel/debug/dynamic_debug/control</code></pre>

<h2><a class="anchor" id="wg-quick" href="#wg-quick"></a>wg-quick</h2>

<p><a href="https://git.zx2c4.com/wireguard-tools/about/src/man/wg-quick.8">wg-quick</a> is a script that is shipped with Wireguard to help users bring up tunnels in some common use cases. </p>

<blockquote>
<p>It is designed for users with simple needs, and users with more advanced needs are highly encouraged to use a more specific tool, a more complete network manager, or otherwise just use wg(8) and ip(8), as usual.</p>
</blockquote>

<p>The script makes some changes that are not valid when used for DN42 tunnels, and which must be worked around:</p>

<ul>
<li>
<p>By default, the script will add a routing policy that routes the 'AllowedIP' ranges through the tunnel. In DN42, route selection is managed by BGP so the routing policy <em>must</em> be removed to avoid problems. This is achieved by adding the '<em>Table = off</em>' directive. </p>

<ul>
<li><strong>Warning: a common pattern for DN42 tunnels is to use <code>AllowedIPs = 0.0.0.0/0</code> or <code>AllowedIPs = ::/0</code> then use firewall rules to limit source and destination addresses. If you do not add 'Table = off' this could cause you to route clearnet traffic via your peer and potentially lose connectivity to your node!</strong></li>
</ul>
</li>
<li><p>It is common in DN42 to use Point-to-Point addressing schemes on tunnel interfaces (that is, using IPv4/32 and IPv6/128 addresses); this is not supported by wg-quick. To configure PTP addresses you must add a '<em>PostUp</em>' statement. On Linux, this will typically be done using <code>ip</code> from <code>iproute2</code>.</p></li>
</ul>

<p>An example wg-quick script that incorporates the above two workarounds is below, where <code>&lt;MyIPv[46]&gt;</code> are the DN42 IP addresses of your node and <code>&lt;PeerIPv[46]&gt;</code> are the IP addresses for your peer. </p>

<p></p><pre class="highlight"><code>[Interface]
PrivateKey = &lt;your private key&gt;
Address = &lt;your link-local address, if any&gt;
PostUp = /sbin/ip addr add dev %i &lt;MyIPv4&gt;/32 peer &lt;PeerIPv4&gt;/32
PostUp = /sbin/ip addr add dev %i &lt;MyIPv6&gt;/128 peer &lt;PeerIPv6&gt;/128
Table = off

[Peer]
Endpoint = &lt;your peer's wireguard endpoint&gt;
PublicKey = &lt;your peer's public key&gt;
AllowedIPs = 172.16.0.0/12, 10.0.0.0/8, fd00::/8, fe80::/10</code></pre>
Use <code>which ip</code> to get the full path to your ip binary.

<h2><a class="anchor" id="systemd-networkd" href="#systemd-networkd"></a>systemd-networkd</h2>

<p>Example configuration for systemd-networkd.</p>

<p>peer.netdev
</p><pre class="highlight"><code>[NetDev]
Name=&lt;ifname&gt;
Kind=wireguard

[WireGuard]
PrivateKey=&lt;your private key&gt;
ListenPort=&lt;your listen port&gt;

[WireGuardPeer]
PublicKey=&lt;peer public key&gt;
# OPTIONAL, pre-shared key
PresharedKey=&lt;pre-shared key&gt;
Endpoint=&lt;peer host and port, e.g. 1.2.3.4:9876&gt;
AllowedIPs=fe80::/64
AllowedIPs=fd00::/8
AllowedIPs=0.0.0.0/0</code></pre>

<p>peer.network
</p><pre class="highlight"><code>[Match]
Name=&lt;ifname&gt;

[Network]
DHCP=no
IPv6AcceptRA=false
IPForward=yes

# for networkd &gt;= 244 KeepConfiguration stops networkd from
# removing routes on this interface when restarting
KeepConfiguration=yes

# for networkd &lt; 244 the CriticalConnection parameter achieves
# the same thing
[DHCP]
CriticalConnection=true

# if using link local addresses for peering
[Address]
Address=fe80::xx:xx:xx:xx/64

# if using IPv6 point to point
[Address]
Address=&lt;your ipv6 address&gt;/128
Peer=&lt;your peer's IPv6 address&gt;/128

# IPv4 point to point
[Address]
Address=&lt;your IPv4 address&gt;/32
Peer=&lt;your peer's IPv4 address&gt;/32</code></pre>

<h2><a class="anchor" id="dynamics-ip" href="#dynamics-ip"></a>Dynamics IP</h2>

<p>As wireguard are only resolving the hostname to IP only on start, dynamics DNS will stop working after a while without further configuration. The Following is a <a href="https://github.com/WireGuard/wireguard-tools/blob/master/contrib/reresolve-dns/reresolve-dns.sh">script</a> from wireguard which will "re-resolve" the DNS and update the wireguard. </p>

<p>You can add cron entries to periodically  "re-resolve" the DNS:
</p><pre class="highlight"><code>* * * * * /path-to-the-script/reresolve-dns.sh</code></pre>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
<li>
<a href="/Home" rel="nofollow">Home</a>

<ul>
<li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
<li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
<li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
<li><a href="/howto/Bird-communities" rel="nofollow">BGP communities</a></li>
<li><a href="/FAQ" rel="nofollow">FAQ</a></li>
</ul>
</li>
</ul>

<ul>
<li>
<p>How-To</p>

<ul>
<li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
<li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
<li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
<li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
<li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
<li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
<li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
<li>
<a href="/howto/Bird" rel="nofollow">Bird</a> / <a href="/howto/Bird2" rel="nofollow">Bird2</a>
</li>
<li><a href="/howto/Quagga" rel="nofollow">Quagga</a></li>
<li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
<li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
<li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
<li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
<li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
<li>
<a href="/howto/vyos" rel="nofollow">VyOS</a> / <a href="/howto/vyos1.4.x" rel="nofollow">VyOS 1.4.x</a>
</li>
<li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
</ul>
</li>
<li>
<p>Services</p>

<ul>
<li><a href="/services/IRC" rel="nofollow">IRC</a></li>
<li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
<li><a href="/services/DNS" rel="nofollow">DNS</a></li>
<li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
<li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
<li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
<li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
<li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
<li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
<li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
</ul>
</li>
<li>
<p>Internal</p>

<ul>
<li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
<li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
<li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
<li>
<a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a><br />
</li>
<li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
</ul>
</li>
<li>
<p>External Tools</p>

<ul>
<li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
<li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
</ul>
</li>
</ul>

<hr />

	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p>Hosted by: <a href="mailto:xuu@sour.is" rel="nofollow">xuu</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">nurtic-vibe</a>, <a href="mailto:tom@xcv.vc" rel="nofollow">toBee</a>, <a href="mailto:dn42@burble.com" rel="nofollow">burble</a> | Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a></p>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/wireguard.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/wireguard.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
