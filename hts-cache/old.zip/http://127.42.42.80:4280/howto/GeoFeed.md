<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/GeoFeed.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>GeoFeed</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>GeoFeed</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/GeoFeed.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/GeoFeed.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    GeoFeed
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="geofeed" href="#geofeed"></a>GeoFeed</h1>

<p>A <strong>GeoFeed</strong> is a standardized mechanism for publishing geographic location information about IP address prefixes, helping associate IP blocks with real-world locations for better geolocation accuracy, latency mapping, and network topology documentation.</p>

<h2><a class="anchor" id="standards" href="#standards"></a>Standards</h2>

<table>
  <thead>
    <tr>
      <th>RFC</th>
      <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><a href="https://www.rfc-editor.org/rfc/rfc8805">RFC 8805</a></td>
      <td>Defines the CSV-based GeoFeed file format</td>
    </tr>
    <tr>
      <td><a href="https://www.rfc-editor.org/rfc/rfc9632">RFC 9632</a></td>
      <td>Specifies referencing GeoFeeds from RPSL objects via <code>geofeed:</code> attribute</td>
    </tr>
    <tr>
      <td><a href="https://www.rfc-editor.org/rfc/rfc9877">RFC 9877</a></td>
      <td>RDAP extension for automated GeoFeed discovery</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="file-format" href="#file-format"></a>File Format</h2>

<p>A UTF-8 CSV file with the following fields:</p>

<pre class="highlight"><span class="err"># prefix,country_code,region_code,city,postal
172.20.0.0/24,FR,FR-ARA,Lyon,69123
fd42:1234::/48,FR,,,</span></pre>

<p>Fields follow <a href="https://en.wikipedia.org/wiki/ISO_3166">ISO 3166</a> conventions. Unused fields may be left empty.</p>

<h2><a class="anchor" id="publishing-on-dn42" href="#publishing-on-dn42"></a>Publishing on DN42</h2>

<ol>
  <li>
<strong>Host the file</strong> - Serve your GeoFeed over HTTP/HTTPS. <strong>Hosting within DN42 is strongly recommended</strong> so that the file remains accessible to all DN42 participants regardless of public internet connectivity, and to keep DN42 infrastructure self-contained.</li>
  <li>
<strong>Reference in the registry</strong> - Add a <code>geofeed:</code> attribute to your <code>inetnum</code> and <code>inet6num</code> objects:</li>
</ol>

<pre class="highlight"><span class="err">inetnum:    172.20.0.0/24
geofeed:    http://example.dn42/geofeed.csv</span></pre>

<blockquote>
  <p>⚠️ Hosting your GeoFeed on the public internet means it may be unreachable to peers who access DN42 exclusively through the internal network. Always prefer a DN42-reachable URL.</p>
</blockquote>

<h2><a class="anchor" id="best-practices" href="#best-practices"></a>Best Practices</h2>

<ul>
  <li>Ensure the URL remains reachable and update the registry if it changes</li>
  <li>Maintain consistent node names and clear comments for easier automation and identification</li>
  <li>Keep locations accurate</li>
  <li>Store your GeoFeed in version control (e.g., Git) for easier management</li>
</ul>

<h2><a class="anchor" id="further-reading" href="#further-reading"></a>Further Reading</h2>

<ul>
  <li><a href="https://ripe82.ripe.net/presentations/84-RIPE82_geofeed.pdf">RIPE 82 GeoFeed presentation</a></li>
</ul>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/GeoFeed.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/GeoFeed.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
