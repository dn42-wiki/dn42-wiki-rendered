<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/EdgeOS-GRE-IPsec-Example.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>EdgeOS-GRE-IPsec-Example</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>EdgeOS-GRE-IPsec-Example</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/EdgeOS-GRE-IPsec-Example.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/EdgeOS-GRE-IPsec-Example.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    EdgeOS-GRE-IPsec-Example
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="edgeos-gre-ipsec-config-example" href="#edgeos-gre-ipsec-config-example"></a>EdgeOS GRE/IPsec config example</h1>
<p>This is an example configuration derived from the config used on a peering router in AS64746. It was created using EdgeOS version 1.5.0alpha1 on an EdgeRouter Lite.</p>

<h2><a class="anchor" id="features" href="#features"></a>Features</h2>
<ul>
  <li>Zone-based firewall</li>
  <li>BGP prefix filtering and route summarization</li>
  <li>GRE/IPsec tunnel in transport mode with "plainrsa" public key authentication</li>
  <li>TCP MSS clamping to avoid fragmentation</li>
</ul>

<h2><a class="anchor" id="setup" href="#setup"></a>Setup</h2>
<p>This configuration assumes that both peers have static public IPs.</p>

<p>You'll need to generate a public/private keypair for your router if you intend to use "plainrsa" authentication for your IPsec connections. The local public key listed in the output is what you'll send to your peer.</p>

<pre class="highlight"><code>ryan@edge1:~<span class="nv">$ </span>generate vpn rsa-key bits 4096
ryan@edge1:~<span class="nv">$ </span>show vpn ike rsa-keys

Local public key <span class="o">(</span>/config/ipsec.d/rsa-keys/localhost.key<span class="o">)</span>:

0sAQPNdF370ZEbN+kZUJQ10qnBlZujrg39ujfk20ILTjELksOIdJw/4jiU1MfpqFDKuB/XxERwJQp2POsFyV/n76jAgxIYBfFYfuaBcIH1rdNQtDhCnkmWzlueRXGEsz0Af79n8TKyQ9otzNhJ2cPE1CWCJbKqbIUN3piviLgGlItWNeya+Tl3Oj3ZfEVwr1QOvUAw32+m4L8T9jf1vqSlOTHpRpxxPWBrLEzstk0FOcZISji2JBpDOCU8Kpyyf74JM+LxsOIHwmS15b6iFZR3U9KZLqbbd0dSy/cM8P4XjrwM5UMyRDjrLqvuA/K/33BgtnxdQR3e9DJoYH3Qr8eRgSkR+jHyq06LvgHkHbMvrEjUnc3n8bg+YfR4oyJpIWsKjfIXmN1Q51KzxAPIAww+YSYUYtamSsQsspVAtMIQqR4e0r1In1qyoSn8VCPlksNMWpqYHbSjDo5HJYoSwxf2epzMtCvhenn0OuiH0xlgzziA+wBi6txksTMvJYcPJYnBVR2NIBjkWftOfmkY+rKMozViGjyd6kB7C8lqd8W7Ha5Ds2WxIY22DM3HcYH/zTp9z2xbuMOsbIgib/Y12Kh0wHyCz0lzFvs+d6CZwinyIXNKB/Vo4iiwT5luL5mGqf3pZx4zB+30GYSs/6MaELRF9BxD7tfqYCkOLXUtxyZ4Pdl2sw<span class="o">==</span></code></pre>

<p>If your peer sends you a key in PEM format (starts with <code>-----BEGIN PUBLIC KEY-----</code>), you'll need to convert it to the format used by EdgeOS (begins with <code>0s</code>) in order to insert it into the configuration. See <a href="http://community.ubnt.com/t5/EdgeMAX/ERL-lt-gt-Mikrotik-IPsec-Connections/m-p/534682#M13015">this forum post</a> for a script to convert between the two key formats.</p>

<h2><a class="anchor" id="configuration" href="#configuration"></a>Configuration</h2>

<pre class="highlight"><code>  <span class="n">firewall</span> {
      <span class="n">all</span>-<span class="n">ping</span> <span class="n">enable</span>
      <span class="n">broadcast</span>-<span class="n">ping</span> <span class="n">disable</span>
      <span class="n">ipv6</span>-<span class="n">receive</span>-<span class="n">redirects</span> <span class="n">disable</span>
      <span class="n">ipv6</span>-<span class="n">src</span>-<span class="n">route</span> <span class="n">disable</span>
      <span class="n">ip</span>-<span class="n">src</span>-<span class="n">route</span> <span class="n">disable</span>
      <span class="n">log</span>-<span class="n">martians</span> <span class="n">enable</span>
      <span class="n">name</span> <span class="n">DN42</span>-<span class="n">to</span>-<span class="n">Local</span> {
          <span class="n">default</span>-<span class="n">action</span> <span class="n">reject</span>
          <span class="n">rule</span> <span class="m">10</span> {
              <span class="n">action</span> <span class="n">accept</span>
              <span class="n">description</span> <span class="n">Established</span>/<span class="n">Related</span>
              <span class="n">state</span> {
                  <span class="n">established</span> <span class="n">enable</span>
                  <span class="n">related</span> <span class="n">enable</span>
              }
          }
          <span class="n">rule</span> <span class="m">20</span> {
              <span class="n">action</span> <span class="n">accept</span>
              <span class="n">description</span> <span class="n">ICMP</span>
              <span class="n">protocol</span> <span class="n">icmp</span>
          }
          <span class="n">rule</span> <span class="m">30</span> {
              <span class="n">action</span> <span class="n">accept</span>
              <span class="n">description</span> <span class="n">BGP</span>
              <span class="n">destination</span> {
                  <span class="n">port</span> <span class="n">bgp</span>
              }
              <span class="n">protocol</span> <span class="n">tcp</span>
              <span class="n">state</span> {
                  <span class="n">new</span> <span class="n">enable</span>
              }
              <span class="n">tcp</span> {
                  <span class="n">flags</span> <span class="n">SYN</span>,!<span class="n">ACK</span>,!<span class="n">FIN</span>,!<span class="n">RST</span>
              }
          }
      }
      <span class="n">name</span> <span class="n">DN42</span>-<span class="n">to</span>-<span class="n">LAN</span> {
          <span class="n">default</span>-<span class="n">action</span> <span class="n">reject</span>
          <span class="n">rule</span> <span class="m">10</span> {
              <span class="n">action</span> <span class="n">accept</span>
              <span class="n">description</span> <span class="n">Established</span>/<span class="n">Related</span>
              <span class="n">state</span> {
                  <span class="n">established</span> <span class="n">enable</span>
                  <span class="n">related</span> <span class="n">enable</span>
              }
          }
          <span class="n">rule</span> <span class="m">20</span> {
              <span class="n">action</span> <span class="n">accept</span>
              <span class="n">description</span> <span class="n">ICMP</span>
              <span class="n">protocol</span> <span class="n">icmp</span>
          }
      }
      <span class="n">name</span> <span class="n">WAN</span>-<span class="n">to</span>-<span class="n">Local</span> {
          <span class="n">default</span>-<span class="n">action</span> <span class="n">drop</span>
          <span class="n">rule</span> <span class="m">10</span> {
              <span class="n">action</span> <span class="n">accept</span>
              <span class="n">description</span> <span class="n">Established</span>/<span class="n">Related</span>
              <span class="n">state</span> {
                  <span class="n">established</span> <span class="n">enable</span>
                  <span class="n">related</span> <span class="n">enable</span>
              }
          }
          <span class="n">rule</span> <span class="m">20</span> {
              <span class="n">action</span> <span class="n">accept</span>
              <span class="n">description</span> <span class="n">ICMP</span>
              <span class="n">protocol</span> <span class="n">icmp</span>
          }
          <span class="n">rule</span> <span class="m">30</span> {
              <span class="n">action</span> <span class="n">accept</span>
              <span class="n">description</span> <span class="s2">"SSH Management"</span>
              <span class="n">destination</span> {
                  <span class="n">port</span> <span class="m">22</span>
              }
              <span class="n">protocol</span> <span class="n">tcp</span>
              <span class="n">state</span> {
                  <span class="n">new</span> <span class="n">enable</span>
              }
              <span class="n">tcp</span> {
                  <span class="n">flags</span> <span class="n">SYN</span>,!<span class="n">ACK</span>,!<span class="n">FIN</span>,!<span class="n">RST</span>
              }
          }
          <span class="n">rule</span> <span class="m">40</span> {
              <span class="n">action</span> <span class="n">accept</span>
              <span class="n">description</span> <span class="n">IKE</span>
              <span class="n">destination</span> {
                  <span class="n">port</span> <span class="m">500</span>,<span class="m">4500</span>
              }
              <span class="n">protocol</span> <span class="n">udp</span>
          }
          <span class="n">rule</span> <span class="m">50</span> {
              <span class="n">action</span> <span class="n">accept</span>
              <span class="n">description</span> <span class="n">IPSEC</span>/<span class="n">ESP</span>
              <span class="n">protocol</span> <span class="n">esp</span>
          }
          <span class="n">rule</span> <span class="m">60</span> {
              <span class="n">action</span> <span class="n">accept</span>
              <span class="n">description</span> <span class="s2">"GRE over IPsec"</span>
              <span class="n">ipsec</span> {
                  <span class="n">match</span>-<span class="n">ipsec</span>
              }
              <span class="n">protocol</span> <span class="n">gre</span>
          }
      }
      <span class="n">name</span> <span class="n">established</span>-<span class="n">only</span> {
          <span class="n">default</span>-<span class="n">action</span> <span class="n">drop</span>
          <span class="n">rule</span> <span class="m">10</span> {
              <span class="n">action</span> <span class="n">accept</span>
              <span class="n">description</span> <span class="n">Established</span>/<span class="n">Related</span>
              <span class="n">state</span> {
                  <span class="n">established</span> <span class="n">enable</span>
                  <span class="n">related</span> <span class="n">enable</span>
              }
          }
      }
      <span class="n">name</span> <span class="n">allow</span>-<span class="n">all</span>-<span class="n">v4</span> {
          <span class="n">default</span>-<span class="n">action</span> <span class="n">accept</span>
      }
      <span class="n">options</span> {
          <span class="n">mss</span>-<span class="n">clamp</span> {
              <span class="n">interface</span>-<span class="n">type</span> <span class="n">tun</span>
              <span class="n">mss</span> <span class="m">1300</span>
          }
      }
      <span class="n">receive</span>-<span class="n">redirects</span> <span class="n">disable</span>
      <span class="n">send</span>-<span class="n">redirects</span> <span class="n">enable</span>
      <span class="n">source</span>-<span class="n">validation</span> <span class="n">disable</span>
      <span class="n">syn</span>-<span class="n">cookies</span> <span class="n">enable</span>
  }
  <span class="n">interfaces</span> {
      <span class="n">ethernet</span> <span class="n">eth0</span> {
          <span class="n">address</span> <span class="m">192</span>.<span class="m">0</span>.<span class="m">2</span>.<span class="m">2</span>/<span class="m">30</span>
          <span class="n">description</span> <span class="n">WAN</span>
          <span class="n">duplex</span> <span class="n">auto</span>
          <span class="n">speed</span> <span class="n">auto</span>
      }
      <span class="n">ethernet</span> <span class="n">eth1</span> {
          <span class="n">address</span> <span class="m">172</span>.<span class="m">23</span>.<span class="m">248</span>.<span class="m">33</span>/<span class="m">27</span>
          <span class="n">description</span> <span class="n">LAN</span>
          <span class="n">duplex</span> <span class="n">auto</span>
          <span class="n">speed</span> <span class="n">auto</span>
      }
      <span class="n">ethernet</span> <span class="n">eth2</span> {
          <span class="n">disable</span>
          <span class="n">duplex</span> <span class="n">auto</span>
          <span class="n">speed</span> <span class="n">auto</span>
      }
      <span class="n">loopback</span> <span class="n">lo</span> {
          <span class="n">address</span> <span class="m">172</span>.<span class="m">23</span>.<span class="m">248</span>.<span class="m">2</span>/<span class="m">32</span>
      }
      <span class="n">tunnel</span> <span class="n">tun0</span> {
          <span class="n">address</span> <span class="m">172</span>.<span class="m">23</span>.<span class="m">248</span>.<span class="m">10</span>/<span class="m">31</span>
          <span class="n">description</span> <span class="s2">"CREST-DN42 AS64828"</span>
          <span class="n">encapsulation</span> <span class="n">gre</span>
          <span class="n">local</span>-<span class="n">ip</span> <span class="m">192</span>.<span class="m">0</span>.<span class="m">2</span>.<span class="m">2</span>
          <span class="n">mtu</span> <span class="m">1400</span>
          <span class="n">multicast</span> <span class="n">disable</span>
          <span class="n">remote</span>-<span class="n">ip</span> <span class="m">192</span>.<span class="m">0</span>.<span class="m">2</span>.<span class="m">243</span>
          <span class="n">ttl</span> <span class="m">255</span>
      }
  }
  <span class="n">policy</span> {
      <span class="n">prefix</span>-<span class="n">list</span> <span class="n">AS64746</span>-<span class="n">IPv4</span> {
          <span class="n">rule</span> <span class="m">1</span> {
              <span class="n">action</span> <span class="n">permit</span>
              <span class="n">le</span> <span class="m">32</span>
              <span class="n">prefix</span> <span class="m">172</span>.<span class="m">23</span>.<span class="m">248</span>.<span class="m">0</span>/<span class="m">24</span>
          }
      }
      <span class="n">prefix</span>-<span class="n">list</span> <span class="n">DN42</span>-<span class="n">IPv4</span> {
          <span class="n">rule</span> <span class="m">1</span> {
              <span class="n">action</span> <span class="n">permit</span>
              <span class="n">description</span> <span class="s2">"DN42 native"</span>
              <span class="n">ge</span> <span class="m">23</span>
              <span class="n">le</span> <span class="m">28</span>
              <span class="n">prefix</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">0</span>.<span class="m">0</span>/<span class="m">15</span>
          }
          <span class="n">rule</span> <span class="m">2</span> {
              <span class="n">action</span> <span class="n">permit</span>
              <span class="n">description</span> <span class="s2">"DN42 anycast"</span>
              <span class="n">ge</span> <span class="m">32</span>
              <span class="n">prefix</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">0</span>.<span class="m">0</span>/<span class="m">24</span>
          }
          <span class="n">rule</span> <span class="m">3</span> {
              <span class="n">action</span> <span class="n">permit</span>
              <span class="n">description</span> <span class="n">Freifunk</span>
              <span class="n">ge</span> <span class="m">16</span>
              <span class="n">prefix</span> <span class="m">10</span>.<span class="m">0</span>.<span class="m">0</span>.<span class="m">0</span>/<span class="m">8</span>
          }
          <span class="n">rule</span> <span class="m">4</span> {
              <span class="n">action</span> <span class="n">permit</span>
              <span class="n">description</span> <span class="n">ChaosVPN</span>
              <span class="n">ge</span> <span class="m">23</span>
              <span class="n">prefix</span> <span class="m">172</span>.<span class="m">31</span>.<span class="m">0</span>.<span class="m">0</span>/<span class="m">16</span>
          }
      }
      <span class="n">route</span>-<span class="n">map</span> <span class="n">AS64746</span> {
          <span class="n">rule</span> <span class="m">1</span> {
              <span class="n">action</span> <span class="n">permit</span>
              <span class="n">match</span> {
                  <span class="n">ip</span> {
                      <span class="n">address</span> {
                          <span class="n">prefix</span>-<span class="n">list</span> <span class="n">AS64746</span>-<span class="n">IPv4</span>
                      }
                  }
              }
          }
      }
      <span class="n">route</span>-<span class="n">map</span> <span class="n">DN42</span> {
          <span class="n">rule</span> <span class="m">1</span> {
              <span class="n">action</span> <span class="n">permit</span>
              <span class="n">match</span> {
                  <span class="n">ip</span> {
                      <span class="n">address</span> {
                          <span class="n">prefix</span>-<span class="n">list</span> <span class="n">DN42</span>-<span class="n">IPv4</span>
                      }
                  }
              }
          }
      }
  }
  <span class="n">protocols</span> {
      <span class="n">bgp</span> <span class="m">64746</span> {
          <span class="n">aggregate</span>-<span class="n">address</span> <span class="m">172</span>.<span class="m">23</span>.<span class="m">248</span>.<span class="m">0</span>/<span class="m">24</span> {
              <span class="n">summary</span>-<span class="n">only</span>
          }
          <span class="n">neighbor</span> <span class="m">172</span>.<span class="m">23</span>.<span class="m">248</span>.<span class="m">11</span> {
              <span class="n">description</span> <span class="n">CREST</span>-<span class="n">DN42</span>
              <span class="n">peer</span>-<span class="n">group</span> <span class="n">DN42</span>
              <span class="n">remote</span>-<span class="n">as</span> <span class="m">64828</span>
              <span class="n">update</span>-<span class="n">source</span> <span class="m">172</span>.<span class="m">23</span>.<span class="m">248</span>.<span class="m">10</span>
          }
          <span class="n">network</span> <span class="m">172</span>.<span class="m">23</span>.<span class="m">248</span>.<span class="m">0</span>/<span class="m">24</span> {
          }
          <span class="n">parameters</span> {
              <span class="n">router</span>-<span class="n">id</span> <span class="m">172</span>.<span class="m">23</span>.<span class="m">248</span>.<span class="m">2</span>
          }
          <span class="n">peer</span>-<span class="n">group</span> <span class="n">DN42</span> {
              <span class="n">route</span>-<span class="n">map</span> {
                  <span class="n">export</span> <span class="n">DN42</span>
                  <span class="n">import</span> <span class="n">DN42</span>
              }
              <span class="n">soft</span>-<span class="n">reconfiguration</span> {
                  <span class="n">inbound</span>
              }
          }
          <span class="n">redistribute</span> {
              <span class="n">connected</span> {
                  <span class="n">route</span>-<span class="n">map</span> <span class="n">AS64746</span>
              }
          }
      }
      <span class="n">static</span> {
          <span class="n">route</span> <span class="m">0</span>.<span class="m">0</span>.<span class="m">0</span>.<span class="m">0</span>/<span class="m">0</span> {
              <span class="n">next</span>-<span class="n">hop</span> <span class="m">192</span>.<span class="m">0</span>.<span class="m">2</span>.<span class="m">1</span> {
              }
          }
          <span class="n">route</span> <span class="m">172</span>.<span class="m">23</span>.<span class="m">248</span>.<span class="m">0</span>/<span class="m">24</span> {
              <span class="n">blackhole</span> {
                  <span class="n">distance</span> <span class="m">255</span>
              }
          }
      }
  }
  <span class="n">service</span> {
      <span class="n">nat</span> {
          <span class="n">rule</span> <span class="m">6000</span> {
              <span class="n">outbound</span>-<span class="n">interface</span> <span class="n">eth0</span>
              <span class="n">type</span> <span class="n">masquerade</span>
          }
      }
      <span class="n">ssh</span> {
          <span class="n">disable</span>-<span class="n">password</span>-<span class="n">authentication</span>
          <span class="n">port</span> <span class="m">22</span>
          <span class="n">protocol</span>-<span class="n">version</span> <span class="n">v2</span>
      }
      <span class="n">ubnt</span>-<span class="n">discover</span> {
          <span class="n">disable</span>
      }
  }
  <span class="n">system</span> {
      <span class="n">config</span>-<span class="n">management</span> {
          <span class="n">commit</span>-<span class="n">revisions</span> <span class="m">10</span>
      }
      <span class="n">domain</span>-<span class="n">name</span> <span class="n">ryan</span>.<span class="n">dn42</span>
      <span class="n">host</span>-<span class="n">name</span> <span class="n">edge1</span>
      <span class="n">login</span> {
          <span class="n">banner</span> {
              <span class="n">pre</span>-<span class="n">login</span> <span class="s2">""</span>
          }
          <span class="n">user</span> <span class="n">ryan</span> {
              <span class="n">authentication</span> {
                  <span class="n">encrypted</span>-<span class="n">password</span> :)
                  <span class="n">public</span>-<span class="n">keys</span> <span class="n">ryan</span> {
                      <span class="n">key</span> <span class="n">AAAAB3NzaC1yc2EAAAADAQABAAACAQCymzCbuc777hZ8acvK</span>+<span class="m">68</span><span class="n">tB7WlZl9V8rQjeQCHny2f9Fy2uSnDHXymUzQJSBY8dr4QM07owCFyYciYqhJRBeBRiaP1dj6avzZzlrOC2xuXSWw4aCYVkEaBPWkntCvBjmPhtvA</span>+<span class="n">x5w8qm0X</span>+<span class="n">B41DG1D44qzrQSmL5geheQCHWSf48Za6RUvPxPuQ</span>+<span class="n">xfBMlIaWscRn95NST2102sYwfl3GDJEqV8FqZ5gQeuG3LDRBQmVEZOSMFIN0pOrp6</span>+<span class="n">UYDe6LSw8eD3uBNrkfbbwwEqjHKFNuYaIw</span>/<span class="n">XNdY0nqhHec0KjsuPLHTQMc44h8CPL5ytAtjF1WnPAE4e3aDQFnB05V</span>/<span class="m">3</span><span class="n">GThJI010bNkLw5zbGkq0QUa7SmFfAsyOg50grByqZWY</span>/<span class="n">J997HXjWdsgK</span>+<span class="m">7</span><span class="n">d3K4VQXlI1Uak6G2i0Vb5KX0Xv6dmFmsqwuomeGozBJOl3YebvHI</span>/<span class="m">39</span><span class="n">Y1VcZls2Zkjg4dBWJQGhsZv8wAX8bf7owtLPE</span>+<span class="n">PcWvX5dRmk44r93mk1M1PTz7XAJGXfeii</span>/<span class="n">OV</span>+<span class="n">QRZZkbzhi3h7VItF5Yv5nptMQUx</span>+<span class="n">irUrIX3gaTHOu8cMTxtP52kIOGOEN</span>/<span class="n">LmYbmrdc</span>++<span class="n">QJNGGadopuZBDpCiR2xQhwQL5yKaXH6Rdenn9d0mdNTzdqw5QOUfjY</span>+<span class="n">SqTMDqLk</span>+<span class="n">ETY</span>+<span class="n">YZ6fvJYDIm4yfgi</span>//<span class="n">Q</span>==
                      <span class="n">type</span> <span class="n">ssh</span>-<span class="n">rsa</span>
                  }
              }
              <span class="n">level</span> <span class="n">admin</span>
          }
      }
      <span class="n">name</span>-<span class="n">server</span> <span class="m">4</span>.<span class="m">2</span>.<span class="m">2</span>.<span class="m">2</span>
      <span class="n">name</span>-<span class="n">server</span> <span class="m">8</span>.<span class="m">8</span>.<span class="m">8</span>.<span class="m">8</span>
      <span class="n">ntp</span> {
          <span class="n">server</span> <span class="m">0</span>.<span class="n">ubnt</span>.<span class="n">pool</span>.<span class="n">ntp</span>.<span class="n">org</span> {
          }
          <span class="n">server</span> <span class="m">1</span>.<span class="n">ubnt</span>.<span class="n">pool</span>.<span class="n">ntp</span>.<span class="n">org</span> {
          }
          <span class="n">server</span> <span class="m">2</span>.<span class="n">ubnt</span>.<span class="n">pool</span>.<span class="n">ntp</span>.<span class="n">org</span> {
          }
          <span class="n">server</span> <span class="m">3</span>.<span class="n">ubnt</span>.<span class="n">pool</span>.<span class="n">ntp</span>.<span class="n">org</span> {
          }
      }
      <span class="n">offload</span> {
          <span class="n">ipsec</span> <span class="n">enable</span>
          <span class="n">ipv4</span> {
              <span class="n">forwarding</span> <span class="n">enable</span>
          }
          <span class="n">ipv6</span> {
              <span class="n">forwarding</span> <span class="n">enable</span>
          }
      }
      <span class="n">options</span> {
          <span class="n">reboot</span>-<span class="n">on</span>-<span class="n">panic</span> <span class="n">true</span>
      }
      <span class="n">package</span> {
          <span class="n">repository</span> <span class="n">squeeze</span> {
              <span class="n">components</span> <span class="s2">"main contrib non-free"</span>
              <span class="n">distribution</span> <span class="n">squeeze</span>
              <span class="n">password</span> <span class="s2">""</span>
              <span class="n">url</span> <span class="n">http</span>://<span class="n">http</span>.<span class="n">us</span>.<span class="n">debian</span>.<span class="n">org</span>/<span class="n">debian</span>
              <span class="n">username</span> <span class="s2">""</span>
          }
          <span class="n">repository</span> <span class="n">squeeze</span>-<span class="n">security</span> {
              <span class="n">components</span> <span class="n">main</span>
              <span class="n">distribution</span> <span class="n">squeeze</span>/<span class="n">updates</span>
              <span class="n">password</span> <span class="s2">""</span>
              <span class="n">url</span> <span class="n">http</span>://<span class="n">security</span>.<span class="n">debian</span>.<span class="n">org</span>
              <span class="n">username</span> <span class="s2">""</span>
          }
          <span class="n">repository</span> <span class="n">squeeze</span>-<span class="n">updates</span> {
              <span class="n">components</span> <span class="s2">"main contrib non-free"</span>
              <span class="n">distribution</span> <span class="n">squeeze</span>-<span class="n">updates</span>
              <span class="n">password</span> <span class="s2">""</span>
              <span class="n">url</span> <span class="n">http</span>://<span class="n">http</span>.<span class="n">us</span>.<span class="n">debian</span>.<span class="n">org</span>/<span class="n">debian</span>
              <span class="n">username</span> <span class="s2">""</span>
          }
      }
      <span class="n">syslog</span> {
          <span class="n">global</span> {
              <span class="n">facility</span> <span class="n">all</span> {
                  <span class="n">level</span> <span class="n">notice</span>
              }
              <span class="n">facility</span> <span class="n">protocols</span> {
                  <span class="n">level</span> <span class="n">debug</span>
              }
          }
      }
  }
  <span class="n">vpn</span> {
      <span class="n">ipsec</span> {
          <span class="n">auto</span>-<span class="n">firewall</span>-<span class="n">nat</span>-<span class="n">exclude</span> <span class="n">disable</span>
          <span class="n">esp</span>-<span class="n">group</span> <span class="n">ESP</span>-<span class="n">AES128</span>-<span class="n">SHA1</span>-<span class="n">DH5</span>-<span class="n">TRANSPORT</span> {
              <span class="n">compression</span> <span class="n">disable</span>
              <span class="n">lifetime</span> <span class="m">3600</span>
              <span class="n">mode</span> <span class="n">transport</span>
              <span class="n">pfs</span> <span class="n">dh</span>-<span class="n">group5</span>
              <span class="n">proposal</span> <span class="m">1</span> {
                  <span class="n">encryption</span> <span class="n">aes128</span>
                  <span class="n">hash</span> <span class="n">sha1</span>
              }
          }
          <span class="n">ike</span>-<span class="n">group</span> <span class="n">IKE</span>-<span class="n">AES128</span>-<span class="n">SHA1</span>-<span class="n">DH5</span> {
              <span class="n">lifetime</span> <span class="m">28800</span>
              <span class="n">proposal</span> <span class="m">1</span> {
                  <span class="n">dh</span>-<span class="n">group</span> <span class="m">5</span>
                  <span class="n">encryption</span> <span class="n">aes128</span>
                  <span class="n">hash</span> <span class="n">sha1</span>
              }
          }
          <span class="n">ipsec</span>-<span class="n">interfaces</span> {
              <span class="n">interface</span> <span class="n">eth0</span>
          }
          <span class="n">site</span>-<span class="n">to</span>-<span class="n">site</span> {
              <span class="n">peer</span> <span class="m">192</span>.<span class="m">0</span>.<span class="m">2</span>.<span class="m">243</span> {
                  <span class="n">authentication</span> {
                      <span class="n">mode</span> <span class="n">rsa</span>
                      <span class="n">rsa</span>-<span class="n">key</span>-<span class="n">name</span> <span class="n">crest</span>-<span class="n">dn42</span>
                  }
                  <span class="n">connection</span>-<span class="n">type</span> <span class="n">initiate</span>
                  <span class="n">default</span>-<span class="n">esp</span>-<span class="n">group</span> <span class="n">ESP</span>-<span class="n">AES128</span>-<span class="n">SHA1</span>-<span class="n">DH5</span>-<span class="n">TRANSPORT</span>
                  <span class="n">ike</span>-<span class="n">group</span> <span class="n">IKE</span>-<span class="n">AES128</span>-<span class="n">SHA1</span>-<span class="n">DH5</span>
                  <span class="n">local</span>-<span class="n">ip</span> <span class="m">192</span>.<span class="m">0</span>.<span class="m">2</span>.<span class="m">2</span>
                  <span class="n">tunnel</span> <span class="m">0</span> {
                      <span class="n">allow</span>-<span class="n">nat</span>-<span class="n">networks</span> <span class="n">disable</span>
                      <span class="n">allow</span>-<span class="n">public</span>-<span class="n">networks</span> <span class="n">disable</span>
                      <span class="n">esp</span>-<span class="n">group</span> <span class="n">ESP</span>-<span class="n">AES128</span>-<span class="n">SHA1</span>-<span class="n">DH5</span>-<span class="n">TRANSPORT</span>
                      <span class="n">protocol</span> <span class="n">gre</span>
                  }
              }
          }
      }
      <span class="n">rsa</span>-<span class="n">keys</span> {
          <span class="n">rsa</span>-<span class="n">key</span>-<span class="n">name</span> <span class="n">crest</span>-<span class="n">dn42</span> {
              <span class="n">rsa</span>-<span class="n">key</span> <span class="m">0</span><span class="n">sAwEAAbsbRoUcgdm4A4Nm</span>+<span class="n">PLxWcW</span>+<span class="n">zFis7pkaJ0MkGVzM7VC8nmngkM</span>+<span class="n">W2zqZyQ4NUTBKKfGOUc4Ogi6gyhlzUnHdag9tDERIX</span>+<span class="n">BwlDO6G4arod9z9KqmJuX4AOYVjH5QlAPz7NDMAezVekGoVLPGdOAMPD6NN54ihLRH6V3if8AGoJRpiajhcgQipjeQnhH4QhsYK4XSjayGT1onQwA8nhy5kt4ofyqSale4Fl4166S9tCn4RKwtlJDjR6VIrg6op6Ip8</span>+<span class="n">ke2vjEHPJHj6qVsxfRgOk2d8pY8oPVt8ayc5F1z</span>+<span class="n">lqJ7R0fADfN</span>+<span class="n">AQSaBqOMmg5dHDFYWwgYkU5egdVKS7Oko6uNuUWsZ0VEnRoPZ4syJEUbiF5wGfaVBaaVLZYUlRLQCffB4JKzp</span>+<span class="n">JesVToCX6JYRfb4JYQWFCDeQfrqRZHM4r13h8MOWPn9cqXcP47RKJjzNp6595biUotmCbMHyy</span>/<span class="n">uveMWxK6vDzPQRkywqMMJE2qOyACmbMnSce9KlYhvma82Vd</span>+<span class="n">z</span>/<span class="m">9</span>/<span class="n">U9NEy0s5MaYNDn</span>+<span class="n">q</span>+<span class="n">KYT5My3NSv52F6sLVGrKxTk79tzUejZcoukJv</span>+<span class="n">gf51Epam4kVHzPIal</span>/<span class="n">khsfjZn6YCU2j5</span>+<span class="n">qcdRmzF</span>+<span class="n">SG5c2WicvEU2Gc4ratfYNEPxU5oArzHIhIz6x2nAF</span>+<span class="n">szcx</span>/<span class="n">x8GEyXPNHnxEboJB7ox</span>
          }
      }
  }
  <span class="n">zone</span>-<span class="n">policy</span> {
      <span class="n">zone</span> <span class="n">DN42</span> {
          <span class="n">default</span>-<span class="n">action</span> <span class="n">reject</span>
          <span class="n">description</span> <span class="n">DN42</span>
          <span class="n">from</span> <span class="n">Local</span> {
              <span class="n">firewall</span> {
                  <span class="n">name</span> <span class="n">allow</span>-<span class="n">all</span>-<span class="n">v4</span>
              }
          }
          <span class="n">from</span> <span class="n">LAN</span> {
              <span class="n">firewall</span> {
                  <span class="n">name</span> <span class="n">allow</span>-<span class="n">all</span>-<span class="n">v4</span>
              }
          }
          <span class="n">interface</span> <span class="n">tun0</span>
      }
      <span class="n">zone</span> <span class="n">LAN</span> {
          <span class="n">default</span>-<span class="n">action</span> <span class="n">reject</span>
          <span class="n">from</span> <span class="n">DN42</span> {
              <span class="n">firewall</span> {
                  <span class="n">name</span> <span class="n">DN42</span>-<span class="n">to</span>-<span class="n">LAN</span>
              }
          }
          <span class="n">from</span> <span class="n">Local</span> {
              <span class="n">firewall</span> {
                  <span class="n">name</span> <span class="n">allow</span>-<span class="n">all</span>-<span class="n">v4</span>
              }
          }
          <span class="n">from</span> <span class="n">WAN</span> {
              <span class="n">firewall</span> {
                  <span class="n">name</span> <span class="n">established</span>-<span class="n">only</span>
              }
          }
          <span class="n">interface</span> <span class="n">eth1</span>
      }
      <span class="n">zone</span> <span class="n">Local</span> {
          <span class="n">default</span>-<span class="n">action</span> <span class="n">reject</span>
          <span class="n">from</span> <span class="n">DN42</span> {
              <span class="n">firewall</span> {
                  <span class="n">name</span> <span class="n">DN42</span>-<span class="n">to</span>-<span class="n">Local</span>
              }
          }
          <span class="n">from</span> <span class="n">LAN</span> {
              <span class="n">firewall</span> {
                  <span class="n">name</span> <span class="n">allow</span>-<span class="n">all</span>-<span class="n">v4</span>
              }
          }
          <span class="n">from</span> <span class="n">WAN</span> {
              <span class="n">firewall</span> {
                  <span class="n">name</span> <span class="n">WAN</span>-<span class="n">to</span>-<span class="n">Local</span>
              }
          }
          <span class="n">local</span>-<span class="n">zone</span>
      }
      <span class="n">zone</span> <span class="n">WAN</span> {
          <span class="n">default</span>-<span class="n">action</span> <span class="n">reject</span>
          <span class="n">from</span> <span class="n">LAN</span> {
              <span class="n">firewall</span> {
                  <span class="n">name</span> <span class="n">allow</span>-<span class="n">all</span>-<span class="n">v4</span>
              }
          }
          <span class="n">from</span> <span class="n">Local</span> {
              <span class="n">firewall</span> {
                  <span class="n">name</span> <span class="n">allow</span>-<span class="n">all</span>-<span class="n">v4</span>
              }
          }
          <span class="n">interface</span> <span class="n">eth0</span>
      }
  }</code></pre>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/EdgeOS-GRE-IPsec-Example.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/EdgeOS-GRE-IPsec-Example.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
