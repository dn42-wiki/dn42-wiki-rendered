<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-309be032396e783b13a47df58f389b7c8e11c2b2d42640560b874f677c25f6e5.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">

  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/EMail.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-f05401ee374f0c7f48fc2bc08e30b4f4db705861fd5895ed70998683b383bfb5.js" type="text/javascript"></script>
  

  <title>EMail</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>EMail</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/EMail.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <a class="btn btn-sm" id="minibutton-home" href="/">
      Home
    </a>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/overview"
          id="minibutton-overview"
        >
          Overview
        </a>

        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/latest_changes"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </a>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          href="/gollum/history/howto/EMail.md/"
          id="minibutton-history"
        >
          History
        </a>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    EMail
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <p>Running email in dn42 is not very complicated.  Your SMTP daemon probably already listens on the wildcard address, so you mostly need to:</p>

<ul>
<li>open your firewall to allow TCP/25 from dn42</li>
<li>setup DNS (MX records, or simply relevant A records)</li>
<li>configure your mail server if needed</li>
</ul>

<h2><a class="anchor" id="redirect" href="#redirect"></a>Redirect</h2>

<p><del>There are forwarding rules for <em>PERSON</em> @ dn42.org to the mail addresses which have been given in the registry. Please note that the trailing <code>-DN42</code> is stripped from the local part.</del></p>

<h3><a class="anchor" id="example" href="#example"></a>Example</h3>

<table>
<thead>
<tr>
<th align="left">Handle</th>
<th align="left">Alias</th>
<th align="left">Redirection</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left"><code>STV0G-DN42</code></td>
<td align="left"><a href="mailto:stv0g@dn42.org">stv0g@dn42.org</a></td>
<td align="left"><code>post@steffenvogel.de</code></td>
</tr>
</tbody>
</table>

<h2><a class="anchor" id="test-email" href="#test-email"></a>Test email</h2>

<p><del>Send an email to <code>test@evenet.dn42</code> to check if your mail setup is correct.</del> This host will reply using the following
sieve filter:</p>

<pre class="highlight"><code><span class="n">require</span> [<span class="s2">"regex"</span>, <span class="s2">"variables"</span>, <span class="s2">"vacation-seconds"</span>];
<span class="n">if</span> <span class="n">header</span> :<span class="n">contains</span> <span class="s2">"To"</span> [<span class="s2">"test@evenet.dn42"</span>] {
  <span class="n">if</span> <span class="n">header</span> :<span class="n">matches</span> <span class="s2">"Subject"</span> <span class="s2">"*"</span> {
      <span class="n">set</span> <span class="s2">"subject_was"</span> <span class="s2">": ${1}"</span>;
  }
  <span class="n">vacation</span> :<span class="n">addresses</span> [<span class="s2">"test@evenet.dn42"</span>] :<span class="n">seconds</span> <span class="m">60</span> :<span class="n">subject</span>  <span class="s2">"Re: ${subject_was}"</span> <span class="s2">"Your dn42 email setup works!"</span>;
}</code></pre>

<h2><a class="anchor" id="exim-tips" href="#exim-tips"></a>Exim tips</h2>

<h3><a class="anchor" id="sending-emails" href="#sending-emails"></a>Sending emails</h3>

<p>By default on Debian, Exim refuses to send mail to other mailservers when they resolve to RFC1918 addresses.  This will manifest by the following error message when trying to send a mail:</p>

<pre><code>** foo@bar.dn42: all relevant MX records point to non-existent hosts
</code></pre>

<p>This is controlled by the <code>ignore_target_hosts</code> variable in the configuration file.</p>

<h3><a class="anchor" id="receiving-emails" href="#receiving-emails"></a>Receiving emails</h3>

<p>Don't forget to add your dn42 domains to the list of local domains, so that you accept incoming emails.  On Debian, it is controlled by <code>dc_other_hostnames</code> in <code>update-exim4.conf.conf</code>.  For instance:
</p><pre class="highlight"><code><span class="n">dc_other_hostnames</span>=<span class="s1">'myself.org;myself.dn42;myserver.myself.dn42'</span></code></pre>

<h2><a class="anchor" id="postfix" href="#postfix"></a>Postfix</h2>

<h3><a class="anchor" id="sending-mails" href="#sending-mails"></a>Sending Mails</h3>

<p>If your machine sends/receives Mails in "clearnet" with specific bound IP's you need to create an additional transport in master.cf</p>

<pre class="highlight"><code><span class="n">out_dn42</span>  <span class="n">unix</span> -       -       <span class="n">n</span>       -       -       <span class="n">smtp</span>
    -<span class="n">o</span> <span class="n">smtp_bind_address</span>=<span class="m">172</span>.<span class="m">23</span>.<span class="m">67</span>.<span class="m">1</span>
    -<span class="n">o</span> <span class="n">smtp_bind_address6</span>=<span class="n">fd70</span>:<span class="m">96</span><span class="n">c9</span>:<span class="n">ef25</span>::<span class="m">1</span>
    -<span class="n">o</span> <span class="n">smtp_helo_name</span>=<span class="n">ns1</span>.<span class="n">mhm</span>.<span class="n">dn42</span>
    -<span class="n">o</span> <span class="n">syslog_name</span>=<span class="n">postfix</span>-<span class="n">dn42</span></code></pre>

<p>and add this transport to /etc/postfix/transport for dn42 (and dont forget to postmap)</p>

<pre class="highlight"><code>.dn42           out_dn42:</code></pre>

<p>This should to the trick for sending mails via your DN42-IP</p>

<p>If you use <code>smtpd_recipient_restrictions</code> you can use the following rule to white-list dn42 as sender.
This can circumvent certain rdns configuration failure or in case you use rbl lists:</p>

<pre class="highlight"><code><span class="n">smtpd_recipient_restrictions</span> = <span class="n">permit_mynetworks</span>,
                         <span class="n">permit_sasl_authenticated</span>,
                         <span class="n">check_client_access</span> <span class="n">cidr</span>:/<span class="n">etc</span>/<span class="n">postfix</span>/<span class="n">dn42</span>.<span class="n">cidr</span>,
                         <span class="n">reject_non_fqdn_sender</span>,
                         <span class="c"># ...
</span>                         <span class="n">permit</span></code></pre>

<pre class="highlight"><code><span class="c">#/etc/postfix/dn42.cidr
</span><span class="m">172</span>.<span class="m">16</span>.<span class="m">0</span>.<span class="m">0</span>/<span class="m">12</span> <span class="n">OK</span>
<span class="m">10</span>.<span class="m">0</span>.<span class="m">0</span>.<span class="m">0</span>/<span class="m">8</span> <span class="n">OK</span>
<span class="n">fc00</span>::/<span class="m">7</span> <span class="n">OK</span></code></pre>

<pre class="highlight"><code><span class="nv">$ </span>postmap /etc/postfix/dn42.cidr</code></pre>

<h3><a class="anchor" id="receiving-emails-1" href="#receiving-emails-1"></a>Receiving emails</h3>

<p>The Domain mails should be received for has to be added to <code>mydestination =</code> in main.cf</p>

<h2><a class="anchor" id="new-smtp-rfc-smtputf8" href="#new-smtp-rfc-smtputf8"></a>New SMTP RFC SMTPUTF8</h2>

<h3><a class="anchor" id="eai" href="#eai"></a>EAI</h3>

<p>Email Address Internationalization (EAI) as defined in <a href="http://tools.ietf.org/html/rfc6531">RFC 6531</a> (SMTPUTF8 extension), <a href="http://tools.ietf.org/html/rfc6532">RFC 6532</a> (Internationalized email headers) and <a href="http://tools.ietf.org/html/rfc6533">RFC 6533</a> (Internationalized delivery status notifications).</p>

<h3><a class="anchor" id="postfix-1" href="#postfix-1"></a>Postfix</h3>

<p>Introduced with Postfix version 3.0, this fully supports UTF-8 email addresses and UTF-8 message header values.
more at the <a href="http://www.postfix.org/SMTPUTF8_README.html">SMTPUTF8_README</a>.</p>

<h3><a class="anchor" id="exim" href="#exim"></a>Exim</h3>

<p>Watch Exims EAI Tracker <a href="http://bugs.exim.org/show_bug.cgi?id=1177">Bug 1177</a></p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
<li>
<p><a href="/Home" rel="nofollow">Home</a></p>

<ul>
<li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
<li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
<li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
<li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
<li><a href="/FAQ" rel="nofollow">FAQ</a></li>
</ul>
</li>
<li>
<p>How-To</p>

<ul>
<li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
<li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
<li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
<li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
<li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
<li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
<li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
<li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
<li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
<li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
<li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
<li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
<li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
<li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
<li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
<li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
<li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
<li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
</ul>
</li>
<li>
<p>Services</p>

<ul>
<li><a href="/services/IRC" rel="nofollow">IRC</a></li>
<li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
<li><a href="/services/DNS" rel="nofollow">DNS</a></li>
<li><a href="/services/IX-Collection" rel="nofollow">IX Collection</a></li>
<li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
<li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
<li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
<li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
<li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
<li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
<li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
</ul>
</li>
<li>
<p>Internal</p>

<ul>
<li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
<li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
<li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
<li>
<a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a><br />
</li>
<li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
</ul>
</li>
<li>
<p>Historical</p>

<ul>
<li><a href="/historical/Bird" rel="nofollow">Bird 1</a></li>
<li><a href="/historical/Quagga" rel="nofollow">Quagga</a></li>
</ul>
</li>
<li>
<p>External Tools</p>

<ul>
<li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
<li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
</ul>
</li>
</ul>

<hr />

	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a> | Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a></p>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/EMail.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/EMail.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
