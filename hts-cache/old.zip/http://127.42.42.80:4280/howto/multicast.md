<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/multicast.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>multicast</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>multicast</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/multicast.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/multicast.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    multicast
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h2><a class="anchor" id="multicast" href="#multicast"></a>Multicast</h2>

<p><a href="https://datatracker.ietf.org/doc/html/rfc8815">RFC 8815</a> deprecated interdomain PIM-ASM (any-source multicast) so PIM-SSM (source-specific multicast) is the way to go!</p>

<h3><a class="anchor" id="setup" href="#setup"></a>Setup</h3>

<p>For it to work, you'll need to do the following:</p>
<ul>
  <li>Ask your peering to enable IPv4/IPv6 multicast AFI on your peering</li>
  <li>Set up IPv4/IPv6 PIM for the (s,g) joins to pass through</li>
  <li>Be prepared to setup IGMPv3 and MLDv2 from your listeners</li>
</ul>

<p>You're done! You should receive the multicast routes from peers advertising them.</p>

<h2><a class="anchor" id="configuration" href="#configuration"></a>Configuration</h2>

<h3><a class="anchor" id="frr-configuration" href="#frr-configuration"></a>frr configuration</h3>

<p>Enable PIM:
</p><pre class="highlight"><code>router pim
 no autorp discovery
exit
router pim6
exit</code></pre>
For IPv4, you can also add the <code>send-v6-secondary</code> directive, which allows you to omit an IPv4 address (as with "extended next hop") on the interface. (Does this work? I haven't tried it yet.)

<p>Import kernel multicast table into frr:
</p><pre class="highlight"><code>ip import-table [TABLE NUMBER] mrib
ipv6 import-table [TABLE NUMBER] mrib</code></pre>
This method is suitable when frr is used only as a multicast routing daemon and another daemon, such as bird, is used for BGP. In this case, bird can export the unicast routes intended for multicast to a special kernel routing table, and frr can import them. If frr also handles BGP, it can store the corresponding unicast routes directly in mrib.

<p>Enable PIM on a interface:
</p><pre class="highlight"><code>interface [INTERFACE NAME]
 ip pim
 ip pim use-source [SOURCE IPv4 ADDRESS]
 ipv6 pim
 ipv6 pim use-source [SOURCE IPv6 ADDRESS]
exit</code></pre>
Specifying a source address is optional, but can be used if frr would otherwise select the wrong address.

<p>Enable multicast for a client:
</p><pre class="highlight"><code>interface client21
 ip igmp
 ip igmp max-groups 32
 ip igmp require-router-alert
 ip igmp version 3
 ip pim
 ip pim passive
 ipv6 mld
 ipv6 mld max-groups 32
 ipv6 mld require-router-alert
 ipv6 mld version 2
 ipv6 pim
 ipv6 pim passive
exit</code></pre>
The number of maximum groups is optional and can be set freely. For security reasons, this number should not be set unreasonably high. Specifying an explicit IGMP or MLD version is also optional.
IGMP and MLD messages must follow a specific format. <code>require-router-alert</code> filters out invalid messages.
Even if an interface is only intended to handle IGMP/MLD, PIM must be enabled on it. If you still do not want to use PIM, a firewall rule is recommended.

<h3><a class="anchor" id="nftables-configuration" href="#nftables-configuration"></a>nftables configuration</h3>

<p>Allow PIM:
</p><pre class="highlight"><code>iifname "[INTERFACE NAME]" ip6 saddr [SOURCE ADDRESS] ip6 daddr ff02::d meta protocol ip6 meta l4proto pim counter accept;</code></pre>
<pre class="highlight"><code>iifname "[INTERFACE NAME]" ip saddr [SOURCE ADDRESS] ip daddr 224.0.0.13 meta protocol ip meta l4proto pim counter accept;</code></pre>

<p>Allow MLDv2:
</p><pre class="highlight"><code>set icmp6_mld {
    type icmpv6_type . icmpv6_code;
    flags interval;
    elements = {
        mld-listener-query . 0,
        mld2-listener-report . 0
    };
}</code></pre>
<pre class="highlight"><code>iifname [CLIENT INTERFACE NAME] icmpv6 type . icmpv6 code @icmp6_mld ip6 hoplimit 1 exthdr hbh exists ip6 saddr fe80::/10 counter accept;</code></pre>

<p>Allow IGMPv3:
</p><pre class="highlight"><code>iifname [CLIENT INTERFACE NAME] ip protocol igmp igmp type { membership-query, membership-report-v3 } ip ttl 1 counter accept;</code></pre>

<h2><a class="anchor" id="participants" href="#participants"></a>Participants</h2>

<p>Current participants:</p>
<ul>
  <li>NOP-MNT</li>
  <li>MIRSAL-MNT</li>
  <li>C4TG1RL5-MNT</li>
  <li>KIOUBIT-MNT</li>
  <li>PREVARINITE-MNT</li>
  <li>MARK22K-MNT</li>
</ul>

<p>Feel free to ask for a peering and set it up!</p>

<h2><a class="anchor" id="current-streams" href="#current-streams"></a>Current streams</h2>

<h3><a class="anchor" id="nop-music-stream" href="#nop-music-stream"></a>NOP music stream</h3>

<p>cs broadcasts a 96 kHz, 24-bit music stream. An SDP file is required to receive it:
</p><pre class="highlight"><code>v=0
o=- 0 0 IN IP4 172.23.199.110
s=-
i=NOP 96 kHz 24-bit music stream
e=dn42@nop.hu
c=IN IP4 232.2.3.2
m=audio 1234 RTP/AVP 96
a=rtpmap:96 L24/96000/2
a=recvonly
a=type:broadcast
a=source-filter: incl IN IP4 232.2.3.2 172.23.199.110</code></pre>
<pre class="highlight"><code>v=0
o=- 0 0 IN IP6 fd40:cc1e:c0de::fffe
s=-
i=NOP 96 kHz 24-bit music stream
e=dn42@nop.hu
c=IN IP6 ff3e::8232:232
m=audio 1234 RTP/AVP 96
a=rtpmap:96 L24/96000/2
a=recvonly
a=type:broadcast
a=source-filter: incl IN IP6 ff3e::8232:232 fd40:cc1e:c0de::fffe</code></pre>

<p>The stream can then be streamed with <code>ffplay -protocol_whitelist file,fd,udp,rtp -fflags +genpts /path/to/sdp_file</code>.</p>

<h3><a class="anchor" id="mping" href="#mping"></a>mping</h3>

<p>mping is a program that sends a ping message to a multicast group every second (and responds to incoming pings, if any).
There are two implementations:</p>
<ul>
  <li>The <a href="https://github.com/troglobit/mping/">original implementation</a> by troglobit, which supports both sending and receiving.</li>
  <li>A <a href="https://codeberg.org/mark22k/mping-sender">reimplementation</a>, which supports only sending.</li>
</ul>

<p>Streams:</p>
<ul>
  <li>
<code>mcjoin -j -i [INTERFACE] [fd00:8e13:ce5d::9bee],[ff3e::8000:42]:4321</code> mping-sender</li>
</ul>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/Policies" rel="nofollow">Policies</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
      <li><a href="/Links" rel="nofollow">Links</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
      <li><a href="/howto/GeoFeed" rel="nofollow">GeoFeed</a></li>
      <li><a href="/howto/Telephony-Asterisk" rel="nofollow">Telephony (Asterisk)</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/dns/Overview" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">ROA + RPKI</a></li>
      <li><a href="/services/exchanges/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Pingables" rel="nofollow">Pingables</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/ca/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>, <a href="https://iedon.net/post/24" rel="nofollow">IEDON-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>, <a href="https://dn42.jp/" rel="nofollow">dn42.jp</a> (wiki-go)</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/multicast.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/multicast.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
