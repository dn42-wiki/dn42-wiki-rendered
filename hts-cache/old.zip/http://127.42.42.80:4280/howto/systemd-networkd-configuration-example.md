<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/systemd-networkd-configuration-example.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>systemd-networkd-configuration-example</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>systemd-networkd-configuration-example</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/systemd-networkd-configuration-example.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/systemd-networkd-configuration-example.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    systemd-networkd-configuration-example
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="systemd-networkd-configuration-example" href="#systemd-networkd-configuration-example"></a>systemd-networkd configuration example</h1>
<p>This is the config that is used on ZOTAN Networks (AS4242422341). Full network configuration available on <a href="https://git.zotan.dn42/zotan/dn42">my Git</a> (dn42) or alternatively <a href="https://git.prod.zotan.network/zotan/dn42">my Git</a> (clear)</p>

<h1><a class="anchor" id="configuration" href="#configuration"></a>Configuration</h1>

<h2><a class="anchor" id="loopback-device-lo-network" href="#loopback-device-lo-network"></a>loopback device (lo.network)</h2>
<pre class="highlight"><code>[<span class="n">Match</span>]
<span class="n">Name</span>=<span class="n">lo</span>

[<span class="n">Network</span>]
<span class="n">Address</span>=<span class="n">fdff</span>:<span class="n">b02d</span>:<span class="m">2</span><span class="n">ef7</span>::<span class="m">2</span>/<span class="m">128</span></code></pre>

<h2><a class="anchor" id="wireguard-netdev-dn42p1-netdev" href="#wireguard-netdev-dn42p1-netdev"></a>wireguard netdev (dn42p1.netdev)</h2>
<pre class="highlight"><code>[<span class="n">NetDev</span>]
<span class="n">Name</span> = <span class="n">dn42p1</span>
<span class="n">Kind</span> = <span class="n">wireguard</span>
<span class="n">Description</span> = <span class="n">WireGuard</span>

[<span class="n">WireGuard</span>]
<span class="n">ListenPort</span> = <span class="m">42421</span>
<span class="n">PrivateKeyFile</span> = /<span class="n">etc</span>/<span class="n">wireguard</span>/<span class="n">private</span>.<span class="n">key</span>

[<span class="n">WireGuardPeer</span>]
<span class="n">PublicKey</span> = &lt;<span class="n">peer</span> <span class="n">wg</span> <span class="n">pubkey</span>&gt;
<span class="n">Endpoint</span> = &lt;<span class="n">peer</span> <span class="n">wg</span> <span class="n">endpoint</span>&gt;:&lt;<span class="n">peer</span> <span class="n">wg</span> <span class="n">port</span>&gt;
<span class="n">AllowedIPs</span> = <span class="m">172</span>.<span class="m">16</span>.<span class="m">0</span>.<span class="m">0</span>/<span class="m">12</span>,<span class="m">10</span>.<span class="m">0</span>.<span class="m">0</span>.<span class="m">0</span>/<span class="m">8</span>,<span class="n">fd00</span>::/<span class="m">8</span>,<span class="n">fe80</span>::/<span class="m">10</span>,<span class="n">ff00</span>::/<span class="m">8</span></code></pre>

<h2><a class="anchor" id="wireguard-network-dn42p1-network" href="#wireguard-network-dn42p1-network"></a>wireguard network (dn42p1.network)</h2>
<pre class="highlight"><code>[<span class="n">Match</span>]
<span class="n">Name</span> = <span class="n">dn42p1</span>

[<span class="n">Address</span>]
<span class="n">Address</span> = <span class="n">fe80</span>::<span class="m">2342</span>/<span class="m">128</span> <span class="c"># arbitrary, doesn't need to be unique for each interface
</span><span class="n">Peer</span> = &lt;<span class="n">peer</span> <span class="n">tunnel</span> <span class="n">linklocal</span> <span class="n">address</span>&gt;/<span class="m">128</span>

[<span class="n">Address</span>]
<span class="n">Address</span> = &lt;<span class="n">your</span> <span class="n">DN42</span> <span class="n">ipv4</span>&gt;/<span class="m">32</span>
<span class="n">Peer</span> = &lt;<span class="n">peer</span> <span class="n">DN42</span> <span class="n">ipv4</span>&gt;/<span class="m">32</span>
</code></pre>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/systemd-networkd-configuration-example.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/systemd-networkd-configuration-example.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
