<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/IPv6.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>IPv6</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>IPv6</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/IPv6.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/IPv6.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    IPv6
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <p><em>Work in progress</em></p>

<h2><a class="anchor" id="introduction" href="#introduction"></a>Introduction</h2>

<p>DN42 is a somewhat unique undertaking, and a great way to learn about networking and routing techs.
If you feel like spicing the challenge up a bit, why not get familiar with IPv6 at the same time ?</p>

<p>There's nothing too different from IPv4, except one major point: it's a separate network space, and therefore you might not be able to reach the IPv4-part of DN42. That is, without NAT64, proxies, etc.. (read more below!) or if you're running dual-stack, both IPv4 and IPv6 at the same time.</p>

<h2><a class="anchor" id="getting-started" href="#getting-started"></a>Getting Started</h2>

<p>If you're already running IPv4 on DN42, here's how to get started:</p>
<ul>
  <li>Register an inet6num block on the registry. A /56-size prefix is good, but with the space available in IPv6 space, you can probably go for /48</li>
  <li>Setup your interfaces to use them</li>
  <li>Negociate with your v6-capable peers to setup peering sessions to allow your v6 prefixes</li>
  <li>???</li>
  <li>Profit!</li>
</ul>

<p>If not, you can follow the instructions on the <a href="/howto/Getting-Started">Getting Started</a> page, as they'll mostly apply to IPv6 aswell.</p>

<h2><a class="anchor" id="what-can-i-do-on-dn42-v6" href="#what-can-i-do-on-dn42-v6"></a>What can i do on DN42-v6 ?</h2>

<p>A fair share of the services are available through IPv6. However some of the well known addresses might not work, so you'll have to find alternative services.</p>

<p>Quick list of some native-IPv6-capable services:</p>
<ul>
  <li>Anycast <a href="/services/whois">whois.dn42</a>
</li>
  <li>DNS, including anycast</li>
  <li>Media boards, including DN42-Chan</li>
  <li>torrents.dn42</li>
  <li>wiki.dn42/internal.dn42</li>
  <li>Dn42 Exchange: admin.dn42-ix.tk</li>
</ul>

<p>What doesn't work (yet?):</p>
<ul>
  <li>Search engines, none seems to support IPv6 currently</li>
  <li>Pretty much everything from Freifunk and ChaosVPN</li>
  <li>Any services hosted by e-utp.dn42</li>
</ul>

<h2><a class="anchor" id="accessing-legacy-services-from-an-ipv6-only-stack" href="#accessing-legacy-services-from-an-ipv6-only-stack"></a>Accessing legacy services from an IPv6-only stack</h2>
<p>In order to access legacy IPv4 services from the IPv6 side of DN42, you're going to need some kind of service to jump from one to the other.
This can typically be done in two ways:</p>
<ul>
  <li>A dual-stack Proxy with Remote DNS</li>
  <li>A dual-stack Router with NAT64, plus DNS64 services</li>
</ul>

<p>It's important to note that since these services require IPv4 connectivity, you can't set them up yourself if you are running IPv6-only. You'll need to ask another DN42 participant to be your provider for these services, effectively using his node as a gateway/proxy.</p>

<h3><a class="anchor" id="with-a-socks5-proxy-and-remote-dns" href="#with-a-socks5-proxy-and-remote-dns"></a>With a SOCKS5 proxy and Remote DNS</h3>
<p>Just set it up like you would usually. Any IPv4 connection going through the proxy will be made to the proxy by IPv6, then from the proxy to target using IPv4.</p>

<h3><a class="anchor" id="nat64-dns64" href="#nat64-dns64"></a>NAT64+DNS64</h3>
<p>In order to maintain backward compatibility, a number of methods have been used to be able to reach IPv4 space from IPv6. NAT-PT was deprecated, so this mostly leaves us with NAT64.
NAT64 simply consists in embedding IPv4 addresses after an IPv6 prefix, and mapping the whole prefix to the whole of IPv4 space. Thanksfully, that's easily doable because we have 128-bit wide addresses in IPv6. As the name implies, we however have to perform Dynamic-NAT on the IPv4 side to squeeze all the incoming v6 space in v4 addresses (though it should be possible to run 1-1 mappings, but in that case, why not get a v4 address and NAT to it to begin with?)</p>

<p>Currently, NAT64 support in DN42 is non-existant, though there are ongoing experimentations with it. Technically, it is possible to announce a global anycast prefix for NAT64, allowing seamless IPv4 connectivity from any properly configured IPv6 host, or any using the DNS64 (which can also be setup on the anycast servers).</p>

<p>DNS64 itself simply allow to synthetizes AAAA records from the received usual A records. Because DNS runs at the transport level and does not care for Layer 3 triffles, this is a service that you can run on your Nameserver even without being Dual-Stack capable. (TODO: DNS64 Howto with BIND9)
As such, any address that can only resolve to IPv4 will now also resolve to an address corresponding to it through the NAT64 prefix.</p>

<h2><a class="anchor" id="routing-to-internet-and-dn42" href="#routing-to-internet-and-dn42"></a>Routing to Internet and DN42</h2>
<p>So now that you've got IPv6 setup for DN42, you'd like to start using it on the Internet aswell. Or maybe you already do. But how to use your services on both public Internet and DN42 ?</p>

<h3><a class="anchor" id="with-npt" href="#with-npt"></a>With NPT</h3>
<p>A first approach is to use NPT: Network Prefix Translation. Yes, this sounds a lot like NAT, but fear not: it does not have most of its problems as it is fully stateless. Initially, the purpose of NPT was to allow multi-homing without an ASN: how can you be reachable through several prefixes allocated by different ISPs ? The IPv6-way of doing it would be to assign multiple addresses from the multiple prefixes to all your nodes, but isn't that just too complicated ?</p>

<p>Enter NPT. Address your services using a reserved private block, and map that block to a public block upon routing to internet. 
For example, if you've been assigned a public /48 prefix, and want to be reachable on DN42 aswell, you can use only ULA addresses from DN42 internally (or your own!), then map them to outside prefixes. Note that they'll need to all use the same prefix size to maintain the one-to-one mapping, so you may have to subnet the public prefix.</p>

<p>In Linux's netfilter, this can be implemented through the use of the NETMAP target, for the example above:
</p><pre class="highlight"><code>ip6tables <span class="nt">-t</span> nat <span class="nt">-A</span> POSTROUTING <span class="nt">-d</span> 2000::/3 <span class="nt">-s</span> &lt;DN42-PREFIX&gt;:&lt;SUBNET&gt;::/56 <span class="nt">-j</span> NETMAP <span class="nt">--to</span> &lt;PUBLIC-PREFIX&gt;:&lt;SUBNET&gt;::/56<span class="p">;</span> <span class="c"># Map ULA to the public prefix for outgoing packets</span>
ip6tables <span class="nt">-t</span> nat <span class="nt">-A</span> PREROUTING <span class="nt">-s</span> 2000::/3 <span class="nt">-d</span> &lt;PUBLIC-PREFIX&gt;:&lt;SUBNET&gt;::/56 <span class="nt">-j</span> NETMAP <span class="nt">--to</span> &lt;DN42-PREFIX&gt;:&lt;SUBNET&gt;::/56<span class="p">;</span> <span class="c"># Map public prefix to ULA for incoming packets</span></code></pre>

<h3><a class="anchor" id="with-multiple-prefixes" href="#with-multiple-prefixes"></a>With Multiple Prefixes</h3>

<h2><a class="anchor" id="more-info" href="#more-info"></a>More Info</h2>
<p>This page is a work in progress. Please contact Fira if you feel like more information should be added here! Also see ASN 4242423218 for an example of IPv6-only AS on DN42.</p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>
</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/IPv6.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/IPv6.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
