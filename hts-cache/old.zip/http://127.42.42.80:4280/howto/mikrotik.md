<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/mikrotik.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>mikrotik</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>mikrotik</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/mikrotik.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/mikrotik.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    mikrotik
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="how-to-connect-to-dn42-using-mikrotik-routeros" href="#how-to-connect-to-dn42-using-mikrotik-routeros"></a>How to connect to dn42 using Mikrotik RouterOS</h1>

<p>NB: this is a somewhat outdated page, it uses a VPN stack that's a bit less elegant and not as well supported nowadays. I'm sure it'll still work, but if you're interested in using a modern supported method and current RouterOS version (as of mid-2026), there's <a href="/howto/mikrotik/modern-style">a subpage you can check out</a>. It's a work in progress, but it works perfectly well!</p>

<h2><a class="anchor" id="legend" href="#legend"></a>Legend</h2>

<ul>
  <li>1.1.1.1 - peer external IP</li>
  <li>2.2.2.2 - your external IP</li>
  <li>A private /30 range for the GRE endpoints: 192.168.200.128/30</li>
  <li>192.168.200.129 - remote GRE IPv4 address</li>
  <li>192.168.200.130 - local GRE IPv4 address</li>
  <li>fd42:c644:5222:3222::40 - remote GRE IPv6 address</li>
  <li>fd42:c644:5222:3222::41 - local GRE IPv6 address</li>
  <li>YOUR_AS - your AS number (numbers only)</li>
  <li>PEER_AS - peer AS number (numbers only)</li>
</ul>

<h2><a class="anchor" id="routeros-limitations" href="#routeros-limitations"></a>RouterOS limitations</h2>

<ul>
  <li>IPSec only supports IKEv1</li>
  <li>OpenVPN only works in tcp mode</li>
  <li>OpenVPN does not support LZO compression</li>
  <li>You can't use /31 subnet for Point-to-Point (PtP) links</li>
</ul>

<p>Mikrotik/RouterOS doesn't handle /32 addresses very well on Point-to-Point links (like GRE). There is a <a href="/howto/mikrotik/ptp32">separate howto</a> to explain how to setup /32 addresses on a GRE tunnel (or even an OpenVPN tunnel). What is the easy way? Just use any /30 subnet on the GRE Link, either from your assigned DN42 pool of addresses, or use a private address like 192.168.x.x. Please don't choose from 172.16.0.0/12 or 10.0.0.0/8 because they may overlap with DN42 or ChaosVPN.</p>

<p>RouterOS v7.2 has some nasty bugs when using PTP configuration or IPv6 link local addresses as NEXTHOP. It won't work (confirmed for v7.2 by their support staff).</p>

<h2><a class="anchor" id="tunnel" href="#tunnel"></a>Tunnel</h2>

<h3><a class="anchor" id="ipsec" href="#ipsec"></a>IPSec</h3>
<p>First, let's add IPSec peer and encryption policy.
Your peer most likely provided you with encryption details. If not, ask them about it.
Here we're gonna use aes256-sha256-modp1536</p>

<pre class="highlight"><code>/ip ipsec peer
add address=1.1.1.1 comment=gre-dn42-peer dh-group=modp1536 \
enc-algorithm=aes-256 hash-algorithm=sha256 local-address=2.2.2.2 secret=PASSWORD</code></pre>

<pre class="highlight"><code>/ip ipsec policy
add comment=gre-dn42-peer dst-address=1.1.1.1/32 proposal=dn42 protocol=gre \
sa-dst-address=1.1.1.1 sa-src-address=2.2.2.2 src-address=2.2.2.2/32</code></pre>

<h3><a class="anchor" id="gre" href="#gre"></a>GRE</h3>
<p>Pretty straightforward here:
</p><pre class="highlight"><code>/interface gre
add allow-fast-path=no comment="DN42 somepeer" local-address=2.2.2.2 name=gre-dn42-peer \
remote-address=1.1.1.1</code></pre>

<h3><a class="anchor" id="ips-inside-the-gre-tunnel" href="#ips-inside-the-gre-tunnel"></a>IPs inside the GRE tunnel</h3>
<p>Your peer most likely provided you with IP adresses for the GRE tunnel.
As mentioned before, you can't use /31 for PtP links, so for the "easy way" we will be using a /30.
If you want to avoid wasting a whole /30 for your peering, please check the <a href="/howto/mikrotik/ptp32">point-to-point configuration for RouterOS</a></p>

<p>Add the IP your peer provided you:</p>

<h4><a class="anchor" id="ipv4" href="#ipv4"></a>IPv4</h4>

<pre class="highlight"><code>/ip address
add address=192.168.200.130/30 interface=gre-dn42-peer network=192.168.200.128</code></pre>

<h4><a class="anchor" id="ipv6" href="#ipv6"></a>IPv6</h4>

<p>Here we can use /127, so it's simple:
</p><pre class="highlight"><code>/ipv6 address
add address=fdc8:c633:5319:3300::41/127 advertise=no interface=gre-dn42-peer</code></pre>

<p>If you configured everything correctly you should be able to ping the remote end of the tunnel. In this specific example that would be 192.168.200.129 (IPv4) or fdc8:c633:5319:3300::40 (IPv6).</p>

<h2><a class="anchor" id="bgp" href="#bgp"></a>BGP</h2>

<h3><a class="anchor" id="filters" href="#filters"></a>Filters</h3>

<p>Both BGP and routing filters were redone from the ground up for RouterOS v7. If you're updating an existing v6 installation, the official migration guide can be found <a href="https://help.mikrotik.com/docs/display/ROS/Routing">here</a></p>

<p>It's a good idea to setup filters for BGP instances, both IN (advertisements you accept) and OUT (advertisements you send).</p>

<p>In this example, we will be filtering:</p>

<ul>
  <li>IN: 192.168.0.0/16 and 169.254.0.0/16, because we don't want other people's routes interfering with out network</li>
  <li>OUT: 192.168.0.0/16 and 169.254.0.0/16, because you shouldn't be advertising your private (non-DN42) network</li>
</ul>

<p>This filter will not only catch /8 or /16 networks, but smaller networks inside this subnets as well.</p>

<h4><a class="anchor" id="ros-7-x" href="#ros-7-x"></a>RoS 7.x</h4>

<p>RoS 7 filters have a default-reject behaviour, meaning if you reach the end of the chain without matching any rules, the route will be rejected.</p>

<p>As such, you need to either explicitly accept all the prefixes that you want to keep, or place a final accept at the end of the chain, after rejecting undesired prefixes.</p>

<p>In this example, we will use the second method.
</p><pre class="highlight"><code>/routing filter rule
add chain=dn42-in rule="if (dst in 192.168.0.0/16 &amp;&amp; dst-len &gt; 16) { reject }"
add chain=dn42-in rule="if (dst in 169.254.0.0/1 &amp;&amp; dst-len &gt; 16) { reject }"
add chain=dn42-in rule="accept"
add chain=dn42-out rule="if (dst in 192.168.0.0/16 &amp;&amp; dst-len &gt; 16) { reject }"
add chain=dn42-out rule="if (dst in 169.254.0.0/1 &amp;&amp; dst-len &gt; 16) { reject }"
add chain=dn42-out rule="accept"</code></pre>

<p>If you want only DN42 connectivity, you can also filter IN 10.0.0.0/8 (ChaosVPN / freifunk networks):</p>

<pre class="highlight"><code>/routing filter
add chain=dn42-in rule="if (dst in 10.0.0.0 &amp;&amp; dst-len &gt; 8) { reject }"</code></pre>

<h4><a class="anchor" id="ros-6-x" href="#ros-6-x"></a>RoS 6.x</h4>

<p>RouterOS v6 does not have a default-reject behaviour. It will apply the rules in the chain, then accept anything that didn't match a rule.</p>

<pre class="highlight"><code>/routing filter
add action=discard address-family=ip chain=dn42-in prefix=192.168.0.0/16 prefix-length=16-32 protocol=bgp
add action=discard address-family=ip chain=dn42-in prefix=169.254.0.0/16 prefix-length=16-32 protocol=bgp
add action=discard address-family=ip chain=dn42-out prefix=192.168.0.0/16 prefix-length=16-32 protocol=bgp
add action=discard address-family=ip chain=dn42-out prefix=169.254.0.0/16 prefix-length=16-32 protocol=bgp</code></pre>

<p>If you want only DN42 connectivity, you can filter IN 10.0.0.0/8 (ChaosVPN / freifunk networks):
</p><pre class="highlight"><code>/routing filter
add action=discard address-family=ip chain=dn42-in prefix=10.0.0.0/8 prefix-length=8-32 protocol=bgp</code></pre>

<h3><a class="anchor" id="bgp-1" href="#bgp-1"></a>BGP</h3>
<p>Now, for actual BGP configuration.</p>

<h4><a class="anchor" id="ros-7-x-1" href="#ros-7-x-1"></a>RoS 7.x</h4>

<p>We'll start by defining the subnets that we host and want to advertise. RouterOS v7 uses the firewall's Address Lists to define a list of networks, then our BGP config refers to those lists when making advertisements.</p>

<p>Create an address list containing your DN42 subnet allocation, one for IPv4 and one for IPv6:
</p><pre class="highlight"><code>IPv4
/ip firewall address-list
add address=YOUR_ALLOCATED_SUBNET/MASK list=DN42_allocated_v4

IPv6
/ipv6 firewall address-list
add address=YOUR_ALLOCATED_SUBNET/MASK list=DN42_allocated_v6</code></pre>

<p>RouterOS will only advertise networks that it has a route to, this helps prevent you from accidentally advertising subnets that aren't usable (eg. due to a typo). If your subnet is already attached to an interface then this isn't a problem, but it's common practice to add a dummy route to the routing table anyway, to ensure that your subnet will always be advertised.</p>

<p>Add a blackhole route to your DN42 subnet allocation:
</p><pre class="highlight"><code>IPv4
/ip route
add blackhole distance=1 dst-address=YOUR_ALLOCATED_SUBNET/MASK

IPv6
/ipv6 route
add blackhole distance=1 dst-address=YOUR_ALLOCATED_SUBNET/MASK</code></pre>

<p>This behaviour is explained here: https://forum.mikrotik.com/t/rosv7-bgp-blackhole/177053/4</p>

<p>In recent releases (around v7.21) this can be done from the BGP connection settings instead. If you enable the <code>output.network-blackhole</code> setting, RouterOS will create suitable blackhole routes for the subnets in your Address List, so you don't have to add them yourself.</p>

<p>Let's create a connection template for DN42. It isn't strictly necessary, but it makes our life easier when adding more peers in future.
</p><pre class="highlight"><code>/routing bgp template
add afi=ipv4 as=YOUR_AS_NUMBER name=DN42_template_v4 output.network=DN42_allocated_v4 router-id=1.1.1.1
add afi=ipv6 as=YOUR_AS_NUMBER name=DN42_template_v6 output.network=DN42_allocated_v6 router-id=1.1.1.1</code></pre>

<p>Create an instance, you can think of this as the BGP daemon that's running.
</p><pre class="highlight"><code>/routing bgp instance
add as=&lt;YOUR_AS&gt; name=bgp-dn42-somename router-id=1.1.1.1</code></pre>

<p>Now it's time to add a peer. In RouterOS v7 you can use link-local addresses instead of regular routable addresses, which helps simplify config and reduces the number of IP addresses used for routing (validated with RoS 7.14.3, 7.18.1, 7.18.2 and 7.19rc2). The trick is to add <code>%INTERFACE</code> after the address, where "INTERFACE" is the name of the interface the link-local address is assigned to, or the interface used to reach your peer's link-local address. So, if You want to listen on fe80::1 on the "myPeer" interface, the address would be "fe80::1%myPeer".</p>

<p>RoS 7.17 and newer can set the link local address.</p>

<pre class="highlight"><code>IPv4 peer
/routing bgp connection
add address-families=ipv4 disabled=no input.filter=dn42-in \
local.address=ADDRESS_YOUR_PEER_USE_TO_CONNECT_TO_YOU .role=ebgp \
multihop=yes name=PEER_NAME output.filter-chain=dn42-out \
.network=DN42_allocated_v4 remote.address=YOUR_PEER_REMOTE_ADDRESS \
.as=PEER_AS_NUMBER routing-table=main templates=DN42_template_v4

IPv6 peer
/routing bgp connection
add address-families=ipv6 disabled=no input.filter=dn42-in \
local.address=ADDRESS_YOUR_PEER_USE_TO_CONNECT_TO_YOU .role=ebgp \
multihop=yes name=PEER_NAME output.filter-chain=dn42-out \
.network=DN42_allocated_v6 remote.address=YOUR_PEER_REMOTE_ADDRESS \
.as=PEER_AS_NUMBER routing-table=main templates=DN42_template_v6</code></pre>

<h4><a class="anchor" id="ros-6-x-1" href="#ros-6-x-1"></a>RoS 6.x</h4>

<p>The older RouterOS 6.x is fairly similar, but the biggest difference is that instead of using Address Lists for your advertised subnets, you specify them directly in the BGP settings, in the Network menu. We'll deal with that later.</p>

<p>Create an instance, you can think of this as the BGP daemon that's running.
</p><pre class="highlight"><code>/routing bgp instance
set default disabled=yes
add as=YOUR_AS client-to-client-reflection=no name=bgp-dn42-somename out-filter=dn42-in router-id=1.1.1.1</code></pre>

<p>Let's add some peers. Right now we have just one, but we still need two connections - for IPv4 and IPv6</p>

<p>IPv4:
</p><pre class="highlight"><code>/routing bgp peer
add comment="DN42: somepeer IPv4" in-filter=dn42-in instance=bgp-dn42-somename multihop=yes \
name=dn42-somepeer-ipv4 out-filter=dn42-out remote-address=192.168.200.129 remote-as=PEER_AS \
route-reflect=yes ttl=default</code></pre>

<p>IPv6 (if desired):
</p><pre class="highlight"><code>/routing bgp peer
add address-families=ipv6 comment="DN42: somepeer IPv6" in-filter=dn42-in \
instance=bgp-dn42-somename multihop=yes name=dn42-somepeer-ipv6 out-filter=dn42-out \
remote-address=fd42:c644:5222:3222::40 remote-as=PEER_AS route-reflect=yes ttl=default</code></pre>

<p>NB: Mikrotik RoS 6.x doesn't deal well with BGP running over link-local addresses (addresses that start with with fe80). You need to use an fd42:: address in your BGP session, otherwise BGP will not install any received routes.</p>

<p>Finally we can advertise our routes. You're presumably advertising your allocated DN42 subnet, it's very simple:</p>

<pre class="highlight"><code>/routing bgp network
add network=YOUR_ALLOCATED_SUBNET synchronize=no</code></pre>

<p>You can repeat this for all the IPv4 and IPv6 networks that you host.</p>

<h2><a class="anchor" id="split-dns" href="#split-dns"></a>Split DNS</h2>

<p>You can separate DNS requests for the .dn42 TLD from your default DNS traffic. This allows regular (non-DN42) lookups to work as normal, while .dn42 queries are handled on the DN42 network.</p>

<p>Adjust the network and LAN GW in these examples to match your own network configuration.</p>

<h3><a class="anchor" id="ros-6-47-and-later" href="#ros-6-47-and-later"></a>RoS 6.47 and later</h3>

<p>Newer versions of RouterOS can redirect DNS queries according to special rules. We add a "static" DNS mapping that forwards matching queries to a specific DNS server:
</p><pre class="highlight"><code>/ip dns static
add comment=DN42 forward-to=172.23.0.53 regexp=".*\\.dn42" type=FWD</code></pre>

<h3><a class="anchor" id="ros-earlier-than-6-47" href="#ros-earlier-than-6-47"></a>RoS earlier than 6.47</h3>

<p>DNS redirection can be achieved with a Layer 7 (L7) filter in RouterOS. We define a new L7 protocol by matching the body of the DNS query, then use NAT to redirect those queries to a DN42 DNS server.</p>

<p>In this example we assume that your LAN hosts use the 192.168.0.0/24 subnet, and your gateway is 192.168.0.1</p>

<pre class="highlight"><code>/ip firewall layer7-protocol
add name=DN42-DNS regexp="\\x04dn42.\\x01"

/ip firewall nat
add action=src-nat chain=srcnat comment="NAT to DN42 DNS" dst-address=172.23.0.53 dst-port=53 protocol=udp src-address=192.168.0.0/24 to-addresses=192.168.0.1
add action=dst-nat chain=dstnat dst-address-type=local dst-port=53 layer7-protocol=DN42-DNS protocol=udp src-address=192.168.0.0/24 to-addresses=172.23.0.53 to-ports=53</code></pre>

<h2><a class="anchor" id="specifying-bgp-communities-v7" href="#specifying-bgp-communities-v7"></a>Specifying BGP Communities (v7)</h2>

<p>See the <a href="/howto/BGP-communities">BGP communities</a> page to understand what this means.</p>

<p>In this example we are applying community numbers 5 (peer link latency of 55-148ms) and 41 (prefixes originate from Europe) to our advertisements.</p>

<pre class="highlight"><code>/routing/filter/community-list
add list=dn42 communities=64511:41
add list=dn42 communities=64511:5

/routing/filter/rule/
add chain=dn42-out rule="append bgp-communities dn42"</code></pre>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>, <a href="https://iedon.net/post/24" rel="nofollow">IEDON-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>, <a href="https://dn42.jp/" rel="nofollow">dn42.jp</a> (wiki-go)</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/mikrotik.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/mikrotik.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
