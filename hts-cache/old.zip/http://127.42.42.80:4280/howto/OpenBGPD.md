<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-309be032396e783b13a47df58f389b7c8e11c2b2d42640560b874f677c25f6e5.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">

  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/OpenBGPD.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-f05401ee374f0c7f48fc2bc08e30b4f4db705861fd5895ed70998683b383bfb5.js" type="text/javascript"></script>
  

  <title>OpenBGPD</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>OpenBGPD</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/OpenBGPD.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <a class="btn btn-sm" id="minibutton-home" href="/">
      Home
    </a>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/overview"
          id="minibutton-overview"
        >
          Overview
        </a>

        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/latest_changes"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </a>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          href="/gollum/history/howto/OpenBGPD.md/"
          id="minibutton-history"
        >
          History
        </a>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    OpenBGPD
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <p>This guide describes a simple configuration for <a href="https://openbgpd.org">OpenBGPD</a> running on <a href="https://openbsd.org">OpenBSD</a>.
The <a href="https://openbgpd.org/ftp.html">portable version</a> should run with little to no configuration changes on other operating systems as well.</p>

<h1><a class="anchor" id="setup" href="#setup"></a>Setup</h1>

<p>Only IPv6 is used for the sake of simplicity.
Neighbors use ULA addresses (/127 transfer net) assigned from one of the peer's allocation.</p>

<p>The goal is to have a small, yet complete setup for all peers with ROA validation and other safety measurements in place.</p>

<h1><a class="anchor" id="configuration" href="#configuration"></a>Configuration</h1>

<p><a href="https://man.openbsd.org/bgpd.conf.5"><code>/etc/bgpd.conf</code></a> contains all information and may include further (automatically generated) files, as is done in this guide.</p>

<p>As per the manual, configuration is divided into logical sections;  <a href="http://cvsweb.openbsd.org/cgi-bin/cvsweb/%7Echeckout%7E/src/etc/examples/bgpd.conf?rev=HEAD&amp;content-type=text/plain&amp;only_with_tag=MAIN"><code>/etc/examples/bgpd.conf</code></a> is a complete and commented example which this guide is roughly based on.</p>

<p>By default, <a href="http://man.openbsd.org/bgpd.8">bgpd(8)</a> listens on all local addresses (on the current default <a href="http://man.openbsd.org/rdomain.4"><code>routing domain</code></a>), but this guide explicitly listens on the configured transfer ULA only for each peer to better illustrate of this setup.</p>

<h2><a class="anchor" id="local-host" href="#local-host"></a>local host</h2>

<p>Information such as ASN, router ID and allocated networks are required:
</p><pre class="highlight"><code><span class="c"># macros
</span><span class="n">ASN</span>=<span class="s2">"4242421234"</span>

<span class="c"># global configuration
</span><span class="n">AS</span> $<span class="n">ASN</span>
<span class="n">router</span>-<span class="n">id</span> <span class="m">1</span>.<span class="m">2</span>.<span class="m">3</span>.<span class="m">4</span>

<span class="n">prefix</span>-<span class="n">set</span> <span class="n">mynetworks</span> {
        <span class="n">fd00</span>:<span class="m">12</span>:<span class="m">34</span>::/<span class="m">48</span>
}</code></pre>

<p>These can be used in subsequent filter rules.
The local peer's announcements is then defined as follows:
</p><pre class="highlight"><code><span class="c"># Generate routes for the networks our ASN will originate.
# The communities (read 'tags') are later used to match on what
# is announced to EBGP neighbors
</span><span class="n">network</span> <span class="n">prefix</span>-<span class="n">set</span> <span class="n">mynetworks</span> <span class="n">set</span> <span class="n">large</span>-<span class="n">community</span> $<span class="n">ASN</span>:<span class="m">1</span>:<span class="m">1</span></code></pre>

<h2><a class="anchor" id="neighbors" href="#neighbors"></a>neighbors</h2>

<p>For each neighbor its ASN and transfer ULA is required.
An optional description is provided such that <a href="http://man.openbsd.org/bgpctl.8">bgpctl(8)</a> for example can be used with mnemonic names instead of AS numbers:
</p><pre class="highlight"><code><span class="c"># peer A, transport over IPSec/GRE
</span>$<span class="n">A_local</span>=<span class="s2">"fd00:12:34:A::1"</span>
$<span class="n">A_remote</span>=<span class="s2">"fd00:12:34:A::2"</span>
$<span class="n">A_ASN</span>=<span class="s2">"4242425678"</span>

<span class="n">listen</span> <span class="n">on</span> $<span class="n">A_local</span>

<span class="n">neighbor</span>  $<span class="n">A_remote</span> {
    <span class="n">remote</span>-<span class="n">as</span> $<span class="n">A_ASN</span>
    <span class="n">descr</span> <span class="s2">"A"</span>
}</code></pre>

<h2><a class="anchor" id="filter-rules" href="#filter-rules"></a>filter rules</h2>

<p><strong>bgpd</strong> blocks all BGP <strong>UPDATE</strong> messages by default.
The filter rules are evaluated in sequential order, form first to last.
The last matching allow or deny rule decides what action is taken.</p>

<p>Start off with basic protection and sanity rules:
</p><pre class="highlight"><code><span class="c"># deny more-specifics of our own originated prefixes
</span><span class="n">deny</span> <span class="n">quick</span> <span class="n">from</span> <span class="n">ebgp</span> <span class="n">prefix</span>-<span class="n">set</span> <span class="n">mynetworks</span> <span class="n">or</span>-<span class="n">longer</span>

<span class="c"># filter out too long paths, establish more peerings instead
</span><span class="n">deny</span> <span class="n">quick</span> <span class="n">from</span> <span class="n">any</span> <span class="n">max</span>-<span class="n">as</span>-<span class="n">len</span> <span class="m">8</span></code></pre>

<p><code>quick</code> rules are considered the last matching rule, and evaluation of subsequent rules is skipped.</p>

<p>Allow own announcements:
</p><pre class="highlight"><code><span class="c"># Outbound EBGP: only allow self originated networks to ebgp peers
# Don't leak any routes from upstream or peering sessions. This is done
# by checking for routes that are tagged with the large-community $ASN:1:1
</span><span class="n">allow</span> <span class="n">to</span> <span class="n">ebgp</span> <span class="n">prefix</span>-<span class="n">set</span> <span class="n">mynetworks</span> <span class="n">large</span>-<span class="n">community</span> $<span class="n">ASN</span>:<span class="m">1</span>:<span class="m">1</span></code></pre>

<p>Allow all remaining UPDATES based on <strong>O</strong>rigin <strong>V</strong>alidation <strong>S</strong>tates:
</p><pre class="highlight"><code><span class="c"># enforce ROA
</span><span class="n">allow</span> <span class="n">from</span> <span class="n">ebgp</span> <span class="n">ovs</span> <span class="n">valid</span></code></pre>

<p>Note how the <code>ovs</code> filter requires the <code>roa-set {...}</code> to be defined;  see the <code>ROA</code> section below.</p>

<h3><a class="anchor" id="path-attributes" href="#path-attributes"></a>path attributes</h3>

<p>Besides <code>allow</code> and <code>deny</code> statements, filter rules can modify UPDATE messages, e.g.
</p><pre class="highlight"><code><span class="c"># Scrub normal and large communities relevant to our ASN from EBGP neighbors
# https://tools.ietf.org/html/rfc7454#section-11
</span><span class="n">match</span> <span class="n">from</span> <span class="n">ebgp</span> <span class="n">set</span> { <span class="n">large</span>-<span class="n">community</span> <span class="n">delete</span> $<span class="n">ASN</span>:*:* }

<span class="c"># Honor requests to gracefully shutdown BGP sessions
# https://tools.ietf.org/html/rfc8326
</span><span class="n">match</span> <span class="n">from</span> <span class="n">any</span> <span class="n">community</span> <span class="n">GRACEFUL_SHUTDOWN</span> <span class="n">set</span> { <span class="n">localpref</span> <span class="m">0</span> }</code></pre>

<h1><a class="anchor" id="roa" href="#roa"></a>ROA</h1>

<p>An roa-set can be generated from the registry directly or you can use the following pre-build tables.</p>

<p>One single <code>roa-set</code> may be defined, against which <strong>bgpd</strong> will validate the origin of each prefix;  this allows filter rules to use the <code>ovs</code> keyword as demonstrated above.</p>

<p>ROA files generated by <a href="https://git.dn42.dev/burble/dn42regsrv">dn42regsrv</a> are available from burble.dn42:</p>

<table>
<thead>
<tr>
<th>URL</th>
<th> IPv4/IPv6 </th>
</tr>
</thead>
<tbody>
<tr>
<td>
<a href="https://dn42.burble.com/roa/dn42_roa_obgpd_46.conf">https://dn42.burble.com/roa/dn42_roa_obgpd_46.conf</a>  </td>
<td> Both </td>
</tr>
<tr>
<td>
<a href="https://dn42.burble.com/roa/dn42_roa_obgpd_4.conf">https://dn42.burble.com/roa/dn42_roa_obgpd_4.conf</a>  </td>
<td> IPv4 Only </td>
</tr>
<tr>
<td>
<a href="https://dn42.burble.com/roa/dn42_roa_obgpd_6.conf">https://dn42.burble.com/roa/dn42_roa_obgpd_6.conf</a>  </td>
<td> IPv6 Only </td>
</tr>
</tbody>
</table>

<p><code>/etc/dn42.roa-set</code> is the generated set:
</p><pre class="highlight"><code><span class="n">roa</span>-<span class="n">set</span> {
    <span class="n">fd00</span>:<span class="m">12</span>:<span class="m">34</span>::/<span class="m">48</span> <span class="n">source</span>-<span class="n">as</span> <span class="m">4242421234</span>
    <span class="n">fd00</span>:<span class="n">ab</span>:<span class="n">cd</span>::/<span class="m">44</span> <span class="n">maxlen</span> <span class="m">64</span> <span class="n">source</span>-<span class="n">as</span> <span class="m">4242427890</span>
    ...
}</code></pre>

<p>Include it in <code>/etc/bgpd.conf</code>:
</p><pre class="highlight"><code><span class="c"># defines roat-set, see _rpki-client crontab
</span><span class="n">include</span> <span class="s2">"/etc/dn42.roa-set"</span></code></pre>

<h1><a class="anchor" id="looking-glass" href="#looking-glass"></a>Looking glass</h1>

<p>This is mostly OpenBSD specific since <a href="http://man.openbsd.org/bgplg.8">bgplg(8)</a> and <a href="http://man.openbsd.org/httpd.8">httpd(8)</a> ship as part of the operating system.
The <strong>bgplg</strong> manual contains the few steps and example <a href="http://man.openbsd.org/httpd.conf.5">httpd.conf(5)</a> required to enable the looking glass.</p>

<p>See <a href="https://t4-2.high5.nl/bgplg">https://t4-2.high5.nl/bgplg</a> for a running instance operating within DN42.</p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
<li>
<p><a href="/Home" rel="nofollow">Home</a></p>

<ul>
<li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
<li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
<li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
<li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
<li><a href="/FAQ" rel="nofollow">FAQ</a></li>
</ul>
</li>
<li>
<p>How-To</p>

<ul>
<li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
<li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
<li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
<li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
<li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
<li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
<li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
<li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
<li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
<li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
<li><a href="/howto/Quagga" rel="nofollow">Quagga</a></li>
<li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
<li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
<li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
<li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
<li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
<li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
<li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
<li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
</ul>
</li>
<li>
<p>Services</p>

<ul>
<li><a href="/services/IRC" rel="nofollow">IRC</a></li>
<li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
<li><a href="/services/DNS" rel="nofollow">DNS</a></li>
<li><a href="/services/IX-Collection" rel="nofollow">IX Collection</a></li>
<li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
<li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
<li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
<li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
<li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
<li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
<li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
</ul>
</li>
<li>
<p>Internal</p>

<ul>
<li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
<li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
<li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
<li>
<a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a><br />
</li>
<li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
</ul>
</li>
<li>
<p>Historical</p>

<ul>
<li>
<a href="/historical/Bird" rel="nofollow">Bird 1</a> / </li>
</ul>
</li>
<li>
<p>External Tools</p>

<ul>
<li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
<li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
</ul>
</li>
</ul>

<hr />

	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p>Hosted by: <a href="mailto:xuu@sour.is" rel="nofollow">xuu</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">nurtic-vibe</a>, <a href="mailto:tom@xcv.vc" rel="nofollow">toBee</a>, <a href="mailto:dn42@burble.com" rel="nofollow">burble</a> | Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a></p>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/OpenBGPD.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/OpenBGPD.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
