<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/IPsecWithPublicKeys/strongSwan4Example.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>strongSwan4Example</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>strongSwan4Example</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/IPsecWithPublicKeys/strongSwan4Example.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/IPsecWithPublicKeys/strongSwan4Example.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    strongSwan4Example
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/IPsecWithPublicKeys/">IPsecWithPublicKeys</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="ipsec-with-public-key-authentication-on-strongswan-5-0-0" href="#ipsec-with-public-key-authentication-on-strongswan-5-0-0"></a>IPsec with public key authentication on strongSwan &lt; 5.0.0</h1>
<h2><a class="anchor" id="setup" href="#setup"></a>Setup</h2>
<h3><a class="anchor" id="generate-an-rsa-keypair" href="#generate-an-rsa-keypair"></a>Generate an RSA keypair</h3>

<pre class="highlight"><code>root@debian:~# <span class="nb">mkdir</span> /etc/ipsec.d/public
root@debian:~# ipsec pki <span class="nt">--gen</span> <span class="nt">--type</span> rsa <span class="nt">--outform</span> pem <span class="nt">--size</span> 4096 <span class="o">&gt;</span> /etc/ipsec.d/private/mykey.pem
root@debian:~# ipsec pki <span class="nt">--pub</span> <span class="nt">--in</span> /etc/ipsec.d/private/mykey.pem <span class="nt">--outform</span> pem <span class="o">&gt;</span> /etc/ipsec.d/public/mykey.pub
root@debian:~# <span class="nb">echo</span> <span class="s2">": RSA mykey.pem"</span> <span class="o">&gt;&gt;</span> /etc/ipsec.secrets</code></pre>

<h3><a class="anchor" id="exchange-public-keys-with-your-peer" href="#exchange-public-keys-with-your-peer"></a>Exchange public keys with your peer</h3>
<ol>
  <li>Display the public key. Send the key data to your peer.</li>
</ol>

<pre class="highlight"><code>root@debian:~# more /etc/ipsec.d/public/mykey.pub
<span class="nt">-----BEGIN</span> PUBLIC KEY-----
MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA2/FWIJuVUtfsLovavNp+
nPSsT2mQoNK3ZUUwuEKfBjT7mhijdXRHh1SAtIaU2aen5+d5q6e27vMCCYOQLagn
9CkKatBq54zGNvDSzQEpz0mIsaBx9xjvhsgqAmKCTpLtKuMz6cZbH8y8o9/ZZ8Kv
+Jht67T8BDKXczgOg5IIaX84UpCrlSgmnSvKYKu3PXnt91bZ66HaDZJjPf9aiMNc
fvuUqVfFWnsV2zI6HFvG/uwkqLalsnPaAwVeIWl2Ovy2Jzdj0GRLSYx87eneSBo+
7tjlURQTudAj1+53SFOkBcCPSnzPYpIC3hBfZ8Zw8r/25moW3xf8TlLLJqgAh50Y
tVyvyVSv1MKYBdjZcFsEXUceC5LI9JZryB/Serq0R+4//ZiR3LEtetVKNvco9bcI
JHXr88HM2XeYRfRPAB6wembIEMKYdwIhwYAPPAtL+lDHtZBiBAIAp0y0FhaozSzl
MSry8tbJR2fD/i8/yXr5isVfjJZdw8WK0LAd8a8zvmNIFKgiKWjoDgIycM5HrRD+
rY0Br9xONkNdgB7Lz/wPEyUsiIiZpawM/S4taX7ExK4Wi3pdxkOHLn2ZyaWKsdhX
PpCkdMfSOJ0SqCUcVze+xD8GlInUQsPgbDGvxT73jT6Ie+wSA94Cgs3mq7FS6cNo
ZAASv7cT9DG+xfQmjrJC9SUCAwEAAQ<span class="o">==</span>
<span class="nt">-----END</span> PUBLIC KEY-----</code></pre>

<ol>
  <li>Convert your peer's public key to the Base64 RFC 3110 format using the <a href="https://dn42.us/git/user/ryan/pubkey-converter.git/plain/pubkey-converter.pl" title="Public key conversion script">pubkey-converter</a> script, if necessary.</li>
</ol>

<h2><a class="anchor" id="configuration" href="#configuration"></a>Configuration</h2>
<h3><a class="anchor" id="configure-the-phase-1-ike-parameters" href="#configure-the-phase-1-ike-parameters"></a>Configure the phase 1 IKE parameters</h3>
<p>In this example, we'll use the following settings:</p>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Key</th>
      <th style="text-align:left;">Value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">Encryption</td>
      <td style="text-align:left;">AES-128</td>
    </tr>
    <tr>
      <td style="text-align:left;">Hash</td>
      <td style="text-align:left;">HMAC-SHA1</td>
    </tr>
    <tr>
      <td style="text-align:left;">DH Group</td>
      <td style="text-align:left;">5 (modp1536)</td>
    </tr>
    <tr>
      <td style="text-align:left;">Lifetime</td>
      <td style="text-align:left;">28800 seconds</td>
    </tr>
    <tr>
      <td style="text-align:left;">Peer address</td>
      <td style="text-align:left;">192.0.2.2</td>
    </tr>
    <tr>
      <td style="text-align:left;">Local address</td>
      <td style="text-align:left;">192.0.2.1</td>
    </tr>
  </tbody>
</table>

<p><em>Note: strongSwan &lt; 5.0.0 will read PEM-formatted <strong>private</strong> keys, but requires public keys to be added to the configuration in Base64 RFC 3110 format. Convert your host's public key from PEM to Base64 RFC 3110 for inclusion in ipsec.conf as described below.</em></p>

<ol>
  <li>Configure a connection policy in ipsec.conf for your peer. The <code>leftrsasigkey</code> attribute is your host's public key in Base64 RFC 3110 format enclosed in double quotes, and <code>rightrsasigkey</code> is your peer's key.</li>
</ol>

<pre class="highlight"><code>root@debian:~# <span class="nb">cat</span> <span class="o">&lt;&lt;</span> <span class="no">EOF</span><span class="sh"> &gt;&gt; /etc/ipsec.conf
conn MYPEER
    # peer IPs
    left=192.0.2.1
    right=192.0.2.2
    # phase 1 parameters
    ike=aes128-sha1-modp1536!
    ikelifetime=28800s
    # authentication
    authby=pubkey
    leftrsasigkey="0sAwEAAdvxViCblVLX7C6L2rzafpz0rE9pkKDSt2VFMLhCnwY0+5oYo3V0R4dUgLSGlNmnp+fneauntu7zAgmDkC2oJ/QpCmrQaueMxjbw0s0BKc9JiLGgcfcY74bIKgJigk6S7SrjM+nGWx/MvKPf2WfCr/iYbeu0/AQyl3M4DoOSCGl/OFKQq5UoJp0rymCrtz157fdW2euh2g2SYz3/WojDXH77lKlXxVp7FdsyOhxbxv7sJKi2pbJz2gMFXiFpdjr8tic3Y9BkS0mMfO3p3kgaPu7Y5VEUE7nQI9fud0hTpAXAj0p8z2KSAt4QX2fGcPK/9uZqFt8X/E5SyyaoAIedGLVcr8lUr9TCmAXY2XBbBF1HHguSyPSWa8gf0nq6tEfuP/2YkdyxLXrVSjb3KPW3CCR16/PBzNl3mEX0TwAesHpmyBDCmHcCIcGADzwLS/pQx7WQYgQCAKdMtBYWqM0s5TEq8vLWyUdnw/4vP8l6+YrFX4yWXcPFitCwHfGvM75jSBSoIilo6A4CMnDOR60Q/q2NAa/cTjZDXYAey8/8DxMlLIiImaWsDP0uLWl+xMSuFot6XcZDhy59mcmlirHYVz6QpHTH0jidEqglHFc3vsQ/BpSJ1ELD4Gwxr8U+940+iHvsEgPeAoLN5quxUunDaGQAEr+3E/QxvsX0Jo6yQvUl"
    rightrsasigkey="0sAwEAAbkNYV9/gBIi4rOKeY75mCHxIGqvePPBlNp5LkdYGSuPwqYa3HJs7YAA1P05IhOSDjqO8yj6Wq3JfHWcCX1/o/aCBH7yB6lmxfKyJJiQwJ+WUADQ7FSklb7vJ6jWYQLJQZBVMNSJeiia3WRMFeCCy42Zj4zf0yKcz0rbn3ii31K+zqHRZyV3b1hltTsEVUfGD2T/td0tp22qqISWWLpU8xHBGlhYV0Ss5tXcV6rdh9Evd5r+Qk9Cc1VAL9+ZQd/TTKnEcK4ORbMNM+OPJ5Xp0qSA5z/ACD5ubITX/ZGSQpLDhPRnzzM+SmQzqEd61j772qWP2bPkgc/Haz8B62WoRio8Vdk8Ze12JBRFr63vq6YlkonSLJ84sxAUNXmuiJ8HemNvbs5kC4brNTj34ZwiJAFcnCvrLQmTmz5emm6JpP2r2k/hcJ40YEmc5KLZWwNiB4BIxduguGt2VBgcA2fu61NgOwymx0TfOH+tgXDMomaWr1z75OAFEA+fpUSLWxQw3mWLaCHR2/YJjHDR1rBi/GFcRdgPCAL6+0NU0H8JtljwFr42otq25esPGWIkAT1MJBbVAE11O18hnC5owhiRoB2aAKjx3XV9c+x6LBSHfkknO7oAp1DbcEmB6vg3MwVXU2uuWj7++fM8Xis1KiQSspj+B5Lx5RJlxz9qAEOBuj05"
EOF</span></code></pre>

<ol>
  <li>All done! Configure the phase 2 parameters as you otherwise would.</li>
</ol>

<h2><a class="anchor" id="full-gre-ipsec-example" href="#full-gre-ipsec-example"></a>Full GRE/IPsec example</h2>

<pre class="highlight"><code>root@debian:~# ip addr show dev gre1
11: gre1@NONE: &lt;POINTOPOINT,NOARP,UP,LOWER_UP&gt; mtu 1400 qdisc noqueue state UNKNOWN
    <span class="nb">link</span>/gre 192.0.2.1 peer 192.0.2.2
    inet 10.1.2.0/31 scope global gre1
        valid_lft forever preferred_lft forever
    inet6 fe80::200:5efe:6825:1c22/64 scope <span class="nb">link
         </span>valid_lft forever preferred_lft forever
root@debian:~# more /etc/ipsec.conf
<span class="c"># ipsec.conf - strongSwan IPsec configuration file</span>

config setup

conn %default
    <span class="nv">keyexchange</span><span class="o">=</span>ikev1
    <span class="nv">dpdaction</span><span class="o">=</span>restart

conn MYPEER
    <span class="c"># peer IPs</span>
    <span class="nv">left</span><span class="o">=</span>192.0.2.1
    <span class="nv">right</span><span class="o">=</span>192.0.2.2
    <span class="c"># phase 1 parameters</span>
    <span class="nv">ike</span><span class="o">=</span>aes128-sha1-modp1536!
    <span class="nv">ikelifetime</span><span class="o">=</span>28800s
    <span class="c"># authentication</span>
    <span class="nv">authby</span><span class="o">=</span>pubkey
    <span class="nv">leftrsasigkey</span><span class="o">=</span><span class="s2">"0sAwEAAdvxViCblVLX7C6L2rzafpz0rE9pkKDSt2VFMLhCnwY0+5oYo3V0R4dUgLSGlNmnp+fneauntu7zAgmDkC2oJ/QpCmrQaueMxjbw0s0BKc9JiLGgcfcY74bIKgJigk6S7SrjM+nGWx/MvKPf2WfCr/iYbeu0/AQyl3M4DoOSCGl/OFKQq5UoJp0rymCrtz157fdW2euh2g2SYz3/WojDXH77lKlXxVp7FdsyOhxbxv7sJKi2pbJz2gMFXiFpdjr8tic3Y9BkS0mMfO3p3kgaPu7Y5VEUE7nQI9fud0hTpAXAj0p8z2KSAt4QX2fGcPK/9uZqFt8X/E5SyyaoAIedGLVcr8lUr9TCmAXY2XBbBF1HHguSyPSWa8gf0nq6tEfuP/2YkdyxLXrVSjb3KPW3CCR16/PBzNl3mEX0TwAesHpmyBDCmHcCIcGADzwLS/pQx7WQYgQCAKdMtBYWqM0s5TEq8vLWyUdnw/4vP8l6+YrFX4yWXcPFitCwHfGvM75jSBSoIilo6A4CMnDOR60Q/q2NAa/cTjZDXYAey8/8DxMlLIiImaWsDP0uLWl+xMSuFot6XcZDhy59mcmlirHYVz6QpHTH0jidEqglHFc3vsQ/BpSJ1ELD4Gwxr8U+940+iHvsEgPeAoLN5quxUunDaGQAEr+3E/QxvsX0Jo6yQvUl"</span>
    <span class="nv">rightrsasigkey</span><span class="o">=</span><span class="s2">"0sAwEAAbkNYV9/gBIi4rOKeY75mCHxIGqvePPBlNp5LkdYGSuPwqYa3HJs7YAA1P05IhOSDjqO8yj6Wq3JfHWcCX1/o/aCBH7yB6lmxfKyJJiQwJ+WUADQ7FSklb7vJ6jWYQLJQZBVMNSJeiia3WRMFeCCy42Zj4zf0yKcz0rbn3ii31K+zqHRZyV3b1hltTsEVUfGD2T/td0tp22qqISWWLpU8xHBGlhYV0Ss5tXcV6rdh9Evd5r+Qk9Cc1VAL9+ZQd/TTKnEcK4ORbMNM+OPJ5Xp0qSA5z/ACD5ubITX/ZGSQpLDhPRnzzM+SmQzqEd61j772qWP2bPkgc/Haz8B62WoRio8Vdk8Ze12JBRFr63vq6YlkonSLJ84sxAUNXmuiJ8HemNvbs5kC4brNTj34ZwiJAFcnCvrLQmTmz5emm6JpP2r2k/hcJ40YEmc5KLZWwNiB4BIxduguGt2VBgcA2fu61NgOwymx0TfOH+tgXDMomaWr1z75OAFEA+fpUSLWxQw3mWLaCHR2/YJjHDR1rBi/GFcRdgPCAL6+0NU0H8JtljwFr42otq25esPGWIkAT1MJBbVAE11O18hnC5owhiRoB2aAKjx3XV9c+x6LBSHfkknO7oAp1DbcEmB6vg3MwVXU2uuWj7++fM8Xis1KiQSspj+B5Lx5RJlxz9qAEOBuj05"</span>
    <span class="c"># phase 2 parameters</span>
    <span class="nv">esp</span><span class="o">=</span>aes128-sha1!
    <span class="nv">pfs</span><span class="o">=</span><span class="nb">yes
    </span><span class="nv">pfsgroup</span><span class="o">=</span>modp1536
    <span class="nv">lifetime</span><span class="o">=</span>3600s
    <span class="nb">type</span><span class="o">=</span>transport
    <span class="nv">leftprotoport</span><span class="o">=</span>gre
    <span class="nv">rightprotoport</span><span class="o">=</span>gre
    <span class="c"># startup</span>
    <span class="nv">auto</span><span class="o">=</span>route
    <span class="nv">keyingtries</span><span class="o">=</span>%forever</code></pre>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
      <li><a href="/Links" rel="nofollow">Links</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
      <li><a href="/howto/GeoFeed" rel="nofollow">GeoFeed</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/DNS" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">RPKI</a></li>
      <li><a href="/services/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
      <li><a href="/services/Registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
      <li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
    </ul>
  </li>
  <li>Historical
    <ul>
      <li><a href="/historical/Bird" rel="nofollow">Bird 1</a></li>
      <li><a href="/historical/Quagga" rel="nofollow">Quagga</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://hedgedoc.dn42.eu" rel="nofollow">HedgeDoc</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/IPsecWithPublicKeys/strongSwan4Example.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/IPsecWithPublicKeys/strongSwan4Example.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
