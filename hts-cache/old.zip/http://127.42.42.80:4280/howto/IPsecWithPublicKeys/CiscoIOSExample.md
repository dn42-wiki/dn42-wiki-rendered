<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-309be032396e783b13a47df58f389b7c8e11c2b2d42640560b874f677c25f6e5.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">

  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/IPsecWithPublicKeys/CiscoIOSExample.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-f05401ee374f0c7f48fc2bc08e30b4f4db705861fd5895ed70998683b383bfb5.js" type="text/javascript"></script>
  

  <title>CiscoIOSExample</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>CiscoIOSExample</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/IPsecWithPublicKeys/CiscoIOSExample.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <a class="btn btn-sm" id="minibutton-home" href="/">
      Home
    </a>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/overview"
          id="minibutton-overview"
        >
          Overview
        </a>

        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/latest_changes"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </a>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          href="/gollum/history/howto/IPsecWithPublicKeys/CiscoIOSExample.md/"
          id="minibutton-history"
        >
          History
        </a>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    CiscoIOSExample
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/IPsecWithPublicKeys/">IPsecWithPublicKeys</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="ipsec-with-public-key-authentication-on-cisco-ios" href="#ipsec-with-public-key-authentication-on-cisco-ios"></a>IPsec with public key authentication on Cisco IOS</h1>
<h2><a class="anchor" id="setup" href="#setup"></a>Setup</h2>
<h3><a class="anchor" id="generate-an-rsa-keypair" href="#generate-an-rsa-keypair"></a>Generate an RSA keypair</h3>
<p><em>Note: You may already have completed this step, since it's required to enable SSH.</em></p>

<ol>
  <li>
    <p>Configure a hostname and domain name.</p>

    <pre><code> Router#conf t
 Router(config)#hostname foo
 foo(config)#ip domain-name bar
</code></pre>
  </li>
  <li>
    <p>Generate an RSA key. The maximum length was increased from 2048 to 4096 as of release 15.1(1)T</p>

    <pre><code> foo(config)#crypto key generate rsa general-keys modulus 2048
 % The key modulus size is 2048 bits
 % Generating 2048 bit RSA keys, keys will be non-exportable...
 foo(config)#exit
</code></pre>
  </li>
</ol>

<h3><a class="anchor" id="exchange-public-keys-with-your-peer" href="#exchange-public-keys-with-your-peer"></a>Exchange public keys with your peer</h3>
<ol>
  <li>
    <p>Display the public key. Send the key data portion to your peer.</p>

    <pre><code>  foo#show crypto key mypubkey rsa foo.bar
  % Key pair was generated at: 19:24:02 UTC Jul 19 2014
  Key name: foo.bar
  Storage Device: not specified
  Usage: General Purpose Key
  Key is not exportable.
  Key Data:
   30820122 300D0609 2A864886 F70D0101 01050003 82010F00 3082010A 02820101
   00ABF25E 090CBDFC 47B3763B 01E38993 584F1D47 49DEE0FC 6A766D95 F416C5A8
   83E16EF2 19C00BC9 64B3E351 D6F43E57 461AC689 912C22FE C4BE10EE 05750F27
   FEBB9C8C 2DFC7DD7 C0D1E8B2 7F022F54 04101205 60E47D99 2307E625 404F1130
   CBD1759B BBDBBF89 0C0F6B09 52E50A81 BFCC6AA6 96AFF612 B700AEA5 0EDFCDDB
   D3C7E014 2A59CD82 29A403CA 01EE580A CC4A3A2C C36369FE D2FA0FEF 2DC32D50
   1C55A296 3CBD6AAC 6AA66C73 FAB30A12 CFD1341D C261E013 8A7DA310 8D0E6C99
   C248D554 D0D68508 3EA53F0F 971DA7A6 203CA186 A79F9D93 0D2E54EF F7E311B2
   F7A8B486 D980661D DEB6C0B3 80A82583 4936F131 57C6D204 0AA5ED7F 7749F044
   8F020301 0001
</code></pre>
  </li>
  <li>
    <p>Convert your peer's public key to the hexadecimal DER format using the <a href="https://git.dn42.dev/ryan/pubkey-converter/raw/master/pubkey-converter.pl" title="Public key conversion script">pubkey-converter</a> script, if necessary.</p>
  </li>
</ol>

<h2><a class="anchor" id="configuration" href="#configuration"></a>Configuration</h2>
<h3><a class="anchor" id="configure-the-phase-1-ike-parameters" href="#configure-the-phase-1-ike-parameters"></a>Configure the phase 1 IKE parameters</h3>
<p>In this example, we'll use the following settings:</p>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Key</th>
      <th style="text-align:left;">Value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">Encryption</td>
      <td style="text-align:left;">AES-128</td>
    </tr>
    <tr>
      <td style="text-align:left;">Hash</td>
      <td style="text-align:left;">HMAC-SHA1</td>
    </tr>
    <tr>
      <td style="text-align:left;">DH Group</td>
      <td style="text-align:left;">5 (modp1536)</td>
    </tr>
    <tr>
      <td style="text-align:left;">Lifetime</td>
      <td style="text-align:left;">28800 seconds</td>
    </tr>
    <tr>
      <td style="text-align:left;">Peer address</td>
      <td style="text-align:left;">192.0.2.2</td>
    </tr>
    <tr>
      <td style="text-align:left;">Local address</td>
      <td style="text-align:left;">192.0.2.1</td>
    </tr>
  </tbody>
</table>

<ol>
  <li>
    <p>Add your peer's public key</p>

    <pre><code> foo#conf t
 Enter configuration commands, one per line.  End with CNTL/Z.
 foo(config)#crypto key pubkey-chain rsa
 foo(config-pubkey-chain)#addressed-key 192.0.2.2
 foo(config-pubkey-key)#key-string
 Enter a public key as a hexidecimal number ....

 foo(config-pubkey)#30820122 300D0609 2A864886 F70D0101 01050003 82010F00 3082010A 02820101
 foo(config-pubkey)#00F3E0AA 8924E512 C08BA87C 73820A15 E5180DDC EF827221 2B3864BF B2D2A5E0
 foo(config-pubkey)#33D04C1D 43A0CAF8 617EEEBA 7DB5BD38 429660CC 3144618E 4F386201 52483DA7
 foo(config-pubkey)#FDDF7AAC DCA8C19D FF5B1956 14F63831 ACE70D0F 4C557CE7 220C7E8B 9A2C837F
 foo(config-pubkey)#065A2B41 23B68074 C57F6F78 2F222DA1 915A095C CED77FF3 F1DF849C 3FD086EA
 foo(config-pubkey)#0A74901D 99DA97D5 0CFB22E7 C6C827E6 E53BE215 8D4928D2 458B02E2 1600F1F1
 foo(config-pubkey)#F1128D63 3A55EC4B 54E6A8E1 0B197E1E 7DA31CC2 54C30A2D 03BE5B8A 16A5E324
 foo(config-pubkey)#F3B15B67 C3FB2831 7F31610A 3BD59E74 E749DC25 74424F3F 7EC305AD 0BFA5008
 foo(config-pubkey)#E36C6E00 854433B6 A0E8DBF1 7A4741DD A91A5320 1D5150FA 28F12273 56A3E9A2
 foo(config-pubkey)#D5020301 0001
 foo(config-pubkey)#quit
 foo(config-pubkey-key)#exit
 foo(config-pubkey-chain)#exit
</code></pre>
  </li>
  <li>
    <p>Configure an ISAKMP policy</p>

    <pre><code> foo(config)#crypto isakmp policy 10
 foo(config-isakmp)#encryption aes
 foo(config-isakmp)#hash sha
 foo(config-isakmp)#group 5
 foo(config-isakmp)#lifetime 28800
 foo(config-isakmp)#authentication rsa-sig
 foo(config-isakmp)#exit
</code></pre>
  </li>
  <li>
    <p>All done! Configure the phase 2 parameters as you otherwise would.</p>
  </li>
</ol>

<h2><a class="anchor" id="full-gre-ipsec-example" href="#full-gre-ipsec-example"></a>Full GRE/IPsec example</h2>
<pre><code>crypto key pubkey-chain rsa
 addressed-key 192.0.2.2
  address 192.0.2.2
  key-string
   30820122 300D0609 2A864886 F70D0101 01050003 82010F00 3082010A 02820101
   00F3E0AA 8924E512 C08BA87C 73820A15 E5180DDC EF827221 2B3864BF B2D2A5E0
   33D04C1D 43A0CAF8 617EEEBA 7DB5BD38 429660CC 3144618E 4F386201 52483DA7
   FDDF7AAC DCA8C19D FF5B1956 14F63831 ACE70D0F 4C557CE7 220C7E8B 9A2C837F
   065A2B41 23B68074 C57F6F78 2F222DA1 915A095C CED77FF3 F1DF849C 3FD086EA
   0A74901D 99DA97D5 0CFB22E7 C6C827E6 E53BE215 8D4928D2 458B02E2 1600F1F1
   F1128D63 3A55EC4B 54E6A8E1 0B197E1E 7DA31CC2 54C30A2D 03BE5B8A 16A5E324
   F3B15B67 C3FB2831 7F31610A 3BD59E74 E749DC25 74424F3F 7EC305AD 0BFA5008
   E36C6E00 854433B6 A0E8DBF1 7A4741DD A91A5320 1D5150FA 28F12273 56A3E9A2
   D5020301 0001
  quit
!
crypto isakmp policy 10
 encr aes
 group 5
 lifetime 28800
!
crypto ipsec transform-set tset esp-aes esp-sha-hmac
 mode transport
!
crypto ipsec profile FOO
 set transform-set tset
 set pfs group5
!
interface Tunnel0
 ip address 10.1.2.0 255.255.255.254
 ip mtu 1400
 tunnel source 192.0.2.1
 tunnel destination 192.0.2.2
 tunnel protection ipsec profile FOO
!
interface FastEthernet0/0
 description WAN
 ip address 192.0.2.1 255.255.255.0
 duplex full
</code></pre>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li><a href="/Home" rel="nofollow">Home</a></li>
  <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
  <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
  <li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
  <li><a href="/howto/Bird-communities" rel="nofollow">BGP communities</a></li>
  <li>
    <p><a href="/FAQ" rel="nofollow">FAQ</a></p>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li>
<a href="/howto/Bird" rel="nofollow">Bird</a> / <a href="/howto/Bird2" rel="nofollow">Bird2</a>
</li>
      <li><a href="/howto/Quagga" rel="nofollow">Quagga</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/vyos" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/DNS" rel="nofollow">DNS</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
      <li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:xuu@sour.is" rel="nofollow">xuu</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">nurtic-vibe</a>, <a href="mailto:tom@xcv.vc" rel="nofollow">toBee</a>, <a href="mailto:dn42@burble.com" rel="nofollow">burble</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>
</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/IPsecWithPublicKeys/CiscoIOSExample.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/IPsecWithPublicKeys/CiscoIOSExample.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
