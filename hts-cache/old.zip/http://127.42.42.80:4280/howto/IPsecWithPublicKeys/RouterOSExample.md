<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/IPsecWithPublicKeys/RouterOSExample.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>RouterOSExample</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>RouterOSExample</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/IPsecWithPublicKeys/RouterOSExample.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/IPsecWithPublicKeys/RouterOSExample.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    RouterOSExample
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/IPsecWithPublicKeys/">IPsecWithPublicKeys</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="ipsec-with-public-key-authentication-on-mikrotik-routeros" href="#ipsec-with-public-key-authentication-on-mikrotik-routeros"></a>IPsec with public key authentication on Mikrotik RouterOS</h1>
<h2><a class="anchor" id="setup" href="#setup"></a>Setup</h2>
<h3><a class="anchor" id="generate-an-rsa-keypair" href="#generate-an-rsa-keypair"></a>Generate an RSA keypair</h3>

<pre class="highlight"><code>[admin@mtk1] &gt; /ip ipsec key
[admin@mtk1] /ip ipsec key&gt; generate-key mykey key-size=4096
For key bigger than 1024bit this may take a while..
[admin@mtk1] /ip ipsec key&gt; print
Flags: P - private-key, R - rsa
 #    NAME                                                             KEY-SIZE
 0 PR mykey                                                            4096-bit</code></pre>

<h2><a class="anchor" id="exchange-public-keys-with-your-peer" href="#exchange-public-keys-with-your-peer"></a>Exchange public keys with your peer</h2>
<ol>
  <li>Export the public key to a file.</li>
</ol>

<pre class="highlight"><code>[admin@mtk1] /ip ipsec key&gt; export-pub-key mykey file-name=mykey.pub

[admin@mtk1] /ip ipsec key&gt; /file print where name=mykey.pub
 # NAME                   TYPE                        SIZE CREATION-TIME
 2 mykey.pub              ssh key                      451 jul/20/2014 12:35:33</code></pre>

<ol>
  <li>Copy the file to your workstation and send it to your peer. The contents of the file should look like this:</li>
</ol>

<pre class="highlight"><code>-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAv4RHohMZP4F5qTJKqoSL
TqefoZZRt1RVI5dOocjV1pJZnqcXMtHfQ/5+O+igUCAX+yBv0hie+U32FWcy5cQO
+xaohZW1zFzvlRWVqOpTwdk/993Zmy070T1FzK4kFShsNtxYrtYNheCnakgfXgMg
23w/35zcof64/ewzF6RuqkTzmccIFCWDuv2IobXTOYAk7G3PGN4xWscvFIroIy5s
4E8oOmKWVoFErQA6XetJzI+X+knzI3J/6/Pff4Tz7TLxu1m2I0InFaBv1G0+BXnh
QOvIM7fvs5s0YWaUdT+vz8F0SHtb6Q/IdWc4JJPH/Q2t4HKTkk7FUnvvub2GxVbs
8QIDAQAB
-----END PUBLIC KEY-----</code></pre>

<ol>
  <li>Convert your peer's public key to the PEM format using the <a href="https://dn42.us/git/user/ryan/pubkey-converter.git/plain/pubkey-converter.pl" title="Public key conversion script">pubkey-converter</a> script, if necessary.</li>
</ol>

<h2><a class="anchor" id="configuration" href="#configuration"></a>Configuration</h2>
<h3><a class="anchor" id="configure-the-phase-1-ike-parameters" href="#configure-the-phase-1-ike-parameters"></a>Configure the phase 1 IKE parameters</h3>
<p>In this example, we'll use the following settings:</p>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Key</th>
      <th style="text-align:left;">Value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">Encryption</td>
      <td style="text-align:left;">AES-128</td>
    </tr>
    <tr>
      <td style="text-align:left;">Hash</td>
      <td style="text-align:left;">HMAC-SHA1</td>
    </tr>
    <tr>
      <td style="text-align:left;">DH Group</td>
      <td style="text-align:left;">5 (modp1536)</td>
    </tr>
    <tr>
      <td style="text-align:left;">Lifetime</td>
      <td style="text-align:left;">28800 seconds</td>
    </tr>
    <tr>
      <td style="text-align:left;">Peer address</td>
      <td style="text-align:left;">192.0.2.2</td>
    </tr>
    <tr>
      <td style="text-align:left;">Local address</td>
      <td style="text-align:left;">192.0.2.1</td>
    </tr>
  </tbody>
</table>

<ol>
  <li>Copy your peer's PEM-encoded public key to the router and import it. (Hit enter when it asks for a passphrase)</li>
</ol>

<pre class="highlight"><code>[admin@mtk1] /ip ipsec key&gt; import peer-key.pub name=peer-key
passphrase:

[admin@mtk1] /ip ipsec key&gt; print
Flags: P - private-key, R - rsa
 #    NAME                                                             KEY-SIZE
 0 PR mykey                                                            4096-bit
 1  R peer-key                                                         4096-bit</code></pre>

<ol>
  <li>Configure your peer definition to use the public key</li>
</ol>

<pre class="highlight"><code>[admin@mtk1] /ip ipsec peer&gt; add address=192.0.2.2 local-address=192.0.2.1 enc-algorithm=aes-128 hash-algorithm=sha1 dh-group=modp1536 lifetime=28800 key=mykey remote-key=peer-key auth-method=rsa-key
[admin@mtk1] /ip ipsec peer&gt; print
Flags: X - disabled
 0   address=192.0.2.2/32 local-address=192.0.2.1 passive=no port=500
     auth-method=rsa-key key=mykey remote-key=peer-key generate-policy=no
     exchange-mode=main send-initial-contact=yes nat-traversal=no
     proposal-check=obey hash-algorithm=sha1 enc-algorithm=aes-128
     dh-group=modp1536 lifetime=8h lifebytes=0 dpd-interval=2m
     dpd-maximum-failures=5</code></pre>

<ol>
  <li>All done! Configure the phase 2 parameters as you otherwise would.</li>
</ol>

<h2><a class="anchor" id="full-gre-ipsec-example" href="#full-gre-ipsec-example"></a>Full GRE/IPsec example</h2>
<pre class="highlight"><code># jul/20/2014 13:00:04 by RouterOS 6.15
# software id = HBCA-0B2J
#
/interface gre
add dscp=inherit local-address=192.0.2.1 mtu=1400 name=gre-tunnel1 \
    remote-address=192.0.2.2
/ip address
add address=10.1.2.0/31 interface=gre-tunnel1 network=10.1.2.0
/ip ipsec proposal
set [ find default=yes ] lifetime=1h pfs-group=modp1536
/ip ipsec peer
add address=192.0.2.2/32 auth-method=rsa-key dh-group=modp1536 key=mykey \
    lifetime=8h local-address=192.0.2.1 remote-key=peer-key
/ip ipsec policy
add dst-address=192.0.2.2/32 protocol=gre sa-dst-address=192.0.2.2 \
    sa-src-address=192.0.2.1 src-address=192.0.2.1/32</code></pre>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/Policies" rel="nofollow">Policies</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
      <li><a href="/Links" rel="nofollow">Links</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
      <li><a href="/howto/GeoFeed" rel="nofollow">GeoFeed</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/dns/Overview" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">RPKI</a></li>
      <li><a href="/services/exchanges/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Pingables" rel="nofollow">Pingables</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/ca/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
      <li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
    </ul>
  </li>
  <li>Historical
    <ul>
      <li><a href="/historical/Bird" rel="nofollow">Bird 1</a></li>
      <li><a href="/historical/Quagga" rel="nofollow">Quagga</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://hedgedoc.dn42.eu" rel="nofollow">HedgeDoc</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/IPsecWithPublicKeys/RouterOSExample.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/IPsecWithPublicKeys/RouterOSExample.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
