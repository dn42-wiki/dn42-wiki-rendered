<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/IPsec-on-FreeBSD.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>IPsec-on-FreeBSD</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>IPsec-on-FreeBSD</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/IPsec-on-FreeBSD.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/IPsec-on-FreeBSD.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    IPsec-on-FreeBSD
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="ipsec-on-freebsd" href="#ipsec-on-freebsd"></a>IPsec on FreeBSD</h1>

<p>These instructions are for IPsec in transport mode not IPsec in tunnel mode. IPsec in tunnel mode requires a too tight coupling with the routing table for dynamic routing because the policies can only be specified based on source/destination address and protocol not based on interfaces.</p>

<h2><a class="anchor" id="requirements" href="#requirements"></a>Requirements</h2>
<ul>
  <li>Root access to both endpoints.</li>
  <li>Static IPv4 addresses for both endpoints unless you want to write a small shell script as hook for racoon.</li>
  <li>At least one static IPv4 on at least one endpoint unless you hate yourself.</li>
</ul>

<h2><a class="anchor" id="kernel-configuration" href="#kernel-configuration"></a>Kernel configuration</h2>
<p>The FreeBSD GENERIC kernel lacks support for in-kernel IPsec processing. Add these two lines to your kernel config and (re-)build your own kernel.
If you're new to FreeBSD, check chapters <a href="http://www.freebsd.org/doc/handbook/ipsec.html">15.9.1</a> and <a href="http://www.freebsd.org/doc/handbook/kernelconfig.html">9</a> of the FreeBSD handbook.
</p><pre class="highlight"><code><span class="n">options</span>   <span class="n">IPSEC</span>        <span class="c">#IP security
</span><span class="n">device</span>    <span class="n">crypto</span></code></pre>
Reboot into your new kernel.

<h2><a class="anchor" id="userland-configuration" href="#userland-configuration"></a>Userland configuration</h2>

<p>Install the racoon daemon. It's included in the <a href="http://www.freshports.org/security/ipsec-tools/">security/ipsec-tools</a> port.
Racoon is pain in the ass to configure the first time because its error messages aren't helping and the complexity of IPsec. Don't let this stop you.
</p><pre class="highlight"><code><span class="n">path</span>    <span class="n">pre_shared_key</span>  <span class="s2">"/usr/local/etc/racoon/psk"</span>;
<span class="n">path</span>    <span class="n">certificate</span>     <span class="s2">"/usr/local/etc/racoon/certs"</span>;
<span class="n">log</span>     <span class="n">info</span>;

<span class="n">listen</span> {
        <span class="n">isakmp</span>          <span class="n">a</span>.<span class="n">b</span>.<span class="n">c</span>.<span class="n">d</span> [<span class="m">500</span>];
        <span class="n">isakmp_natt</span>     <span class="n">a</span>.<span class="n">b</span>.<span class="n">c</span>.<span class="n">d</span> [<span class="m">4500</span>];
}

<span class="n">padding</span> {
        <span class="n">strict_check</span>    <span class="n">on</span>;
}

<span class="n">timer</span> {
        <span class="n">natt_keepalive</span>   <span class="m">5</span> <span class="n">sec</span>;
        <span class="n">interval</span>         <span class="m">3</span> <span class="n">sec</span>;
        <span class="n">phase1</span>          <span class="m">45</span> <span class="n">sec</span>; <span class="c"># give embedded CPUs time to finish RSA operations
</span>        <span class="n">phase2</span>          <span class="m">45</span> <span class="n">sec</span>;
}

<span class="n">remote</span> <span class="n">b</span>.<span class="n">c</span>.<span class="n">d</span>.<span class="n">e</span> [<span class="m">500</span>] {
        <span class="n">exchange_mode</span>           <span class="n">main</span>;
        <span class="n">proposal_check</span>          <span class="n">strict</span>;
        <span class="n">my_identifier</span>           <span class="n">asn1dn</span>;
        <span class="n">peers_identifier</span>        <span class="n">asn1dn</span>;
        <span class="n">lifetime</span>                <span class="n">time</span> <span class="m">1</span> <span class="n">hour</span>;
        <span class="n">certificate_type</span>        <span class="n">x509</span> <span class="s2">"self.crt"</span> <span class="s2">"self.key"</span>;
        <span class="n">peers_certfile</span>          <span class="n">x509</span> <span class="s2">"peer.crt"</span>;
        <span class="n">ca_type</span>                 <span class="n">x509</span> <span class="s2">"ca.crt"</span>;
        <span class="n">verify_cert</span>             <span class="n">on</span>;
        <span class="n">send_cert</span>               <span class="n">off</span>; <span class="c"># neither send
</span>        <span class="n">send_cr</span>                 <span class="n">off</span>; <span class="c"># nor request a crt to be send
</span>
        <span class="n">proposal</span> {
                <span class="n">encryption_algorithm</span>    <span class="n">aes</span> <span class="m">256</span>;
                <span class="n">hash_algorithm</span>          <span class="n">sha256</span>;
                <span class="n">authentication_method</span>   <span class="n">rsasig</span>;
                <span class="n">dh_group</span>                <span class="n">modp4096</span>;
        }
}

<span class="n">sainfo</span> (<span class="n">address</span> <span class="n">a</span>.<span class="n">b</span>.<span class="n">c</span>.<span class="n">d</span> <span class="n">gre</span> <span class="n">address</span> <span class="n">b</span>.<span class="n">c</span>.<span class="n">d</span>.<span class="n">e</span> <span class="n">gre</span>) {
        <span class="n">pfs_group</span>                       <span class="n">modp4096</span>;
        <span class="n">lifetime</span>                        <span class="n">time</span> <span class="m">1</span> <span class="n">hour</span>;
        <span class="n">encryption_algorithm</span>            <span class="n">aes</span> <span class="m">256</span>;
        <span class="n">authentication_algorithm</span>        <span class="n">hmac_sha1</span>;
}
</code></pre>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>, <a href="https://iedon.net/post/24" rel="nofollow">IEDON-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>, <a href="https://dn42.jp/" rel="nofollow">dn42.jp</a> (wiki-go)</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/IPsec-on-FreeBSD.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/IPsec-on-FreeBSD.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
