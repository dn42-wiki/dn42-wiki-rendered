<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/mpls-bird2.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>mpls-bird2</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>mpls-bird2</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/mpls-bird2.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/mpls-bird2.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    mpls-bird2
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <p>Original Article: <a href="https://blog.sherpherd.net/2024/02/11/RunYourMPLSNetworkWithBIRD_en.html">https://blog.sherpherd.net/2024/02/11/RunYourMPLSNetworkWithBIRD_en.html</a></p>

<h1><a class="anchor" id="intro" href="#intro"></a>Intro</h1>
<p>Now, most tutorials about running MPLS on Linux are based on FRR. Because in a long time, FRR and its predecessor Quagga are the only choices who provide industry standard MPLS  related protocol (LDP, BGP-LU, BGP IPv4/IPv6 MPLS L3VPN, etc.) implementation, by the time, most of other routing software don't even have availiable MPLS support.</p>

<p>The most popular routing software among DN42 users, BIRD, has added availiable MPLS support in its newest version (2.14), now BIRD has MPLS-aware, labeled route producing routing protocol, too. (No LDP still though) <a href="#c1"><sup>[1]</sup></a></p>

<p>The newest BIRD 2.0 User Guide has added MPLS function related chapter<a href="#c2"><sup>[2]</sup></a>, this is an excerpt:</p>

<blockquote>
  <p>In BIRD, the whole process generally works this way: A MPLS-aware routing protocol (say BGP) receives
routing information including remote label. It produces a route with attribute mpls policy (p. 30) specifying
desired MPLS label policy (p. 18). Such route then passes the import filter (which could modify the MPLS
label policy or perhaps assign a static label) and when it is accepted, a local MPLS label is selected (according
to the label policy) and attached to the route, producing labeled route. When a new MPLS label is allocated,
the MPLS-aware protocol automatically produces corresponding MPLS route. When all labeled routes that
use specific local MPLS label are retracted, the corresponding MPLS route is retracted too. <br />
There are three important concepts for MPLS in BIRD: MPLS domains, MPLS tables and MPLS channels.
MPLS domain represents an independent label space, all MPLS-aware protocols are associated with some MPLS domain. It is responsible for label management, handling label allocation requests from MPLS-aware protocols. MPLS table is just a routing table for MPLS routes. Routers usually have one MPLS domain and one MPLS table, with Kernel protocol to export MPLS routes into kernel FIB. <br /> 
MPLS channels make protocols MPLS-aware, they are responsible for keeping track of active FECs (and corresponding allocated labels), selecting FECs / local labels for labeled routes, and maintaining correspondence between labeled routes and MPLS routes.</p>
</blockquote>

<p>As mentioned above, the current BGP implementation of BIRD is MPLS-awared, can be used to assign and distribute MPLS labeled route.</p>

<p>In this article, I will make use of official BIRD document to show readers how to construct a simple MPLS VPN network running with BIRD.</p>

<h1><a class="anchor" id="prerequisites" href="#prerequisites"></a>Prerequisites</h1>
<ul>
  <li>Unless specific configuration, your node must running completely independent kernel (dedicated server, KVM virtualization, etc.), so that you can enable MPLS kernel module.</li>
  <li>If you using Vultr VPS, due to unknown reason, Vultr integrated system image has some trouble with MPLS, please reinstall your system with official ISO after deployment.</li>
</ul>

<h1><a class="anchor" id="table-of-contents" href="#table-of-contents"></a>Table of Contents</h1>
<ul>
  <li><a href="#intro">Intro</a></li>
  <li><a href="#prerequisites">Prerequisites</a></li>
  <li><a href="#table-of-contents">Table of Contents</a></li>
  <li>
<a href="#1-lab-topo">1 Lab Topo</a>
    <ul>
      <li><a href="#1-1-node-specs">1.1 Node Specs</a></li>
    </ul>
  </li>
  <li>
<a href="#2-preliminary-work">2 Preliminary Work</a>
    <ul>
      <li><a href="#2-1-enable-mpls-kernel-module">2.1 Enable MPLS Kernel Module</a></li>
      <li>
<a href="#2-2-kernel-parameter-adjustment">2.2 Kernel Parameter Adjustment</a>
        <ul>
          <li><a href="#2-2-1-enable-mpls-input-on-mpls-port">2.2.1 Enable MPLS Input on MPLS Port</a></li>
        </ul>
      </li>
      <li>
<a href="#2-3-create-vrf-and-assign-vrf-for-port">2.3 Create VRF and assign VRF for port</a>
        <ul>
          <li><a href="#2-3-1-adjust-client-faced-port-mtu-to-avoid-fragmentation">2.3.1 Adjust Client-faced Port MTU to Avoid Fragmentation</a></li>
        </ul>
      </li>
      <li><a href="#2-4-ip-address-and-static-route-configuration">2.4 IP Address and Static Route Configuration</a></li>
      <li>
<a href="#2-5-installing-bird">2.5 Installing BIRD</a>
        <ul>
          <li><a href="#2-5-1-install-compiling-and-building-dependencies">2.5.1 Install Compiling and Building Dependencies</a></li>
          <li><a href="#2-5-2-clone-bird-2-14-repo">2.5.2 Clone BIRD 2.14 Repo</a></li>
          <li><a href="#2-5-3-build-software-package-of-bird-2-14">2.5.3 Build Software Package of BIRD 2.14</a></li>
        </ul>
      </li>
    </ul>
  </li>
  <li>
<a href="#3-bird-configuration">3 BIRD Configuration</a>
    <ul>
      <li>
<a href="#3-1-basic-setup">3.1 Basic Setup</a>
        <ul>
          <li><a href="#3-1-1-router-id">3.1.1 Router ID</a></li>
          <li><a href="#3-1-2-adding-mpls-domain-and-tables">3.1.2 Adding MPLS Domain and Tables</a></li>
          <li><a href="#3-1-3-adding-mpls-and-vrf-related-protocol-and-configuration">3.1.3 Adding MPLS and VRF Related Protocol and Configuration</a></li>
        </ul>
      </li>
      <li><a href="#3-2-bgp-configuration">3.2 BGP Configuration</a></li>
      <li><a href="#3-3-setup-binding-between-mpls-l3vpn-and-vrf-instance">3.3 Setup Binding between MPLS L3VPN and VRF Instance</a></li>
      <li>
<a href="#3-4-complete-bird-configuration-file">3.4 Complete BIRD Configuration File</a>
        <ul>
          <li><a href="#3-4-1-r1">3.4.1 R1</a></li>
          <li><a href="#3-4-2-r2">3.4.2 R2</a></li>
          <li><a href="#3-4-3-r3">3.4.3 R3</a></li>
        </ul>
      </li>
    </ul>
  </li>
  <li>
<a href="#4-verification">4 Verification</a>
    <ul>
      <li><a href="#4-1-check-vpnv4-table">4.1 Check VPNv4 Table</a></li>
      <li><a href="#4-2-check-default-ipv4-table">4.2 Check Default IPv4 Table</a></li>
      <li><a href="#4-3-check-vrf-ipv4-table">4.3 Check VRF IPv4 Table</a></li>
      <li><a href="#4-4-check-connectivity-between-pc1-and-pc2">4.4 Check connectivity between PC1 and PC2</a></li>
    </ul>
  </li>
  <li><a href="#5-reference">5 Reference</a></li>
</ul>

<h1><a class="anchor" id="1-lab-topo" href="#1-lab-topo"></a>1 Lab Topo</h1>
<pre class="highlight"><code>
                 ----------------------------------------------------------
--------         |    --------            --------            --------    |         --------
|      |  eth0 ens20  |      | ens19 ens19|      | ens20 ens19|      |  ens20 eth0  |      |
| PC1  | O==========O |  R1  |O==========O|  R3  |O==========O|  R2  | O==========O | PC2  |
|      |         |    |      |            |      |            |      |    |         |      |
--------         |    --------            --------            --------    |         --------
                 |                                                        |
                 |         Confederation ASN: 100                         |
                 |                    R1 ASN: 64512                       |
                 |                    R2 ASN: 64513                       |
                 |                    R3 ASN: 64514                       |
                 |                        RT: 100:500                     |
                 |                     R1 RT: 203.0.113.1:500             |
                 |                     R2 RT: 203.0.113.2:500             |
                 |                                                        |
                 ----------------------------------------------------------
                 |                    Address Assignment                  |
                 ----------------------------------------------------------
                 |                                                        |
                 |                  eth0@PC1: 192.168.1.2/24              |
                 |                  ens20@R1: 192.168.1.1/24              |
                 |                                (vrf blue)              |
                 |                     lo@R1: 203.0.113.1/32              |
                 |                  ens19@R1: 203.0.113.1/32              |
                 |                     lo@R3: 203.0.113.3/32              |
                 |                  ens19@R3: 203.0.113.3/32              |
                 |                  ens20@R3: 203.0.113.3/32              |
                 |                     lo@R2: 203.0.113.2/32              |
                 |                  ens19@R2: 203.0.113.2/32              |
                 |                  ens20@R2: 192.168.2.1/24              |
                 |                                (vrf blue)              |
                 |                  eth0@PC2: 192.168.2.2/24              |
                 |                                                        |
                 ----------------------------------------------------------
</code></pre>

<h2><a class="anchor" id="1-1-node-specs" href="#1-1-node-specs"></a>1.1 Node Specs</h2>
<p>PC1, R1, R2 and PC2 all running Debian 12. R1 and R2 both installed newest version BIRD by the time I finished this, the BIRD 2.14.</p>

<p><strong>Notice: Remember to add third port for R1, R2 and R3 to make them able to access Internet for downloading BIRD software package or compiling dependencies</strong></p>

<h1><a class="anchor" id="2-preliminary-work" href="#2-preliminary-work"></a>2 Preliminary Work</h1>
<h2><a class="anchor" id="2-1-enable-mpls-kernel-module" href="#2-1-enable-mpls-kernel-module"></a>2.1 Enable MPLS Kernel Module</h2>
<p>Run these command on R1 and R2 with root permission:
</p><pre class="highlight"><code>modprobe mpls_router
modprobe mpls_iptunnel
modprobe mpls_gso</code></pre>
<h2><a class="anchor" id="2-2-kernel-parameter-adjustment" href="#2-2-kernel-parameter-adjustment"></a>2.2 Kernel Parameter Adjustment</h2>
<p>Run these command on R1, R2 and R3 with root permission to adjust parameters related to IP routing and MPLS, make them able to work<a href="#c3"><sup>[3]</sup></a>:
</p><pre class="highlight"><code>cat &gt;/etc/sysctl.d/90-mpls-router.conf &lt;&lt;EOF
net.ipv4.ip_forward=1
net.ipv6.conf.all.forwarding=1
net.ipv4.conf.all.rp_filter=0
net.mpls.platform_labels=1048575
net.ipv4.tcp_l3mdev_accept=1
net.ipv4.udp_l3mdev_accept=1
net.mpls.conf.lo.input=1
EOF
sysctl -p /etc/sysctl.d/90-mpls-router.conf</code></pre>
<h3><a class="anchor" id="2-2-1-enable-mpls-input-on-mpls-port" href="#2-2-1-enable-mpls-input-on-mpls-port"></a>2.2.1 Enable MPLS Input on MPLS Port</h3>
<p>Every port transits MPLS traffic need to enable MPLS input, run these command on R1 and R2 with root permission to enable MPLS input for their port ens19:
</p><pre class="highlight"><code>sysctl -w net.mpls.conf.ens19.input=1</code></pre>
So do on R3:
<pre class="highlight"><code>sysctl -w net.mpls.conf.ens19.input=1
sysctl -w net.mpls.conf.ens20.input=1</code></pre>
<strong>Notice: Every MPLS traffic transiting port need this configuration</strong>
<h2><a class="anchor" id="2-3-create-vrf-and-assign-vrf-for-port" href="#2-3-create-vrf-and-assign-vrf-for-port"></a>2.3 Create VRF and assign VRF for port</h2>
<p>Run these command on R1 and R2 with root permission to create a VRF interface named "blue":
</p><pre class="highlight"><code>ip link add blue type vrf table 500
ip link set blue up</code></pre>
Run these command on R1 and R2 with root permission to assign ens20 to VRF blue then enable it:
<pre class="highlight"><code>ip link set ens20 master blue up</code></pre>
<h3><a class="anchor" id="2-3-1-adjust-client-faced-port-mtu-to-avoid-fragmentation" href="#2-3-1-adjust-client-faced-port-mtu-to-avoid-fragmentation"></a>2.3.1 Adjust Client-faced Port MTU to Avoid Fragmentation</h3>
<p>In practice, increasing MTU of core network link is always harder than decreasing client-faced port MTU, and using MPLS incur additional packet header overhead (4 bytes per label), this made large packet may get fragmented when entering MPLS network. To avoid this, we need to approviately decrease the MTU of client-faced port.</p>

<p>Run these command on PC1 and PC2 with root permission to adjust MTU of eth0 then enable it:
</p><pre class="highlight"><code>ip link set eth0 mtu 1492 up</code></pre>
Run these command on R1 and R2 with root permission to adjust MTU of ens20:
<pre class="highlight"><code>ip link set ens20 mtu 1492</code></pre>
<h2><a class="anchor" id="2-4-ip-address-and-static-route-configuration" href="#2-4-ip-address-and-static-route-configuration"></a>2.4 IP Address and Static Route Configuration</h2>
<p>Run command with root permission on nodes below to done this.
R1:
</p><pre class="highlight"><code>ip addr add 203.0.113.1/32 dev lo
ip addr add 203.0.113.1/32 dev ens19 peer 203.0.113.3/32
ip addr add 192.168.1.1/24 dev ens20</code></pre>
R2:
<pre class="highlight"><code>ip addr add 203.0.113.2/32 dev lo
ip addr add 203.0.113.2/32 dev ens19 peer 203.0.113.3/32
ip addr add 192.168.2.1/24 dev ens20</code></pre>
R3:
<pre class="highlight"><code>ip addr add 203.0.113.3/32 dev lo
ip addr add 203.0.113.3/32 dev ens19 peer 203.0.113.1/32
ip addr add 203.0.113.3/32 dev ens20 peer 203.0.113.2/32</code></pre>
PC1:
<pre class="highlight"><code>ip addr add 192.168.1.2/24 dev eth0
ip route add 192.168.2.0/24 via 192.168.1.1</code></pre>
PC1:
<pre class="highlight"><code>ip addr add 192.168.2.2/24 dev eth0
ip route add 192.168.1.0/24 via 192.168.2.1</code></pre>
<h2><a class="anchor" id="2-5-installing-bird" href="#2-5-installing-bird"></a>2.5 Installing BIRD</h2>
<p>The compile installed BIRD is incomplete, it lacks system service file, docs, etc.</p>

<p>If you want complete BIRD, you have to build software package then install from it.</p>

<p>If you don't want build yourself, you can download them here (deb package):</p>

<p><a href="https://drive.google.com/drive/folders/1DUaFJgZGsEXI-RlreNxCG9mnERiAkIVB?usp=drive_link">https://drive.google.com/drive/folders/1DUaFJgZGsEXI-RlreNxCG9mnERiAkIVB?usp=drive_link</a></p>

<p>If hints dependency miss, follow the hint to install missed dependency.</p>

<p>If you want to build it yourself, please read the rest of this chapter.</p>

<p>Prepare a compile node running Debian 12, no need of high spec, mine got 4 cores and 4 gigs of RAM, then do as follow.</p>

<h3><a class="anchor" id="2-5-1-install-compiling-and-building-dependencies" href="#2-5-1-install-compiling-and-building-dependencies"></a>2.5.1 Install Compiling and Building Dependencies</h3>
<pre class="highlight"><code>apt install -y git linuxdoc-tools autoconf build-essential libssh-dev libreadline-dev libncurses-dev flex bison checkinstall debhelper docbook-xsl libssh-gcrypt-dev quilt xsltproc linuxdoc-tools-latex texlive-latex-extra</code></pre>
<pre class="highlight"><code>pipx install apkg</code></pre>
<h3><a class="anchor" id="2-5-2-clone-bird-2-14-repo" href="#2-5-2-clone-bird-2-14-repo"></a>2.5.2 Clone BIRD 2.14 Repo</h3>
<pre class="highlight"><code>git clone --branch v2.14 https://gitlab.nic.cz/labs/bird.git</code></pre>
<h3><a class="anchor" id="2-5-3-build-software-package-of-bird-2-14" href="#2-5-3-build-software-package-of-bird-2-14"></a>2.5.3 Build Software Package of BIRD 2.14</h3>
<p>Enter "bird" then run command below:
</p><pre class="highlight"><code>apkg build</code></pre>
Once finished, apkg gives hint like this:
<pre class="highlight"><code>built 3 packages in: pkg/pkgs/debian-12/bird2_2.14.1707409394.0e1fbaa5-cznic.1</code></pre>
The built software package is located in the location the hint mentioned, make use of it.

<h1><a class="anchor" id="3-bird-configuration" href="#3-bird-configuration"></a>3 BIRD Configuration</h1>
<p>Currently BIRD don't have implementation of distributing MPLS labeled route through IGP topo, so we use BGP-LU to do that.</p>
<h2><a class="anchor" id="3-1-basic-setup" href="#3-1-basic-setup"></a>3.1 Basic Setup</h2>
<h3><a class="anchor" id="3-1-1-router-id" href="#3-1-1-router-id"></a>3.1.1 Router ID</h3>
<p>Having a static Router ID is always not a bad thing.</p>

<p>R1:
</p><pre class="highlight"><code>router id 203.0.113.1;</code></pre>
So do on R2 and R3.

<h3><a class="anchor" id="3-1-2-adding-mpls-domain-and-tables" href="#3-1-2-adding-mpls-domain-and-tables"></a>3.1.2 Adding MPLS Domain and Tables</h3>
<p>Use R1 as example, so do on other nodes:
</p><pre class="highlight"><code>mpls domain mpls_dom;

mpls table bgp_mpls_table;

vpn4 table bgp_vpn4;

ipv4 table vrf_blue4; # This one is no need on R3</code></pre>

<h3><a class="anchor" id="3-1-3-adding-mpls-and-vrf-related-protocol-and-configuration" href="#3-1-3-adding-mpls-and-vrf-related-protocol-and-configuration"></a>3.1.3 Adding MPLS and VRF Related Protocol and Configuration</h3>
<p>Use R1 as example:
</p><pre class="highlight"><code>protocol kernel krt_mpls {
	mpls {
		table bgp_mpls_table;
		export all;
	};
}

protocol kernel vrf_blue_4 { # No need for R3, since it doesn't run any VRF instance
	vrf "blue";
	ipv4 {
		table vrf_blue4;
		export all;
		import all;
	};
	kernel table 500;
}

protocol static {
	ipv4;
	route 203.0.113.1/32 reject; # Inject direct route through static, for advertising it in BGP
}

protocol static {                # Same, no need for R3
	ipv4 { table vrf_blue4; };
	route 192.168.1.0/24 reject;
}</code></pre>

<h2><a class="anchor" id="3-2-bgp-configuration" href="#3-2-bgp-configuration"></a>3.2 BGP Configuration</h2>
<p>Use R1 as example:
</p><pre class="highlight"><code>protocol bgp r3 {
	local 203.0.113.1 as 64512;
	neighbor 203.0.113.3 as 64514;
	confederation 100;
	confederation member;
	ipv4 mpls { # Enable IPv4 Labeled Unicast channel, to enable MPLS reachability between MPLS nodes
		import all;
		export all;
	};
	vpn4 mpls { # Enable VPNv4 channel, carring IPv4 VPN route
		table bgp_vpn4;
		import all;
		export all;
	};
	mpls {
		label policy aggregate;
	};
}</code></pre>

<h2><a class="anchor" id="3-3-setup-binding-between-mpls-l3vpn-and-vrf-instance" href="#3-3-setup-binding-between-mpls-l3vpn-and-vrf-instance"></a>3.3 Setup Binding between MPLS L3VPN and VRF Instance</h2>
<p>No need for R3, it doesn't run any VRF instance.</p>

<p>Use R1 as example:
</p><pre class="highlight"><code>protocol l3vpn vpn_blue4 {
	vrf "blue";
	ipv4 { table vrf_blue4; }; # # Binding VRF Table
	vpn4 { table bgp_vpn4; }; # Binding VPNv4 Table
	mpls { label policy vrf; };

	rd 203.0.113.1:500;
	import target [(rt,100,500)]; # Define RT the desired route import from binded VPNv4 to VRF have
	export target [(rt,100,500)]; # Define RT the route export from VRF to binded VPNv4 will be attached
}</code></pre>

<h2><a class="anchor" id="3-4-complete-bird-configuration-file" href="#3-4-complete-bird-configuration-file"></a>3.4 Complete BIRD Configuration File</h2>
<h3><a class="anchor" id="3-4-1-r1" href="#3-4-1-r1"></a>3.4.1 R1</h3>
<pre class="highlight"><code>log syslog all;

router id 203.0.113.1;

mpls domain mpls_dom;

mpls table bgp_mpls_table;

vpn4 table bgp_vpn4;

ipv4 table vrf_blue4;

protocol device {

}

protocol direct {
	disabled; # Disable by default
	ipv4;			# Connect to default IPv4 table
	ipv6;			# ... and to default IPv6 table
}

protocol kernel {
	ipv4 {			# Connect protocol to IPv4 table by channel
	      export all;	# Export to protocol. default is export none
	      import all;
	};
}

protocol kernel {
	ipv6 { export all; };
}

protocol kernel krt_mpls {
	mpls {
		table bgp_mpls_table;
		export all;
	};
}

protocol kernel vrf_blue_4 {
	vrf "blue";
	ipv4 {
		table vrf_blue4;
		export all;
		import all;
	};
	kernel table 500;
}

protocol static {
	ipv4;			# Again, IPv4 channel with default options
	route 203.0.113.1/32 reject;
}

protocol static {
	ipv4 { table vrf_blue4; };
	route 192.168.1.0/24 reject;
}

protocol bgp r3 {
	local 203.0.113.1 as 64512;
	neighbor 203.0.113.3 as 64514;
	confederation 100;
	confederation member;
	ipv4 mpls {
		import all;
		export all;
	};
	vpn4 mpls {
		table bgp_vpn4;
		import all;
		export all;
	};
	mpls {
		label policy aggregate;
	};
}

protocol l3vpn vpn_blue4 {
	vrf "blue";
	ipv4 { table vrf_blue4; };
	vpn4 { table bgp_vpn4; };
	mpls { label policy vrf; };

	rd 203.0.113.1:500;
	import target [(rt,100,500)];
	export target [(rt,100,500)];
}
</code></pre>
<h3><a class="anchor" id="3-4-2-r2" href="#3-4-2-r2"></a>3.4.2 R2</h3>
<pre class="highlight"><code>router id 203.0.113.2;

log syslog all;

mpls domain mpls_dom;

mpls table bgp_mpls_table;

vpn4 table bgp_vpn4;

ipv4 table vrf_blue4;

protocol device {
}

protocol direct {
	disabled; # Disable by default
	ipv4;			# Connect to default IPv4 table
	ipv6;			# ... and to default IPv6 table
}

protocol kernel krt_mpls {
        mpls {
                table bgp_mpls_table;
                export all;
        };
}

protocol kernel vrf_blue_4 {
        vrf "blue";
        ipv4 {
                table vrf_blue4;
                export all;
                import all;
        };
        kernel table 500;
}

protocol kernel {
	ipv4 {			# Connect protocol to IPv4 table by channel
	      export all;	# Export to protocol. default is export none
	};
}

protocol kernel {
	ipv6 { export all; };
}

protocol static {
	ipv4;			# Again, IPv4 channel with default options
	route 203.0.113.2/32 reject;
}

protocol static {
	ipv4 { table vrf_blue4; };
	route 192.168.2.0/24 reject;
}

protocol bgp r3 {
        local 203.0.113.2 as 64513;
        neighbor 203.0.113.3 as 64514;
        confederation 100;
        confederation member;
        ipv4 mpls {
                import all;
                export all;
        };
        vpn4 mpls {
                table bgp_vpn4;
                import all;
                export all;
        };
        mpls {
                label policy aggregate;
        };
}

protocol l3vpn vpn_blue4 {
        vrf "blue";
        ipv4 { table vrf_blue4; };
        vpn4 { table bgp_vpn4; };
        mpls { label policy vrf; };

        rd 203.0.113.2:500;
        import target [(rt,100,500)];
        export target [(rt,100,500)];
}
</code></pre>
<h3><a class="anchor" id="3-4-3-r3" href="#3-4-3-r3"></a>3.4.3 R3</h3>
<pre class="highlight"><code>log syslog all;

router id 203.0.113.3;

mpls domain mpls_dom;

mpls table bgp_mpls_table;

vpn4 table bgp_vpn4;

protocol device {
}

protocol direct {
	disabled;		# Disable by default
	ipv4;			# Connect to default IPv4 table
	ipv6;			# ... and to default IPv6 table
}

protocol kernel {
	ipv4 {			# Connect protocol to IPv4 table by channel
	      export all;	# Export to protocol. default is export none
	};
}

protocol kernel {
	ipv6 { export all; };
}

protocol kernel krt_mpls {
	mpls {
		table bgp_mpls_table;
		export all;
	};
};

protocol static {
	ipv4;			# Again, IPv4 channel with default options

}

protocol bgp r1 {
        local 203.0.113.3 as 64514;
        neighbor 203.0.113.1 as 64512;
        confederation 100;
        confederation member;
        ipv4 mpls {
		next hop self;
                import all;
                export all;
        };
        vpn4 mpls {
		next hop self;
                table bgp_vpn4;
                import all;
                export all;
        };
        mpls {
                label policy aggregate;
        };
}

protocol bgp r2 {
        local 203.0.113.3 as 64514;
        neighbor 203.0.113.2 as 64513;
        confederation 100;
        confederation member;
        ipv4 mpls {
		next hop self;
                import all;
                export all;
        };
        vpn4 mpls {
		next hop self;
                table bgp_vpn4;
                import all;
                export all;
        };
        mpls {
                label policy aggregate;
        };
}
</code></pre>

<h1><a class="anchor" id="4-verification" href="#4-verification"></a>4 Verification</h1>
<h2><a class="anchor" id="4-1-check-vpnv4-table" href="#4-1-check-vpnv4-table"></a>4.1 Check VPNv4 Table</h2>
<p>R1：
</p><pre class="highlight"><code>bird&gt; show route table bgp_vpn4
Table bgp_vpn4:
203.0.113.2:500 192.168.2.0/24 mpls 1001 unicast [r3 23:20:55.236] * (100) [AS64513i]
        via 203.0.113.3 on ens19 mpls 1002
203.0.113.1:500 192.168.1.0/24 mpls 1002 unicast [vpn_blue4 22:58:48.918] * (120/0)
        dev blue
bird&gt;</code></pre>
R2：
<pre class="highlight"><code>bird&gt; show route table bgp_vpn4
Table bgp_vpn4:
203.0.113.2:500 192.168.2.0/24 mpls 1001 unicast [vpn_blue4 23:20:55.219] * (120/0)
        dev blue
203.0.113.1:500 192.168.1.0/24 mpls 1002 unicast [r3 22:58:56.352] * (100) [AS64512i]
        via 203.0.113.3 on ens19 mpls 1003
bird&gt;</code></pre>
<h2><a class="anchor" id="4-2-check-default-ipv4-table" href="#4-2-check-default-ipv4-table"></a>4.2 Check Default IPv4 Table</h2>
<p>R1：
</p><pre class="highlight"><code>bird&gt; show route table master4
Table master4:
203.0.113.2/32 mpls 1000 unicast [r3 22:58:56.355] * (100) [AS64513i]
        via 203.0.113.3 on ens19 mpls 1000
203.0.113.1/32       unreachable [static1 22:33:27.446] * (200)
bird&gt;</code></pre>
R2：
<pre class="highlight"><code>bird&gt; show route table master4
Table master4:
203.0.113.2/32       unreachable [static1 22:32:38.874] * (200)
203.0.113.1/32 mpls 1000 unicast [r3 22:58:56.352] * (100) [AS64512i]
        via 203.0.113.3 on ens19 mpls 1001
bird&gt;</code></pre>
<h2><a class="anchor" id="4-3-check-vrf-ipv4-table" href="#4-3-check-vrf-ipv4-table"></a>4.3 Check VRF IPv4 Table</h2>
<p>R1：
</p><pre class="highlight"><code>bird&gt; show route table vrf_blue4
Table vrf_blue4:
192.168.1.0/24       unreachable [static2 22:58:48.918] * (200)
192.168.2.0/24       unicast [vpn_blue4 23:20:55.236] * (80/0)
        via 203.0.113.3 on ens19 mpls 1002
bird&gt;</code></pre>
R2：
<pre class="highlight"><code>bird&gt; show route table vrf_blue4
Table vrf_blue4:
192.168.1.0/24       unicast [vpn_blue4 23:20:55.219] * (80/0)
        via 203.0.113.3 on ens19 mpls 1003
192.168.2.0/24       unreachable [static2 22:54:38.777] * (200)
bird&gt;</code></pre>
<h2><a class="anchor" id="4-4-check-connectivity-between-pc1-and-pc2" href="#4-4-check-connectivity-between-pc1-and-pc2"></a>4.4 Check connectivity between PC1 and PC2</h2>
<p>PC1：
</p><pre class="highlight"><code>root@pc1:~# ping -c 4 192.168.2.2
PING 192.168.2.2 (192.168.2.2) 56(84) bytes of data.
64 bytes from 192.168.2.2: icmp_seq=1 ttl=61 time=5.53 ms
64 bytes from 192.168.2.2: icmp_seq=2 ttl=61 time=5.03 ms
64 bytes from 192.168.2.2: icmp_seq=3 ttl=61 time=3.73 ms
64 bytes from 192.168.2.2: icmp_seq=4 ttl=61 time=5.97 ms

--- 192.168.2.2 ping statistics ---
4 packets transmitted, 4 received, 0% packet loss, time 3005ms
rtt min/avg/max/mdev = 3.729/5.063/5.965/0.838 ms
root@pc1:~# traceroute 192.168.2.2
traceroute to 192.168.2.2 (192.168.2.2), 30 hops max, 60 byte packets
 1  192.168.1.1 (192.168.1.1)  5.787 ms  6.165 ms *
 2  * * *
 3  * * *
 4  192.168.2.2 (192.168.2.2)  36.865 ms  37.489 ms  44.775 ms
root@pc1:~#</code></pre>
PC2：
<pre class="highlight"><code>root@pc2:~# ping -c 4 192.168.1.2
PING 192.168.1.2 (192.168.1.2) 56(84) bytes of data.
64 bytes from 192.168.1.2: icmp_seq=1 ttl=61 time=21.7 ms
64 bytes from 192.168.1.2: icmp_seq=2 ttl=61 time=4.35 ms
64 bytes from 192.168.1.2: icmp_seq=3 ttl=61 time=13.6 ms
64 bytes from 192.168.1.2: icmp_seq=4 ttl=61 time=4.67 ms

--- 192.168.1.2 ping statistics ---
4 packets transmitted, 4 received, 0% packet loss, time 3007ms
rtt min/avg/max/mdev = 4.352/11.098/21.731/7.181 ms
root@pc2:~# traceroute 192.168.1.2
traceroute to 192.168.1.2 (192.168.1.2), 30 hops max, 60 byte packets
 1  192.168.2.1 (192.168.2.1)  17.272 ms  17.125 ms  17.175 ms
 2  * * *
 3  * * *
 4  192.168.1.2 (192.168.1.2)  27.517 ms  27.945 ms  32.354 ms
root@pc2:~#</code></pre>

<h1><a class="anchor" id="5-reference" href="#5-reference"></a>5 Reference</h1>
<p><span id="c1">1. BIRD Team. (2023, October 7). <em>News Archive</em>. bird.network.cz. <a href="https://bird.network.cz/?o_news/">https://bird.network.cz/?o_news/</a></span></p>

<p><span id="c2">2. BIRD Team. (2023, October 7). BIRD 2.0 User’s Guide. <em>MPLS</em>, 9-10. <a href="https://bird.network.cz/download/bird-doc-2.14.tar.gz">https://bird.network.cz/download/bird-doc-2.14.tar.gz</a></span></p>

<p><span id="c3">3. James Swineson. (2020, February 22). <em>Use Linux as an MPLS Router</em>. blog.swineson.me. <a href="https://blog.swineson.me/en/use-linux-as-an-mpls-router/">https://blog.swineson.me/en/use-linux-as-an-mpls-router/</a></span></p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
      <li><a href="/Links" rel="nofollow">Links</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
      <li><a href="/howto/GeoFeed" rel="nofollow">GeoFeed</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/DNS" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">RPKI</a></li>
      <li><a href="/services/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
      <li><a href="/services/Registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
      <li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
    </ul>
  </li>
  <li>Historical
    <ul>
      <li><a href="/historical/Bird" rel="nofollow">Bird 1</a></li>
      <li><a href="/historical/Quagga" rel="nofollow">Quagga</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://hedgedoc.dn42.eu" rel="nofollow">HedgeDoc</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/mpls-bird2.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/mpls-bird2.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
