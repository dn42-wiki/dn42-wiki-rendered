<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/GRE-on-OpenBSD.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>GRE-on-OpenBSD</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>GRE-on-OpenBSD</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/GRE-on-OpenBSD.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/GRE-on-OpenBSD.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    GRE-on-OpenBSD
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="point-to-point-layer-3-gre-tunnel-interface" href="#point-to-point-layer-3-gre-tunnel-interface"></a>Point-to-Point Layer 3 GRE tunnel interface</h1>
<p>This guide describes how to establish an unencrypted and unauthenticated IPv6-over-IPv6 tunnel on <a href="https://openbsd.org">OpenBSD</a>, see <a href="http://man.openbsd.org/gre.4#Point-to-Point_Layer_3_GRE_tunnel_interfaces_(gre)_example">gre(4) EXAMPLES</a> for similar setups.</p>

<h1><a class="anchor" id="configuration" href="#configuration"></a>Configuration</h1>
<p>Let <em>A</em> be the local OpenBSD host and <em>D</em> the remote peer, assume public DNS names and IPv6 reachability.</p>

<p>Let <code>fd42::</code> and <code>fd42::1</code> be the IPs of <em>A</em> and <em>D</em> respectively where both are allocated as <code>/127</code> subnet from one of the peer's DN42 prefix.</p>

<h2><a class="anchor" id="pseudo-interface" href="#pseudo-interface"></a>pseudo interface</h2>
<p>Populate <a href="https://man.openbsd.org/hostname.if.5"><code>/etc/hostname.gre0</code></a> with:
</p><pre class="highlight"><code><span class="n">tunnel</span> <span class="n">A</span>.<span class="n">example</span>.<span class="n">com</span> <span class="n">D</span>.<span class="n">example</span>.<span class="n">net</span>
<span class="n">inet6</span> <span class="n">fd42</span>::/<span class="m">127</span></code></pre>
This will resolve FQDNs at parse time, set <em>A</em>'s and <em>D</em>'s IPs as source and destination tunnel address and set <em>A</em>'s assigned IP as point-to-point address on the interface.

<p>Replace hostnames in the <code>tunnel</code> line with literal IPs if DNS is not available (at system boot).</p>

<p>Reboot or run <a href="https://man.openbsd.org/netstart.8"><code>sh /etc/netstart gre0</code></a> to bring up the tunnel.</p>

<h2><a class="anchor" id="miscellaneous" href="#miscellaneous"></a>miscellaneous</h2>
<p>Populate <code>/etc/sysctl.conf</code> with:
</p><pre class="highlight"><code><span class="n">net</span>.<span class="n">inet</span>.<span class="n">gre</span>.<span class="n">allow</span>=<span class="m">1</span></code></pre>
Reboot or run <code>sysctl net.inet.gre.allow=1</code> to allow GRE packet processing.

<p>-
At this point, <code>gre0</code> will be administratively <em>UP</em>:
</p><pre class="highlight"><code>$ ifconfig gre0
gre0: flags=8051&lt;UP,POINTOPOINT,RUNNING,MULTICAST&gt; mtu 1476
        index 22 priority 0 llprio 6
        encap: vnetid none txprio payload rxprio packet
        groups: gre
        tunnel: inet6 2001:db8::a --&gt; 2001:db9::d ttl 64 nodf ecn
        inet6 fe80::221:28ff:fef9:c1d8%gre0 --&gt;  prefixlen 64 scopeid 0x16
        inet6 fd42:: --&gt;  prefixlen 127</code></pre>

<p>All traffic destined to <code>fd42::1/127</code> will be encapsulated and routed to <em>D</em>:
</p><pre class="highlight"><code>$ route show
[...]
Internet6:
Destination                        Gateway                        Flags   Refs      Use   Mtu  Prio Iface
fd42::/127                         fd42::                         UCn        1        0     -     4 gre0
fd42::                             fd42::                         UHl        0        0     -     1 gre0
fd42::1                            link#0                         UHc        0     3180     -     3 gre0
fe80::%gre0/64                     fe80::221:28ff:fef9:c1d8%gre0  Un         0        0     -     4 gre0
fe80::221:28ff:fef9:c1d8%gre0      fe80::221:28ff:fef9:c1d8%gre0  UHl        0        0     -     1 gre0
ff01::%gre0/32                     fe80::221:28ff:fef9:c1d8%gre0  Um         0        1     -     4 gre0
ff02::%gre0/32                     fe80::221:28ff:fef9:c1d8%gre0  Um         0        1     -     4 gre0
[...]</code></pre>
<pre class="highlight"><code>$ route -n get fd42::1
   route to: fd42::1
destination: fd42::1
       mask: ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff
  interface: gre0
 if address: fd42::
   priority: 3 ()
      flags: &lt;UP,HOST,DONE,CLONED&gt;
     use       mtu    expire
    3181         0         0 </code></pre>

<h1><a class="anchor" id="security" href="#security"></a>Security</h1>
<p>GRE may be protected with IPsec to encrypt and authenticate traffic, <a href="http://www.openiked.org/">OpenIKED</a> can be used to establish an IKEv2 session between <em>A</em> and <em>D</em>.</p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/GRE-on-OpenBSD.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/GRE-on-OpenBSD.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
