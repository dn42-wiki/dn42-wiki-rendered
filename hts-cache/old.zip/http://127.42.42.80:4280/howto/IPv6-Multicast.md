<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/IPv6-Multicast.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>IPv6-Multicast</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>IPv6-Multicast</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/IPv6-Multicast.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/IPv6-Multicast.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    IPv6-Multicast
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="ipv6-multicast" href="#ipv6-multicast"></a>IPv6 Multicast</h1>

<p>The following guide illustrates how to set up an IPv6 multicast router using <a href="https://en.wikipedia.org/wiki/Protocol_Independent_Multicast#Sparse_mode">PIM-SM</a> (Protocol Independent Multicast in Sparse Mode) with your own personal multicast prefix.</p>

<p><a href="https://datatracker.ietf.org/doc/html/rfc8815">RFC8815</a> deprecated PIM-SM, please take a look at <a href="/howto/multicast">the new multicast page about PIM-SSM</a>.</p>

<h2><a class="anchor" id="quickstart" href="#quickstart"></a>Quickstart</h2>

<ul>
  <li>Install pim6sd from here: <a href="https://github.com/troglobit/pim6sd/">https://github.com/troglobit/pim6sd/</a>
    <div class="language-sh highlighter-rouge">
<div class="highlight"><pre class="highlight"><code>  <span class="nb">cd</span> /usr/src
  git clone https://github.com/troglobit/pim6sd.git
  <span class="nb">cd </span>pim6sd
  ./autogen.sh
  ./configure
  make
</code></pre></div>    </div>
  </li>
  <li>Find a peer who is already connected to the dn42 multicast backbone</li>
  <li>Calculate your personal, embedded-RP multicast prefix matching your network prefix via <a href="https://tools.ietf.org/html/rfc3956">RFC3956</a>
    <ul>
      <li>Example:
        <ul>
          <li>Pattern: <code>ff7e:&lt;RIID&gt;&lt;plen&gt;:&lt;prefix&gt;::/96</code>
            <ul>
              <li>Prefix: <code>fd00:2001:db8::/48</code>
</li>
              <li>Prefix length: <code>48 == 0x30</code>
</li>
              <li>RIID: An arbitrary number between <code>0x1</code> and <code>0xf</code>, for instance <code>0x2</code>
</li>
            </ul>
          </li>
          <li>Result:
            <ul>
              <li>Multicast prefix: <code>ff7e:230:fd00:2001:db8::/96</code>
</li>
              <li>RP address: <code>fd00:2001:db8::&lt;RIID&gt;</code> -&gt; <code>fd00:2001:db8::2</code>
</li>
            </ul>
          </li>
        </ul>
      </li>
    </ul>
  </li>
  <li>
    <p>Create a dummy interface to hold your calculated unicast Rendezvous Point address. This one needs to be reachable from within dn42. Also set "multicast on" on this dummy interface. Example:</p>

    <div class="language-conf highlighter-rouge">
<div class="highlight"><pre class="highlight"><code>  <span class="c"># /etc/network/interfaces.d/pim6sd
</span>  <span class="n">auto</span> <span class="n">pim</span>-<span class="n">router</span>-<span class="n">id</span>
  <span class="n">iface</span> <span class="n">pim</span>-<span class="n">router</span>-<span class="n">id</span> <span class="n">inet</span> <span class="n">manual</span>
          <span class="n">pre</span>-<span class="n">up</span> <span class="n">ip</span> <span class="n">link</span> <span class="n">add</span> <span class="n">name</span> $<span class="n">IFACE</span> <span class="n">type</span> <span class="n">dummy</span>
          <span class="n">post</span>-<span class="n">up</span> <span class="n">ip</span> <span class="n">link</span> <span class="n">set</span> <span class="n">multicast</span> <span class="n">on</span> <span class="n">dev</span> $<span class="n">IFACE</span>
          <span class="n">post</span>-<span class="n">up</span> <span class="n">ip</span> -<span class="m">6</span> <span class="n">a</span> <span class="n">a</span> <span class="n">fd00</span>:<span class="m">2001</span>:<span class="n">db8</span>::<span class="m">2</span>/<span class="m">128</span> <span class="n">dev</span> $<span class="n">IFACE</span>
          <span class="n">post</span>-<span class="n">down</span> <span class="n">ip</span> <span class="n">link</span> <span class="n">del</span> $<span class="n">IFACE</span>
</code></pre></div>    </div>
  </li>
  <li>
    <p>Create the configuration file:</p>

    <div class="language-sh highlighter-rouge">
<div class="highlight"><pre class="highlight"><code>  <span class="c"># /etc/pim6sd.conf</span>
  <span class="c"># disable all interfaces by default</span>
  default_phyint_status disable<span class="p">;</span>

  <span class="c"># enable the pim-router-id interface first to acquire the correct primary address</span>
  phyint pim-router-id <span class="nb">enable</span><span class="p">;</span>

  <span class="c"># add multicast-capable peer interfaces below</span>
  phyint dn42-peer1 <span class="nb">enable</span><span class="p">;</span>

  <span class="c"># configure rendezvous point for the personal multicast prefix</span>
  cand_rp pim-router-id<span class="p">;</span>
  group_prefix ff7e:230:fd00:2001:db8::/96<span class="p">;</span>
</code></pre></div>    </div>

    <p>The <code>phyint</code> statement enables <a href="https://tools.ietf.org/html/rfc7761">PIM</a> and <a href="https://tools.ietf.org/html/rfc2710">MLD</a> on the target interface - by default all interfaces are in the disable state. Enable an interface if it is directed towards a multicast-capable peer or other multicast-capable routers in your autonomous system. Also enable it for downstream network segments with multicast listeners and senders, like for example your home (W)LAN segments.</p>

    <p>With <code>cand_rp</code> and <code>group_prefix</code> statements you can configure this router as a Rendezvous Point (RP) for your personal multicast group prefix. The address on the interface given as <code>cand_rp</code> will be used as the primary address for your RP, it therefore <em>must</em> be routable.</p>
  </li>
</ul>

<hr />

<h2><a class="anchor" id="testing-applications" href="#testing-applications"></a>Testing &amp; Applications</h2>

<h3><a class="anchor" id="creating-a-test-network-namespace" href="#creating-a-test-network-namespace"></a>Creating a test network namespace</h3>

<p>On your router:</p>

<pre class="highlight"><code>allow-hotplug pim-ns0
iface pim-ns0 inet manual
    pre-up ip <span class="nb">link </span>add pim-ns0 <span class="nb">type </span>veth peer name pim-ns1
    post-up ip netns add pim-ns0
    post-up ip <span class="nb">link set </span>addr 02:11:22:00:00:02 netns pim-ns0 name pim-ns0 up dev pim-ns1
    post-up ip <span class="nb">link set </span>addr 02:11:22:00:00:01 up dev pim-ns0
    post-up ip <span class="nt">-6</span> a a fdd5:69d5:c530:1::1/64 dev pim-ns0
    post-up ip netns <span class="nb">exec </span>pim-ns0 ip <span class="nt">-6</span> a a fdd5:69d5:c530:1::2/64 dev pim-ns0
    post-up ip netns <span class="nb">exec </span>pim-ns0 ip <span class="nt">-6</span> r a default via fdd5:69d5:c530:1::1
    post-down ip <span class="nb">link </span>del pim-ns0
    post-down ip netns del pim-ns0</code></pre>

<p>You can now switch into this test network namespace via "ip netns exec /bin/bash". Inside this network namespace you can try:</p>

<h3><a class="anchor" id="creating-a-test-multicast-listener" href="#creating-a-test-multicast-listener"></a>Creating a test multicast listener</h3>

<pre class="highlight"><code><span class="nv">$ </span>socat <span class="nt">-u</span> UDP6-RECV:1234,reuseaddr,ipv6-join-group<span class="o">=</span><span class="s2">"[ff7e:230:fdd5:69d5:c530::123]:eth0"</span> -</code></pre>

<h3><a class="anchor" id="creating-a-test-multicast-sender" href="#creating-a-test-multicast-sender"></a>Creating a test multicast sender</h3>

<p>First select which interface should be the default one for your multicast traffic. Then send multicast packets via ICMPv6:</p>

<pre class="highlight"><code><span class="nv">$ </span>ip <span class="nt">-6</span> route add ff7e:230:fdd5:69d5:c530::/96 dev eth0 table <span class="nb">local</span>
<span class="nv">$ </span>ping6 <span class="nt">-t</span> 16 ff7e:230:fdd5:69d5:c530::123</code></pre>

<p>The "-t 16", a hop-limit of 16, is important here as <strong>by default all multicast traffic is usually sent with a hop-limit of just 1</strong>.</p>

<hr />

<h2><a class="anchor" id="advanced-configurations" href="#advanced-configurations"></a>Advanced Configurations</h2>

<h3><a class="anchor" id="nomenclature" href="#nomenclature"></a>Nomenclature</h3>

<h4><a class="anchor" id="bootstrap-router-bsr" href="#bootstrap-router-bsr"></a>Bootstrap Router (BSR)</h4>

<p>Router that collects multicast group information from all RP in the network and advertises it across the network.</p>

<h4><a class="anchor" id="rendezvous-point-rp" href="#rendezvous-point-rp"></a>Rendezvous Point (RP)</h4>

<p>Router where senders and receivers will meet for a certain multicast address. Senders must send their data to it, after which it will be forwarded to receivers. As soon as a receivers DR learns of the sender it will ask their router to forward data along a direct path between sender and receiver.</p>

<h4><a class="anchor" id="designated-router-dr" href="#designated-router-dr"></a>Designated Router (DR)</h4>

<p>First-hop router that stand in for sender and receiver on their downstream networks. The senders DR sends their data towards the RP encapsulated in PIM Register packets. The receivers DR will send join and prune messages to the RP, managing the group subscription.</p>

<h3><a class="anchor" id="rfc3306-unicast-prefix-based-ipv6-multicast-addresses" href="#rfc3306-unicast-prefix-based-ipv6-multicast-addresses"></a>RFC3306: "Unicast-Prefix-based IPv6 Multicast Addresses"</h3>

<p>Before RFC3956 (embedded RP addresses) personal, network prefix based multicast prefixes were calculated via RFC3306. Example:</p>

<ul>
  <li>Pattern: <code>ff3e:&lt;plen&gt;:&lt;prefix&gt;::/96</code>
    <ul>
      <li>Prefix: <code>fd00:2001:db8::/48</code>
        <ul>
          <li>Prefix length: <code>48 == 0x30</code>
</li>
        </ul>
      </li>
      <li>Result: <code>ff3e:30:fd00:2001:db8::/96</code>
</li>
    </ul>
  </li>
  <li>Pros:
    <ul>
      <li>More flexible RP address selection</li>
      <li>Allows filtering on the BSR</li>
    </ul>
  </li>
  <li>Cons:
    <ul>
      <li>Needs a central BSR for coordination (or static RP configuration)</li>
      <li>Allows filtering on the BSR</li>
    </ul>
  </li>
</ul>

<p>However you can usually just announce and use both RFC3306 and RFC3956 based multicast prefixes, if you want to. pim6sd allows adding multiple <code>group_prefix</code> entries.</p>

<h3><a class="anchor" id="address-management" href="#address-management"></a>Address Management</h3>

<h4><a class="anchor" id="bootstrap-router" href="#bootstrap-router"></a>Bootstrap Router</h4>

<p>If you want to be participate as a bootstrap router candidate, please read up on how PIM works first. If you join with a bootstrap router candidate add it here below with contact information and join #dn42-multicast on HackInt:</p>
<ul>
  <li>&lt;BSR-ADDR1&gt; - foo@example.com, foo@HackInt</li>
  <li>&lt;BSR-ADDR2&gt; - …</li>
</ul>

<h4><a class="anchor" id="shared-multicast-addresses" href="#shared-multicast-addresses"></a>Shared multicast addresses</h4>

<p>Next to personal multicast prefixes generated by network prefix (RFC3306 or RFC3956) there can also be multicast addresses not owned by a specific AS. In general any one can just set up a multicast sender or listener for those. However to work, they need a reliable RP for coordination.</p>

<p>If you want to offer an RP candidate for a shared multicast address, please read up on how PIM works first. If you join with an RP candidate for a shared multicast address add it here below with contact information and join #dn42-multicast on HackInt:</p>
<ul>
  <li>&lt;multicast-address1&gt;/128:
    <ul>
      <li>&lt;RP-address1&gt; - foo@example.com, foo@HackInt</li>
      <li>&lt;RP-address2&gt; - bar@example.com, bar@HackInt</li>
    </ul>
  </li>
  <li>&lt;multicast-address2&gt;/128:
    <ul>
      <li>…</li>
    </ul>
  </li>
</ul>

<h2><a class="anchor" id="questions" href="#questions"></a>Questions?</h2>

<ul>
  <li>Join: <code>#dn42-multicast</code> on <code>HackInt</code>
</li>
</ul>

<hr />

<p>ToDo:</p>
<ul>
  <li>We have a solution for personal multicast prefixes tied to the network prefix of an AS owner. But what to do with multicast addresses that not only have listeners but also senders globally? We could have everyone add an additional "group_prefix ff00::/8" and then multicast router with the lowest address would win and become the central RP for all these addresses… not really scalable, robust or decentral though :-/. Should we use PIM-DM for some of these addresses instead (e.g. ones which generally have a low throughput, for instance Bittorrent Local Peer Discovery)? Or maybe those global addresses should be managed and configured as /128 and people who are interested in managing a specific, global multicast address will coordinate with each other?</li>
  <li>bootstrap router coordination; according to RFCs a bootstrap router can alter/filter the multicast prefixes it received from candidate RPs. Should a bootstrap router check and filter any multicast prefix that was generated from a network prefix which does not match the network prefix used by the PR?</li>
</ul>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/DNS" rel="nofollow">DNS</a></li>
      <li><a href="/services/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
      <li><a href="/services/Registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
      <li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
    </ul>
  </li>
  <li>Historical
    <ul>
      <li><a href="/historical/Bird" rel="nofollow">Bird 1</a></li>
      <li><a href="/historical/Quagga" rel="nofollow">Quagga</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://hedgedoc.dn42.eu" rel="nofollow">HedgeDoc</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>
</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/IPv6-Multicast.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/IPv6-Multicast.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
