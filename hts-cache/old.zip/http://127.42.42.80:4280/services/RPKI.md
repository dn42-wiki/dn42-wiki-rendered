<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'services/RPKI.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>RPKI</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>RPKI</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/services/RPKI.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/services/RPKI.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    RPKI
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/services/">services</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="dn42-rpki" href="#dn42-rpki"></a>DN42 RPKI</h1>
<p>This page covers guidance and examples on using RPKI within DN42.</p>

<h2><a class="anchor" id="quick-start" href="#quick-start"></a>Quick Start</h2>

<p>It is recommended to run your own RPKI validator, as this provides you with the most security and control over your routing decisions. However, to get started, or if running your own validator isn’t desirable, a public RPKI RTR server is available. The service supports full RPKI validation for all relevant DN42 and affiliated networks’ prefixes.</p>

<h3><a class="anchor" id="using-public-rpki-services" href="#using-public-rpki-services"></a>Using Public RPKI Services</h3>

<p>DN42’s RPKI RTR service endpoints are hosted by multiple operators. By configuring multiple RTR servers in your BGP daemon, you gain additional resiliency and improved validation coverage.</p>

<table>
  <thead>
    <tr>
      <th>Server</th>
      <th>Port</th>
      <th><strong>IPv4/IPv6</strong></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>rpki.akae.re</td>
      <td>8082</td>
      <td>both</td>
    </tr>
    <tr>
      <td>rpki.dn42.launchpadx.top</td>
      <td>8082</td>
      <td>both</td>
    </tr>
    <tr>
      <td>rpki.dn42.milu.moe</td>
      <td>8082</td>
      <td>both</td>
    </tr>
    <tr>
      <td>rpki.dn42.6700.cc</td>
      <td>8282</td>
      <td>both</td>
    </tr>
    <tr>
      <td>rpki.nia.dn42</td>
      <td>8082</td>
      <td>both</td>
    </tr>
  </tbody>
</table>

<h4><a class="anchor" id="flapalerted-rpki-rtr-servers" href="#flapalerted-rpki-rtr-servers"></a>FlapAlerted RPKI RTR Servers</h4>

<p>These services will publish a ROA pointing to AS0 when a prefix flapping. This can be used to prevent flap from spreading further in the network.</p>

<table>
  <thead>
    <tr>
      <th>Server</th>
      <th>Port</th>
      <th><strong>IPv4/IPv6</strong></th>
      <th>FlapAlerted Instance</th>
      <th>Provider</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>rpki.dn42.launchpadx.top</td>
      <td>8084</td>
      <td>both</td>
      <td>
<a href="https://flaps.lpnet0.dn42/">https://flaps.lpnet0.dn42/</a>, <a href="https://dn42-flaps.launchpadx.top/">https://dn42-flaps.launchpadx.top/</a>
</td>
      <td>AS4242423702</td>
    </tr>
    <tr>
      <td>rpki.nia.dn42</td>
      <td>8084</td>
      <td>both</td>
      <td>
<a href="https://flap.nia.dn42/">flap.nia.dn42</a>, <a href="https://flap42.strexp.net/">flap42.strexp.net</a>
</td>
      <td>AS4242421331</td>
    </tr>
    <tr>
      <td>rpki.nia.dn42</td>
      <td>8083</td>
      <td>both</td>
      <td>Multiple Sources (2-Votes Policy) (see <a href="https://flap-data.nia.dn42/">flap-data.nia.dn42</a>)</td>
      <td>AS4242421331</td>
    </tr>
    <tr>
      <td>rpki.dn42.6700.cc</td>
      <td>8280</td>
      <td>both</td>
      <td>Flap data source: https://flap42-data.strexp.net</td>
      <td>AS4242423088</td>
    </tr>
  </tbody>
</table>

<p>To configure the service, connect your BGP software’s RPKI client to one or more of these RTR servers.</p>

<h4><a class="anchor" id="example-configuration-bird-2" href="#example-configuration-bird-2"></a>Example Configuration (Bird 2)</h4>

<pre class="highlight"><code><span class="n">protocol</span> <span class="n">rpki</span> <span class="n">roa_dn42_1</span> {
        <span class="n">roa4</span> { <span class="n">table</span> <span class="n">dn42_roa</span>; };
        <span class="n">roa6</span> { <span class="n">table</span> <span class="n">dn42_roa_v6</span>; };
        <span class="n">remote</span> <span class="s2">"rpki1.example.com"</span>;
        <span class="n">port</span> <span class="m">8082</span>;
        <span class="n">refresh</span> <span class="m">600</span>;
        <span class="n">retry</span> <span class="m">300</span>;
        <span class="n">expire</span> <span class="m">7200</span>;
}

<span class="n">protocol</span> <span class="n">rpki</span> <span class="n">roa_dn42_2</span> {
        <span class="n">roa4</span> { <span class="n">table</span> <span class="n">dn42_roa</span>; };
        <span class="n">roa6</span> { <span class="n">table</span> <span class="n">dn42_roa_v6</span>; };
        <span class="n">remote</span> <span class="s2">"rpki2.example.com"</span>;
        <span class="n">port</span> <span class="m">8082</span>;
        <span class="n">refresh</span> <span class="m">600</span>;
        <span class="n">retry</span> <span class="m">300</span>;
        <span class="n">expire</span> <span class="m">7200</span>;
}</code></pre>

<h3><a class="anchor" id="running-your-own-rpki-server" href="#running-your-own-rpki-server"></a>Running Your Own RPKI Server</h3>

<h4><a class="anchor" id="with-docker" href="#with-docker"></a>With Docker</h4>

<pre class="highlight"><code>docker run <span class="nt">--name</span> dn42rpki <span class="nt">-p</span> 8082:8282 <span class="nt">--restart</span><span class="o">=</span>always <span class="nt">-d</span> rpki/stayrtr <span class="nt">-verify</span><span class="o">=</span><span class="nb">false</span> <span class="nt">-checktime</span><span class="o">=</span><span class="nb">false</span> <span class="nt">-cache</span><span class="o">=</span>https://dn42.burble.com/roa/dn42_roa_46.json</code></pre>

<h4><a class="anchor" id="with-docker-compose" href="#with-docker-compose"></a>With Docker Compose</h4>

<pre class="highlight"><code><span class="n">services</span>:
  <span class="n">stayrtr</span>:
    <span class="n">image</span>: <span class="n">rpki</span>/<span class="n">stayrtr</span>:<span class="n">latest</span>
    <span class="n">ports</span>:
      - <span class="s2">"8082:8282"</span>
    <span class="n">command</span>: &gt;
      -<span class="n">cache</span> <span class="n">https</span>://<span class="n">dn42</span>.<span class="n">burble</span>.<span class="n">com</span>/<span class="n">roa</span>/<span class="n">dn42_roa_46</span>.<span class="n">json</span></code></pre>

<h3><a class="anchor" id="using-kioubit-s-dn42-registry-wizard" href="#using-kioubit-s-dn42-registry-wizard"></a>Using Kioubit's DN42 Registry Wizard</h3>

<p><a href="https://github.com/Kioubit/dn42_registry_wizard">DN42 Registry Wizard</a> is a comprehensive tool for DN42 registry interactions. <strong>Unlike other solutions, it can parse the registry and host an RTR server all-in-one</strong> without requiring separate components.</p>

<h4><a class="anchor" id="all-in-one-rtr-server" href="#all-in-one-rtr-server"></a>All-in-One RTR Server</h4>

<pre class="highlight"><code><span class="c"># Clone the DN42 registry</span>
git clone https://git.dn42.dev/dn42/registry.git

<span class="c"># Start RTR server directly from registry</span>
./registry_wizard &lt;path to registry&gt; rtr 

<span class="c"># Setup a cronjob to continously update the registry and notify registry_wizard</span>
git fetch <span class="nt">--all</span>
git reset <span class="nt">--hard</span> origin/master
<span class="nb">kill</span> <span class="nt">-SIGUSR1</span> <span class="s2">"</span><span class="si">$(</span>pidof <span class="s1">'registry_wizard'</span><span class="si">)</span><span class="s2">"</span></code></pre>

<pre class="highlight"><code>Usage: registry_wizard &lt;registry_root&gt; rtr [OPTIONS]

Options:
  -p, --port &lt;port&gt;        Port to listen on [default: 9323]
      --refresh &lt;refresh&gt;  RTR refresh timing [default: 3600]
      --expire &lt;expire&gt;    RTR expire timing [default: 7200]
      --retry &lt;retry&gt;      RTR retry timing [default: 600]
  -h, --help               Print help</code></pre>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="services/RPKI.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/services/RPKI.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
