<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'services/FreePhone.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>FreePhone</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>FreePhone</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/services/FreePhone.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/services/FreePhone.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    FreePhone
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/services/">services</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="what-s-freephone" href="#what-s-freephone"></a>What's FreePhone?</h1>
<p>Where's the point in using a phone flat just for a single person? !FreePhone is a project aimed to develop a VPN wide SIP phone service. Calling german landline is possible at the moment, as well as local participants (eg. maxx).</p>

<h2><a class="anchor" id="how-does-this-work" href="#how-does-this-work"></a>How does this work?</h2>
<h3><a class="anchor" id="public-proxy" href="#public-proxy"></a>Public proxy</h3>
<p>Set up your softphone or hardware implementation to use:</p>
<ul>
  <li>SIP-Proxy/Proxy domain: maxx.spaceboyz.net (SRV-Record)</li>
  <li>Username/Account/Login: vpn</li>
  <li>Password: vpn  <br />
The proxy is strictly outbound, registration is impossible and unintended.</li>
</ul>

<h2><a class="anchor" id="special-needs" href="#special-needs"></a>Special needs</h2>
<p>Just contact me if you like to use your SIP hardware (eg. Fritz!Box FON). You'll get a special account allowing registrations plus a local extension.</p>

<h2><a class="anchor" id="restrictions" href="#restrictions"></a>Restrictions</h2>
<ul>
  <li>Any call under the terms of the flatrate is allowed, so to speak: no mobile phones or pr0n calls</li>
  <li>One call at a time for FreePhone users (stupid bandwidth restrictions :/).</li>
  <li>Internal calls are more or less unrestricted.</li>
  <li>alaw/ulaw are disallowed for bandwidth reasons</li>
</ul>

<h2><a class="anchor" id="additional-extensions" href="#additional-extensions"></a>Additional extensions</h2>
<p>| <strong>Extension</strong> | <strong>Target</strong> |
|—|—|
| maxx | myself, almost anywhere wireless lan is availiable |
| grim | sometimes, sometimes not |
| equinox | i think nokia prevents but you may try |
| helios | did not connect for some time now |</p>

<p>If you like listening to german news, dial 787326353 (Vanity: STREAMDLF). Just contact me in case you want more.</p>

<h2><a class="anchor" id="configuration-examples" href="#configuration-examples"></a>Configuration examples</h2>
<p>Just look at the german version, you'll get the idea.</p>

<h2><a class="anchor" id="what-s-next" href="#what-s-next"></a>What's next?</h2>
<h3><a class="anchor" id="real-dn42-phone-system" href="#real-dn42-phone-system"></a>Real dn42 phone system</h3>
<p>If i'm bored some day i might implement the following:</p>
<ul>
  <li>SIP extensions for every participant</li>
  <li>Voicemail</li>
  <li>Funny games</li>
  <li>FreePhone integration (maybe with redundancy)</li>
  <li>…</li>
</ul>

<p>If someone is willing to experiment we could try allowing reinvites. This way all SIP endpoints inside the VPN could connect their media streams directly, thus saving bandwidth and raising call quality.</p>

<h2><a class="anchor" id="latest-changes" href="#latest-changes"></a>Latest changes</h2>
<ul>
  <li>G.729 now is the preferred codec because of bandwith issues</li>
  <li>My "Homezone" works perfectly, moving with me</li>
  <li>Phone #: +493727/959023</li>
  <li>Sipgate: 5884293</li>
  <li>SIP: maxx(at)maxx.spaceboyz.net</li>
  <li>Transcoding from/into G.729 works fine now, thanks to some precompiled versions for asterisk.</li>
</ul>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="services/FreePhone.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/services/FreePhone.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
