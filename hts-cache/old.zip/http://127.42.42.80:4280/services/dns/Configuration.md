<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'services/dns/Configuration.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Configuration</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Configuration</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/services/dns/Configuration.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/services/dns/Configuration.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Configuration
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/services/">services</a></li>
<li class="breadcrumb-item"><a href="/gollum/overview/services/dns/">dns</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="forwarder-setup" href="#forwarder-setup"></a>Forwarder setup</h1>

<p>Configuration of common resolver softwares to forward DNS queries for <code>.dn42</code> (and reverse DNS) IPv4 and IPv6 anycast services.</p>

<p>You can use any *.recursive-servers.dn42 (where * is a letter) for resolving .dn42 domains. The current list is available at the <a href="https://git.dn42.dev/dn42/registry/src/master/data/dns/recursive-servers.dn42">DN42 registry</a> or through querying SRV records of recursive-servers.dn42:</p>

<pre class="highlight"><code>drill <span class="nt">-D</span> SRV _dns._udp.recursive-servers.dn42. @172.20.0.53</code></pre>

<p>Two independent anycast services are also provided:</p>

<table>
  <thead>
    <tr>
      <th>Name</th>
      <th>IPv4</th>
      <th>IPv6</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>a0.recursive-servers.dn42</td>
      <td>172.20.0.53</td>
      <td>fd42:d42:d42:54::1</td>
    </tr>
    <tr>
      <td>a3.recursive-servers.dn42</td>
      <td>172.23.0.53</td>
      <td>fd42:d42:d42:53::1</td>
    </tr>
  </tbody>
</table>

<p>All the examples here list 172.20.0.53/fd42:d42:d42:54::1, but users are encouraged to configure
multiple services from *.recursive-servers.dn42 for redundancy.</p>

<h2><a class="anchor" id="note-on-icvpn-zones" href="#note-on-icvpn-zones"></a>Note on ICVPN Zones</h2>

<p>DN42 is <a href="/Interconnections">interconnected</a> with the Inter City VPN or in short "ICVPN". The registry of the ICVPN includes all the DNS information such as the Top level domains (TLDs) used inside ICVPN and the reverse DNS for the IP ranges of the ICVPN. Additionally, it includes the TLDs of some other networks that are interconnected with dn42 and share some of the IP space of ICVPN. The ICVPN <a href="https://github.com/freifunk/icvpn-scripts#dns-mkdns">repository</a> includes a handy script to automatically generate all the required zones.</p>

<h2><a class="anchor" id="bind" href="#bind"></a>BIND</h2>

<p>If you already run a local DNS server, you can tell it to query the dn42 anycast servers for the relevant domains
by adding the following to /etc/bind/named.conf.local</p>

<pre class="highlight"><code><span class="n">zone</span> <span class="s2">"dn42"</span> {
  <span class="n">type</span> <span class="n">forward</span>;
  <span class="n">forwarders</span> { <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>; <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span>; };
};
<span class="n">zone</span> <span class="s2">"20.172.in-addr.arpa"</span> {
  <span class="n">type</span> <span class="n">forward</span>;
  <span class="n">forwarders</span> { <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>; <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span>; };
};
<span class="n">zone</span> <span class="s2">"21.172.in-addr.arpa"</span> {
  <span class="n">type</span> <span class="n">forward</span>;
  <span class="n">forwarders</span> { <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>; <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span>; };
};
<span class="n">zone</span> <span class="s2">"22.172.in-addr.arpa"</span> {
  <span class="n">type</span> <span class="n">forward</span>;
  <span class="n">forwarders</span> { <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>; <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span>; };
};
<span class="n">zone</span> <span class="s2">"23.172.in-addr.arpa"</span> {
  <span class="n">type</span> <span class="n">forward</span>;
  <span class="n">forwarders</span> { <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>; <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span>; };
};
<span class="n">zone</span> <span class="s2">"10.in-addr.arpa"</span> {
  <span class="n">type</span> <span class="n">forward</span>;
  <span class="n">forwarders</span> { <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>; <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span>; };
};
<span class="n">zone</span> <span class="s2">"d.f.ip6.arpa"</span> {
  <span class="n">type</span> <span class="n">forward</span>;
  <span class="n">forwarders</span> { <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>; <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span>; };
};

<span class="c"># for reverse dns to work the following option must be set:
</span><span class="n">options</span> {
  <span class="c"># [...]
</span>
  <span class="c"># disable the integrated handling of RFC1918 and non-assigned IPv6 space reverse dns
</span>  <span class="n">empty</span>-<span class="n">zones</span>-<span class="n">enable</span> <span class="n">no</span>;

  <span class="c"># [...]
</span>};</code></pre>

<p><strong>Note</strong>: With DNSSEC enabled, bind might refuse to accept query results from the dn42 zone: <code>validating dn42/SOA: got insecure response; parent indicates it should be secure</code>.</p>

<p>To disable DNSSEC validation only for certain TLDs include the following in the options section:
</p><pre class="highlight"><code><span class="n">options</span> {
  <span class="c"># [...]
</span>
  <span class="n">validate</span>-<span class="n">except</span> {
    <span class="s2">"dn42"</span>;
    <span class="s2">"20.172.in-addr.arpa"</span>;
    <span class="s2">"21.172.in-addr.arpa"</span>;
    <span class="s2">"22.172.in-addr.arpa"</span>;
    <span class="s2">"23.172.in-addr.arpa"</span>;
    <span class="s2">"10.in-addr.arpa"</span>;
    <span class="s2">"d.f.ip6.arpa"</span>;
  };

  <span class="c"># [...]
</span>};</code></pre>

<h2><a class="anchor" id="dnsmasq" href="#dnsmasq"></a>dnsmasq</h2>

<p>If you are running dnsmasq under openwrt, you just have to add</p>

<pre class="highlight"><code><span class="n">config</span> <span class="n">dnsmasq</span>
        <span class="n">option</span> <span class="n">boguspriv</span> <span class="s1">'0'</span>
        <span class="n">option</span> <span class="n">rebind_protection</span> <span class="s1">'1'</span>
        <span class="n">list</span> <span class="n">rebind_domain</span> <span class="s1">'dn42'</span>
        <span class="n">list</span> <span class="n">server</span> <span class="s1">'/dn42/172.20.0.53'</span>
        <span class="n">list</span> <span class="n">server</span> <span class="s1">'/20.172.in-addr.arpa/172.20.0.53'</span>
        <span class="n">list</span> <span class="n">server</span> <span class="s1">'/21.172.in-addr.arpa/172.20.0.53'</span>
        <span class="n">list</span> <span class="n">server</span> <span class="s1">'/22.172.in-addr.arpa/172.20.0.53'</span>
        <span class="n">list</span> <span class="n">server</span> <span class="s1">'/23.172.in-addr.arpa/172.20.0.53'</span>
        <span class="n">list</span> <span class="n">server</span> <span class="s1">'/10.in-addr.arpa/172.20.0.53'</span>
        <span class="n">list</span> <span class="n">server</span> <span class="s1">'/d.f.ip6.arpa/fd42:d42:d42:54::1'</span>
</code></pre>

<p>to <code>/etc/config/dhcp</code> and run <code>/etc/init.d/dnsmasq restart</code>. After that you are able to resolve <code>.dn42</code> 
with the anycast DNS-Server, while your normal requests go to your standard DNS-resolver.</p>

<p>Attention: If you go with the default config you'll have to disable "boguspriv" in the first dnsmasq config section.</p>

<p>For normal dnsmasq use</p>

<pre class="highlight"><code><span class="n">server</span>=/<span class="n">dn42</span>/<span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>
<span class="n">server</span>=/<span class="m">20</span>.<span class="m">172</span>.<span class="n">in</span>-<span class="n">addr</span>.<span class="n">arpa</span>/<span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>
<span class="n">server</span>=/<span class="m">21</span>.<span class="m">172</span>.<span class="n">in</span>-<span class="n">addr</span>.<span class="n">arpa</span>/<span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>
<span class="n">server</span>=/<span class="m">22</span>.<span class="m">172</span>.<span class="n">in</span>-<span class="n">addr</span>.<span class="n">arpa</span>/<span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>
<span class="n">server</span>=/<span class="m">23</span>.<span class="m">172</span>.<span class="n">in</span>-<span class="n">addr</span>.<span class="n">arpa</span>/<span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>
<span class="n">server</span>=/<span class="m">10</span>.<span class="n">in</span>-<span class="n">addr</span>.<span class="n">arpa</span>/<span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>
<span class="n">server</span>=/<span class="n">d</span>.<span class="n">f</span>.<span class="n">ip6</span>.<span class="n">arpa</span>/<span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span></code></pre>
in <code>dnsmasq.conf</code>.

<h2><a class="anchor" id="powerdns-recursor" href="#powerdns-recursor"></a>PowerDNS recursor</h2>
<p>Old-style config for /etc/powerdns/recursor.conf (Debian and CentOS):</p>

<pre class="highlight"><code><span class="n">dont</span>-<span class="n">query</span>=<span class="m">127</span>.<span class="m">0</span>.<span class="m">0</span>.<span class="m">0</span>/<span class="m">8</span>, <span class="m">192</span>.<span class="m">168</span>.<span class="m">0</span>.<span class="m">0</span>/<span class="m">16</span>, ::<span class="m">1</span>/<span class="m">128</span>, <span class="n">fe80</span>::/<span class="m">10</span>
<span class="n">forward</span>-<span class="n">zones</span>-<span class="n">recurse</span>=<span class="n">dn42</span>=<span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>
<span class="n">forward</span>-<span class="n">zones</span>-<span class="n">recurse</span>+=<span class="m">20</span>.<span class="m">172</span>.<span class="n">in</span>-<span class="n">addr</span>.<span class="n">arpa</span>=<span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>
<span class="n">forward</span>-<span class="n">zones</span>-<span class="n">recurse</span>+=<span class="m">21</span>.<span class="m">172</span>.<span class="n">in</span>-<span class="n">addr</span>.<span class="n">arpa</span>=<span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>
<span class="n">forward</span>-<span class="n">zones</span>-<span class="n">recurse</span>+=<span class="m">22</span>.<span class="m">172</span>.<span class="n">in</span>-<span class="n">addr</span>.<span class="n">arpa</span>=<span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>
<span class="n">forward</span>-<span class="n">zones</span>-<span class="n">recurse</span>+=<span class="m">23</span>.<span class="m">172</span>.<span class="n">in</span>-<span class="n">addr</span>.<span class="n">arpa</span>=<span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>
<span class="n">forward</span>-<span class="n">zones</span>-<span class="n">recurse</span>+=<span class="m">10</span>.<span class="n">in</span>-<span class="n">addr</span>.<span class="n">arpa</span>=<span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>
<span class="n">forward</span>-<span class="n">zones</span>-<span class="n">recurse</span>+=<span class="n">d</span>.<span class="n">f</span>.<span class="n">ip6</span>.<span class="n">arpa</span>=<span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span></code></pre>

<p>New-style (YAML) config:</p>

<pre class="highlight"><code><span class="na">recursor</span><span class="pi">:</span>
    <span class="na">config_dir</span><span class="pi">:</span> <span class="s">/etc/powerdns</span>   <span class="c1"># as per default config</span>
    <span class="na">forward_zones_recurse</span><span class="pi">:</span>
      <span class="pi">-</span> <span class="na">zone</span><span class="pi">:</span> <span class="s">dn42</span>
        <span class="na">forwarders</span><span class="pi">:</span>
          <span class="c1"># try primary delegation servers first, then anycast recursors, then other recursors</span>
          <span class="c1"># remove or reorder the servers as desired; just using the anycast recursors should work too</span>
          <span class="pi">-</span> <span class="s1">'</span><span class="s">fd42:4242:2601:ac53::1'</span>              <span class="c1"># b.delegation-servers.dn42</span>
          <span class="pi">-</span> <span class="s1">'</span><span class="s">fd00:913e:130::400'</span>                  <span class="c1"># d.delegation-servers.dn42</span>
          <span class="pi">-</span> <span class="s1">'</span><span class="s">fd42:4242:2189::1'</span>                   <span class="c1"># i.delegation-servers.dn42</span>
          <span class="pi">-</span> <span class="s1">'</span><span class="s">fd42:5d71:219:0:216:3eff:fe1e:22d6'</span>  <span class="c1"># j.delegation-servers.dn42</span>
          <span class="pi">-</span> <span class="s1">'</span><span class="s">fdcf:8538:9ad5:1111::2'</span>              <span class="c1"># k.delegation-servers.dn42</span>
          <span class="pi">-</span> <span class="s1">'</span><span class="s">fd86:bad:11b7:53::1'</span>                 <span class="c1"># l.delegation-servers.dn42</span>
          <span class="pi">-</span> <span class="s1">'</span><span class="s">fd42:d42:d42:53::1'</span>                  <span class="c1"># a0.recursive-servers.dn42</span>
          <span class="pi">-</span> <span class="s1">'</span><span class="s">fd42:d42:d42:54::1'</span>                  <span class="c1"># a3.recursive-servers.dn42</span>
          <span class="pi">-</span> <span class="s1">'</span><span class="s">fd00:913e:130::1000'</span>                 <span class="c1"># d.recursive-servers.dn42</span>
          <span class="pi">-</span> <span class="s1">'</span><span class="s">fd86:bad:11b7:53::2'</span>                 <span class="c1"># l.recursive-servers.dn42</span>
          <span class="pi">-</span> <span class="s1">'</span><span class="s">fdcf:8538:9ad5:1111::1'</span>              <span class="c1"># k.recursive-servers.dn42</span>
          <span class="pi">-</span> <span class="s1">'</span><span class="s">fdbc:f9dc:67ad:2547::53'</span>             <span class="c1"># t.recursive-servers.dn42</span>
          <span class="pi">-</span> <span class="s1">'</span><span class="s">fd42:4242:2189::53'</span>                  <span class="c1"># i.recursive-servers.dn42</span>
          <span class="pi">-</span> <span class="s1">'</span><span class="s">fd42:5d71:219:0:216:3eff:fee8:c215'</span>  <span class="c1"># j.recursive-servers.dn42</span>
          <span class="pi">-</span> <span class="s1">'</span><span class="s">fd42:4242:2601:ac53::53'</span>             <span class="c1"># b.recursive-servers.dn42</span></code></pre>

<h2><a class="anchor" id="maradns" href="#maradns"></a>MaraDNS</h2>
<p>Put this in your mararc:</p>

<pre class="highlight"><code><span class="n">ipv4_alias</span>[<span class="s2">"dn42_root"</span>] = <span class="s2">"172.20.0.53"</span>
<span class="n">root_servers</span>[<span class="s2">"dn42."</span>] = <span class="s2">"dn42_root"</span>
<span class="n">root_servers</span>[<span class="s2">"20.172.in-addr.arpa."</span>] = <span class="s2">"dn42_root"</span>
<span class="n">root_servers</span>[<span class="s2">"21.172.in-addr.arpa."</span>] = <span class="s2">"dn42_root"</span>
<span class="n">root_servers</span>[<span class="s2">"22.172.in-addr.arpa."</span>] = <span class="s2">"dn42_root"</span>
<span class="n">root_servers</span>[<span class="s2">"23.172.in-addr.arpa."</span>] = <span class="s2">"dn42_root"</span>
<span class="n">root_servers</span>[<span class="s2">"10.in-addr.arpa."</span>] = <span class="s2">"dn42_root"</span></code></pre>

<h2><a class="anchor" id="unbound" href="#unbound"></a>Unbound</h2>

<p>Make sure to disable <code>auto-trust-anchor-file</code> and manually configure <code>trust-anchor-file</code> to 
point to a file with DNSKEY records for dn42.</p>

<pre class="highlight"><code><span class="n">server</span>:
      <span class="n">local</span>-<span class="n">zone</span>: <span class="s2">"20.172.in-addr.arpa."</span> <span class="n">nodefault</span>
      <span class="n">local</span>-<span class="n">zone</span>: <span class="s2">"21.172.in-addr.arpa."</span> <span class="n">nodefault</span>
      <span class="n">local</span>-<span class="n">zone</span>: <span class="s2">"22.172.in-addr.arpa."</span> <span class="n">nodefault</span>
      <span class="n">local</span>-<span class="n">zone</span>: <span class="s2">"23.172.in-addr.arpa."</span> <span class="n">nodefault</span>
      <span class="n">local</span>-<span class="n">zone</span>: <span class="s2">"10.in-addr.arpa."</span> <span class="n">nodefault</span>
      <span class="n">local</span>-<span class="n">zone</span>: <span class="s2">"d.f.ip6.arpa."</span> <span class="n">nodefault</span>

<span class="n">forward</span>-<span class="n">zone</span>: 
      <span class="n">name</span>: <span class="s2">"dn42"</span>
      <span class="n">forward</span>-<span class="n">addr</span>: <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span>
      <span class="n">forward</span>-<span class="n">addr</span>: <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>

<span class="n">forward</span>-<span class="n">zone</span>: 
      <span class="n">name</span>: <span class="s2">"20.172.in-addr.arpa"</span>
      <span class="n">forward</span>-<span class="n">addr</span>: <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span>
      <span class="n">forward</span>-<span class="n">addr</span>: <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>

<span class="n">forward</span>-<span class="n">zone</span>: 
      <span class="n">name</span>: <span class="s2">"21.172.in-addr.arpa"</span>
      <span class="n">forward</span>-<span class="n">addr</span>: <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span>
      <span class="n">forward</span>-<span class="n">addr</span>: <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>

<span class="n">forward</span>-<span class="n">zone</span>: 
      <span class="n">name</span>: <span class="s2">"22.172.in-addr.arpa"</span>
      <span class="n">forward</span>-<span class="n">addr</span>: <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span>
      <span class="n">forward</span>-<span class="n">addr</span>: <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>

<span class="n">forward</span>-<span class="n">zone</span>: 
      <span class="n">name</span>: <span class="s2">"23.172.in-addr.arpa"</span>
      <span class="n">forward</span>-<span class="n">addr</span>: <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span>
      <span class="n">forward</span>-<span class="n">addr</span>: <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>

<span class="n">forward</span>-<span class="n">zone</span>: 
      <span class="n">name</span>: <span class="s2">"10.in-addr.arpa"</span>
      <span class="n">forward</span>-<span class="n">addr</span>: <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span>
      <span class="n">forward</span>-<span class="n">addr</span>: <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>

<span class="n">forward</span>-<span class="n">zone</span>:
      <span class="n">name</span>: <span class="s2">"d.f.ip6.arpa"</span>
      <span class="n">forward</span>-<span class="n">addr</span>: <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span>
      <span class="n">forward</span>-<span class="n">addr</span>: <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span></code></pre>

<h2><a class="anchor" id="junos-srx-12-1x46" href="#junos-srx-12-1x46"></a>JunOS (SRX 12.1X46)</h2>
<p>Should also work in 12.1X44 and 12.1X45. After making the changes below you may need to run:
</p><pre class="highlight"><code>restart named-service</code></pre>
Config (vlan.0 is presumed to be your LAN/Trust interface)
<pre class="highlight"><code><span class="n">system</span> {
   <span class="n">services</span> {
      <span class="n">dns</span> {
         <span class="n">dns</span>-<span class="n">proxy</span> {
            <span class="n">interface</span> {
               <span class="n">vlan</span>.<span class="m">0</span>;
            }
        <span class="n">default</span>-<span class="n">domain</span> <span class="n">dn42</span> {
           <span class="n">forwarders</span> {
              <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>;
	      <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span>;
           }
        }
        <span class="n">default</span>-<span class="n">domain</span> <span class="m">20</span>.<span class="m">172</span>.<span class="n">in</span>-<span class="n">addr</span>.<span class="n">arpa</span> {
               <span class="n">forwarders</span> {
                  <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>;
		  <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span>;
               }
            }
        <span class="n">default</span>-<span class="n">domain</span> <span class="m">21</span>.<span class="m">172</span>.<span class="n">in</span>-<span class="n">addr</span>.<span class="n">arpa</span> {
               <span class="n">forwarders</span> {
                  <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>;
		  <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span>;
               }
            }
        <span class="n">default</span>-<span class="n">domain</span> <span class="m">22</span>.<span class="m">172</span>.<span class="n">in</span>-<span class="n">addr</span>.<span class="n">arpa</span> {
               <span class="n">forwarders</span> {
                  <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>;
		  <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span>;
               }
            }
            <span class="n">default</span>-<span class="n">domain</span> <span class="m">23</span>.<span class="m">172</span>.<span class="n">in</span>-<span class="n">addr</span>.<span class="n">arpa</span> {
               <span class="n">forwarders</span> {
                  <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>;
                  <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span>;
               }
            }
            <span class="n">default</span>-<span class="n">domain</span> <span class="m">10</span>.<span class="n">in</span>-<span class="n">addr</span>.<span class="n">arpa</span> {
               <span class="n">forwarders</span> {
                  <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>;
                  <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span>;
               }
            }
         }
      }
   }
}</code></pre>

<h2><a class="anchor" id="ms-dns" href="#ms-dns"></a>MS DNS</h2>
<p>Add a "Conditional Forward" (de: "Bedingte Weiterleitung") for each of "dn42", "20.172.in-addr.arpa", "21.172.in-addr.arpa", "22.172.in-addr.arpa", "23.172.in-addr.arpa", "10.in-addr.arpa" using 172.20.0.53 as forwarder. Ignore the error message that the server is not authoritative.</p>

<h2><a class="anchor" id="systemd-resolved" href="#systemd-resolved"></a>systemd-resolved</h2>

<p>If you are using systemd-networkd and systemd-resolved in a version later then v240 you can set up split DNS by adding the dn42 anycast servers to a interface:</p>

<pre class="highlight"><code>[Match]
Name=dummy0

[Network]
 # don't try to resolve normal internet domains with theses resolvers
DNSDefaultRoute=false
# configure dn42 anycast servers
DNS=fd42:d42:d42:54::1
DNS=172.23.0.53
DNS=fd42:d42:d42:53::1
DNS=172.20.0.53

# configure all relevant dn42 domains as route-only domains
Domains=~dn42
Domains=~20.172.in-addr.arpa
Domains=~21.172.in-addr.arpa
Domains=~22.172.in-addr.arpa
Domains=~23.172.in-addr.arpa
Domains=~10.in-addr.arpa
Domains=~d.f.ip6.arpa</code></pre>

<h2><a class="anchor" id="smartdns" href="#smartdns"></a>smartDNS</h2>

<pre class="highlight"><code># Use -exclude-default-group to exclude dn42 DNS for non-dn42 domains
server fd42:d42:d42:53::1 -exclude-default-group -group dn42
server fd42:d42:d42:54::1 -exclude-default-group -group dn42
server 172.23.0.53 -exclude-default-group -group dn42
server 172.20.0.53 -exclude-default-group -group dn42

# dn42
nameserver /dn42/dn42
nameserver /20.172.in-addr.arpa/dn42
nameserver /21.172.in-addr.arpa/dn42
nameserver /22.172.in-addr.arpa/dn42
nameserver /23.172.in-addr.arpa/dn42
nameserver /10.in-addr.arpa/dn42
nameserver /d.f.ip6.arpa/dn42

# neonetwork
nameserver /neo/dn42

# chaosvpn
nameserver /hack/dn42

# crxn
nameserver /crxn/dn42</code></pre>

<h1><a class="anchor" id="resolver-setup" href="#resolver-setup"></a>Resolver setup</h1>

<p>Configuration of common resolver softwares to do full recursion DNS queries for <code>.dn42</code> (and reverse DNS) IPv4 and IPv6 anycast services.</p>

<p>You can use any *.delegation-servers.dn42 (where * is a letter) as an authoritative server for .dn42 TLD. The current list is available at the <a href="https://git.dn42.dev/dn42/registry/src/master/data/dns/delegation-servers.dn42">DN42 registry</a> or through querying NS records of dn42.:</p>

<pre class="highlight"><code>dig dn42. NS @172.20.0.53</code></pre>

<p>Current list of delegation servers (as of 2025-11-18):</p>

<table>
  <thead>
    <tr>
      <th>Name</th>
      <th>IPv4</th>
      <th>IPv6</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>b.delegation-servers.dn42</td>
      <td>172.20.129.1</td>
      <td>fd42:4242:2601:ac53::1</td>
    </tr>
    <tr>
      <td>d.delegation-servers.dn42</td>
      <td>172.20.132.105</td>
      <td>fd00:913e:130::400</td>
    </tr>
    <tr>
      <td>i.delegation-servers.dn42</td>
      <td>172.23.91.1</td>
      <td>fd42:4242:2189::1</td>
    </tr>
    <tr>
      <td>j.delegation-servers.dn42</td>
      <td>172.20.1.254</td>
      <td>fd42:5d71:219:0:216:3eff:fe1e:22d6</td>
    </tr>
    <tr>
      <td>k.delegation-servers.dn42</td>
      <td>172.20.14.34</td>
      <td>fdcf:8538:9ad5:1111::2</td>
    </tr>
    <tr>
      <td>l.delegation-servers.dn42</td>
      <td>172.22.108.54</td>
      <td>fd86:bad:11b7:53::1</td>
    </tr>
  </tbody>
</table>

<p>All the examples here list 172.20.129.1/fd42:4242:2601:ac53::1, but users are encouraged to configure
multiple services from *.delegation-servers.dn42 for redundancy.</p>

<h2><a class="anchor" id="dnssec" href="#dnssec"></a>Dnssec</h2>
<p>All delegation servers have DNSSEC support and all records are signed.
For more information about DNSSEC visit the <a href="/services/dns/Architecture#dnssec">dns architecture#dnssec</a> page.</p>

<p>Below is a list of links to the DS record for TLD and reverse zone.
To configure the key file, extract the value of ds-rdata and format it as follows.
You must add all ds-rdata to the key file for DNSSEC to work.
NB: each ds-rdata or DS record should contain 4 numbers.</p>

<p>This is an example for dn42. and (fake) ds-rdata of 1 2 3 456
</p><pre class="highlight"><code><span class="n">dn42</span>.	<span class="m">86400</span>	<span class="n">IN</span>	<span class="n">DS</span>	<span class="m">1</span> <span class="m">2</span> <span class="m">3</span> <span class="m">456</span></code></pre>

<p>This is an example for 172.20.0.0/16 and (fake) ds-rdata of 1 2 3 456
</p><pre class="highlight"><code><span class="m">20</span>.<span class="m">172</span>.<span class="n">in</span>-<span class="n">addr</span>.<span class="n">arpa</span>.	<span class="m">86400</span>	<span class="n">IN</span>	<span class="n">DS</span>	<span class="m">1</span> <span class="m">2</span> <span class="m">3</span> <span class="m">456</span></code></pre>

<p>This is an example for fd00::/8 and (fake) ds-rdata of 1 2 3 456
</p><pre class="highlight"><code><span class="n">d</span>.<span class="n">f</span>.<span class="n">ip6</span>.<span class="n">arpa</span>.	<span class="m">86400</span>	<span class="n">IN</span>	<span class="n">DS</span>	<span class="m">1</span> <span class="m">2</span> <span class="m">3</span> <span class="m">456</span></code></pre>

<h3><a class="anchor" id="dn42-ds-record" href="#dn42-ds-record"></a>DN42 DS record</h3>
<p><a href="https://git.dn42.dev/dn42/registry/src/branch/master/data/dns/dn42">dn42. TLD</a></p>

<p><a href="https://git.dn42.dev/dn42/registry/src/branch/master/data/inetnum/172.20.0.0_16">172.20.0.0/16 range</a></p>

<p><a href="https://git.dn42.dev/dn42/registry/src/branch/master/data/inetnum/172.21.0.0_16">172.21.0.0/16 range</a></p>

<p><a href="https://git.dn42.dev/dn42/registry/src/branch/master/data/inetnum/172.22.0.0_16">172.22.0.0/16 range</a></p>

<p><a href="https://git.dn42.dev/dn42/registry/src/branch/master/data/inetnum/172.23.0.0_16">172.23.0.0/16 range</a></p>

<p><a href="https://git.dn42.dev/dn42/registry/src/branch/master/data/inet6num/fd00::_8">fd00::/8 range</a></p>

<h3><a class="anchor" id="non-dn42-ds-record" href="#non-dn42-ds-record"></a>Non DN42 DS record</h3>
<p><a href="https://git.dn42.dev/dn42/registry/src/branch/master/data/inetnum/172.31.0.0_16">172.31.0.0/16 (chaosvpn) range</a></p>

<p><a href="https://git.dn42.dev/dn42/registry/src/branch/master/data/inetnum/10.0.0.0_8">10.0.0.0/8 (Freifunk) range</a></p>

<h2><a class="anchor" id="unbound-1" href="#unbound-1"></a>Unbound</h2>
<pre class="highlight"><code><span class="n">trust</span>-<span class="n">anchor</span>-<span class="n">file</span>: &lt;<span class="n">path</span> <span class="n">to</span> <span class="n">key</span> <span class="n">file</span>&gt;

<span class="n">server</span>:
<span class="n">local</span>-<span class="n">zone</span>: <span class="s2">"dn42"</span> <span class="n">typetransparent</span>
<span class="n">local</span>-<span class="n">zone</span>: <span class="s2">"20.172.in-addr.arpa"</span> <span class="n">typetransparent</span>
<span class="n">local</span>-<span class="n">zone</span>: <span class="s2">"21.172.in-addr.arpa"</span> <span class="n">typetransparent</span>
<span class="n">local</span>-<span class="n">zone</span>: <span class="s2">"22.172.in-addr.arpa"</span> <span class="n">typetransparent</span>
<span class="n">local</span>-<span class="n">zone</span>: <span class="s2">"23.172.in-addr.arpa"</span> <span class="n">typetransparent</span>
<span class="n">local</span>-<span class="n">zone</span>: <span class="s2">"d.f.ip6.arpa"</span> <span class="n">typetransparent</span>

<span class="n">private</span>-<span class="n">domain</span>: <span class="s2">"dn42"</span>
<span class="n">private</span>-<span class="n">domain</span>: <span class="s2">"20.172.in-addr.arpa"</span>
<span class="n">private</span>-<span class="n">domain</span>: <span class="s2">"21.172.in-addr.arpa"</span>
<span class="n">private</span>-<span class="n">domain</span>: <span class="s2">"22.172.in-addr.arpa"</span>
<span class="n">private</span>-<span class="n">domain</span>: <span class="s2">"23.172.in-addr.arpa"</span>
<span class="n">private</span>-<span class="n">domain</span>: <span class="s2">"d.f.ip6.arpa"</span>

<span class="n">stub</span>-<span class="n">zone</span>:
	<span class="n">name</span>: <span class="s2">"dn42"</span>
	<span class="n">stub</span>-<span class="n">addr</span>: <span class="n">fd42</span>:<span class="m">4242</span>:<span class="m">2601</span>:<span class="n">ac53</span>::<span class="m">1</span>
	<span class="n">stub</span>-<span class="n">addr</span>: <span class="m">172</span>.<span class="m">20</span>.<span class="m">129</span>.<span class="m">1</span>

<span class="n">stub</span>-<span class="n">zone</span>:
	<span class="n">name</span>: <span class="s2">"20.172.in-addr.arpa"</span>
	<span class="n">stub</span>-<span class="n">addr</span>: <span class="n">fd42</span>:<span class="m">4242</span>:<span class="m">2601</span>:<span class="n">ac53</span>::<span class="m">1</span>
	<span class="n">stub</span>-<span class="n">addr</span>: <span class="m">172</span>.<span class="m">20</span>.<span class="m">129</span>.<span class="m">1</span>

<span class="n">stub</span>-<span class="n">zone</span>:
	<span class="n">name</span>: <span class="s2">"21.172.in-addr.arpa"</span>
	<span class="n">stub</span>-<span class="n">addr</span>: <span class="n">fd42</span>:<span class="m">4242</span>:<span class="m">2601</span>:<span class="n">ac53</span>::<span class="m">1</span>
	<span class="n">stub</span>-<span class="n">addr</span>: <span class="m">172</span>.<span class="m">20</span>.<span class="m">129</span>.<span class="m">1</span>

<span class="n">stub</span>-<span class="n">zone</span>:
	<span class="n">name</span>: <span class="s2">"22.172.in-addr.arpa"</span>
	<span class="n">stub</span>-<span class="n">addr</span>: <span class="n">fd42</span>:<span class="m">4242</span>:<span class="m">2601</span>:<span class="n">ac53</span>::<span class="m">1</span>
	<span class="n">stub</span>-<span class="n">addr</span>: <span class="m">172</span>.<span class="m">20</span>.<span class="m">129</span>.<span class="m">1</span>

<span class="n">stub</span>-<span class="n">zone</span>:
	<span class="n">name</span>: <span class="s2">"23.172.in-addr.arpa"</span>
	<span class="n">stub</span>-<span class="n">addr</span>: <span class="n">fd42</span>:<span class="m">4242</span>:<span class="m">2601</span>:<span class="n">ac53</span>::<span class="m">1</span>
	<span class="n">stub</span>-<span class="n">addr</span>: <span class="m">172</span>.<span class="m">20</span>.<span class="m">129</span>.<span class="m">1</span>

<span class="n">stub</span>-<span class="n">zone</span>:
	<span class="n">name</span>: <span class="s2">"d.f.ip6.arpa"</span>
	<span class="n">stub</span>-<span class="n">addr</span>: <span class="n">fd42</span>:<span class="m">4242</span>:<span class="m">2601</span>:<span class="n">ac53</span>::<span class="m">1</span>
	<span class="n">stub</span>-<span class="n">addr</span>: <span class="m">172</span>.<span class="m">20</span>.<span class="m">129</span>.<span class="m">1</span></code></pre>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/Policies" rel="nofollow">Policies</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
      <li><a href="/Links" rel="nofollow">Links</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
      <li><a href="/howto/GeoFeed" rel="nofollow">GeoFeed</a></li>
      <li><a href="/howto/telephony42-Asterisk" rel="nofollow">Telephony42 (Asterisk)</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/dns/Overview" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">ROA + RPKI</a></li>
      <li><a href="/services/exchanges/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Pingables" rel="nofollow">Pingables</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/ca/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="services/dns/Configuration.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/services/dns/Configuration.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
