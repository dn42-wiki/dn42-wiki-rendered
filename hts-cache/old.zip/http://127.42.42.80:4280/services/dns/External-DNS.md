<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-309be032396e783b13a47df58f389b7c8e11c2b2d42640560b874f677c25f6e5.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">

  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'services/dns/External-DNS.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-e63ab45773141139cffcd04474f73c21042c7267568325d4e00775b4f9eaa022.js" type="text/javascript"></script>
  

  <title>External-DNS</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>External-DNS</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/services/dns/External-DNS.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <a class="btn btn-sm" id="minibutton-home" href="/">
      Home
    </a>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/overview"
          id="minibutton-overview"
        >
          Overview
        </a>

        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/latest_changes"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </a>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          href="/gollum/history/services/dns/External-DNS.md/"
          id="minibutton-history"
        >
          History
        </a>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    External-DNS
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/services/">services</a></li>
<li class="breadcrumb-item"><a href="/gollum/overview/services/dns/">dns</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <p>This page lists external DNS zones, provided by networks that are interconnected with dn42.</p>

<h2><a class="anchor" id="authoritative-nameservers" href="#authoritative-nameservers"></a>Authoritative nameservers</h2>

<table>
  <thead>
    <tr>
      <th style="text-align:center;"><strong>Network name</strong></th>
      <th style="text-align:center;"><strong>Contact</strong></th>
      <th style="text-align:center;"><strong>DNS zone</strong></th>
      <th style="text-align:center;"><strong>Reverse zone</strong></th>
      <th><strong>Authoritative nameservers</strong></th>
      <th><strong>Last update</strong></th>
      <th><strong>Comments</strong></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:center;">ChaosVPN</td>
      <td style="text-align:center;">-</td>
      <td style="text-align:center;"><code>hack.</code></td>
      <td style="text-align:center;">
<code>31.172.in-addr.arpa.</code> <code>100.10.in-addr.arpa</code> <code>101.10.in-addr.arpa</code> <code>102.10.in-addr.arpa</code> <code>103.10.in-addr.arpa</code>
</td>
      <td>
<code>172.31.0.5</code> <code>172.31.255.53</code> (anycast)</td>
      <td>Nov. 2013</td>
      <td>-</td>
    </tr>
    <tr>
      <td style="text-align:center;">NeoNetwork</td>
      <td style="text-align:center;">-</td>
      <td style="text-align:center;"><code>neo.</code></td>
      <td style="text-align:center;">
<code>127.10.in-addr.arpa</code> <code>7.2.1.0.0.1.d.f.ip6.arpa</code>
</td>
      <td>
<code>10.127.255.53</code> <code>fd10:127:ffff:53::</code>
</td>
      <td>Jul. 2022</td>
      <td>-</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="freifunk" href="#freifunk"></a>Freifunk</h2>

<p>Freifunk generates its zone configuration from the <a href="https://github.com/freifunk/icvpn-meta">icvpn-meta</a> repositority via the <strong>mkdns</strong>-script contained in <a href="https://github.com/freifunk/icvpn-scripts">icvpn-scripts</a>. As there are many Freifunk-Communities this is the easiest way to get them all.</p>

<pre><code>git clone https://github.com/freifunk/icvpn-scripts.git
git clone https://github.com/freifunk/icvpn-meta.git
cd icvpn-scripts
./mkdns -f bind -s ../icvpn-meta/ -x dn42 -x chaosvpn -x rzl -x neonetwork
</code></pre>

<p><em>Note: dn42, chaosvpn (, rzl which has been removed, but is still in the script) and neonetwork are excluded (-x), because they are not part of Freifunk and you might want to configure them yourself.</em></p>

<p>The mkdns script currently supports the following setups:</p>
<ul>
  <li>bind (static-stub)</li>
  <li>bind-forward (forward zone)</li>
  <li>dnsmasq</li>
  <li>unbound (forward-zone)</li>
</ul>

<h2><a class="anchor" id="neonetwork" href="#neonetwork"></a>NeoNetwork</h2>

<p>The NeoNetwork also has a recursive DNS server at <code>10.127.255.54</code> and <code>fd10:127:53:53::</code>.
The zone files can be found here: <a href="https://github.com/NeoCloud/NeoNetwork/tree/master/dns">https://github.com/NeoCloud/NeoNetwork/tree/master/dns</a></p>

<h2><a class="anchor" id="configuration" href="#configuration"></a>Configuration</h2>

<p>See <a href="/services/dns/Configuration">DNS forwarding configuration</a>.</p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="services/dns/External-DNS.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/services/dns/External-DNS.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
