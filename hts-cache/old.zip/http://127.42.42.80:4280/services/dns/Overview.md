<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'services/dns/Overview.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Overview</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Overview</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/services/dns/Overview.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/services/dns/Overview.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Overview
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/services/">services</a></li>
<li class="breadcrumb-item"><a href="/gollum/overview/services/dns/">dns</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="dn42-dns" href="#dn42-dns"></a>DN42 DNS</h1>

<p>This page covers guidance and examples on using DNS within DN42.</p>

<h2><a class="anchor" id="quick-start" href="#quick-start"></a>Quick Start</h2>

<p>It is recommended to run your own DNS resolver as this provides you with the most security and privacy. 
However, to get started, or if running your own resolver isn't desirable an anycast service
is available. The anycast service supports DNSSEC and will resolve public DNS names together with all the 
relevant DN42 and affiliated networks' names.</p>

<h3><a class="anchor" id="using-the-dns-anycast-service" href="#using-the-dns-anycast-service"></a>Using the DNS Anycast Service</h3>

<p>The DNS anycast service is provided by multiple operators, with each operator contributing to one of the two separate 
anycast services. By configuring both services, users get additional resiliency from having two, independent, resolvers.</p>

<table>
  <thead>
    <tr>
      <th>Name</th>
      <th>IPv4</th>
      <th>IPv6</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>a0.recursive-servers.dn42</td>
      <td>172.20.0.53</td>
      <td>fd42:d42:d42:54::1</td>
    </tr>
    <tr>
      <td>a3.recursive-servers.dn42</td>
      <td>172.23.0.53</td>
      <td>fd42:d42:d42:53::1</td>
    </tr>
  </tbody>
</table>

<p>To configure the service, ping both sets of addresses then set your primary nameserver to the lowest latency 
service and configure the other service as the secondary or backup nameserver.</p>

<p>Example resolv.conf, preferring a0.recursive-servers.dn42 and IPv4:</p>

<pre class="highlight"><code><span class="n">nameserver</span> <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>
<span class="n">nameserver</span> <span class="m">172</span>.<span class="m">23</span>.<span class="m">0</span>.<span class="m">53</span>
<span class="n">nameserver</span> <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span>
<span class="n">nameserver</span> <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">53</span>::<span class="m">1</span>
<span class="n">search</span> <span class="n">dn42</span></code></pre>

<p>Example resolv.conf, preferring a3.recursive-servers.dn42 and IPv6:</p>

<pre class="highlight"><code><span class="n">nameserver</span> <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">53</span>::<span class="m">1</span>
<span class="n">nameserver</span> <span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">54</span>::<span class="m">1</span>
<span class="n">nameserver</span> <span class="m">172</span>.<span class="m">23</span>.<span class="m">0</span>.<span class="m">53</span>
<span class="n">nameserver</span> <span class="m">172</span>.<span class="m">20</span>.<span class="m">0</span>.<span class="m">53</span>
<span class="n">option</span> <span class="n">inet6</span>       <span class="c"># Linux/glibc
</span><span class="n">family</span> <span class="n">inet6</span> <span class="n">inet4</span> <span class="c"># BSD
</span><span class="n">search</span> <span class="n">dn42</span></code></pre>

<h2><a class="anchor" id="advanced-configuration" href="#advanced-configuration"></a>Advanced Configuration</h2>

<p>There are multiple top level domains (TLDs) associated with DN42, its affiliated networks and for reverse DNS that must
be configured in order to run your own resolver. The registry is the authoritative source of active TLDs, but see also
the <a href="/services/dns/External-DNS">External-DNS</a> page in the wiki.</p>

<h3><a class="anchor" id="split-horizon-dns" href="#split-horizon-dns"></a>Split horizon DNS</h3>

<p>In this configuration, you run your own, caching resolver but forward DN42 related queries (with recursion bit set) 
to the anycast service. Example configurations for different recursor implementations are included in the <a href="/services/dns/Configuration">Configuration</a> page.</p>

<h3><a class="anchor" id="full-recursion" href="#full-recursion"></a>Full recursion</h3>

<p>Authoritative DNS for DN42 is provided by the *.delegation-servers.dn42 servers, see the DNS architecture here 
Delegations servers have full support for DNSSEC. Example configuration unbound implementations are included in the <a href="/services/dns/Configuration#resolver-setup">Configuration</a> page.</p>

<h2><a class="anchor" id="additional-client-configuration" href="#additional-client-configuration"></a>Additional client configuration</h2>

<ul>
  <li>
<strong>Firefox</strong>: Set <code>browser.fixup.domainsuffixwhitelist.dn42</code> to <code>true</code> in <code>about:config</code> to prevent Firefox from confusing dn42 domains with search queries.</li>
</ul>

<h2><a class="anchor" id="further-information" href="#further-information"></a>Further Information</h2>

<ul>
  <li>
<a href="/services/dns/Configuration">Configuration</a> - Forwarder/Resolver configuration examples</li>
  <li>
<a href="/services/dns/Architecture">Architecture</a> - Current DNS system architecture</li>
  <li>
<a href="/services/dns/External-DNS">External-DNS</a> - External DNS zones from interconnected networks</li>
</ul>


	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="services/dns/Overview.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/services/dns/Overview.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
