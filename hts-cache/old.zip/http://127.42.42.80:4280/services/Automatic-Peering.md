<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'services/Automatic-Peering.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Automatic-Peering</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Automatic-Peering</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/services/Automatic-Peering.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/services/Automatic-Peering.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Automatic-Peering
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/services/">services</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="automatic-peering" href="#automatic-peering"></a>Automatic Peering</h1>

<p>It is recommended to use the <a href="https://peerfinder.dn42.dev/">Public node directory</a> to find the network with the lowest latency to peer with.</p>

<h2><a class="anchor" id="fully-self-service" href="#fully-self-service"></a>Fully self-service</h2>

<p>This list includes only systems that offer instant peering (fully self-service, unattended).</p>

<table>
  <thead>
    <tr>
      <th style="text-align:center;">ASN</th>
      <th style="text-align:center;">Network</th>
      <th>Autopeer URL</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:center;">AS4242420207</td>
      <td style="text-align:center;"><a href="https://dn42.routedbits.io">RoutedBits</a></td>
      <td><a href="https://dn42.routedbits.io">https://dn42.routedbits.io</a></td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242420253</td>
      <td style="text-align:center;"><a href="https://blog.moe233.net/dn42/">moe233</a></td>
      <td><a href="https://blog.moe233.net/dn42/">https://blog.moe233.net/dn42/</a></td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242420263</td>
      <td style="text-align:center;"><a href="https://hcartiaux.github.io/dn42/">FLIPFLAP-DN42</a></td>
      <td><a href="https://hcartiaux.github.io/dn42/">https://hcartiaux.github.io/dn42/</a></td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242420454</td>
      <td style="text-align:center;"><a href="https://dn42.nedifinita.com/">Nedifinita Network</a></td>
      <td><a href="https://peer-dn42.nedifinita.com/">https://peer-dn42.nedifinita.com/</a></td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242421023</td>
      <td style="text-align:center;"><a href="https://network.owo.li/">Iris Network</a></td>
      <td>Clearnet → <a href="https://autopeer.owo.li/">https://autopeer.owo.li/</a> <br /> DN42 → <a href="https://autopeer.iris.dn42/">https://autopeer.iris.dn42/</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242421588</td>
      <td style="text-align:center;"><a href="https://www.chrismoos.com/dn42-peering">TECH9 CORE NETWORK</a></td>
      <td><a href="https://www.chrismoos.com/dn42-peering">https://www.chrismoos.com/dn42-peering</a></td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242421816</td>
      <td style="text-align:center;"><a href="https://dn42.potat0.cc">Potat0 Network</a></td>
      <td><a href="https://dn42.potat0.cc">https://dn42.potat0.cc</a></td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242421817</td>
      <td style="text-align:center;"><a href="https://dn42.kskb.eu.org">KSKB Network</a></td>
      <td><a href="https://dn42.kskb.eu.org">https://dn42.kskb.eu.org</a></td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242422016</td>
      <td style="text-align:center;"><a href="https://dn42.sidereal.ca">sidereal</a></td>
      <td>Clearnet → <a href="https://dn42.sidereal.ca">https://dn42.sidereal.ca</a> <br /> DN42 → <a href="https://sidereal.dn42">https://sidereal.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242422189</td>
      <td style="text-align:center;"><a href="https://iedon.net">iEdon Networks</a></td>
      <td>Clearnet → <a href="https://iedon.net/">https://iedon.net/</a> <br /> DN42 → <a href="https://iedon.dn42/">https://iedon.dn42/</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242422225</td>
      <td style="text-align:center;"><a href="https://peering.maraun.de">MARAUN</a></td>
      <td><a href="https://peering.maraun.de">https://peering.maraun.de</a></td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242422227</td>
      <td style="text-align:center;"><a href="https://pudunet.net">PUDUNET</a></td>
      <td><a href="https://pudunet.net">https://pudunet.net</a></td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242422244</td>
      <td style="text-align:center;"><a href="https://sgp.dn42.icez.net/">ICEZ-DN42</a></td>
      <td><a href="https://sgp.dn42.icez.net/">https://sgp.dn42.icez.net/</a></td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242422717</td>
      <td style="text-align:center;"><a href="https://net.whojk.com">JK-Network</a></td>
      <td><a href="https://net.whojk.com">https://net.whojk.com</a></td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242423035</td>
      <td style="text-align:center;"><a href="https://dn42.lare.cc">LARE-DN42</a></td>
      <td><a href="https://dn42.lare.cc/autopeer">https://dn42.lare.cc/autopeer</a></td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242423088</td>
      <td style="text-align:center;"><a href="https://dn42.6700.cc">SUNNET</a></td>
      <td><a href="https://peer.dn42.6700.cc">https://peer.dn42.6700.cc</a></td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242423310</td>
      <td style="text-align:center;"><a href="https://peer42.tmpfs.dev/">ACh Sulfate</a></td>
      <td><a href="https://peer42.tmpfs.dev/">https://peer42.tmpfs.dev/</a></td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242423374</td>
      <td style="text-align:center;"><a href="https://dn42.baka.pub/en/peering-request/bingxin-network">Bingxin Network</a></td>
      <td><a href="https://dn42.baka.pub/en/peering-request/bingxin-network">https://dn42.baka.pub/en/peering-request/bingxin-network</a></td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242423432</td>
      <td style="text-align:center;"><a href="https://dn42.s6v.net">S6V</a></td>
      <td><a href="https://dn42.s6v.net">https://dn42.s6v.net</a></td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242423914</td>
      <td style="text-align:center;"><a href="https://dn42.g-load.eu">Kioubit Network</a></td>
      <td>Clearnet → <a href="https://dn42.g-load.eu">https://dn42.g-load.eu</a>
</td>
    </tr>
  </tbody>
</table>

<p>Sort by AS number</p>

<h2><a class="anchor" id="semi-automatic-peering" href="#semi-automatic-peering"></a>Semi-automatic peering</h2>

<p>This list contains all services that are not fully automatic and require some action from the operator or similar.</p>

<table>
  <thead>
    <tr>
      <th style="text-align:center;">ASN</th>
      <th style="text-align:center;">Network</th>
      <th>Autopeer URL</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:center;">AS4242420893</td>
      <td style="text-align:center;"><a href="https://maiyun.me/dn42.html">Maiyun-dn42</a></td>
      <td>DN42 → <a href="https://git.dn42/MAIYUN-DN42/dn42-config-pub">https://git.dn42/MAIYUN-DN42/dn42-config-pub</a> <br /> GitHub → <a href="https://github.com/myzhang1029/dn42-config-pub">https://github.com/myzhang1029/dn42-config-pub</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242421117</td>
      <td style="text-align:center;"><a href="https://dn42.yuyuko.com">Yuyuko Network</a></td>
      <td><a href="https://dn42.yuyuko.com">https://dn42.yuyuko.com</a></td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242421732</td>
      <td style="text-align:center;"><a href="https://as215887.net/dn42">BaragoonNetworks</a></td>
      <td><a href="https://peering.as215887.net">https://peering.as215887.net</a></td>
    </tr>
  </tbody>
</table>

<p>Sort by AS number</p>

<h2><a class="anchor" id="historical-services" href="#historical-services"></a>Historical services</h2>

<p>This list contains defunct services.</p>

<table>
  <thead>
    <tr>
      <th style="text-align:center;">ASN</th>
      <th style="text-align:center;">Network</th>
      <th>Autopeer URL</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:center;">AS64719</td>
      <td style="text-align:center;"><a href="https://dn42.lutoma.org">lutoma</a></td>
      <td><a href="https://dn42.lutoma.org">https://dn42.lutoma.org</a></td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242420603</td>
      <td style="text-align:center;"><a href="https://dn42.mol.moe">MolMoe Network</a></td>
      <td><a href="https://dn42.mol.moe">https://dn42.mol.moe</a></td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242420927</td>
      <td style="text-align:center;"><a href="https://dn42.liki.link">Liki4</a></td>
      <td><a href="https://dn42.liki.link">https://dn42.liki.link</a></td>
    </tr>
    <tr>
      <td style="text-align:center;">AS4242423847</td>
      <td style="text-align:center;"><a href="https://dn42.0011.de">TheQ Network</a></td>
      <td><a href="https://dn42.0011.de">https://dn42.0011.de</a></td>
    </tr>
  </tbody>
</table>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="services/Automatic-Peering.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/services/Automatic-Peering.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
