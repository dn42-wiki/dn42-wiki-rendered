<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-309be032396e783b13a47df58f389b7c8e11c2b2d42640560b874f677c25f6e5.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">

  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'services/Route-Collector.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-e63ab45773141139cffcd04474f73c21042c7267568325d4e00775b4f9eaa022.js" type="text/javascript"></script>
  

  <title>Route-Collector</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Route-Collector</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/services/Route-Collector.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <a class="btn btn-sm" id="minibutton-home" href="/">
      Home
    </a>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/overview"
          id="minibutton-overview"
        >
          Overview
        </a>

        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/latest_changes"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </a>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          href="/gollum/history/services/Route-Collector.md/"
          id="minibutton-history"
        >
          History
        </a>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Route-Collector
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/services/">services</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="global-route-collector" href="#global-route-collector"></a>Global Route Collector</h1>

<p>The Global Route Collector (GRC) provides a real time view of routing and peering across DN42 and can be used to generate maps, stats or just query how routes are being propagated across the network.</p>

<p>Technically the GRC is a <a href="https://bird.network.cz/">bird</a> instance that anyone can peer with, it imports all routes whilst exporting none and provides a number of interfaces for querying the route data.</p>

<p>Data from the GRC is used to generate some of the DN42 Maps (see the <a href="/internal/Internal-Services">Internal Services</a> page).</p>

<h2><a class="anchor" id="peering-with-the-collector" href="#peering-with-the-collector"></a>Peering with the collector</h2>

<p>The collector uses the dynamic peering capability in Bird2 to allow anyone to peer with it without any new server side configuration being required. The collector relies on users peering with it across the network so the more peers the better and the more comprehensive the collector data will be.</p>

<table>
  <thead>
    <tr>
      <th style="text-align:left;"> </th>
      <th style="text-align:left;">Details</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">ASN</td>
      <td style="text-align:left;">AS4242422602</td>
    </tr>
    <tr>
      <td style="text-align:left;">Hostname</td>
      <td style="text-align:left;">collector.dn42</td>
    </tr>
    <tr>
      <td style="text-align:left;">IPv4 Address</td>
      <td style="text-align:left;">172.20.129.4</td>
    </tr>
    <tr>
      <td style="text-align:left;">IPv6 Address</td>
      <td style="text-align:left;">fd42:4242:2601:ac12::1</td>
    </tr>
  </tbody>
</table>

<h3><a class="anchor" id="bgp-configuration" href="#bgp-configuration"></a>BGP Configuration</h3>

<ul>
  <li>Unlike normal DN42 peerings, you must enable multihop to peer with the collector</li>
  <li>The collector supports Multiprotocol BGP, so you don't need to configure separate IPv4 and IPv6 sessions</li>
  <li>Please enable the Add Paths BGP extension to export all available routes</li>
</ul>

<p>Example bird2 config:</p>

<pre class="highlight"><code><span class="n">protocol</span> <span class="n">bgp</span> <span class="n">ROUTE_COLLECTOR</span>
{
  <span class="n">local</span> <span class="n">as</span> ***<span class="n">YOUR_ASN</span>***;
  <span class="n">neighbor</span> <span class="n">fd42</span>:<span class="m">4242</span>:<span class="m">2601</span>:<span class="n">ac12</span>::<span class="m">1</span> <span class="n">as</span> <span class="m">4242422602</span>;

  <span class="c"># enable multihop as the collector is not locally connected
</span>  <span class="n">multihop</span>;

  <span class="n">ipv4</span> {
    <span class="c"># export all available paths to the collector    
</span>    <span class="n">add</span> <span class="n">paths</span> <span class="n">tx</span>;

    <span class="c"># import/export filters
</span>    <span class="n">import</span> <span class="n">none</span>;
    <span class="n">export</span> <span class="n">filter</span> {
      <span class="c"># export all valid routes
</span>      <span class="n">if</span> ( <span class="n">is_valid_network</span>() &amp;&amp; <span class="n">source</span> ~ [ <span class="n">RTS_STATIC</span>, <span class="n">RTS_BGP</span> ] )
      <span class="n">then</span> {
        <span class="n">accept</span>;
      }
      <span class="n">reject</span>;
    };
  };

  <span class="n">ipv6</span> {
    <span class="c"># export all available paths to the collector    
</span>    <span class="n">add</span> <span class="n">paths</span> <span class="n">tx</span>;

    <span class="c"># import/export filters
</span>    <span class="n">import</span> <span class="n">none</span>;
    <span class="n">export</span> <span class="n">filter</span> {
      <span class="c"># export all valid routes
</span>      <span class="n">if</span> ( <span class="n">is_valid_network_v6</span>() &amp;&amp; <span class="n">source</span> ~ [ <span class="n">RTS_STATIC</span>, <span class="n">RTS_BGP</span> ] )
      <span class="n">then</span> {
        <span class="n">accept</span>;
      }
      <span class="n">reject</span>;
    };
  };
}</code></pre>

<p>Example OpenBGPD config snippet (assumes config similar to
the <a href="/howto/OpenBGPD">OpenBGPD setup guide</a>; note the GRC
neighbor should be defined separately (outside the
<code>dn42peers</code> group)):</p>

<pre class="highlight"><code><span class="n">neighbor</span> <span class="n">fd42</span>:<span class="m">4242</span>:<span class="m">2601</span>:<span class="n">ac12</span>::<span class="m">1</span> {
	<span class="n">local</span>-<span class="n">address</span> &lt;<span class="n">YOUR</span>-<span class="n">ROUTER</span>-<span class="n">DN42</span>-<span class="n">IPv6</span>&gt;
	<span class="n">descr</span> <span class="n">dn42grc</span>
	<span class="n">remote</span>-<span class="n">as</span> <span class="m">4242422602</span>
	<span class="n">multihop</span> <span class="m">255</span>
	<span class="n">announce</span> <span class="n">IPv4</span> <span class="n">unicast</span>
	<span class="n">announce</span> <span class="n">IPv6</span> <span class="n">unicast</span>
	<span class="n">announce</span> <span class="n">add</span>-<span class="n">path</span> <span class="n">send</span> <span class="n">all</span>
}

<span class="c"># [...]
</span>
<span class="n">allow</span> <span class="n">to</span> {<span class="n">group</span> <span class="n">dn42peers</span> <span class="n">fd42</span>:<span class="m">4242</span>:<span class="m">2601</span>:<span class="n">ac12</span>::<span class="m">1</span>} <span class="n">prefix</span>-<span class="n">set</span> <span class="n">dn42etc</span></code></pre>

<p>Example VyOS 1.4 "Sagitta" config
</p><pre class="highlight"><code># The route collector should never export routes, so let's make a route-map to reject them if it does.
set policy route-map Deny-All rule 1 action deny
set protocols bgp neighbor fd42:4242:2601:ac12::1 address-family ipv4-unicast route-map import 'Deny-All'
set protocols bgp neighbor fd42:4242:2601:ac12::1 address-family ipv6-unicast route-map import 'Deny-All'
set protocols bgp neighbor fd42:4242:2601:ac12::1 description 'https://lg.collector.dn42'
set protocols bgp neighbor fd42:4242:2601:ac12::1 ebgp-multihop '10'
set protocols bgp neighbor fd42:4242:2601:ac12::1 remote-as '4242422602'
</code></pre>

<h2><a class="anchor" id="querying-the-collector" href="#querying-the-collector"></a>Querying the collector</h2>

<h3><a class="anchor" id="looking-glass" href="#looking-glass"></a>Looking Glass</h3>

<p>The collector runs a looking glass based on <a href="https://github.com/xddxdd/bird-lg-go">bird-lg-go</a>.</p>

<ul>
  <li><a href="https://lg.collector.dn42/">https://lg.collector.dn42/</a></li>
</ul>

<h3><a class="anchor" id="mrt-dumps" href="#mrt-dumps"></a>MRT Dumps</h3>

<p><a href="https://tools.ietf.org/html/rfc6396">MRT Dumps</a> are produced by the collector every 10 minutes. Bird produces MRT dumps corresponding to tables, so two separate dumps are created, one for IPv4 (master4) and one for IPv6 (master6). The 10 minutes dumps are available for one week before being reduced down to one a day.</p>

<ul>
  <li><a href="https://mrt.collector.dn42">https://mrt.collector.dn42</a></li>
</ul>

<p>The latest dumps can always be found at the following URLs:</p>

<ul>
  <li><a href="https://mrt.collector.dn42/master4_latest.mrt.bz2">https://mrt.collector.dn42/master4_latest.mrt.bz2</a></li>
  <li><a href="https://mrt.collector.dn42/master6_latest.mrt.bz2">https://mrt.collector.dn42/master6_latest.mrt.bz2</a></li>
</ul>

<h3><a class="anchor" id="prometheus-metrics" href="#prometheus-metrics"></a>Prometheus Metrics</h3>

<p>The collector runs <a href="https://github.com/czerwonk/bird_exporter">bird_exporter</a> and prometheus style metrics are available at the following URL:</p>

<ul>
  <li><a href="http://collector.dn42:9324/metrics">http://collector.dn42:9324/metrics</a></li>
</ul>

<h3><a class="anchor" id="ssh-interface" href="#ssh-interface"></a>SSH Interface</h3>

<p>The collector bird instance can be queried directly using a birdc shell.</p>

<ul>
  <li>ssh shell@collector.dn42</li>
</ul>

<pre class="highlight"><code><span class="nv">$ </span>ssh shell@collector.dn42
<span class="nt">------------------------------------</span>
<span class="k">*</span>    DN42 Global Route Collector   <span class="k">*</span>
<span class="nt">------------------------------------</span>
<span class="k">*</span> http://collector.dn42/

This service provides a bird2 shell
<span class="k">for </span>querying the route collector

Be <span class="nb">nice</span>, access is logged and
abuse will not be tolerated
<span class="nt">------------------------------------</span>
BIRD burble-2.0.8-210322-1-ge6133456 ready.
Access restricted
bird&gt; show route count
bird&gt;       297441 of 297441 routes <span class="k">for </span>502 networks <span class="k">in </span>table master4
286007 of 286007 routes <span class="k">for </span>427 networks <span class="k">in </span>table master6
1437 of 1437 routes <span class="k">for </span>1437 networks <span class="k">in </span>table dn42_roa4
1231 of 1231 routes <span class="k">for </span>1231 networks <span class="k">in </span>table dn42_roa6
Total: 586116 of 586116 routes <span class="k">for </span>3597 networks <span class="k">in </span>4 tables
bird&gt; 
</code></pre>


	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="services/Route-Collector.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/services/Route-Collector.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
