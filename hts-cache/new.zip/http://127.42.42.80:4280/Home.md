<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'Home.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Home</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Home</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/Home.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/Home.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Home
  </h1>
	<div class="breadcrumb"></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h2><a class="anchor" id="about-dn42" href="#about-dn42"></a>About dn42</h2>

<p>dn42 is a large, dynamic <a href="https://en.wikipedia.org/wiki/Virtual_private_network">VPN</a> that employs Internet technologies (<a href="https://en.wikipedia.org/wiki/Bgp">BGP</a>, whois database, <a href="https://en.wikipedia.org/wiki/Domain_Name_System">DNS</a>, etc.). Participants connect to each other using network tunnels (<a href="/howto/GRE-on-FreeBSD">GRE</a>, <a href="/howto/openvpn">OpenVPN</a>, <a href="/howto/wireguard">WireGuard</a>, <a href="/howto/tinc">Tinc</a>, <a href="/howto/IPsec-with-PublicKeys">IPsec</a>) and exchange routes using the Border Gateway Protocol.</p>

<p>Network addresses are assigned in the <code>172.20.0.0/14</code> range with private AS numbers (see <a href="/services/Whois">registry</a>), as well as IPv6 addresses from the ULA range (<code>fd00::/8</code>) - see <a href="/FAQ#frequently-asked-questions_what-about-ipv6-in-dn42">FAQ</a>.</p>

<p>A variety of <a href="/internal/Internal-Services">services</a> are available on the network, only accessible from within dn42. dn42 is also <a href="/Interconnections">interconnected</a> with other networks, such as <a href="http://wiki.hamburg.ccc.de/ChaosVPN">ChaosVPN</a> and various <a href="https://en.wikipedia.org/wiki/Freifunk">Freifunk</a> networks.</p>

<p>Still have questions? Check out our <a href="/FAQ">FAQs</a>.</p>

<h2><a class="anchor" id="why-dn42" href="#why-dn42"></a>Why dn42?</h2>

<p>dn42 can be used to learn networking and to connect private networks, such as hackerspaces or community networks. But above all, experimenting with routing in dn42 is fun!</p>

<h3><a class="anchor" id="experiment-with-routing-technology" href="#experiment-with-routing-technology"></a>Experiment with routing technology</h3>

<p>dn42 is primarily useful for learning routing technologies such as BGP within a reasonably large network (1,500+ AS, 1,700+ prefixes).</p>

<p>Since dn42 closely mirrors the Internet, it serves as a hands-on testing ground for new ideas, or simply for learning real networking concepts that aren't practical on the public Internet (BGP multihoming, transit, etc.). The biggest advantage: if you break something, no large network operator will be yelling at you.</p>

<h3><a class="anchor" id="connect-hackerspaces-and-private-networks" href="#connect-hackerspaces-and-private-networks"></a>Connect hackerspaces and private networks</h3>

<p>dn42 provides a way to connect hackerspaces and other private networks, enabling them to share services with each other.</p>

<p>Most end-user networks rely on <a href="https://en.wikipedia.org/wiki/Network_address_translation">NAT</a> to share a single public IPv4 address among multiple devices, making it difficult to host services directly. You may also want to offer services to other hackerspaces without exposing them to the entire Internet.</p>

<p>dn42 solves this problem. By addressing your network within dn42, your devices can communicate transparently with all other participants - no NAT required. You still maintain full control: like with IPv6, you can use a firewall to restrict access while selectively allowing traffic from dn42.</p>

<p>If your hackerspace uses dn42 to provide services, please let us know on this wiki or the mailing list. It's rewarding to see the network put to practical use!</p>

<h2><a class="anchor" id="join-or-contact-us" href="#join-or-contact-us"></a>Join or contact us</h2>

<p>dn42 is operated by volunteers with no central authority. Visit the <a href="/contact">contact</a> page to learn how to collaborate or get in touch.</p>

<p>Ready to join? The <a href="/howto/Getting-Started">Getting Started</a> guide will help you set up your first node.</p>

<h2><a class="anchor" id="external-resources" href="#external-resources"></a>External resources</h2>

<ul>
  <li><a href="https://en.wikipedia.org/wiki/Decentralized_network_42">Wikipedia: Decentralized network 42</a></li>
  <li><a href="https://fahrplan.events.ccc.de/congress/2009/Fahrplan/events/3504.en.html">26c3 lecture</a></li>
  <li><a href="https://entropia.de/GPN8:dn42">GPN8 lecture</a></li>
  <li><a href="http://nowhere.ws/guides/dn42/">nobody's dn42 guide</a></li>
  <li><a href="https://web.archive.org/web/20090831211324/http://mrmcd0x8.metarheinmain.de/fahrplan/events/3321.de.html">mrmcd0x8 lecture</a></li>
  <li><a href="https://wiki.hackerspaces.org/Category:DN42">dn42 on hackerspaces.org</a></li>
  <li><a href="https://www.c3d2.de/news/pentaradio24-20150428.html">pentaradio24 podcast (German)</a></li>
  <li><a href="http://sandbox.freertr.org/">dn42 in your browser</a></li>
  <li><a href="http://portable.freertr.org/">dn42 in your terminal</a></li>
</ul>

<h2><a class="anchor" id="participant-groups" href="#participant-groups"></a>Participant groups</h2>

<ul>
  <li><a href="http://spaceboyz.net">SpaceBoyz</a></li>
  <li><a href="https://aachen.ccc.de">CCC Aachen</a></li>
  <li><a href="http://ccchb.de">CCC Bremen</a></li>
  <li><a href="http://darmstadt.ccc.de">CCC Darmstadt</a></li>
  <li><a href="http://c3d2.de">CCC Dresden</a></li>
  <li><a href="https://www.chaosdorf.de">CCC Düsseldorf</a></li>
  <li><a href="https://www.muc.ccc.de">CCC Munich</a></li>
  <li><a href="https://chaoschemnitz.de">Chaostreff Chemnitz</a></li>
  <li><a href="https://dev.0l.de">/dev/nulll</a></li>
  <li><a href="http://freifunk.net">freifunk</a></li>
  <li><a href="https://www.noname-ev.de">NoName e.V. Heidelberg</a></li>
  <li><a href="http://www.raumzeitlabor.de">raumzeitlabor / hackerspace rhein-neckar</a></li>
  <li><a href="http://hackerspace.be">Hackerspace Brussels (HSB)</a></li>
  <li><a href="https://hsmr.cc">hsmr / Hackspace Marburg</a></li>
  <li><a href="http://www.0x20.be">Whitespace (0x20)</a></li>
  <li><a href="http://www.revspace.nl">Revelation Space</a></li>
  <li><a href="https://www.os3.nl">SNE group</a></li>
  <li><a href="http://www.smrsh.net">smrsh</a></li>
  <li><a href="http://wiki.breizh-entropy.org/wiki/DN42">Breizh-Entropy</a></li>
  <li><a href="https://www.ffdn.org">Fédération FDN</a></li>
  <li><a href="https://leloop.org/">Le LOOP</a></li>
  <li><a href="https://acmelabs.space">ACME Labs</a></li>
  <li><a href="https://dn42.fixmix.tech/">fixmix Technologies Ltd</a></li>
  <li><a href="https://strexp.net">Strategic Explorations Ltd</a></li>
</ul>

<h2><a class="anchor" id="about-this-wiki" href="#about-this-wiki"></a>About this wiki</h2>

<p>This wiki is the main reference for dn42. It is available in read-only mode from the Internet at:</p>

<ul>
  <li><a href="https://wiki.dn42.us">wiki.dn42.us</a></li>
  <li><a href="https://dn42.dev">dn42.dev</a></li>
  <li><a href="https://dn42.pp.ua">dn42.pp.ua</a></li>
  <li><a href="https://dn42.eu">dn42.eu</a></li>
  <li><a href="https://dn42.wiki">dn42.wiki</a></li>
  <li><a href="https://dn42.cc">dn42.cc</a></li>
  <li>
<a href="https://dn42.de">dn42.de</a> (IPv6 only)</li>
  <li><a href="https://dn42.jp">dn42.jp</a></li>
  <li><a href="https://dn42.net">dn42.net</a></li>
  <li><a href="https://dn42.li">dn42.li</a></li>
  <li><a href="https://dn42.app">dn42.app</a></li>
</ul>

<p>Editing is available from within dn42 at <a href="https://wiki.dn42">https://wiki.dn42</a> (<a href="/services/ca/Certificate-Authority">HTTPS certificate</a> required).</p>

<h3><a class="anchor" id="dn42-logo" href="#dn42-logo"></a>DN42 logo</h3>

<p>An SVG of the DN42 logo is available <a href="/dn42.svg">here</a>.</p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="Home.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/Home.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
