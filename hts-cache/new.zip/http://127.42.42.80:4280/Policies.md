<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'Policies.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Policies</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Policies</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/Policies.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/Policies.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Policies
  </h1>
	<div class="breadcrumb"></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="policies" href="#policies"></a>Policies</h1>

<h2><a class="anchor" id="resource-allocations" href="#resource-allocations"></a>Resource Allocations</h2>

<p>dn42 global resources are limited so, by necessity, all requests for resources above the typical allocations must be treated as exceptions. If users genuinely need additional resources they can be provided, but the registry maintainers can only do this by challenging every request to ensure it is justified. It's not fair to throw away resources now and then require much stricter limits in the future because we ran out of space.</p>

<p>Users applying for additional resources should consider their requests against the following criteria:</p>

<ul>
  <li>Does your allocation provide <strong>additional value</strong> to the rest of the dn42 community?</li>
</ul>

<p>Allocations for personal use are harder to justify, why should you get global, community resources if that doesn't provide any value back to the community?</p>

<ul>
  <li>Why is your use case <strong>exceptional</strong>?</li>
</ul>

<p>Requests for additional resources cannot be the norm, so they must be exceptional.<br />
What makes your use special over everybody else in the network?<br />
Why should you get additional resources when other people will not be able to have them?</p>

<ul>
  <li>Is your request based on <strong>demonstrable need</strong>?</li>
</ul>

<p>Additional resources should only be requested where there is clear evidence that existing resources are being fully utilised and are insufficient for the current requirement. Resources will not be granted based on anticipated future demand or the possibility that they may be needed later.</p>

<p>If you are developing a new service that requires additional resources, you should first deploy and operate the service so that the requirement can be demonstrated and justified.</p>

<h3><a class="anchor" id="new-users" href="#new-users"></a>New Users</h3>

<p>Typical and maximum allocations for new users</p>

<table>
  <thead>
    <tr>
      <th style="text-align:left;"> </th>
      <th style="text-align:left;">ASN</th>
      <th style="text-align:left;">IPv6 Allocation</th>
      <th style="text-align:left;">IPv4 Allocation</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">Typical</td>
      <td style="text-align:left;">1</td>
      <td style="text-align:left;">/48</td>
      <td style="text-align:left;">/27</td>
    </tr>
    <tr>
      <td style="text-align:left;">Maximum</td>
      <td style="text-align:left;">1</td>
      <td style="text-align:left;">/48</td>
      <td style="text-align:left;">/26</td>
    </tr>
  </tbody>
</table>

<p>The typical allocation provides enough resources for most new users; it is suitable for doing all the fun things in dn42 and growing your network.</p>

<p>For IPv4, new users should be aware that allocations smaller than a /27 can become restrictive. Even if your network is currently small, a /27 usually provides a better starting point and gives you room to expand later without requiring a second resource request or fragmenting the IP space.</p>

<p>For IPv6, there is generally no advantage to request anything other than a /48. Even if your network doesn't support IPv6 yet, some parts of dn42 are IPv6-only, and IPv6 is the preferred protocol for many services. Allocations smaller than a /48 can be very restrictive, while a /48 provides enough address space for even very large networks.</p>

<p>When registering for the first time, new users will not be allocated more than the maximum amounts shown above.</p>

<p>These limits are based on the principle of demonstrable need. Additional resources are provided when there is clear evidence that existing resources are being fully used and are no longer sufficient.</p>

<p>For this reason, please do not register and immediately request more resources. Requests for additional allocations will normally only be considered after you can demonstrate that your current allocations are actively in use and no longer meet your requirements.</p>

<h3><a class="anchor" id="asn-allocations" href="#asn-allocations"></a>ASN Allocations</h3>

<p>ASNs are administrative, not geographical boundaries; additional ASNs are not required for additional nodes or to provide geographic services.</p>

<p>Additional ASNs 'for testing' are also unlikely to be provided.</p>

<p>Alternative approaches include:</p>

<ul>
  <li>
    <p>Setting up local lab environment using private ASNs in the 42xxxxxxxx range, outside the dn42 424242xxxx range. There's no problem peering locally with your dn42 router as an external peer to testing policies and what it looks like, or even having your own local mini dn42 with multiple peers and transits.</p>
  </li>
  <li>
    <p>You can already view how the rest of the network sees your ASN via looking glasses; it's also instructive to see how other user's policies impact your announcements. Learning what to look for or diagnose problems using a looking glass is a valuable skill in its own right.</p>
  </li>
  <li>
    <p>Talk to your peers! dn42 is a community and most users will be happy to help.</p>
  </li>
</ul>

<h3><a class="anchor" id="ipv4-allocations" href="#ipv4-allocations"></a>IPv4 Allocations</h3>

<p>A typical IPv4 allocation is /27. This provides you with 32 x /32 IPv4 addresses which is often more than enough for most networks. You should typically only require 1 IPv4 address for each peering node or service on dn42.</p>

<p>The smallest routable IPv4 prefix size in dn42 is /29.</p>

<p>Total IPv4 allocations greater than /26 will be challenged and you will be expected to provide robust justification.</p>

<p>Allocations &gt;= /25 are rare and &gt;= /24 require mailing list consensus; these will require extraordinary justification and are almost never granted apart from the most exceptional (and usually temporary) circumstances.</p>

<p>If you have a requirement for a large number of IP addresses you should consider using IPv6 first.</p>

<p>You should also consider using NAT for anything not directly providing dn42 services (for example, where you want to access dn42 from a homelab or laptop, but are not providing services to the rest of the dn42 community).</p>

<h3><a class="anchor" id="ipv6-allocations" href="#ipv6-allocations"></a>IPv6 Allocations</h3>

<p>The smallest routable IPv6 prefix size in dn42 is /64.</p>

<p>There are very few reasons for not allocating the standard /48 address block; it provides a huge address space sufficient to run a global network whilst smaller block sizes can often be limiting.</p>

<p>A typical IPv6 address plan will use /56 subnets per site, with the typical /48 providing for 256 x /56 sites and 256 x /64 networks per site.</p>

<h2><a class="anchor" id="bridging-from-the-internet" href="#bridging-from-the-internet"></a>Bridging from the Internet</h2>

<p>dn42 is a separate network from the public Internet. While dual-homed services can be beneficial (for example, looking glasses), users should not provide services that grant direct access to the dn42 address space from the Internet. This includes, public NAT gateways, VPN services, proxies, or other mechanisms that allow non-dn42 users to reach dn42 resources.</p>

<p>dn42 is primarily for learning about network technologies. Providing zero effort access to the network runs counter to that core purpose and prevents users gaining experience of learning how to create and configure their own network.</p>

<p>Preventing direct access from the public Internet also helps protect the network from abuse, including AI scrapers, large-scale crawlers, and other unwanted traffic that is commonplace on the Internet. This reduces unnecessary load on network participants and contributes to a safer and more stable environment.</p>

<h2><a class="anchor" id="network-port-scans" href="#network-port-scans"></a>Network / Port scans</h2>

<p>A network scan involves examining hosts in a network. The general aim is to find information such as open ports, software versions, and vulnerabilities. Depending on how the scan is performed, many packets are sent to the individual hosts at short intervals.</p>

<h3><a class="anchor" id="rules" href="#rules"></a>Rules</h3>

<p>There are no technically enforceable rules for port scanning (i.e., rules that apply only to port scanning; general restriction rules such as rate limits can of course be set), but that does not mean that you should just go ahead and do it - depending on how it is done, it can be perceived as very intrusive. Therefore, the following rules of politeness have become established over time:</p>

<ol>
  <li>Announce the network scan in advance on the mailing list.</li>
  <li>Provide the option to opt out.</li>
</ol>

<h3><a class="anchor" id="opt-out" href="#opt-out"></a>Opt out</h3>

<p>Unfortunately, there is currently no standard way to signal that a network should not be scanned. Several proposals have been discussed in the past - communication via BGP, via the registry, or via the mailing list.</p>

<p>Another option would be to signal opt-outs via the wiki:</p>

<table>
  <thead>
    <tr>
      <th>Maintainer</th>
      <th>Network</th>
      <th>Opt-out?</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><code>EXAMPLE-MNT</code></td>
      <td>172.0.0.1/24</td>
      <td>Yes</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="registry-cleanup" href="#registry-cleanup"></a>Registry cleanup</h2>

<p>A maintainer is classified as "inactive" if the following conditions have been fulfilled:</p>
<ol>
  <li>All of the ASNs the maintainer has been directly or indirectly associated with (in any way and by following all references, whether through mnt-by, admin-c, tech-c, etc. or through an ORG) have not been observed originating any prefix in the global routing table at any point within the last three years. (Determined by analyzing the daily MRT RIB dumps provided by the DN42 Global Route collector.)</li>
  <li>The maintainer has not edited any of the ASN objects they are associated with in the registry within the last three years. (Determined by analyzing the git commit history.)</li>
</ol>

<p>Maintainers that are not affiliated with an ASN (whether directly or indirectly or through other maintainers) are also considered inactive regardless of whether they fulfill the above conditions.
A maintainer may also ask to opt out from a cleanup operation.</p>

<h3><a class="anchor" id="process" href="#process"></a>Process</h3>
<p>The process is to be executed on a regular basis (yearly).</p>

<p>Using <strong>registry_wizard (written for v0.4.12)</strong>:</p>

<ol>
  <li>Download the MRT files from the Global Route Collector (GRC):
<code>wget -r -np -nH --cut-dirs=1 -A "*.mrt.bz2" --reject "*:*" http://collector.dn42/</code>
</li>
  <li>Generate a list of active ASNs based on MRT data:
<code>./registry_wizard /path/to/registry mrt_activity parse /path/to/mrt/files --cutoff-time &lt;value&gt; --list &gt; active_list.txt</code>
</li>
  <li>Based on the list of active ASNs and through referencing the registry git commit log, generate a list of inactive ASNs:
<code>./registry_wizard /path/to/registry mrt_activity active_asn_to_inactive --list_file /path/to/active_list.txt --cutoff-time &lt;value&gt; &gt; inactive_list.txt</code>
</li>
  <li>Generate the removal commands to remove inactive objects based on the previous list:
<code>./registry_wizard /path/to/registry remove aut-num --list_file /path/to/inactive_list.txt --enable_subgraph_check</code>
</li>
</ol>

<p>ASNs can be excluded from removal by removing them from the list produced in step 3.</p>

<p>Manual review of a few resources (primarily those affiliated with "DN42-MNT") will be required as they cannot be removed in an automated way (for example, resources associated with an inactive maintainer that used to host the DN42 anycast DNS will be affiliated with DN42-MNT and will require manual removal).
To identify the exact conflicts leading to the manual review requirement the following command can be used:
<code>./registry_wizard /path/to/registry graph path mntner YAMAKAYA-MNT mntner DN42-MNT</code> (To list conflicts between YAMAKAYA-MNT and DN42-MNT)</p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="Policies.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/Policies.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
