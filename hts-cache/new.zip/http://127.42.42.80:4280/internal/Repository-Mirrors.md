<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'internal/Repository-Mirrors.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Repository-Mirrors</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Repository-Mirrors</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/internal/Repository-Mirrors.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/internal/Repository-Mirrors.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Repository-Mirrors
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/internal/">internal</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="repository-mirrors" href="#repository-mirrors"></a>Repository Mirrors</h1>

<p>There are some mirrors available in DN42. All mirrors are subdomains of "mirror.dn42". DNS Round-Robin is set up for Load Balancing.</p>

<h2><a class="anchor" id="mirror-ano-org-dn42" href="#mirror-ano-org-dn42"></a>mirror.ano-org.dn42</h2>

<p>Proxy to multiple repositories:</p>

<ul>
  <li>
<a href="http://mirror.ano-org.dn42/debian">http://mirror.ano-org.dn42/debian</a>: deb.debian.org/debian</li>
  <li>
<a href="http://mirror.ano-org.dn42/debsec">http://mirror.ano-org.dn42/debsec</a>: security.debian.org/debian-security</li>
  <li>
<a href="http://mirror.ano-org.dn42/ubuntu">http://mirror.ano-org.dn42/ubuntu</a>: archive.ubuntu.com/ubuntu</li>
  <li>
<a href="http://mirror.ano-org.dn42/ubsec">http://mirror.ano-org.dn42/ubsec</a>: security.ubuntu.com/ubuntu</li>
  <li>
<a href="http://mirror.ano-org.dn42/proxmox">http://mirror.ano-org.dn42/proxmox</a>: download.proxmox.com/debian</li>
  <li>
<a href="http://mirror.ano-org.dn42/grafana">http://mirror.ano-org.dn42/grafana</a>: packages.grafana.com/oss/deb</li>
  <li>
<a href="http://mirror.ano-org.dn42/rpi">http://mirror.ano-org.dn42/rpi</a>: archive.raspberrypi.org/debian</li>
</ul>

<p>Other repos can be added on request, contact glueckself@hackint on IRC or send a mail to <a href="mailto:noc@ano-org.sml.name">noc@ano-org.sml.name</a></p>

<h2><a class="anchor" id="ubuntu" href="#ubuntu"></a>Ubuntu</h2>
<p><strong><a href="http://mirror.dn42/ubuntu">http://mirror.dn42/ubuntu</a></strong></p>

<p>Hosted by:</p>
<ul>
  <li>mephisto</li>
</ul>

<h2><a class="anchor" id="mirror-yandex-ru-proxy" href="#mirror-yandex-ru-proxy"></a>mirror.yandex.ru proxy</h2>
<p><strong><a href="http://172.23.158.41/">http://172.23.158.41/</a></strong>
<strong><a href="http://[fd91:9191:9191:3::1]/">http://[fd91:9191:9191:3::1]/</a></strong></p>

<p>Hosted by:</p>
<ul>
  <li>ne-vlezay80</li>
</ul>

<h2><a class="anchor" id="mirrors-nia-dn42-ipv6-only" href="#mirrors-nia-dn42-ipv6-only"></a>mirrors.nia.dn42 (IPv6 Only)</h2>

<p><a href="https://os.ewe.moe/download">eweOS</a>:</p>
<ul>
  <li>
<a href="http://mirrors.nia.dn42/eweos/">http://mirrors.nia.dn42/eweos/</a>: Official Mirror in DN42</li>
  <li>
<a href="http://mirrors.nia.dn42/eweos-images/">http://mirrors.nia.dn42/eweos-images/</a>: Official Mirror in DN42</li>
</ul>

<h2><a class="anchor" id="mirror-z-dn42" href="#mirror-z-dn42"></a>mirror.z.dn42</h2>

<p>Not hosting repositories itself, it collects other mirrors</p>

<ul>
  <li>Dynamic page: <strong><a href="http://mirror.z.dn42/">http://mirror.z.dn42/</a></strong>
</li>
  <li>Static page: <strong><a href="http://mirror.z.dn42/_/">http://mirror.z.dn42/_/</a></strong>
</li>
</ul>

<h2><a class="anchor" id="mirrors-leziblog-dn42" href="#mirrors-leziblog-dn42"></a>mirrors.leziblog.dn42</h2>

<p>Notes:</p>
<ul>
  <li>Local repository, hosted by <a href="mailto:lezi@leziblog.dn42">LeZi</a>
</li>
  <li>Synchronize with the upstream every day at 00:00 UTC.</li>
  <li>Supports <code>https</code>, <code>rsync</code>
    <ul>
      <li>https: <code>https://mirrors.leziblog.dn42</code>
</li>
      <li>rsync: <code>rsync://rsync.mirrors.leziblog.dn42</code>
</li>
    </ul>
  </li>
</ul>

<p>Ubuntu:</p>
<ul>
  <li>
<a href="http://mirrors.leziblog.dn42/ubuntu/">http://mirrors.leziblog.dn42/ubuntu/</a>: archive.ubuntu.com/ubuntu</li>
  <li>
<a href="http://mirrors.leziblog.dn42/ubuntu-ports/">http://mirrors.leziblog.dn42/ubuntu-ports/</a>: ports.ubuntu.com</li>
</ul>

<p>OpenWrt:</p>
<ul>
  <li>
<a href="http://mirrors.leziblog.dn42/openwrt/">http://mirrors.leziblog.dn42/openwrt/</a>: downloads.openwrt.org</li>
</ul>

<p>Ubuntu-image:</p>
<ul>
  <li>20.04.6
    <ul>
      <li><a>magnet:?xt=urn:btih:83df9f532bed288518d884fe63363e8f5b2286e2</a></li>
    </ul>
  </li>
  <li>22.04.5
    <ul>
      <li><a>magnet:?xt=urn:btih:8df707795d20b9d8021241d56c6f8282929c8b8d</a></li>
    </ul>
  </li>
  <li>24.04.3
    <ul>
      <li><a>magnet:?xt=urn:btih:5fd2dd3688fdb31fe554b15ed65228f3db29a9f9</a></li>
    </ul>
  </li>
</ul>

<h1><a class="anchor" id="container-repository-proxy" href="#container-repository-proxy"></a>Container Repository Proxy</h1>

<p>Allows access to IPv6 capable container repositories (e.g. quay.io, AWS ECR, Dockerhub, …). Just add <code>oci.ano-org.dn42/</code> in front of the the image name, e.g. <code>podman pull quay.io/akvorado/akvorado</code> becomes <code>podman pull oci.ano-org.dn42/quay.io/akvorado/akvorado</code></p>

<p>Notes:</p>
<ul>
  <li>Docker automatically uses <code>docker.io</code>, so if you're doing e.g. <code>docker pull homeassistant/home-assistant</code>, you need to include docker.io: <code>docker pull oci.ano-org.dn42/docker.io/homeassistant/home-assistant</code>
</li>
  <li>GHCR is not IPv6 capable and can't be used! Annoy either the project maintainer to upload it somewhere else; or mail to noc@ano-org.sml.name or write glueckself@hackint in IRC to fix their NAT.</li>
  <li>AWS ECR's <code>public.ecr.aws</code> (not IPv6 capable) must be replaced with <code>ecr-public.aws.com</code> (IPv6 capable)</li>
</ul>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/Policies" rel="nofollow">Policies</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
      <li><a href="/Links" rel="nofollow">Links</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
      <li><a href="/howto/GeoFeed" rel="nofollow">GeoFeed</a></li>
      <li><a href="/howto/Telephony-Asterisk" rel="nofollow">Telephony (Asterisk)</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/dns/Overview" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">ROA + RPKI</a></li>
      <li><a href="/services/exchanges/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Pingables" rel="nofollow">Pingables</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/ca/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>, <a href="https://iedon.net/post/24" rel="nofollow">IEDON-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:sess@sess.dn42" rel="nofollow">SESS-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>, <a href="https://dn42.jp/" rel="nofollow">dn42.jp</a> (wiki-go), <a href="https://dn42.net/" rel="nofollow">dn42.net</a>, <a href="https://dn42.li/" rel="nofollow">dn42.li</a> (wiki-go)</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="internal/Repository-Mirrors.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/internal/Repository-Mirrors.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
