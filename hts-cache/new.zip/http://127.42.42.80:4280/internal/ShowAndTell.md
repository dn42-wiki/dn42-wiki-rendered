<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'internal/ShowAndTell.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>ShowAndTell</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>ShowAndTell</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/internal/ShowAndTell.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/internal/ShowAndTell.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    ShowAndTell
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/internal/">internal</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="dn42-show-and-tell" href="#dn42-show-and-tell"></a>dn42 Show and Tell</h1>

<p>Let us know the most creative, best, strangest, complex, weird or just plain fun setups that you've created with dn42.</p>

<p>Document your mad setups in the categories below, with links to a full write up, photos and screenshots welcome.</p>

<h2><a class="anchor" id="things-peered-into-dn42" href="#things-peered-into-dn42"></a>Things peered into dn42</h2>
<ul>
  <li>Fun devices peered into dn42,</li>
  <li>Or fun ways to connect them</li>
  <li>The thing must be running BGP and connected into dn42 as a full dynamic peer</li>
</ul>

<p><em>Examples</em>:</p>
<ul>
  <li>Fun with virtualisation
    <ul>
      <li>peer into dn42 from your browser</li>
      <li>Emulate some old bgp capable hardware</li>
    </ul>
  </li>
  <li>Fun with hardware
    <ul>
      <li>obsolete routers you still have in your garage/loft/basement</li>
      <li>shiny new hardware that you need to 'test' for work</li>
    </ul>
  </li>
  <li>Fun with networks
    <ul>
      <li>fast networks (100G+), slow networks (UART), strange networks (IP over dns/usb/etc)</li>
      <li>Wired: Token Ring/X.25/ATM/ISDN etc (encapsulation allowed, but bonus points for real physical networks)</li>
      <li>Wireless: dn42 via microwave/laser/satellite</li>
    </ul>
  </li>
</ul>

<p><em>… your stuff goes here</em></p>

<h2><a class="anchor" id="things-attached-to-dn42" href="#things-attached-to-dn42"></a>Things attached to dn42</h2>
<ul>
  <li>The thing must be pingable from dn42</li>
  <li>Bonus points if you can access the wiki from it</li>
  <li>Double bonus, the device was able to add or edit its own entry on this page</li>
  <li>Static routing, protocol encapsulation and virtualisation allowed</li>
</ul>

<p><em>Examples</em>:</p>
<ul>
  <li>Fun with virtualisation
    <ul>
      <li>connect using an obscure or obsolete operating system</li>
    </ul>
  </li>
  <li>Fun with hardware
    <ul>
      <li>Microprocessors (ESP32, Arduino, Pico etc) or FPGAs</li>
      <li>Connect your phone, watch, tv, clock, washing machine etc</li>
    </ul>
  </li>
</ul>

<p><em>… your stuff goes here</em></p>

<hr />

<ul>
  <li>Retro dn42 access service by Burble</li>
  <li>
    <p>burble.dn42 provides a <a href="https://dn42.burble.com/retro/">dn42 dialup service</a> using real modems over VOIP, together with a <a href="https://dn42.burble.com/retro/fake/">modem emulator</a> to ease attaching retro computers or virtual machines into dn42</p>
  </li>
  <li>
    <p>04dco: At a maximum theoretical speed of a whopping 28.8 Kbps, web browsing and IRC chatting were done. My site still loads faster than everyone else's :)</p>

    <p><img src="/internal/images/ircdun.png" alt="Screenshot of Windows XP while chatting on a familiar client" /></p>
  </li>
  <li>
    <p>grawity: Lacking a physical modem, configured VirtualBox to attach the Windows 98 serial port to a TCP modem emulator at dialup.burble.dn42. Listening to a shoutcast stream of local FM radio station.</p>

    <p><img src="/internal/images/win98dun.png" alt="Screenshot of Win98 showing &quot;Connection Established&quot;" /></p>
  </li>
  <li>
    <p>jlu5: a Windows Server running BGP and receiving dn42 routes! (<a href="https://jlu5.com/blog/bgp-dn42-windows-server">Full writeup here</a>)</p>

    <p><img src="/internal/images/gobgp-windows.png" alt="GoBGP and route table output on Windows" /></p>
  </li>
  <li>
    <p>mdr: An 8-bit Sinclair ZX Spectrum with Spectranet card fitted connecting to my TNFS server over DN42. Emulator in a web browser also available at <a href="https://speccy.mdr.dn42">https://speccy.mdr.dn42</a> - sort of like an old-school BBS system with games, message wall, user accounts etc.</p>

    <p><img src="https://share.markround.com/speccy1.jpg" alt="ZX Spectrum connecting to DN24 service" /></p>
  </li>
  <li>
    <p>haksrpd: Greeting to dn42 from Kim! Access dn42 with latest Chromium on Red Star OS 3.0.
<img src="https://blog.sherpherd.net/img/greeting%20from%20red%20os%203.0.png" alt="Access dn42 with latest Chromium on Red Star OS 3.0" /></p>
  </li>
  <li>calvin: DN42 from your wrist! A working DN42 node with bgp on a android watch
Running a BGP enabled dn42 node on <strong>almost any</strong> linux device via my <a href="https://github.com/lin-calvin/gouter">userspace router written in golang</a>
Try to access the http server on my watch via <a href="http://172.22.138.40:8080">172.22.138.40:8080</a> (not 7x24 online)
    <h2><a class="anchor" id="things-that-use-dn42" href="#things-that-use-dn42"></a>Things that use dn42</h2>
  </li>
  <li>Fun stuff that you've done with dn42</li>
</ul>

<p><em>Examples</em>:</p>
<ul>
  <li>Fun with hardware
    <ul>
      <li>home automation or IoT over dn42</li>
    </ul>
  </li>
  <li>Fun with networking
    <ul>
      <li>Unique or obscure network and routing protocols</li>
    </ul>
  </li>
</ul>

<p><em>… your stuff goes here</em></p>

<hr />

<ul>
  <li>Hardware Random Number Generator by Kioubit</li>
  <li>A raspberry pi was connected to a random number source and random bytes offered via dn42. The raspberry pi is running a custom server to take requests via a simple HTTPS API and interface with the device.</li>
</ul>

<h2><a class="anchor" id="achievements" href="#achievements"></a>Achievements</h2>
<p>Add what you did in/for dn42, yet:</p>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Who</th>
      <th style="text-align:left;">#peerings</th>
      <th style="text-align:left;">Bandwidth</th>
      <th style="text-align:left;">DNS</th>
      <th style="text-align:left;">Fileserver</th>
      <th style="text-align:left;">Network service</th>
      <th style="text-align:left;">Website</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">allo</td>
      <td style="text-align:left;">7</td>
      <td style="text-align:left;">1 GBit/s</td>
      <td style="text-align:left;">auth. only</td>
      <td style="text-align:left;">no</td>
      <td style="text-align:left;">no</td>
      <td style="text-align:left;">yes</td>
    </tr>
    <tr>
      <td style="text-align:left;">stv0g</td>
      <td style="text-align:left;">8</td>
      <td style="text-align:left;">1 GBit/s</td>
      <td style="text-align:left;">no</td>
      <td style="text-align:left;">no</td>
      <td style="text-align:left;">no</td>
      <td style="text-align:left;"><a href="https://dev.0l.dn42">yes</a></td>
    </tr>
    <tr>
      <td style="text-align:left;">fsteinel</td>
      <td style="text-align:left;">2</td>
      <td style="text-align:left;">2 MBit/s</td>
      <td style="text-align:left;">auth. only</td>
      <td style="text-align:left;">no</td>
      <td style="text-align:left;">no</td>
      <td style="text-align:left;"><a href="http://www.flonet.dn42">yes</a></td>
    </tr>
    <tr>
      <td style="text-align:left;">haksrpd</td>
      <td style="text-align:left;">30+</td>
      <td style="text-align:left;">30 gbps maximum approx.</td>
      <td style="text-align:left;">auth. only</td>
      <td style="text-align:left;">no</td>
      <td style="text-align:left;">MPLS L3VPN, EVPN, DN42 Service Hosting, etc.</td>
      <td style="text-align:left;"><a href="http://blog.sherpherd.dn42">yes</a></td>
    </tr>
  </tbody>
</table>


	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/Policies" rel="nofollow">Policies</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
      <li><a href="/Links" rel="nofollow">Links</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
      <li><a href="/howto/GeoFeed" rel="nofollow">GeoFeed</a></li>
      <li><a href="/howto/Telephony-Asterisk" rel="nofollow">Telephony (Asterisk)</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/dns/Overview" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">ROA + RPKI</a></li>
      <li><a href="/services/exchanges/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Pingables" rel="nofollow">Pingables</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/ca/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="https://iedon.net/post/24" rel="nofollow">IEDON-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:sess@sess.dn42" rel="nofollow">SESS-MNT</a>, <a href="mailto:nedifinita@ik.me" rel="nofollow">NEDIFINITA-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.jp/" rel="nofollow">dn42.jp</a> (wiki-go), <a href="https://dn42.net/" rel="nofollow">dn42.net</a>, <a href="https://dn42.li/" rel="nofollow">dn42.li</a> (wiki-go), <a href="https://dn42.app/" rel="nofollow">dn42.app</a>
</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="internal/ShowAndTell.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/internal/ShowAndTell.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
