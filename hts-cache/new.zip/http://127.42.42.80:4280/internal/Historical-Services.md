<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-309be032396e783b13a47df58f389b7c8e11c2b2d42640560b874f677c25f6e5.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">

  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'internal/Historical-Services.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-f05401ee374f0c7f48fc2bc08e30b4f4db705861fd5895ed70998683b383bfb5.js" type="text/javascript"></script>
  

  <title>Historical-Services</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Historical-Services</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/internal/Historical-Services.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <a class="btn btn-sm" id="minibutton-home" href="/">
      Home
    </a>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/overview"
          id="minibutton-overview"
        >
          Overview
        </a>

        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/latest_changes"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </a>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          href="/gollum/history/internal/Historical-Services.md/"
          id="minibutton-history"
        >
          History
        </a>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Historical-Services
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/internal/">internal</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="historical-services" href="#historical-services"></a>Historical Services</h1>

<p><strong>The services below were available on DN42 in the past.</strong></p>

<p><strong>This section exists to serve as an inspiration for people wanting to provide a service to the DN42 community.</strong></p>

<hr />

<p>You can inspect the services status <a href="https://services.dn42">on this page</a></p>

<h2><a class="anchor" id="network-related" href="#network-related"></a>Network-related</h2>

<ul>
<li>
<a href="http://net.smrsh.dn42/routes/d3js.html">net.smrsh.dn42/routes/d3js.html</a> aka 172.23.174.1 (dn42) or <a href="http://dn42.smrsh.net/routes/d3js.html">dn42.smrsh.net/routes/d3js.html</a> (Internet)</li>
<li>Polynome has some nice scripts and visualizations here: <a href="http://dataviz.polynome.dn42/dn42-netblock-visu/registry.html">http://dataviz.polynome.dn42/dn42-netblock-visu/registry.html</a>
</li>
<li>DN42 Toplevel domain DNS monitoring: <a href="http://gatuno.dn42/dns">gatuno.dn42/dns</a>
</li>
<li>Free DNS Hosting. You can host any toplevel or subdomain from dn42: <a href="http://gatuno.dn42/managed/">gatuno.dn42/managed</a>
</li>
<li>Nixnodes original Map of the network: <a href="http://map.nixnodes.net">map.nixnodes.net</a>
</li>
<li>IP base network map: <a href="https://jh0project.dn42/map">map.jh0project.dn42</a> (DN42) or <a href="https://dn42.jh0project.com/map">dn42.jh0project.com</a> (IANA) <em>(uses ping and traceroute the whole DN42's ipv4 addresss block.)</em>
</li>
<li>BGP lookup tool: <a href="https://bgp.charlie.dn42/">bgp.charlie.dn42</a> (DN42)</li>
<li>Observed routes over time (from the perspective of the C4TG1RL5 network): <a href="https://catgirls.dn42/routes/">https://catgirls.dn42/routes/</a>
</li>
</ul>

<h3><a class="anchor" id="dns-hosting" href="#dns-hosting"></a>DNS Hosting</h3>

<p>Free DNS Hosting is provided by tombii - currently in a beta test phase. Please contact tombii in #dn42 to get an account.</p>

<p>DNS Hosting with PowerDNS GUI is provided by Nellicus. Support for Domains and RDNS. Please contact nellicus in #dn42 or email admin (at) nellic.us</p>

<p>DNS Hosting with PowerDNS GUI is also provided by KaiRaphixx. Support for Domains and RDNS. Please contact KaiRaphixx in #dn42 or email ich (at) kai.cool</p>

<h3><a class="anchor" id="dns-tunnel" href="#dns-tunnel"></a>DNS tunnel</h3>

<p>This DNS tunnel service uses <a href="http://code.kryo.se/iodine/">Iodine</a>, and provides access to the dn42 network. Useful when you're on a shitty network (airport, train station) that still allows DNS.</p>

<p>Use the anycast DNS servers (172.22.0.53) inside your tunnel.</p>

<table>
<thead>
<tr>
<th align="left">Hostname / IP</th>
<th align="left">Password</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left">t.polyno.me (172.23.185.193)</td>
<td align="left">dn42</td>
</tr>
<tr>
<td align="left">t.hax404.de (172.23.136.98)</td>
<td align="left">dn42</td>
</tr>
</tbody>
</table>

<h3><a class="anchor" id="dns-tools" href="#dns-tools"></a>DNS Tools</h3>

<p>This tool allows you to lookup your dn42 domain name and check to see if your name servers are all working and have the correct information.</p>

<p>Select "Disable Recursion" to check only entries found in the registry or leave it off to check all (both are useful tests).</p>

<p>Currently this system only supports IPv4.</p>

<p><a href="http://mwd.dn42/dns.php">http://mwd.dn42/dns.php</a></p>

<p>MWD will also provide a secondary DNS server and/or cacti monitoring of your devices. Just ask on IRC. More info: <a href="http://mwd.dn42">http://mwd.dn42</a></p>

<h3><a class="anchor" id="getting-your-current-dn42-ipv4-ipv6-address" href="#getting-your-current-dn42-ipv4-ipv6-address"></a>Getting your current dn42 IPv4/IPv6 address</h3>

<ul>
<li>What is my IP: <a href="http://ip4.dn42/">ip4.dn42</a>, <a href="http://ip6.dn42/">ip6.dn42</a>
</li>
<li>What is my IP: <a href="http://whatismyip.dn42/">whatismyip.dn42</a>
</li>
<li>
<a href="http://wieistmeineip.dn42">http://wieistmeineip.dn42</a> provides a service like <a href="http://wieistmeineip.de">http://wieistmeineip.de</a>, but for dn42.
wieistmeineip.dn42 also provides a telnet service that returns the address you connected with. This service only shows you the address of the preferred protocol, but there are also ipv4.wieistmeineip.dn42 and ipv6.wieistmeineip.dn42 that accept only connections via IPv4/IPv6.</li>
<li>You can also use <a href="http://whatismyip.dn42">http://whatismyip.dn42</a> from inside dn42 to get your IPv4 and IPv6 address. It also returns information about your latency, netblock details, and route information.</li>
<li>An alternative is available at <a href="https://ip.naive.network">https://ip.naive.network</a>, which displays your clearnet and dn42 IP addresses.</li>
</ul>

<h2><a class="anchor" id="search-engines" href="#search-engines"></a>Search engines</h2>

<table>
<thead>
<tr>
<th align="left">Hostname / IP</th>
<th align="left">Remarks</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left">
<a href="http://yacy.dn42">http://yacy.dn42</a> (OFFLINE 2020-01-18)</td>
<td align="left">YaCy search engine. Indexing local nets</td>
</tr>
<tr>
<td align="left"><em>Configuring Yacy Network settings:</em></td>
<td align="left"><a href="http://yacy.dn42/yacy.network.dn42.unit">YaCy Network Configuration</a></td>
</tr>
<tr>
<td align="left"><a href="http://mhm.dn42/search">http://mhm.dn42/search</a></td>
<td align="left">Hosted by toBee</td>
</tr>
<tr>
<td align="left"></td>
<td align="left">Hosted by marlinc</td>
</tr>
</tbody>
</table>

<h2><a class="anchor" id="radio-and-video-streaming" href="#radio-and-video-streaming"></a>Radio and Video Streaming</h2>

<table>
<thead>
<tr>
<th align="left">Hostname / IP</th>
<th align="left">Remarks</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left">
<a href="https://invidious.doxz.dn42/">https://invidious.doxz.dn42/</a> (BROKEN 2021-04-19)</td>
<td align="left">Invidious instance with proxy (Youtube)</td>
</tr>
<tr>
<td align="left"><a href="http://stream.media.dn42/">http://stream.media.dn42/</a></td>
<td align="left">icecast-relay, contact toBee for more streams (DOWN 2020-11-02)</td>
</tr>
<tr>
<td align="left"><a href="http://radio.hex.dn42/">http://radio.hex.dn42/</a></td>
<td align="left">Ambient musics</td>
</tr>
<tr>
<td align="left"><a href="https://yp.unknownts.dn42/">https://yp.unknownts.dn42/</a></td>
<td align="left">A YellowPages for internet radio stations inside dn42</td>
</tr>
<tr>
<td align="left"><a href="http://deep.radio.unknownts.dn42/">http://deep.radio.unknownts.dn42/</a></td>
<td align="left">Internet radio playing random music</td>
</tr>
<tr>
<td align="left"><a href="http://rickroll.dn42">http://rickroll.dn42</a></td>
<td align="left">Play Rickroll Video</td>
</tr>
</tbody>
</table>

<h2><a class="anchor" id="images-e-books-videos-and-other-media" href="#images-e-books-videos-and-other-media"></a>Images, E-Books, Videos and other Media</h2>

<table>
<thead>
<tr>
<th align="left">Hostname / IP</th>
<th align="left">Remarks</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left"><a href="http://img.dn42">http://img.dn42</a></td>
<td align="left">Imagehoster</td>
</tr>
<tr>
<td align="left"><a href="http://chan.dn42">http://chan.dn42</a></td>
<td align="left">DN42-Chan, an imageboard</td>
</tr>
</tbody>
</table>

<h2><a class="anchor" id="file-sharing" href="#file-sharing"></a>File Sharing</h2>

<h3><a class="anchor" id="ftp-http" href="#ftp-http"></a>FTP / HTTP</h3>

<table>
<thead>
<tr>
<th align="left">Hostname / IP</th>
<th align="left">Space</th>
<th align="left">Speed</th>
<th align="left">Remarks</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left"><a href="http://filer.mhm.dn42">http://filer.mhm.dn42</a></td>
<td align="left">4TB</td>
<td align="left">1GBit</td>
<td align="left">24/7/365</td>
</tr>
<tr>
<td align="left"><a href="http://data.0l.dn42">http://data.0l.dn42</a></td>
<td align="left">5TB</td>
<td align="left">1GBit</td>
<td align="left">24/7/365, download, dn42 MRT dumps</td>
</tr>
<tr>
<td align="left"><a href="http://seafile.dn42">http://seafile.dn42</a></td>
<td align="left"></td>
<td align="left"></td>
<td align="left">Opensource Dropbox, yay!</td>
</tr>
</tbody>
</table>

<h3><a class="anchor" id="tahoe-lafs" href="#tahoe-lafs"></a>Tahoe LAFS</h3>

<p>Some people runs <a href="/services/Tahoe-LAFS">Tahoe LAFS</a> nodes to provide a secure decentralized crypted file storage but in dn42.</p>

<h3><a class="anchor" id="ipfs" href="#ipfs"></a>ipfs</h3>

<p>bootstrap peers
</p><pre class="highlight"><code>/ip4/172.20.161.135/tcp/4001/ipfs/QmYgD1wdPjx5oWzYJ195K84PqAXRnw9mcqbyZYAdXfaYkD
/ip4/172.20.52.220/tcp/4001/ipfs/QmW5ZhZFav8MZLJyvKuK6pKaR4vnQ5MVHfXY3LuMXqa4kc</code></pre>
test hashes
<pre class="highlight"><code>/ipfs/QmQ7psrGrXS3GFNC4BtU6pJXq6G7ps5NbYrhS2VYFufj9T
/ipfs/QmYLapmcSU7q93Ta4eHMh8fq9ios2HTSdbpHDRQwGG6ocJ</code></pre>
cdn (currently only jquery
<pre class="highlight"><code>/ipns/QmW5ZhZFav8MZLJyvKuK6pKaR4vnQ5MVHfXY3LuMXqa4kc/cdn/jquery</code></pre>
Until browsers have ipfs access (either through native support or js), one can use the http gateway
<pre class="highlight"><code>https://rest.dn42/</code></pre>

<h3><a class="anchor" id="torrent-search-engine" href="#torrent-search-engine"></a>Torrent Search Engine</h3>

<ul>
<li>
<a href="https://magnetic.dn42">https://magnetic.dn42</a> (DHT Search Engine)</li>
</ul>

<h3><a class="anchor" id="torrent-index" href="#torrent-index"></a>Torrent Index</h3>

<ul>
<li><a href="http://torrents.dn42">http://torrents.dn42</a></li>
</ul>

<h3><a class="anchor" id="torrent-tracker" href="#torrent-tracker"></a>Torrent Tracker</h3>

<table>
<thead>
<tr>
<th align="left">Hostname / IP</th>
<th align="left">Port</th>
<th align="left">Protocol</th>
<th align="left">Remarks</th>
<th align="left">Announce URL</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left">tracker.mhm.dn42</td>
<td align="left">6969</td>
<td align="left">TCP &amp; UDP</td>
<td align="left">Opentracker</td>
<td align="left"><a href="http://tracker.mhm.dn42:6969/announce">http://tracker.mhm.dn42:6969/announce</a></td>
</tr>
<tr>
<td align="left">tracker.mhm.dn42</td>
<td align="left">80</td>
<td align="left">TCP &amp; UDP</td>
<td align="left">Opentracker</td>
<td align="left"><a href="http://tracker.mhm.dn42/announce">http://tracker.mhm.dn42/announce</a></td>
</tr>
</tbody>
</table>

<h2><a class="anchor" id="ntp" href="#ntp"></a>NTP</h2>

<table>
<thead>
<tr>
<th align="left">Hostname / IP</th>
<th align="left">Remarks</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left">ntp.e-utp.dn42 (172.22.165.50)</td>
<td align="left">Stratum 1, GPS+NMEA</td>
</tr>
<tr>
<td align="left">ntp1.nixnodes.dn42 (172.22.177.123)</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">ntp2.nixnodes.dn42 (172.22.177.124)</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">ntp.martin89.dn42</td>
<td align="left">more than one A records/server</td>
</tr>
<tr>
<td align="left">tick.gotroot.dn42 (172.20.14.247)</td>
<td align="left">Stratum 1, GPS, Vancouver Canada</td>
</tr>
<tr>
<td align="left">tock.gotroot.dn42 (172.20.14.250)</td>
<td align="left">Stratum 2, Anycast on each node</td>
</tr>
<tr>
<td align="left">ntp.yuetau.dn42 (172.21.68.50)</td>
<td align="left">Anycast on all node</td>
</tr>
</tbody>
</table>

<h2><a class="anchor" id="os-mirror-repository-s" href="#os-mirror-repository-s"></a>OS Mirror/Repository's</h2>

<p>Also check <a href="/services/Repository-Mirrors">Repository Mirrors</a></p>

<table>
<thead>
<tr>
<th align="left">Hostname / IP</th>
<th align="left">What's Available:</th>
<th align="left">Updates</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left"><a href="http://debian.trunet.dn42">http://debian.trunet.dn42</a></td>
<td align="left">Debian mirror</td>
<td align="left">Each 6 hours</td>
</tr>
<tr>
<td align="left"><a href="http://ubuntu.trunet.dn42">http://ubuntu.trunet.dn42</a></td>
<td align="left">Ubuntu releases mirror</td>
<td align="left">Each 4 hours</td>
</tr>
<tr>
<td align="left"><a href="http://archive.ubuntu.trunet.dn42">http://archive.ubuntu.trunet.dn42</a></td>
<td align="left">Ubuntu archive mirror</td>
<td align="left">Each 6 hours</td>
</tr>
<tr>
<td align="left"><a href="http://centos.trunet.dn42">http://centos.trunet.dn42</a></td>
<td align="left">CentOS mirror</td>
<td align="left">Each 6 hours</td>
</tr>
<tr>
<td align="left">
<del><a href="http://files.twink0r.dn42">http://files.twink0r.dn42</a></del>(OFFLINE 2016-08-24)</td>
<td align="left">Debian, Ubuntu</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">
<del><a href="http://freebsd.e-utp.dn42">http://freebsd.e-utp.dn42</a></del>(OFFLINE 2016-08-24)</td>
<td align="left">FreeBSD Homepage mirror</td>
<td align="left"></td>
</tr>
<tr>
<td align="left"><a href="http://mirrors.zhaofeng.dn42/archlinux">http://mirrors.zhaofeng.dn42/archlinux</a></td>
<td align="left">Arch Linux</td>
<td align="left">Every hour</td>
</tr>
</tbody>
</table>

<h3><a class="anchor" id="direct-connect" href="#direct-connect"></a>Direct Connect</h3>

<p>Some <a href="https://en.wikipedia.org/wiki/Advanced_Direct_Connect">Advanced Direct Connect</a> Hubs are being run DN42 internally. Choose a <a href="https://en.wikipedia.org/wiki/Comparison_of_ADC_software#Client_software">client</a> and connect to exchange files.</p>

<table>
<thead>
<tr>
<th align="left">Address</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left">adcs://hub.dcpp.dn42:1511</td>
</tr>
<tr>
<td align="left">dchub://hub.dcpp.dn42:2780</td>
</tr>
<tr>
<td align="left">dchub://dcpp.grmml.dn42:4111</td>
</tr>
</tbody>
</table>

<h2><a class="anchor" id="misc" href="#misc"></a>Misc</h2>

<table>
<thead>
<tr>
<th>Hostname / IP</th>
<th>Remarks</th>
</tr>
</thead>
<tbody>
<tr>
<td><a href="https://bin.dn42">https://bin.dn42</a></td>
<td>AES-encrypted pastebin-like service (<a href="https://github.com/sebsauvage/ZeroBin">zerobin</a>)</td>
</tr>
<tr>
<td><a href="http://pastebin.trunet.dn42">http://pastebin.trunet.dn42</a></td>
<td>AES-encrypted pastebin-like (<a href="https://github.com/sebsauvage/ZeroBin">zerobin</a>)</td>
</tr>
<tr>
<td><del><a href="http://zerobin.e-utp.dn42">http://zerobin.e-utp.dn42</a></del></td>
<td>AES-encrypted pastebin-like, second one (<a href="https://github.com/sebsauvage/ZeroBin">zerobin</a>)</td>
</tr>
<tr>
<td><a href="https://pad.dn42">https://pad.dn42</a></td>
<td>
<a href="http://etherpad.org">Etherpad</a> service for collaborative work</td>
</tr>
<tr>
<td><a href="http://ip.synhacx.dn42">http://ip.synhacx.dn42</a></td>
<td>Basic "whatismyip" service (<a href="http://synhacx.dn42/showmyip">description</a>)</td>
</tr>
<tr>
<td><a href="http://tor.e-utp.dn42">http://tor.e-utp.dn42</a></td>
<td>Tor Project Homepage mirror</td>
</tr>
<tr>
<td><a href="http://ngit.dn42">http://ngit.dn42</a></td>
<td></td>
</tr>
<tr>
<td>nntp://news.blacksheep.dn42</td>
<td>Martin's newsgroup server (ping MB-DN42 for a rw account or a nntp/uucp feed)</td>
</tr>
<tr>
<td>mumble://shard.smrsh.dn42:64738</td>
<td>
<a href="http://mumble.sourceforge.net/">Mumble</a> Voice Chat</td>
</tr>
<tr>
<td>ts3.kai-server.dn42 / ts3.fastnameserver.eu</td>
<td>Teamspeak 3 Server (also reachable over clearnet)</td>
</tr>
<tr>
<td><a href="https://whois.rest.dn42/">https://whois.rest.dn42/</a></td>
<td>whois restful API</td>
</tr>
<tr>
<td><a href="http://pgp.dn42">pgp.dn42</a></td>
<td>PGP keyserver, <a href="http://pgp.dn42/pks/lookup?op=stats">synchronizes</a> with the SKS keyservers</td>
</tr>
<tr>
<td><a href="https://git.dn42%5B.us%5D">https://git.dn42[.us]</a></td>
<td>Git Repository Hosting (Signup: email ssh pubkey to <a href="mailto:xuu@dn42.us">xuu@dn42.us</a>)</td>
</tr>
<tr>
<td><a href="https://git.dn42%5B.us%5D/pubkeys/%5Busername%5D">https://git.dn42[.us]/pubkeys/[username]</a></td>
<td>Get ssh public keys from Git Users of git.dn42.</td>
</tr>
<tr>
<td><a href="http://teams.dn42%5B.us%5D/dn42">http://teams.dn42[.us]/dn42</a></td>
<td>Mattermost (Slack clone) instance: get notifications for wiki/CA changes here</td>
</tr>
<tr>
<td><a href="http://nowhere.ws/dn42">http://nowhere.ws/dn42</a></td>
<td>Some random stuff concerning dn42, packages for Debian, e.g. Quagga</td>
</tr>
<tr>
<td><a href="https://paste.weiti.dn42">https://paste.weiti.dn42</a></td>
<td>AES-encrypted pastebin-like (privatebin)</td>
</tr>
<tr>
<td>
<a href="https://bbs.dn42">https://bbs.dn42</a>, <a href="https://dn42bbs.0b1.me">https://dn42bbs.0b1.me</a> via Clearnet</td>
<td>A general BBS powered by Flarum for virtually any topics. Maintained by nicholascw.</td>
</tr>
<tr>
<td><a href="http://jack.pyropeter.eu/dn42/routecount/">http://jack.pyropeter.eu/dn42/routecount/</a></td>
<td>Statistics about the number of v4/v6 routes seen by AS76115 (Since Aug. 2014)</td>
</tr>
<tr>
<td>
<a href="https://flapping.p2p-node.de/dashboard/">Clearnet</a>, <a href="https://flapping.bandura.dn42/dashboard">dn42</a>, <a href="https://flapping.bandura.neo/dashboard/">NeoNetwork</a>
</td>
<td>FlapAlertedPro by Kioubit hosted by mark22k</td>
</tr>
</tbody>
</table>

<h2><a class="anchor" id="gaming" href="#gaming"></a>Gaming</h2>

<table>
<thead>
<tr>
<th align="left">Hostname / IP</th>
<th align="left">Game</th>
<th align="left">Remarks</th>
</tr>
</thead>
<tbody>
<tr>
<td align="left">mc.nia.dn42 (172.20.168.137, fd01:1926:817:7::)</td>
<td align="left">Minecraft</td>
<td align="left">Latest Stable, Optimized for CN , Map available on mc-map.nia.dn42</td>
</tr>
<tr>
<td align="left">hulk.mhm.dn42 (172.23.67.1)</td>
<td align="left">Tetrinet</td>
<td align="left"></td>
</tr>
<tr>
<td align="left">ns1.deltaman.dn42 (172.22.134.131, fd1b:7f7d:dd55:4600:219:ff:fe00:fafe)</td>
<td align="left">OpenTTD</td>
<td align="left">1.10.3, Hosted in NL</td>
</tr>
<tr>
<td align="left">mc.nico.dn42</td>
<td align="left">Minecraft</td>
<td align="left">1.16.5, <a href="https://bbs.dn42/d/17-modded-116-minecraft-server">Forge Modded</a>, IPv4 &amp; IPv6, Central US Server</td>
</tr>
<tr>
<td align="left">mc.northrend.dn42 (172.20.222.240)</td>
<td align="left">Minecraft</td>
<td align="left">latest, IPv4 only</td>
</tr>
<tr>
<td align="left">redtrap.northrend.dn42 (172.20.222.252)</td>
<td align="left">Minecraft</td>
<td align="left">RedTrap DN42 Bridge, 1.8.8 - 1.19, IPv4 only</td>
</tr>
</tbody>
</table>

<h2><a class="anchor" id="dn42-freephone" href="#dn42-freephone"></a>DN42 FreePhone</h2>

<p>Somebody was providing a FreePhone <a href="/services/FreePhone">here</a></p>

<h2><a class="anchor" id="email-providers" href="#email-providers"></a>Email Providers</h2>

<p>There is a page for email Providers <a href="/services/E-Mail-Providers">here</a></p>

<h1><a class="anchor" id="other-networks" href="#other-networks"></a>Other Networks</h1>

<h2><a class="anchor" id="chaosvpn" href="#chaosvpn"></a>ChaosVPN</h2>

<ul>
<li>Anybody can add services to this list, which will be monitored for uptime: <a href="http://10.100.44.1">http://10.100.44.1</a>
</li>
<li>Check your IP and reverse lookup: <a href="http://ifconfig.hack">ifconfig.hack</a>
</li>
<li>View of the network: <a href="http://vpnhub1-intern.hamburg.ccc.de/chaosvpn.png">http://vpnhub1-intern.hamburg.ccc.de/chaosvpn.png</a>
</li>
<li>List of nodes: <a href="http://vpnhub1-intern.hamburg.ccc.de/chaosvpn.nodes.html">http://vpnhub1-intern.hamburg.ccc.de/chaosvpn.nodes.html</a>
</li>
</ul>

<h2><a class="anchor" id="freifunk" href="#freifunk"></a>Freifunk</h2>

<h3><a class="anchor" id="augsburg" href="#augsburg"></a>Augsburg</h3>

<p>We have a plugin that enables us to announce services in the mesh. So instead of listing them here again just have a look at <a href="http://10.11.0.8/cgi-bin/luci/freifunk/services">http://10.11.0.8/cgi-bin/luci/freifunk/services</a> to see what we have to offer.
(Upload is not fast, most probably DSL speed only)</p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
<li>
<p><a href="/Home" rel="nofollow">Home</a></p>

<ul>
<li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
<li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
<li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
<li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
<li><a href="/FAQ" rel="nofollow">FAQ</a></li>
</ul>
</li>
<li>
<p>How-To</p>

<ul>
<li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
<li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
<li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
<li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
<li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
<li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
<li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
<li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
<li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
<li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
<li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
<li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
<li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
<li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
<li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
<li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
<li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
<li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
</ul>
</li>
<li>
<p>Services</p>

<ul>
<li><a href="/services/IRC" rel="nofollow">IRC</a></li>
<li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
<li><a href="/services/DNS" rel="nofollow">DNS</a></li>
<li><a href="/services/IX-Collection" rel="nofollow">IX Collection</a></li>
<li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
<li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
<li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
<li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
<li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
<li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
<li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
</ul>
</li>
<li>
<p>Internal</p>

<ul>
<li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
<li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
<li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
<li>
<a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a><br />
</li>
<li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
</ul>
</li>
<li>
<p>Historical</p>

<ul>
<li><a href="/historical/Bird" rel="nofollow">Bird 1</a></li>
<li><a href="/historical/Quagga" rel="nofollow">Quagga</a></li>
</ul>
</li>
<li>
<p>External Tools</p>

<ul>
<li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
<li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
</ul>
</li>
</ul>

<hr />

	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a> | Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a></p>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="internal/Historical-Services.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/internal/Historical-Services.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
