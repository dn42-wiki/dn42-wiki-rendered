<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'internal/E-Mail-Providers.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>E-Mail-Providers</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>E-Mail-Providers</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/internal/E-Mail-Providers.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/internal/E-Mail-Providers.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    E-Mail-Providers
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/internal/">internal</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="e-mail-providers" href="#e-mail-providers"></a>E-mail Providers</h1>

<p><strong>X Mail by Bingxin.</strong></p>
<ul>
  <li>X Mail <a href="https://mail.x.dn42">https://mail.x.dn42</a>
    <ul>
      <li>Free, easy to sign up, and unlimited internal email system.</li>
      <li>Use the /email command on Telegram @baka_lg_bot to register an account.</li>
      <li>Or, Register at <a href="https://mail.x.dn42/email/">https://mail.x.dn42/email/</a>
</li>
      <li>Having issues with registration? Send an email to <a href="mailto:bingxin@x.dn42">bingxin@x.dn42</a> or <a href="mailto:bingxin@baka.pub">bingxin@baka.pub</a> for assistance.</li>
    </ul>
  </li>
</ul>

<p><strong>bMail by Buzzster.</strong></p>
<ul>
  <li>bMail <a href="https://mail.bmail.dn42">https://mail.bmail.dn42</a>
    <ul>
      <li>Free, easy and unlimited internal email system.</li>
      <li>Register at <a href="https://accounts.buzzster.dn42/register">https://accounts.buzzster.dn42/register</a>
</li>
    </ul>
  </li>
</ul>

<p><strong>Free E-Mail Addresses for DN42 Users.</strong></p>
<ul>
  <li>DN42 Mail, <a href="https://dmail.dn42">https://dmail.dn42</a>
    <ul>
      <li>Free, easy to sign up, unlimited internal emailing. Hosted by zane_reick</li>
      <li>Register at <a href="https://dmail.dn42/register/register.php">https://dmail.dn42/register/register.php</a>
</li>
    </ul>
  </li>
</ul>

<h3><a class="anchor" id="simplelogin-server" href="#simplelogin-server"></a>Simplelogin server:</h3>
<ul>
  <li>a selfhosted <a href="https://simplelogin.io/">Simplelogin</a> server for dn42.cc</li>
  <li>create aliases that forward to your real e-mail</li>
  <li>signup at <a href="https://simplelogin.dn42/auth/register">https://simplelogin.dn42/auth/register</a> with a clearnet e-mail address (dn42 mail addresses are for some reason not supported by simplelogin)
    <ul>
      <li>also available via <a href="https://sl.dn42.cc/">https://sl.dn42.cc/</a> (except signup)</li>
    </ul>
  </li>
  <li>for "lifetime premium" (more than 5 aliases + custom domains), if you want aliases for &lt;anything&gt;@&lt;your_mntner&gt;.dn42.cc or experience deliverability problems please send a mail to <a href="mailto:support@dn42.cc">support@dn42.cc</a> or <a href="mailto:lare@dn42.cc">lare@dn42.cc</a>
</li>
</ul>

<h1><a class="anchor" id="echo-test-services" href="#echo-test-services"></a>Echo test services</h1>
<ul>
  <li>If you have an E-Mail service and would like to test it's functionality, send an email to <a href="mailto:zane_reik@dmail.dn42">zane_reick@dmail.dn42</a>. You will get a response usually within a few hours.</li>
  <li>
<a href="https://deliverance.dn42/">Deliverance</a> provides automated deliverability analysis. It checks your DNS records, inspects email headers and runs your email through spam detection suites. This provides an overall deliverability score for your email service.</li>
</ul>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="internal/E-Mail-Providers.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/internal/E-Mail-Providers.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
