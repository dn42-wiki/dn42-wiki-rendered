<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'internal/Internal-Services.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Internal-Services</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Internal-Services</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/internal/Internal-Services.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/internal/Internal-Services.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Internal-Services
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/internal/">internal</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="internal-services" href="#internal-services"></a>Internal services</h1>

<p>You are asked to show some creativity in terms of network usage and content. ;)</p>

<h2><a class="anchor" id="search-engine" href="#search-engine"></a>Search engine</h2>

<p>There is a search engine at <a href="http://buzzster.dn42">buzzster.dn42</a> that can also be used to discover services and content. If you don't see your website, index it in the console.</p>

<p>A searx-ng instance is available at <a href="https://search.androw.dn42">search.androw.dn42</a> to search the clearnet.</p>

<h2><a class="anchor" id="certificate-authority" href="#certificate-authority"></a>Certificate Authority</h2>

<ul>
  <li>
    <p>xuu is maintaining a <a href="/services/Certificate-Authority">certificate authority</a> for internal services.</p>
  </li>
  <li>
    <p>Burble maintains an <a href="https://burble.dn42/services/acme/">ACME server</a> (with accompanying CA), compatible with any LetsEncrypt client like Certbot, Dehydrated or Caddy.</p>
  </li>
  <li>
    <p>Kioubit maintains a <a href="https://dn42.g-load.eu/about/certificate-authority/">certificate authority</a> with certificates obtainable via a simple script or completely <a href="https://dn42.g-load.eu/about/certificate-authority/oneclick/">using only the browser</a>.</p>
  </li>
</ul>

<h2><a class="anchor" id="network-related" href="#network-related"></a>Network-related</h2>

<ul>
  <li>See <a href="/services/Looking-Glasses">Looking Glasses</a> for more network diagnostic tools</li>
  <li>Realtime network map: <a href="https://map.dn42/">map.dn42</a> (DN42) or <a href="https://map.iedon.net">map.iedon.net</a> (via clearnet) <em>(This map currently uses MRT dumps from GRC as its source. It refreshes whenever the collector provides a new MRT file, generally every 10-15 minutes.)</em>
</li>
  <li>Network Information Service: <a href="https://bgp42.strexp.net">bgp42.strexp.net</a> (via IANA). Main functions include <em>network information</em>, <em>network map (from map.dn42, requires WebGL)</em>, <em>network ranking (based on centrality)</em>, <em>ROA alerting</em> and <em>path finder</em>.</li>
  <li>Yet Another network map: <a href="https://map.jerry.dn42/">map.jerry.dn42</a> (DN42) or <a href="https://map.meson.cc">map.meson.cc</a> (via clearnet) <em>(uses MRT dump as source, updated every 15 minutes.)</em>
</li>
  <li>Various DN42-related tools: <a href="https://dn42.g-load.eu/toolbox/">dn42.g-load.eu/toolbox/</a>
</li>
  <li>Cloudflare-like cdn-cgi/trace: <a href="https://map.jerry.dn42/cdn-cgi/trace">map.jerry.dn42/cdn-cgi/trace</a>
</li>
  <li>Another Cloudflare-like cdn-cgi/trace: <a href="https://buzzster.dn42/cdn-cgi/trace">buzzster.dn42/cdn-cgi/trace</a>
</li>
  <li>New DNS System monitoring: <a href="https://grafana.burble.com/d/E4iCaHoWk/dn42-dns-status?orgId=1&amp;refresh=1m">grafana.burble.com/d/E4iCaHoWk/dn42-dns-status</a>
</li>
  <li>whatsmyip:
    <ul>
      <li>ipv4+ipv6: <a href="http://myip.dn42/">myip.dn42</a>
</li>
      <li>ipv4 only: <a href="http://v4.myip.dn42/">v4.myip.dn42</a> or <a href="http://172.20.0.81">172.20.0.81</a>
</li>
      <li>ipv6 only: <a href="http://v6.myip.dn42/">v6.myip.dn42</a> or <a href="http://[fd42:d42:d42:81::1]/">fd42:d42:d42:81::1</a>
</li>
      <li>API endpoints:
        <ul>
          <li>/raw: return your IP address as plain text</li>
          <li>/api: JSON with your IP plus the details of the server you reached (location, ASN, etc.)</li>
        </ul>
      </li>
      <li>with geolocation provided by <a href="https://github.com/Xe-iu/dn42-geoip">DN42-Geoip</a> and autonomous system info provided by <a href="https://github.com/rdp-studio/dn42-geoasn">DN42-GeoASN</a>: <a href="https://myip.launchpadx.dn42">myip.launchpadx.dn42</a>
        <ul>
          <li>Geolocation API
            <ul>
              <li>API endpoints:
                <ul>
                  <li>IPv4: v4.myip.launchpadx.dn42</li>
                  <li>IPv6: v6.myip.launchpadx.dn42</li>
                  <li>Dual-stack: api.myip.launchpadx.dn42</li>
                </ul>
              </li>
              <li><a href="https://github.com/Xe-iu/dn42-geoip/blob/main/api/README.md">API documentation</a></li>
            </ul>
          </li>
          <li>ASN API
            <ul>
              <li>API endpoints:
                <ul>
                  <li>IPv4: asn4.myip.launchpadx.dn42</li>
                  <li>IPv6: asn6.myip.launchpadx.dn42</li>
                  <li>Dual-stack: asn.myip.launchpadx.dn42</li>
                </ul>
              </li>
            </ul>
          </li>
        </ul>
      </li>
      <li>
<a href="http://myip.buzzster.dn42">myip.buzzster.dn42</a>
        <ul>
          <li>API endpoint:
            <ul>
              <li>IPv4 and IPv6: myip.buzzster.dn42/api/ip</li>
            </ul>
          </li>
        </ul>
      </li>
      <li>
<a href="http://whatismyip.dn42">whatismyip.dn42</a>
        <ul>
          <li>API endpoint:
            <ul>
              <li>IPv4: <a href="http://ipv4.whatismyip.dn42:8080/ipinfo">http://ipv4.whatismyip.dn42:8080/ipinfo</a>
</li>
              <li>IPv6: <a href="http://ipv6.whatismyip.dn42:8080/ipinfo">http://ipv6.whatismyip.dn42:8080/ipinfo</a>
</li>
            </ul>
          </li>
        </ul>
      </li>
    </ul>
  </li>
  <li>Route Graphs: <a href="http://routegraphs.highdef.dn42">routegraphs.highdef.dn42</a> (DN42), <a href="https://routegraphs.highdef.network">routegraphs.highdef.network</a> (clearnet) - graph reachability from ASes to specific prefixes, using data from the dn42 GRC</li>
  <li>BGP flap detector (FlapAlerted by Kioubit) hosted by AS4242422092: <a href="https://flaps.pebkac.dn42">flaps.pebkac.dn42</a>
</li>
</ul>

<h3><a class="anchor" id="speedtest" href="#speedtest"></a>Speedtest</h3>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Operator</th>
      <th style="text-align:left;">Location</th>
      <th style="text-align:left;">Max Speed</th>
      <th>Link</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">Burble</td>
      <td style="text-align:left;">Anycast</td>
      <td style="text-align:left;">Unknown</td>
      <td><a href="https://speedtest.burble.dn42/">speedtest.burble.dn42</a></td>
    </tr>
    <tr>
      <td style="text-align:left;">Kioubit</td>
      <td style="text-align:left;">Nuremberg, Germany</td>
      <td style="text-align:left;">400 Mbps</td>
      <td><a href="https://kioubit.dn42/speedtest/">kioubit.dn42/speedtest/</a></td>
    </tr>
    <tr>
      <td style="text-align:left;">Routedbits</td>
      <td style="text-align:left;">Multiple</td>
      <td style="text-align:left;">Unknown</td>
      <td><a href="https://dn42.routedbits.io/nodes">dn42.routedbits.io/nodes</a></td>
    </tr>
    <tr>
      <td style="text-align:left;">vr18</td>
      <td style="text-align:left;">Unknown</td>
      <td style="text-align:left;">100/20 Mbps</td>
      <td><a href="http://speed.vr18.dn42/">speed.vr18.dn42/</a></td>
    </tr>
    <tr>
      <td style="text-align:left;">NOT-MNT</td>
      <td style="text-align:left;">Athens</td>
      <td style="text-align:left;">500/1000Mbps</td>
      <td><a href="https://speedtest.not.dn42/">speedtest.not.dn42/</a></td>
    </tr>
    <tr>
      <td style="text-align:left;">Gensokyo</td>
      <td style="text-align:left;">Wuhan, China</td>
      <td style="text-align:left;">U:50Mbps/D:1Gbps</td>
      <td><a href="https://speed.gensokyo.dn42">speed.gensokyo.dn42</a></td>
    </tr>
  </tbody>
</table>

<h3><a class="anchor" id="map-dn42-api-services" href="#map-dn42-api-services"></a>Map.dn42 API Services</h3>

<p>Data refreshes whenever the collector provides a new MRT file, generally every 10-15 minutes.</p>

<table>
  <thead>
    <tr>
      <th>API</th>
      <th>URL</th>
      <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><code>/map</code></td>
      <td>
<a href="https://map.dn42/map">https://map.dn42/map</a> <br /> <a href="https://api.iedon.com/dn42/map">https://api.iedon.com/dn42/map</a>
</td>
      <td>Raw binary map data</td>
    </tr>
    <tr>
      <td><code>/map?type=json</code></td>
      <td>
<a href="https://map.dn42/map?type=json">https://map.dn42/map?type=json</a> <br /> <a href="https://api.iedon.com/dn42/map?type=json">https://api.iedon.com/dn42/map?type=json</a>
</td>
      <td>Raw map data, in JSON</td>
    </tr>
    <tr>
      <td><code>/asn/{asn}</code></td>
      <td>
<a href="https://map.dn42/asn/4242422189">https://map.dn42/asn/4242422189</a> <br /> <a href="https://api.iedon.com/dn42/asn/4242422189">https://api.iedon.com/dn42/asn/4242422189</a>
</td>
      <td>Real-time node information from the map, including WHOIS data, in JSON</td>
    </tr>
    <tr>
      <td><code>/ranking</code></td>
      <td>
<a href="https://map.dn42/ranking">https://map.dn42/ranking</a> <br /> <a href="https://api.iedon.com/dn42/ranking">https://api.iedon.com/dn42/ranking</a>
</td>
      <td>DN42 Global Ranking, based on the map.dn42 index</td>
    </tr>
    <tr>
      <td><code>/myip/[raw｜api]</code></td>
      <td>
<a href="https://map.dn42/myip/">https://map.dn42/myip/</a> <br /> <a href="https://map.dn42/myip/api">https://map.dn42/myip/api</a> <br /> <a href="https://map.dn42/myip/raw">https://map.dn42/myip/raw</a>
</td>
      <td>What's My IP instance by map.dn42, including <code>netname</code> and <code>country</code> information if available</td>
    </tr>
  </tbody>
</table>

<h3><a class="anchor" id="ix-services" href="#ix-services"></a>IX Services</h3>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Name</th>
      <th style="text-align:left;">Wiki Page</th>
      <th style="text-align:left;">AS Number</th>
      <th style="text-align:left;">Related Link(s)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">IXP-frnte</td>
      <td style="text-align:left;"><a href="/services/IXP-frnte">IXP-frnte</a></td>
      <td style="text-align:left;">4242421081</td>
      <td style="text-align:left;">N/A</td>
    </tr>
    <tr>
      <td style="text-align:left;">mcast-ix</td>
      <td style="text-align:left;"><a href="/services/mcast-ix">mcast-ix</a></td>
      <td style="text-align:left;">4242421951</td>
      <td style="text-align:left;">N/A</td>
    </tr>
    <tr>
      <td style="text-align:left;">SERNET-IX</td>
      <td style="text-align:left;"><a href="/services/SERNET-IX">SERNET-IX</a></td>
      <td style="text-align:left;">4242422245</td>
      <td style="text-align:left;"><a href="https://blog.sherpherd.top/ix">SERNET-IX</a></td>
    </tr>
  </tbody>
</table>

<h3><a class="anchor" id="asn-authentication-solution" href="#asn-authentication-solution"></a>ASN Authentication Solution</h3>

<p>Authenticate your users by having them verify their ASN ownership with KIOUBIT-MNT using their registry-provided methods in an automated way. An example of this is the automatic peering system for the Kioubit Network. <a href="https://dn42.g-load.eu/about/authentication-services/">Documentation</a></p>

<h2><a class="anchor" id="irc" href="#irc"></a>IRC</h2>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Hostname / IP</th>
      <th style="text-align:left;">SSL</th>
      <th style="text-align:left;">Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">irc.hackint.dn42</td>
      <td style="text-align:left;">Yes</td>
      <td style="text-align:left;">DN42</td>
    </tr>
    <tr>
      <td style="text-align:left;">irc.hackint.hack/dn42</td>
      <td style="text-align:left;">Yes</td>
      <td style="text-align:left;">ChaosVPN</td>
    </tr>
    <tr>
      <td style="text-align:left;">irc.dn42</td>
      <td style="text-align:left;">Yes</td>
      <td style="text-align:left;">Internal IRC</td>
    </tr>
    <tr>
      <td style="text-align:left;">irc.ty3r0x.dn42</td>
      <td style="text-align:left;">Yes</td>
      <td style="text-align:left;">BonoboNET (ty3r0x.bnet)</td>
    </tr>
    <tr>
      <td style="text-align:left;">irc.catgirls.dn42</td>
      <td style="text-align:left;">Yes</td>
      <td style="text-align:left;">Karx IRC, clearnet karx.xyz/6697, dn42 v6 only</td>
    </tr>
    <tr>
      <td style="text-align:left;">irc.replirc.dn42</td>
      <td style="text-align:left;">Yes</td>
      <td style="text-align:left;">ReplIRC (started in 2022 on Replit (but no longer uses Replit), uses Solanum for servers), self-signed certificates</td>
    </tr>
  </tbody>
</table>

<h3><a class="anchor" id="clients" href="#clients"></a>Clients</h3>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Hostname / IP</th>
      <th style="text-align:left;">Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;"><a href="https://lounge.burble.dn42">https://lounge.burble.dn42</a></td>
      <td style="text-align:left;">
<a href="https://thelounge.chat/">thelounge</a> for lurking on #dn42, see <a href="https://dn42.burble.com/services/internal/#loungeburbledn42">burble.dn42 services</a>.</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://irc.pebkac.dn42">https://irc.pebkac.dn42</a></td>
      <td style="text-align:left;">
<a href="https://thelounge.chat/">thelounge</a> for lurking on #dn42, ask TOMKAP-DN42 for an account</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="images-e-books-videos-and-other-media" href="#images-e-books-videos-and-other-media"></a>Images, E-Books, Videos and other Media</h2>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Hostname / IP</th>
      <th style="text-align:left;">Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;"><a href="http://j.munsternet.dn42">http://j.munsternet.dn42</a></td>
      <td style="text-align:left;">Jellyfin instance with movies and TV shows (test).</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://e621ng.dn42">https://e621ng.dn42</a></td>
      <td style="text-align:left;">Just e621ng, contains bunch of nsfw</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="radio-and-video-streaming" href="#radio-and-video-streaming"></a>Radio and Video Streaming</h2>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Hostname / IP</th>
      <th style="text-align:left;">Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;"><a href="https://live.jerry.dn42/">https://live.jerry.dn42/</a></td>
      <td style="text-align:left;">Live audio stream powered by mpd</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://radio.vr18.dn42/">http://radio.vr18.dn42/</a></td>
      <td style="text-align:left;">Online radio by vr18</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://dn42:dn42@tv.munsternet.dn42/playlist">https://dn42:dn42@tv.munsternet.dn42/playlist</a></td>
      <td style="text-align:left;">TV Channels Streaming</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://icy.jones.dn42">http://icy.jones.dn42</a></td>
      <td style="text-align:left;">Homegrown Icecast Radio covering a number of genres (HLS &amp; Player coming soon [ish]!)</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://radio.vrpnet.dn42">https://radio.vrpnet.dn42</a></td>
      <td style="text-align:left;">Online radio by Pi3rrot on VRPNET, using Icecast&amp;Liquidsoap</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://webdj.nop.dn42/">http://webdj.nop.dn42/</a></td>
      <td style="text-align:left;">controller for Multicast stream: rtp://172.23.199.110@232.2.3.2:1234/</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://sdr.pebkac.dn42/">https://sdr.pebkac.dn42/</a></td>
      <td style="text-align:left;">OpenWebRX SDR Receiver, FM/VHF/UHF Analog &amp; Digital (ask TOMKAP-DN42 for an account)</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://adsb.androw.dn42/">https://adsb.androw.dn42/</a></td>
      <td style="text-align:left;">ADS-B Receiver located in Paris</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://kz.dn42:8888/6MusicProxy/index.m3u8">http://kz.dn42:8888/6MusicProxy/index.m3u8</a></td>
      <td style="text-align:left;">BBC Radio 6 Music Proxy service (320kbps AAC streams over HLS)</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://live.yobanirot.dn42">https://live.yobanirot.dn42</a></td>
      <td style="text-align:left;">RTMP(s)\RTSP\HLS server, can handle FullHD h264 stream!</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="file-sharing" href="#file-sharing"></a>File Sharing</h2>

<h3><a class="anchor" id="ftp-http" href="#ftp-http"></a>FTP / HTTP</h3>

<p><strong>FIXME</strong>: Please add info about (approximate) bandwidth of the servers.</p>

<p>Repository Mirrors are listed on another page: <a href="/services/Repository-Mirrors">Repository Mirrors</a></p>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Hostname / IP</th>
      <th>Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;"><a href="http://files.nop.dn42">http://files.nop.dn42</a></td>
      <td>download only, max 1Mbit/s</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://rfc-editor.dn42">http://rfc-editor.dn42</a></td>
      <td>download only, max 1Mbit/s</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://freertr.dn42/">http://freertr.dn42/</a></td>
      <td>freeRouter main site</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://sources.nop.dn42">http://sources.nop.dn42</a></td>
      <td>freeRouter source tree</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://rtros.nop.dn42/">http://rtros.nop.dn42/</a></td>
      <td>freeRouter distribution</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="vpn" href="#vpn"></a>VPN</h2>

<p>DN42 Network Access over Automatic Wireguard VPN Service (IPv6 only, fd00::/8)
provided by TheQ at <a href="https://dn42.0011.de/vpnusers">https://dn42.0011.de/vpnusers</a></p>

<h2><a class="anchor" id="proxies" href="#proxies"></a>Proxies</h2>

<p>See <a href="http://wiki.hamburg.ccc.de/ChaosVPN:Proxy">http://wiki.hamburg.ccc.de/ChaosVPN:Proxy</a></p>

<h3><a class="anchor" id="telegram" href="#telegram"></a>Telegram</h3>

<p>A DN42 private Telegram app and server is available at <a href="https://buzzgram.dn42">buzzgram.dn42</a>, the app requires a new registration (Official Telegram account isn't valid), only support IPv6 at the moment.</p>

<h4><a class="anchor" id="mtproxy" href="#mtproxy"></a>MTProxy</h4>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">IP</th>
      <th style="text-align:left;">Secret</th>
      <th style="text-align:left;">Provider</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;"><a href="https://t.me/proxy?server=mtp.jerry.dn42&amp;port=8044&amp;secret=ee1419944c0a129dbba2beb2636fcf361a616e64726f69642e676f6f676c65736f757263652e636f6d">mtp.jerry.dn42:8044</a></td>
      <td style="text-align:left;"><code>ee1419944c0a129dbba2beb2636fcf361a616e64726f69642e676f6f676c65736f757263652e636f6d</code></td>
      <td style="text-align:left;">JERRY-MNT</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://t.me/proxy?server=172.20.54.58&amp;port=8101&amp;secret=de5ba4a48126705a60add5e1cacbbd4b">172.20.54.58:8101</a></td>
      <td style="text-align:left;"><code>de5ba4a48126705a60add5e1cacbbd4b</code></td>
      <td style="text-align:left;">LAUNCHPAD-MNT</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="ntp" href="#ntp"></a>NTP</h2>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Hostname / IP</th>
      <th style="text-align:left;">Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">*.burble.dn42</td>
      <td style="text-align:left;">All burble.dn42 nodes provide NTP over clearnet and DN42. See also <a href="https://dn42.burble.com/services/public/">burble.dn42 public services</a>
</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="gaming" href="#gaming"></a>Gaming</h2>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Hostname / IP</th>
      <th style="text-align:left;">Game</th>
      <th style="text-align:left;">Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">172.20.210.193</td>
      <td style="text-align:left;">Minecraft</td>
      <td style="text-align:left;">Vanilla Server - latest(1.21.4)</td>
    </tr>
    <tr>
      <td style="text-align:left;">mc.jerry.dn42 &amp; jerry.dn42</td>
      <td style="text-align:left;">Minecraft</td>
      <td style="text-align:left;">latest, IPv4 &amp; IPv6</td>
    </tr>
    <tr>
      <td style="text-align:left;">mc.razu.neo (formerly mc.razuritta.dn42)</td>
      <td style="text-align:left;">Minecraft</td>
      <td style="text-align:left;">latest(1.20.4 atm), IPv4+IPv6</td>
    </tr>
    <tr>
      <td style="text-align:left;">mc.licen777.dn42 (172.23.197.197 &amp; fde8:2e18:e127::300)</td>
      <td style="text-align:left;">Minecraft</td>
      <td style="text-align:left;">1.16.5-1.21.5, (/gm 1, Cracked)</td>
    </tr>
    <tr>
      <td style="text-align:left;">ttd.jerry.dn42</td>
      <td style="text-align:left;">OpenTTD</td>
      <td style="text-align:left;">latest, IPv4 &amp; IPv6</td>
    </tr>
    <tr>
      <td style="text-align:left;">stk.jerry.dn42:2759, stk.jerry.neo:2759</td>
      <td style="text-align:left;">SuperTuxKart</td>
      <td style="text-align:left;">latest, IPv4 only</td>
    </tr>
    <tr>
      <td style="text-align:left;">stk2.jerry.dn42:2759, stk2.jerry.neo:2759</td>
      <td style="text-align:left;">SuperTuxKart</td>
      <td style="text-align:left;">latest, IPv4 &amp; IPv6</td>
    </tr>
    <tr>
      <td style="text-align:left;">factorio.catgirls.dn42 (IPv6 only)</td>
      <td style="text-align:left;">factorio</td>
      <td style="text-align:left;">Still in testing, expect downtime</td>
    </tr>
    <tr>
      <td style="text-align:left;">The burble.dn42 shell servers include a number of classic text games, see <a href="https://dn42.burble.com/services/shell/#classic-games">shell access</a>
</td>
      <td style="text-align:left;">Various</td>
      <td style="text-align:left;">Log in to the shell servers for more</td>
    </tr>
    <tr>
      <td style="text-align:left;">telnet tetris.dn42</td>
      <td style="text-align:left;">tetris in your terminal</td>
      <td style="text-align:left;">other games available on request, ping mc36 @ irc</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="https://clicker.burble.dn42/">https://clicker.burble.dn42/</a></td>
      <td style="text-align:left;">Clicker/Idle</td>
      <td style="text-align:left;">Waste your time away with a dn42-themed browser-based idle game</td>
    </tr>
    <tr>
      <td style="text-align:left;">
<a href="https://monkic.mk16.de/">monkic.mk16.de</a>, <a href="https://monkic.bandura.dn42/">dn42</a>
</td>
      <td style="text-align:left;">Monkic (Game in German)</td>
      <td style="text-align:left;"> </td>
    </tr>
    <tr>
      <td style="text-align:left;">yobanirot.dn42:7591</td>
      <td style="text-align:left;">Minecraft and Minetest</td>
      <td style="text-align:left;">One more "tech" minecraft server, mods <a href="http://yobanirot.dn42/mods.zip">here</a>
</td>
    </tr>
    <tr>
      <td style="text-align:left;">yobanirot.dn42:27015</td>
      <td style="text-align:left;">CS 1.6</td>
      <td style="text-align:left;"> </td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://taiko.furry.dn42">http://taiko.furry.dn42/</a></td>
      <td style="text-align:left;">Taiko Web</td>
      <td style="text-align:left;"> </td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="voice-chat" href="#voice-chat"></a>Voice chat</h2>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Hostname / IP</th>
      <th style="text-align:left;">Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">mumble://ty3r0x.dn42:64738</td>
      <td style="text-align:left;">Ty3r0X's Lair (men's club)</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="voip-sip-endpoints" href="#voip-sip-endpoints"></a>VOIP/SIP Endpoints</h2>

<ul>
  <li>burble.dn42 runs an <a href="https://dn42.burble.com/services/public/#voip">asterisk based VOIP service</a> with various test extensions and real hardware modems for dialing in to dn42</li>
  <li>jerry.dn42 also runs an <a href="https://blog.jerry.dn42/dn42#Services_pbx">asterisk based VOIP service</a> with live radio (see live.jerry.dn42 above), whois service, conference room and software modems for dialing in to dn42</li>
  <li>buzzster.dn42 runs an asterisk based VOIP service with shorts numbers, inbound and outbound calls and live radio. Request your short number on <a href="https://t.me/KevvoGeek">KevvoGeek Telegram</a> for make and receive internal and external calls.</li>
  <li>gensokyo.dn42 runs an asterisk based VOIP service with fax modems, CallerID playback and PSTN to DN42 proxy gateway (+1 424 242 9915).</li>
</ul>

<h2><a class="anchor" id="challenges" href="#challenges"></a>Challenges</h2>

<p>Test out your skills with online challenges</p>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Start here</th>
      <th style="text-align:left;">Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;"><a href="https://burble.dn42/services/ping/">https://burble.dn42/services/ping/</a></td>
      <td style="text-align:left;">burble.dn42 ping challenge</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://kioubit.dn42/challenge/ch1/">http://kioubit.dn42/challenge/ch1/</a></td>
      <td style="text-align:left;">Kioubit.dn42 challenge 1</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="http://kioubit.dn42/challenge/ch2/">http://kioubit.dn42/challenge/ch2/</a></td>
      <td style="text-align:left;">Kioubit.dn42 challenge 2</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="shell" href="#shell"></a>Shell</h2>

<p>Providers of shell access:</p>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Person</th>
      <th style="text-align:left;">Hostname</th>
      <th style="text-align:left;">Net</th>
      <th style="text-align:left;">Description</th>
      <th style="text-align:left;">Contact</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">mc36</td>
      <td style="text-align:left;"><code>telnet test.nop.dn42</code></td>
      <td style="text-align:left;">dn42 only</td>
      <td style="text-align:left;">looking glass</td>
      <td style="text-align:left;">-</td>
    </tr>
    <tr>
      <td style="text-align:left;">JerryXiao</td>
      <td style="text-align:left;"><code>ssh lg@lg.jerry.dn42</code></td>
      <td style="text-align:left;">dn42 and icvpn</td>
      <td style="text-align:left;">looking glass</td>
      <td style="text-align:left;">-</td>
    </tr>
    <tr>
      <td style="text-align:left;">burble</td>
      <td style="text-align:left;">
<code>ssh &lt;mntner&gt;@shell.fr-rbx1.burble.dn42</code> <br /> <code>ssh &lt;mntner&gt;@shell.ca-bhs2.burble.dn42</code>
</td>
      <td style="text-align:left;">dn42</td>
      <td style="text-align:left;">Full shell account</td>
      <td style="text-align:left;">See below</td>
    </tr>
  </tbody>
</table>

<h3><a class="anchor" id="burble-dn42-shell-access" href="#burble-dn42-shell-access"></a>burble.dn42 shell access</h3>

<p>Full shell accounts are available for all dn42 users. Usernames are
constructed using the MNTNER name, lowercased and without the '-MNT' suffix. SSH public keys are imported automatically from the registry or alternatively, a password can be used instead.</p>

<p>See also the <a href="https://dn42.burble.com/services/shell/">burble.dn42 website</a> for more details.</p>

<h2><a class="anchor" id="personal-network-blogs-websites" href="#personal-network-blogs-websites"></a>Personal/network/blogs websites</h2>

<table>
  <thead>
    <tr>
      <th>Website</th>
      <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><a href="https://burble.dn42/">https://burble.dn42/</a></td>
      <td>burble.dn42 website</td>
    </tr>
    <tr>
      <td><a href="http://www.marlinc.dn42/">http://www.marlinc.dn42/</a></td>
      <td>Marlinc website</td>
    </tr>
    <tr>
      <td><a href="http://vr18.dn42/">http://vr18.dn42/</a></td>
      <td>vr18.dn42 website</td>
    </tr>
    <tr>
      <td><a href="https://mk16de.bandura.dn42/">https://mk16de.bandura.dn42/</a></td>
      <td>Marek's site</td>
    </tr>
    <tr>
      <td><a href="http://blog.sherpherd.dn42/">http://blog.sherpherd.dn42/</a></td>
      <td>Hawkins' Homepage</td>
    </tr>
    <tr>
      <td><a href="https://20plays.dn42/">https://20plays.dn42/</a></td>
      <td>20plays' website</td>
    </tr>
    <tr>
      <td><a href="https://mdr.dn42/">https://mdr.dn42/</a></td>
      <td>Mark Dastmalchi-Round's website (clearnet mirror)</td>
    </tr>
    <tr>
      <td><a href="https://yobanirot.dn42">https://yobanirot.dn42</a></td>
      <td>NAAIN's website</td>
    </tr>
    <tr>
      <td><a href="https://darkpoint.dn42">https://darkpoint.dn42</a></td>
      <td>AS4242420150 Darkpoint website</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="pastebins" href="#pastebins"></a>Pastebins</h2>

<table>
  <thead>
    <tr>
      <th>Hostname / IP</th>
      <th>Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><a href="http://paste.nop.dn42">http://paste.nop.dn42</a></td>
      <td>yet another paste service</td>
    </tr>
    <tr>
      <td><a href="https://p.pebkac.dn42/">https://p.pebkac.dn42/</a></td>
      <td>PasteBin Service (Netcat/Bash CLI Client)</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="forums-message-boards" href="#forums-message-boards"></a>Forums / Message boards</h2>

<table>
  <thead>
    <tr>
      <th>Hostname / IP</th>
      <th>Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><a href="https://urandom.catgirls.dn42/">https://urandom.catgirls.dn42/</a></td>
      <td>Message board</td>
    </tr>
  </tbody>
  <tbody>
    <tr>
      <td>
<a href="https://bbs.nicholascw.dn42">https://bbs.nicholascw.dn42</a>, <a href="https://dn42bbs.0b1.me">https://dn42bbs.0b1.me</a> via Clearnet</td>
      <td>A general BBS powered by Flarum for virtually any topic. Maintained by nicholascw. Previously under bbs.dn42.</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="misc" href="#misc"></a>Misc</h2>

<table>
  <thead>
    <tr>
      <th>Hostname / IP</th>
      <th>Remarks</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>
<a href="http://wiki.dn42">http://wiki.dn42</a>, <a href="http://internal.dn42">http://internal.dn42</a>
</td>
      <td>This wiki! Git Repo hosted on git.dn42</td>
    </tr>
    <tr>
      <td><a href="http://www.nop.dn42/">http://www.nop.dn42/</a></td>
      <td>Basic "whatismyip" service</td>
    </tr>
    <tr>
      <td><a href="http://fun.nop.dn42/">http://fun.nop.dn42/</a></td>
      <td>some funny images and videos</td>
    </tr>
    <tr>
      <td><a href="http://pvrp.nop.dn42/">http://pvrp.nop.dn42/</a></td>
      <td>a path vector igp main site</td>
    </tr>
    <tr>
      <td><a href="http://lsrp.nop.dn42">http://lsrp.nop.dn42</a></td>
      <td>a link state igp main site</td>
    </tr>
    <tr>
      <td><a href="http://hwp0rn.nop.dn42">http://hwp0rn.nop.dn42</a></td>
      <td>girls with switches and routers, a hwpr0n.se mirror</td>
    </tr>
    <tr>
      <td><a href="http://ix.nop.dn42">http://ix.nop.dn42</a></td>
      <td>mcast-ix main site</td>
    </tr>
    <tr>
      <td><a href="http://mpls.dn42/">http://mpls.dn42/</a></td>
      <td>a brief description of MPLS technology</td>
    </tr>
    <tr>
      <td><a href="http://it.vr18.dn42/">http://it.vr18.dn42/</a></td>
      <td>handy tools for developers</td>
    </tr>
    <tr>
      <td><a href="https://ntfy.weil-isso.dn42">https://ntfy.weil-isso.dn42</a></td>
      <td>NTFY (Push Notify via REST-API)</td>
    </tr>
    <tr>
      <td>kms.weil-isso.dn42 (Port 1688)</td>
      <td>Key Management Server (with Auto-Activation) for any Windows/Office (LAB AND TEST Purposes only)</td>
    </tr>
    <tr>
      <td>anycast.zookeeper.immibis.dn42 (port 2181)</td>
      <td>Apache Zookeeper cluster (requires a client certificate for access - on request)</td>
    </tr>
    <tr>
      <td><a href="https://coin.m724.dn42">https://coin.m724.dn42</a></td>
      <td>Cryptocurrency</td>
    </tr>
    <tr>
      <td><a href="https://mempool.dn42">https://mempool.dn42</a></td>
      <td>Bitcoin explorer</td>
    </tr>
    <tr>
      <td><a href="http://whatismyip.dn42/">http://whatismyip.dn42/</a></td>
      <td>dn42 IPv4 and IPv6 whatismyip service</td>
    </tr>
    <tr>
      <td><a href="https://keyserver.nia.dn42">https://keyserver.nia.dn42</a></td>
      <td>Hockeypuck OpenPGP Server</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="usenet-servers-news" href="#usenet-servers-news"></a>Usenet Servers / News</h2>

<p>There are some News Servers available <a href="/services/News">here</a></p>

<h2><a class="anchor" id="e-mail" href="#e-mail"></a>E-Mail</h2>

<p>There is a list of E-Mail providers <a href="/services/E-Mail-Providers">here</a></p>

<h1><a class="anchor" id="other-networks" href="#other-networks"></a>Other networks</h1>

<p><strong><a href="/Other">List of other Overlay Networks</a></strong></p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="internal/Internal-Services.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/internal/Internal-Services.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
