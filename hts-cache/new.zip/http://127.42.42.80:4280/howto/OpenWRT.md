<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/OpenWRT.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>OpenWRT</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>OpenWRT</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/OpenWRT.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/OpenWRT.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    OpenWRT
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="dn42-on-openwrt" href="#dn42-on-openwrt"></a>dn42 on OpenWRT</h1>

<p>This page gives hints on how to participate to dn42 with an OpenWRT router. It assumes Attitude Adjustment (12.09), but you can adapt it for other versions.</p>

<p>The intended target is a home router, acting as the default gateway for its LAN clients. The goal is to have one or more dn42 peers, announce the LAN subnet with BGP, and thus transparently provide dn42 access to the LAN clients.</p>

<p>This documentation assumes that the LAN is addressed in the dn42 space (<code>172.22.0.0/15</code>), but it's not a big deal to add NAT if it's not.</p>

<h2><a class="anchor" id="initial-configuration" href="#initial-configuration"></a>Initial configuration</h2>

<h2><a class="anchor" id="peerings" href="#peerings"></a>Peerings</h2>

<p>Nothing fancy: use GRE tunnels, openvpn, anything. Don't forget to install the relevant packages with <code>opkg</code> (<code>kmod-gre</code> for instance).</p>

<p>You can't manage GRE tunnels with OpenWRT, so just create them in <code>/etc/rc.local</code> (and assign addresses if needed).</p>

<h2><a class="anchor" id="bgp" href="#bgp"></a>BGP</h2>

<p><code>quagga</code> and <code>bird</code> are both packaged in OpenWRT. Note that quagga is split in many packages, you probably need <code>quagga-bgpd</code>, <code>quagga-vtysh</code> and <code>quagga-zebra</code>.</p>

<p>Of course, you should announce the prefix of your home network.</p>

<h2><a class="anchor" id="interface-definition" href="#interface-definition"></a>Interface definition</h2>

<p>This is needed so that OpenWRT is aware of the new interfaces (for firewall and stuff).</p>

<p>In <code>/etc/config/network</code>, add entries for each dn42 interface:</p>

<pre class="highlight"><code><span class="n">config</span> <span class="n">interface</span> <span class="n">dn42peer1</span>
    <span class="n">option</span> <span class="n">ifname</span> <span class="n">tun</span>-<span class="n">peer1</span>
    <span class="n">option</span> <span class="n">proto</span> <span class="n">none</span></code></pre>

<h2><a class="anchor" id="firewall" href="#firewall"></a>Firewall</h2>

<p>There are two goals:</p>

<ul>
  <li>Allowing traffic from LAN to dn42 (and maybe from dn42 to LAN too)</li>
  <li>If you have more than one peer, allowing traffic from dn42 to dn42 (forwarding)</li>
</ul>

<p>Everything is done in <code>/etc/config/firewall</code>.</p>

<h3><a class="anchor" id="zone-declaration" href="#zone-declaration"></a>Zone declaration</h3>

<pre class="highlight"><code><span class="n">config</span> <span class="n">zone</span>
    <span class="n">option</span> <span class="n">name</span>             <span class="n">dn42</span>
    <span class="n">option</span> <span class="n">network</span>          <span class="s1">'dn42peer1 dn42peer2 dn42peer3'</span>
    <span class="n">option</span> <span class="n">input</span>            <span class="n">REJECT</span>
    <span class="n">option</span> <span class="n">output</span>           <span class="n">ACCEPT</span>
    <span class="n">option</span> <span class="n">forward</span>          <span class="n">REJECT</span></code></pre>

<p>If you need to NAT your home network into dn42, you probably just need to add:</p>

<pre class="highlight"><code><span class="n">option</span> <span class="n">masq</span>             <span class="m">1</span></code></pre>

<h3><a class="anchor" id="dn42-lan-forwarding" href="#dn42-lan-forwarding"></a>dn42 ↔ LAN forwarding</h3>

<pre class="highlight"><code><span class="n">config</span> <span class="n">forwarding</span>                   
    <span class="n">option</span> <span class="n">src</span>              <span class="n">lan</span>
    <span class="n">option</span> <span class="n">dest</span>             <span class="n">dn42</span></code></pre>

<p>If you're confident enough, you can also forward dn42 into your LAN:</p>

<pre class="highlight"><code><span class="n">config</span> <span class="n">forwarding</span>                   
    <span class="n">option</span> <span class="n">src</span>              <span class="n">dn42</span>
    <span class="n">option</span> <span class="n">dest</span>             <span class="n">lan</span></code></pre>

<p>Or you can forward only certain ports, to certain hosts, etc (standard <code>config rule</code> stuff)</p>

<h3><a class="anchor" id="dn42-dn42-forwarding" href="#dn42-dn42-forwarding"></a>dn42 ↔ dn42 forwarding</h3>

<p>This is more tricky. In theory, all you have to do is to set</p>

<pre class="highlight"><code><span class="n">option</span> <span class="n">forward</span>          <span class="n">ACCEPT</span></code></pre>

<p>in the definition of the zone. However, due to a bug in Attitude Adjustment (see <a href="https://dev.openwrt.org/ticket/12945">https://dev.openwrt.org/ticket/12945</a>), this will allow forwarding <strong>everything everywhere</strong>.</p>

<p>You have to use this patch: <a href="https://dev.openwrt.org/changeset/35484">https://dev.openwrt.org/changeset/35484</a> (monkeypatching the relevant files in <code>/lib</code> should work).</p>

<h2><a class="anchor" id="dns" href="#dns"></a>DNS</h2>

<p>See <a href="/services/dns/Configuration">DNS Configuration</a>. This will use the anycast dn42 DNS server to resolve <code>dn42</code> and relevant reverse domains.</p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="https://iedon.net/post/24" rel="nofollow">IEDON-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:sess@sess.dn42" rel="nofollow">SESS-MNT</a>, <a href="mailto:nedifinita@ik.me" rel="nofollow">NEDIFINITA-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.jp/" rel="nofollow">dn42.jp</a> (wiki-go), <a href="https://dn42.net/" rel="nofollow">dn42.net</a>, <a href="https://dn42.li/" rel="nofollow">dn42.li</a> (wiki-go), <a href="https://dn42.app/" rel="nofollow">dn42.app</a>
</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/OpenWRT.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/OpenWRT.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
