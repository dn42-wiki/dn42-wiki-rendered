<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-309be032396e783b13a47df58f389b7c8e11c2b2d42640560b874f677c25f6e5.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">

  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/Quagga.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-f05401ee374f0c7f48fc2bc08e30b4f4db705861fd5895ed70998683b383bfb5.js" type="text/javascript"></script>
  

  <title>Quagga</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Quagga</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/Quagga.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <a class="btn btn-sm" id="minibutton-home" href="/">
      Home
    </a>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/overview"
          id="minibutton-overview"
        >
          Overview
        </a>

        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/latest_changes"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </a>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          href="/gollum/history/howto/Quagga.md/"
          id="minibutton-history"
        >
          History
        </a>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Quagga
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="quagga" href="#quagga"></a>Quagga</h1>

<p>Quagga is probably one of the oldest software router around.  It still works, of course, even though it has an unattractive configuration syntax (unfortunately inspired by  <a href="/howto/IPsecWithPublicKeys/CiscoIOSExample">Cisco's IOS</a>) and has some small issues with IPv6.  But since it's so old, you will find a lot of configuration examples around.</p>

<h2><a class="anchor" id="source-address-selection" href="#source-address-selection"></a>Source address selection</h2>

<p>Use this in your <code>zebra.conf</code>:</p>

<pre class="highlight"><code><span class="n">route</span>-<span class="n">map</span> <span class="n">RM_SET_SRC</span> <span class="n">permit</span> <span class="m">10</span>
    <span class="n">set</span> <span class="n">src</span> <span class="m">172</span>.<span class="m">22</span>.<span class="n">XX</span>.<span class="n">XX</span>
<span class="n">ip</span> <span class="n">protocol</span> <span class="n">bgp</span> <span class="n">route</span>-<span class="n">map</span> <span class="n">RM_SET_SRC</span></code></pre>

<p>Unfortunately, this is not possible with IPv6...</p>

<h2><a class="anchor" id="important-bgp-commands" href="#important-bgp-commands"></a>Important bgp commands</h2>

<p>To connect to bgpd use:</p>

<pre class="highlight"><code><span class="nv">$ </span>vtysh</code></pre>

<p>Which provides an interactive interface.
In this interface '?' can be used to list the available commands or subcommands.</p>

<h2><a class="anchor" id="configure-quagga" href="#configure-quagga"></a>Configure Quagga</h2>

<p>a minimal config would look like this:</p>

<pre class="highlight"><code>vtysh&gt; configure terminal
vtysh<span class="o">(</span>config<span class="o">)&gt;</span> router bgp &lt;your-asn&gt;
vtysh<span class="o">(</span>config-router<span class="o">)&gt;</span> neighbor &lt;neighbor-ip&gt; remote-as &lt;neighbor-asn&gt;
vtysh<span class="o">(</span>config-router<span class="o">)&gt;</span> neighbor &lt;neighbor-ip&gt; interface &lt;interface&gt;
vtysh<span class="o">(</span>config-router<span class="o">)&gt;</span> <span class="nb">exit
</span>vtysh<span class="o">(</span>config<span class="o">)&gt;</span> <span class="nb">exit</span></code></pre>

<h3><a class="anchor" id="ipv6" href="#ipv6"></a>IPv6</h3>

<p>for IPv6 do something like</p>

<pre class="highlight"><code>vtysh&gt; configure terminal
vtysh<span class="o">(</span>config<span class="o">)&gt;</span> router bgp &lt;your-asn&gt;
vtysh<span class="o">(</span>config-router<span class="o">)&gt;</span> neighbor &lt;neighbor-ip&gt; remote-as &lt;neighbor-asn&gt;
vtysh<span class="o">(</span>config-router<span class="o">)&gt;</span> neighbor &lt;neighbor-ip&gt; interface &lt;interface&gt;
vtysh<span class="o">(</span>config-router<span class="o">)&gt;</span> no neighbor &lt;neighbor-ip&gt; activate
vtysh<span class="o">(</span>config-router<span class="o">)&gt;</span> address-family ipv6
vtysh<span class="o">(</span>config-router-af<span class="o">)&gt;</span> neighbor &lt;neighbor-ip&gt; activate
vtysh<span class="o">(</span>config-router-af<span class="o">)&gt;</span> <span class="nb">exit
</span>vtysh<span class="o">(</span>config-router<span class="o">)&gt;</span> <span class="nb">exit
</span>vtysh<span class="o">(</span>config<span class="o">)&gt;</span> <span class="nb">exit</span></code></pre>

<h3><a class="anchor" id="peer-groups-prefix-lists-and-such" href="#peer-groups-prefix-lists-and-such"></a>peer groups, prefix lists and such</h3>

<p>If you want to use 'prefix-list' to filter some of the prefixes quagga is receiving, you can use a 'peer-group' instead of apply the prefix list to every neighbor. </p>

<p>Define a peer group:</p>

<pre class="highlight"><code>vtysh<span class="o">(</span>config-router<span class="o">)&gt;</span> neighbor &lt;peer-group-name&gt; peer-group</code></pre>

<p>Apply to a neighbor:</p>

<pre class="highlight"><code>vtysh<span class="o">(</span>config-router<span class="o">)&gt;</span> neighbor &lt;neighbor-ip&gt; peer-group &lt;name&gt;</code></pre>

<p>Apply a prefix list for incoming prefixes to your peer group:</p>

<pre class="highlight"><code>vtysh<span class="o">(</span>config-router<span class="o">)&gt;</span> neighbor &lt;peer-group-name&gt; prefix-list &lt;prefix-list-name&gt; <span class="k">in</span></code></pre>

<h4><a class="anchor" id="example-filter-list" href="#example-filter-list"></a>Example filter list</h4>

<pre class="highlight"><code>ip prefix-list vpn-in description BGP IPv4 import filter
<span class="o">!</span>old network:
ip prefix-list vpn-in <span class="nb">seq </span>5 permit 172.22.0.0/15 ge 22 le 28
<span class="o">!</span>new dn42 allocation:
ip prefix-list vpn-in <span class="nb">seq </span>10 permit 172.20.0.0/16 ge 22 le 28

<span class="o">!</span> Anycast /32s <span class="k">for </span>Whois and DNS:
ip prefix-list vpn-in <span class="nb">seq </span>11 permit 172.22.0.43/32
ip prefix-list vpn-in <span class="nb">seq </span>12 permit 172.22.0.53/32

ip prefix-list vpn-in <span class="nb">seq </span>18 permit 192.175.48.0/24
ip prefix-list vpn-in <span class="nb">seq </span>20 deny 10.10.10.0/24
ip prefix-list vpn-in <span class="nb">seq </span>21 permit 10.0.0.0/8
ip prefix-list vpn-in <span class="nb">seq </span>30 permit 172.31.0.0/16
ip prefix-list vpn-in <span class="nb">seq </span>39 permit 100.64.0.0/10
ip prefix-list vpn-in <span class="nb">seq </span>40 permit 195.160.168.0/23
ip prefix-list vpn-in <span class="nb">seq </span>41 permit 91.204.4.0/22
ip prefix-list vpn-in <span class="nb">seq </span>43 permit 193.43.220.0/23
ip prefix-list vpn-in <span class="nb">seq </span>46 permit 83.133.178.0/23
ip prefix-list vpn-in <span class="nb">seq </span>47 permit 87.106.29.254/32
ip prefix-list vpn-in <span class="nb">seq </span>50 permit 85.25.246.16/28
ip prefix-list vpn-in <span class="nb">seq </span>51 permit 46.4.248.192/27
ip prefix-list vpn-in <span class="nb">seq </span>60 permit 94.45.224.0/19
ip prefix-list vpn-in <span class="nb">seq </span>70 permit 195.191.196.0/23
ip prefix-list vpn-in <span class="nb">seq </span>80 permit 80.244.241.224/27
ip prefix-list vpn-in <span class="nb">seq </span>90 permit 46.19.90.48/28
ip prefix-list vpn-in <span class="nb">seq </span>91 permit 46.19.90.96/28
ip prefix-list vpn-in <span class="nb">seq </span>110 permit 188.40.34.241/32
ip prefix-list vpn-in <span class="nb">seq </span>130 permit 37.1.89.192/26
ip prefix-list vpn-in <span class="nb">seq </span>140 permit 178.33.32.123/32
ip prefix-list vpn-in <span class="nb">seq </span>150 permit 87.98.246.19/32
ip prefix-list vpn-in <span class="nb">seq </span>1000 deny 0.0.0.0/0

ipv6 prefix-list vpn-in <span class="nb">seq </span>10 permit fd00::/8 ge 9
ipv6 prefix-list vpn-in <span class="nb">seq </span>15 deny any</code></pre>

<h4><a class="anchor" id="example-filter-list-script" href="#example-filter-list-script"></a>Example filter list script</h4>

<pre class="highlight"><code><span class="c">#!/bin/bash</span>

vtysh <span class="nt">-c</span> <span class="s1">'conf t'</span> <span class="nt">-c</span> <span class="s2">"no ip prefix-list dn42"</span><span class="p">;</span> <span class="c">#drop old prefix list</span>

<span class="k">while </span><span class="nb">read </span>pl
<span class="k">do
   </span>vtysh <span class="nt">-c</span> <span class="s1">'conf t'</span> <span class="nt">-c</span> <span class="s2">"</span><span class="nv">$pl</span><span class="s2">"</span><span class="p">;</span> <span class="c">#insert prefix list row by row</span>
<span class="k">done</span> &lt; &lt;<span class="o">(</span>curl <span class="nt">-s</span> https://ca.dn42.us/reg/filter.txt | <span class="nb">grep</span> <span class="nt">-e</span>  ^[0-9] | <span class="nb">awk</span> <span class="s1">'{ print "ip prefix-list dn42 seq " $1 " " $2 " " $3 " ge " $4 " le " $5}'</span> | <span class="nb">sed</span> <span class="s2">"s_/</span><span class="se">\(</span><span class="s2">[0-9]</span><span class="se">\+\)</span><span class="s2"> ge </span><span class="se">\1</span><span class="s2">_/</span><span class="se">\1</span><span class="s2">_g;s_/</span><span class="se">\(</span><span class="s2">[0-9]</span><span class="se">\+\)</span><span class="s2"> le </span><span class="se">\1</span><span class="s2">_/</span><span class="se">\1</span><span class="s2">_g"</span><span class="o">)</span><span class="p">;</span>
vtysh <span class="nt">-c</span> <span class="s2">"wr"</span> <span class="c">#write new prefix list</span>
</code></pre>

<h2><a class="anchor" id="show-bpg-session-status" href="#show-bpg-session-status"></a>show bpg session status</h2>

<p>in this example:</p>

<ul>
<li>an active bgp session exists with peer 64713.</li>
<li>no (vpn) connection at all exists with peer 64692</li>
<li>a (vpn) connection with 4242421375 exists, but no bgp session</li>
</ul>

<pre class="highlight"><code>vtysh&gt; show ip bgp summary 
BGP router identifier 172.22.100.254, local AS number 64698
RIB entries 938, using 103 KiB of memory
Peers 11, using 49 KiB of memory
Peer groups 1, using 32 bytes of memory

Neighbor        V    AS MsgRcvd MsgSent   TblVer  InQ OutQ Up/Down  State/PfxRcd
172.22.92.247   4 64692       0       0        0    0    0 never    Connect
...
172.22.113.2    4 64713    2206     865        0    0    0 01:23:11      322
....
172.23.64.1     4 4242421375  0       0        0    0    0 never    Active
fe80::deca:fbad 4 64699     902     694        0    0    0 01:23:57      486</code></pre>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
<li>
<p><a href="/Home" rel="nofollow">Home</a></p>

<ul>
<li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
<li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
<li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
<li><a href="/howto/Bird-communities" rel="nofollow">BGP communities</a></li>
<li><a href="/FAQ" rel="nofollow">FAQ</a></li>
</ul>
</li>
<li>
<p>How-To</p>

<ul>
<li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
<li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
<li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
<li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
<li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
<li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
<li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
<li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
<li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
<li>
<a href="/howto/Bird" rel="nofollow">Bird</a> / <a href="/howto/Bird2" rel="nofollow">Bird2</a>
</li>
<li><a href="/howto/Quagga" rel="nofollow">Quagga</a></li>
<li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
<li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
<li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
<li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
<li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
<li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
<li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
<li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
</ul>
</li>
<li>
<p>Services</p>

<ul>
<li><a href="/services/IRC" rel="nofollow">IRC</a></li>
<li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
<li><a href="/services/DNS" rel="nofollow">DNS</a></li>
<li><a href="/services/IX2" rel="nofollow">IX</a></li>
<li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
<li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
<li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
<li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
<li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
<li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
<li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
</ul>
</li>
<li>
<p>Internal</p>

<ul>
<li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
<li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
<li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
<li>
<a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a><br />
</li>
<li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
</ul>
</li>
<li>
<p>External Tools</p>

<ul>
<li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
<li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
</ul>
</li>
</ul>

<hr />

	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p>Hosted by: <a href="mailto:xuu@sour.is" rel="nofollow">xuu</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">nurtic-vibe</a>, <a href="mailto:tom@xcv.vc" rel="nofollow">toBee</a>, <a href="mailto:dn42@burble.com" rel="nofollow">burble</a> | Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a></p>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/Quagga.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/Quagga.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
