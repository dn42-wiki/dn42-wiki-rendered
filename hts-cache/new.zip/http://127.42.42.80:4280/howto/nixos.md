<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/nixos.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>nixos</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>nixos</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/nixos.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/nixos.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    nixos
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="nixos" href="#nixos"></a>NixOS</h1>

<p>NixOS is a declarative Linux distribution based on the Nix package Manager. In this post I'll explain how I set up dn42 in this environment. I currently only peer with wireguard and use bird2. NixOS uses configuration files to manage the system state and has a builtin container module.</p>

<h2><a class="anchor" id="container-disclaimer" href="#container-disclaimer"></a>container disclaimer</h2>

<p>I had a spare IPv4 Address so I decided to use a container without a NAT and keep my host "clean" from dn42 Wireguard Interfaces and IP routes. However it's painful to debug since nixos-rebuild restarts the container on every minor change. So every time you change a firewall rule or debug a DNS setting nixos-rebuild restarts the container before the change takes effect and since BGP is BGP, it can be really frustrating.</p>

<p>You may also want to have a look at this <a href="https://github.com/NixOS/nixpkgs/issues/43652">Issue</a> and <a href="https://github.com/NixOS/nixpkgs/pull/80169">Pull Request</a></p>

<p>If you still want to give it a try, here you'll find some inspiration from my setup. You can also use some of these nix expression in a non-container environment.</p>

<h2><a class="anchor" id="building-the-container" href="#building-the-container"></a>Building the container</h2>

<p>Defining the container environment is the base part of the setup. Beginning with network setup, Private Network disables the passthrough of Host Interfaces into the container and adds a bridged Interface to the host default Interface (e.g. eth0). The localAddress is the container side address and the hostAddress is the one the Host gets. Inside the <code>container.&lt;name&gt;.config</code>, you can basicly import the same nix expression as from the Host and don't need to add some special container parts.</p>

<pre class="highlight"><code><span class="nv">containers</span><span class="o">.</span><span class="nv">dn42</span> <span class="o">=</span> <span class="p">{</span>
    <span class="nv">hostAddress</span> <span class="o">=</span> <span class="s2">"192.168.254.1"</span><span class="p">;</span> <span class="c"># Transfer Network</span>
    <span class="nv">hostAddress6</span> <span class="o">=</span> <span class="s2">"2001:db08::42"</span><span class="p">;</span> <span class="c"># Transfer Network</span>
    <span class="nv">localAddress</span> <span class="o">=</span> <span class="s2">"116.203.1.5"</span><span class="p">;</span>
    <span class="nv">localAddress6</span> <span class="o">=</span> <span class="s2">"2a01:4f8:c0c:4f7a::2/128"</span><span class="p">;</span>
    <span class="nv">privateNetwork</span> <span class="o">=</span> <span class="kc">true</span><span class="p">;</span>
    <span class="nv">autoStart</span> <span class="o">=</span> <span class="kc">true</span><span class="p">;</span>

    <span class="nv">config</span> <span class="o">=</span> <span class="p">{</span> <span class="nv">config</span><span class="p">,</span> <span class="nv">pkgs</span><span class="p">,</span> <span class="o">...</span> <span class="p">}:</span> <span class="p">{</span>
        <span class="nv">imports</span> <span class="o">=</span> <span class="p">[</span>
            <span class="sx">./peers</span> <span class="c"># Folder with a config for every Peer</span>
            <span class="sx">./dns.nix</span> <span class="c"># Bind with the litschi.dn42 zone delegated</span>
            <span class="sx">./bird.nix</span> <span class="c"># Bird config for BGP Routing</span>
            <span class="sx">./networking.nix</span> <span class="c"># Static Network configuration (with firewall)</span>
            <span class="sx">./nginx.nix</span> <span class="c"># nginx config for litschi.dn42</span>
        <span class="p">];</span>
        <span class="nv">environment</span><span class="o">.</span><span class="nv">systemPackages</span> <span class="o">=</span> <span class="kn">with</span> <span class="nv">pkgs</span><span class="p">;</span> <span class="p">[</span> 
            <span class="c"># Network debug tools</span>
            <span class="nv">dnsutils</span>
            <span class="nv">mtr</span>
            <span class="nv">tcpdump</span>
            <span class="nv">wireguard-tools</span>
        <span class="p">];</span>
    <span class="p">}</span>
<span class="p">}</span></code></pre>

<p>In theory the container should now be starting and you can get shell access  with <code>sudo nixos-container root-login &lt;name&gt;</code>.</p>

<p>I mounted some host paths into the container for dns zone files and static homepage since the container is the only one providing .dn42 webservers.</p>

<pre class="highlight"><code><span class="nv">containers</span><span class="o">.</span><span class="nv">dn42</span> <span class="o">=</span> <span class="p">{</span>
    <span class="nv">bindMounts</span> <span class="o">=</span> <span class="p">{</span>
        <span class="s2">"/var/www/dn42"</span> <span class="o">=</span> <span class="p">{</span>
            <span class="nv">hostPath</span> <span class="o">=</span> <span class="s2">"/var/www/dn42"</span><span class="p">;</span>
            <span class="nv">isReadOnly</span> <span class="o">=</span> <span class="kc">true</span><span class="p">;</span>
            <span class="nv">mountPoint</span> <span class="o">=</span> <span class="s2">"/var/www/dn42"</span><span class="p">;</span>
        <span class="p">};</span>
        <span class="s2">"/var/dns/dn42"</span> <span class="o">=</span> <span class="p">{</span>
            <span class="nv">hostPath</span> <span class="o">=</span> <span class="s2">"/var/dns/dn42"</span><span class="p">;</span>
            <span class="nv">isReadOnly</span> <span class="o">=</span> <span class="kc">true</span><span class="p">;</span>
            <span class="nv">mountPoint</span> <span class="o">=</span> <span class="s2">"/var/dns"</span><span class="p">;</span>
        <span class="p">};</span>
    <span class="p">};</span>
<span class="p">}</span></code></pre>

<h3><a class="anchor" id="network-setup" href="#network-setup"></a>Network Setup</h3>

<p>As mentioned above, I got a spare public IPv4 Address, but by adding it as <code>localAddress</code>, the container Part is configured static enough. But to forward traffic between Interfaces the following <code>/proc/sys/net/</code> parameters should be configured:</p>

<pre class="highlight"><code><span class="nv">boot</span><span class="o">.</span><span class="nv">kernel</span><span class="o">.</span><span class="nv">sysctl</span> <span class="o">=</span> <span class="p">{</span>
    <span class="s2">"net.ipv4.ip_forward"</span> <span class="o">=</span> <span class="mi">1</span><span class="p">;</span>
    <span class="s2">"net.ipv6.conf.all.forwarding"</span> <span class="o">=</span> <span class="mi">1</span><span class="p">;</span>
<span class="p">};</span></code></pre>
This allows our firewall to configure forwarding between peers and other tunnels. What is allowed to be forwarded can be configured in the firewall. Ferm has only few NixOS Options, but is pretty basic. It's configured with the <code>services.ferm.config</code> option, that contains just a string. Within this string there's standard plain ferm config. Example config is attached below.
If the dn42 address is not bound at any other Interface, you need to add it to the lo Interface to use it as source IP when routing via peers with dedicated transfer net. 
<pre class="highlight"><code><span class="nv">networking</span><span class="o">.</span><span class="nv">interfaces</span><span class="o">.</span><span class="nv">lo</span> <span class="o">=</span> <span class="p">{</span>
    <span class="nv">ipv4</span><span class="o">.</span><span class="nv">addresses</span> <span class="o">=</span> <span class="p">[</span>
        <span class="p">{</span>
            <span class="nv">address</span> <span class="o">=</span> <span class="s2">"172.23.73.65"</span><span class="p">;</span>
            <span class="nv">prefixLength</span> <span class="o">=</span> <span class="mi">32</span><span class="p">;</span>
        <span class="p">}</span>
    <span class="p">];</span>
    <span class="nv">ipv6</span><span class="o">.</span><span class="nv">addresses</span> <span class="o">=</span> <span class="p">[</span>
        <span class="p">{</span>
            <span class="nv">address</span> <span class="o">=</span> <span class="s2">"fd67:24bd:a1ea::1"</span><span class="p">;</span>
            <span class="nv">prefixLength</span> <span class="o">=</span> <span class="mi">128</span><span class="p">;</span>
        <span class="p">}</span>
    <span class="p">];</span>
<span class="p">};</span></code></pre>

<h4><a class="anchor" id="ferm-example" href="#ferm-example"></a>Ferm example</h4>
<pre class="highlight"><code><span class="nv">services</span><span class="o">.</span><span class="nv">ferm</span> <span class="o">=</span> <span class="p">{</span>
    <span class="nv">enable</span> <span class="o">=</span> <span class="kc">true</span><span class="p">;</span>
    <span class="nv">config</span> <span class="o">=</span> <span class="s2">''</span><span class="err">
</span><span class="s2">        domain ip table filter chain INPUT proto icmp ACCEPT;</span><span class="err">
</span><span class="s2">        domain ip6 table filter chain INPUT proto (ipv6-icmp icmp) ACCEPT;</span><span class="err">
</span><span class="s2">        domain (ip ip6) table filter {</span><span class="err">
</span><span class="s2">            chain INPUT {</span><span class="err">
</span><span class="s2">                policy DROP;</span><span class="err">
</span><span class="s2">                interface lo ACCEPT;</span><span class="err">
</span><span class="s2">                interface intern-+ ACCEPT;</span><span class="err">
</span><span class="s2">                # website</span><span class="err">
</span><span class="s2">                proto tcp dport (http https) ACCEPT;</span><span class="err">
</span><span class="s2">                # wireguard</span><span class="err">
</span><span class="s2">                proto udp dport ( &lt;Wireguard Ports&gt; ) ACCEPT;</span><span class="err">
</span><span class="s2">                # bgp</span><span class="err">
</span><span class="s2">                proto tcp dport (179) ACCEPT;</span><span class="err">
</span><span class="s2">                # dns</span><span class="err">
</span><span class="s2">                proto (udp tcp) dport domain ACCEPT;</span><span class="err">
</span><span class="s2">                mod state state (INVALID) DROP;</span><span class="err">
</span><span class="s2">                mod state state (ESTABLISHED RELATED) ACCEPT;</span><span class="err">
</span><span class="s2">            }</span><span class="err">
</span><span class="s2">            chain OUTPUT {</span><span class="err">
</span><span class="s2">                policy ACCEPT;</span><span class="err">
</span><span class="s2">            }</span><span class="err">
</span><span class="s2">            chain FORWARD {</span><span class="err">
</span><span class="s2">                policy DROP;</span><span class="err">
</span><span class="s2">                # allow intern routing and dn42 forwarding</span><span class="err">
</span><span class="s2">                interface dn42-+ outerface dn42-+ ACCEPT;</span><span class="err">
</span><span class="s2">                interface intern-+ outerface intern-+ ACCEPT;</span><span class="err">
</span><span class="s2">                interface intern-+ outerface dn42-+ ACCEPT;</span><span class="err">
</span><span class="s2">                # but dn42 -&gt; intern only with execptions</span><span class="err">
</span><span class="s2">                interface dn42-+ outerface intern-+ {</span><span class="err">
</span><span class="s2">                    proto (ipv6-icmp icmp) ACCEPT;</span><span class="err">
</span><span class="s2">                    proto tcp dport (ssh) ACCEPT; # Allow SSH Access from dn42 to devices behind intern-+ Interfaces</span><span class="err">
</span><span class="s2">                    mod state state (ESTABLISHED) ACCEPT;</span><span class="err">
</span><span class="s2">                }</span><span class="err">
</span><span class="s2">            }</span><span class="err">
</span><span class="s2">        }</span><span class="err">
</span><span class="s2">    ''</span><span class="p">;</span>
<span class="p">};</span></code></pre>

<h3><a class="anchor" id="peering-with-wireguard" href="#peering-with-wireguard"></a>Peering with wireguard</h3>

<p>As explained above, every peer gets a dedicated wireguard Interface and so a dedicated file. In the container config folder there's a peer subfolder and within a folder for dn42- (extern) Peers and intern- configs e.g. my Home Router or mobile devices.</p>

<p>A sample wireguard config may look like this:
</p><pre class="highlight"><code><span class="p">{</span><span class="nv">config</span><span class="p">,</span> <span class="nv">pkgs</span><span class="p">,</span> <span class="o">...</span><span class="p">}:</span>
<span class="p">{</span>
    <span class="nv">networking</span><span class="o">.</span><span class="nv">wireguard</span><span class="o">.</span><span class="nv">interfaces</span><span class="o">.</span><span class="nv">dn42-peer</span> <span class="o">=</span> <span class="p">{</span>
        <span class="nv">privateKey</span> <span class="o">=</span> <span class="s2">""</span><span class="p">;</span>
        <span class="nv">allowedIPsAsRoutes</span> <span class="o">=</span> <span class="kc">false</span><span class="p">;</span>
        <span class="nv">listenPort</span> <span class="o">=</span> <span class="mi">42420</span><span class="p">;</span>

        <span class="nv">peers</span> <span class="o">=</span> <span class="p">[</span>
            <span class="p">{</span>
                <span class="nv">publicKey</span> <span class="o">=</span> <span class="s2">""</span><span class="p">;</span>
                <span class="nv">allowedIPs</span> <span class="o">=</span> <span class="p">[</span> <span class="s2">"0.0.0.0/0"</span> <span class="s2">"::/0"</span> <span class="p">];</span>
                <span class="nv">endpoint</span> <span class="o">=</span> <span class="s2">"42.42.42.42:42421"</span><span class="p">;</span>
            <span class="p">}</span>
        <span class="p">];</span>
        <span class="nv">postSetup</span> <span class="o">=</span> <span class="s2">''</span><span class="err">
</span><span class="s2">            </span><span class="si">${</span><span class="nv">pkgs</span><span class="o">.</span><span class="nv">iproute</span><span class="si">}</span><span class="s2">/bin/ip addr add 169.254.0.1/32 peer 169.254.0.0/32 dev dn42-peer</span><span class="err">
</span><span class="s2">            </span><span class="si">${</span><span class="nv">pkgs</span><span class="o">.</span><span class="nv">iproute</span><span class="si">}</span><span class="s2">/bin/ip -6 addr add fe80::1220/64 dev dn42-peer</span><span class="err">
</span><span class="s2">        ''</span><span class="p">;</span>
    <span class="p">};</span>
<span class="p">}</span></code></pre>

<p>As seen, the IP configuration is applied via ip-commands in the postSetup. This kinda works but isn't a fancy solution. There's room for improvements e.g. configuring static addresses and routes with networkd.</p>

<h3><a class="anchor" id="bgp-routing-with-bird2" href="#bgp-routing-with-bird2"></a>BGP Routing with bird2</h3>

<p>Like ferm, Bird2 is configured by <code>services.bird2.config</code> containing a string. In there the example bird2 config from <a href="/howto/Bird2">wiki.dn42</a> can be imported. Roa tables can be generated or downloaded from host providing them.</p>

<h4><a class="anchor" id="roa-updating-script" href="#roa-updating-script"></a>ROA Updating script</h4>

<p>Sample example to update ROA's : 
</p><pre class="highlight"><code><span class="p">{</span> <span class="nv">pkgs</span><span class="p">,</span> <span class="nv">lib</span><span class="p">,</span> <span class="o">...</span> <span class="p">}:</span>
<span class="kd">let</span> <span class="nv">script</span> <span class="o">=</span> <span class="nv">pkgs</span><span class="o">.</span><span class="nv">writeShellScriptBin</span> <span class="s2">"update-roa"</span> <span class="s2">''</span><span class="err">
</span><span class="s2">    mkdir -p /etc/bird/</span><span class="err">
</span><span class="s2">    </span><span class="si">${</span><span class="nv">pkgs</span><span class="o">.</span><span class="nv">curl</span><span class="si">}</span><span class="s2">/bin/curl -sfSLR {-o,-z}/etc/bird/roa_dn42_v6.conf https://dn42.burble.com/roa/dn42_roa_bird2_6.conf</span><span class="err">
</span><span class="s2">    </span><span class="si">${</span><span class="nv">pkgs</span><span class="o">.</span><span class="nv">curl</span><span class="si">}</span><span class="s2">/bin/curl -sfSLR {-o,-z}/etc/bird/roa_dn42.conf https://dn42.burble.com/roa/dn42_roa_bird2_4.conf</span><span class="err">
</span><span class="s2">    </span><span class="si">${</span><span class="nv">pkgs</span><span class="o">.</span><span class="nv">bird2</span><span class="si">}</span><span class="s2">/bin/birdc c </span><span class="err">
</span><span class="s2">    </span><span class="si">${</span><span class="nv">pkgs</span><span class="o">.</span><span class="nv">bird2</span><span class="si">}</span><span class="s2">/bin/birdc reload in all</span><span class="err">
</span><span class="s2">    ''</span><span class="p">;</span>
<span class="kn">in</span>
<span class="p">{</span>
    <span class="nv">systemd</span><span class="o">.</span><span class="nv">timers</span><span class="o">.</span><span class="nv">dn42-roa</span> <span class="o">=</span> <span class="p">{</span>
        <span class="nv">description</span> <span class="o">=</span> <span class="s2">"Trigger a ROA table update"</span><span class="p">;</span>

        <span class="nv">timerConfig</span> <span class="o">=</span> <span class="p">{</span>
            <span class="nv">OnBootSec</span> <span class="o">=</span> <span class="s2">"5m"</span><span class="p">;</span>
            <span class="nv">OnUnitInactiveSec</span> <span class="o">=</span> <span class="s2">"1h"</span><span class="p">;</span>
            <span class="nv">Unit</span> <span class="o">=</span> <span class="s2">"dn42-roa.service"</span><span class="p">;</span>
        <span class="p">};</span>

        <span class="nv">wantedBy</span> <span class="o">=</span> <span class="p">[</span> <span class="s2">"timers.target"</span> <span class="p">];</span>
        <span class="nv">before</span> <span class="o">=</span> <span class="p">[</span> <span class="s2">"bird.service"</span> <span class="p">];</span>
    <span class="p">};</span>

    <span class="nv">systemd</span><span class="o">.</span><span class="nv">services</span> <span class="o">=</span> <span class="p">{</span>
        <span class="nv">dn42-roa</span> <span class="o">=</span> <span class="p">{</span>
            <span class="nv">after</span> <span class="o">=</span> <span class="p">[</span> <span class="s2">"network.target"</span> <span class="p">];</span>
            <span class="nv">description</span> <span class="o">=</span> <span class="s2">"DN42 ROA Updated"</span><span class="p">;</span>
            <span class="nv">unitConfig</span> <span class="o">=</span> <span class="p">{</span>
                <span class="nv">Type</span> <span class="o">=</span> <span class="s2">"one-shot"</span><span class="p">;</span>
            <span class="p">};</span>
            <span class="nv">serviceConfig</span> <span class="o">=</span> <span class="p">{</span>
                <span class="nv">ExecStart</span> <span class="o">=</span> <span class="s2">"</span><span class="si">${</span><span class="nv">script</span><span class="si">}</span><span class="s2">/bin/update-roa"</span><span class="p">;</span>
            <span class="p">};</span>
        <span class="p">};</span>
    <span class="p">};</span>
<span class="p">}</span></code></pre>

<h3><a class="anchor" id="bird-looking-glass" href="#bird-looking-glass"></a>Bird Looking Glass</h3>

<p>There is now (thanks to <a href="https://github.com/NixOS/nixpkgs/pull/153481">Tchekda</a>) a direct way to set up a looking glass for bird on Nixos. <a href="https://github.com/NixOS/nixpkgs/blob/3aab5ebd436023ca8343a84804d51cd227dd01dd/nixos/modules/services/networking/bird-lg.nix">Documentation</a> and sample:</p>

<pre class="highlight"><code><span class="nv">bird-lg</span> <span class="o">=</span> <span class="p">{</span>
    <span class="nv">proxy</span> <span class="o">=</span> <span class="p">{</span>
        <span class="nv">enable</span> <span class="o">=</span> <span class="kc">true</span><span class="p">;</span>
        <span class="nv">allowedIPs</span> <span class="o">=</span> <span class="p">[</span> <span class="s2">"172.20.XX.XX"</span> <span class="s2">"172.20.XX.YY"</span> <span class="p">];</span>
    <span class="p">};</span>
    <span class="nv">frontend</span> <span class="o">=</span> <span class="p">{</span>
        <span class="nv">enable</span> <span class="o">=</span> <span class="kc">true</span><span class="p">;</span>
        <span class="nv">netSpecificMode</span> <span class="o">=</span> <span class="s2">"dn42"</span><span class="p">;</span>
        <span class="nv">servers</span> <span class="o">=</span> <span class="p">[</span> <span class="s2">"node1"</span> <span class="s2">"node2"</span> <span class="p">];</span>
        <span class="nv">domain</span> <span class="o">=</span> <span class="s2">"domain.dn42"</span><span class="p">;</span>
    <span class="p">};</span>
<span class="p">};</span></code></pre>

<h3><a class="anchor" id="services" href="#services"></a>Services</h3>

<p>I also run services like a nameserver for .litschi.dn42 zones and a nginx webserver within this container. Since Host paths for <code>/var/www/dn42</code> and <code>/var/dns/dn42</code> are both bound into the container, zone config and e.g. website can be edited directly from Host without rebuilding the whole container.</p>

<h3><a class="anchor" id="sample-configuration" href="#sample-configuration"></a>Sample configuration</h3>

<p>You can find a sample Wireguard + Bird configuration made by Tchekda ready for dn42 in <a href="https://github.com/Tchekda/nixos-configuration/tree/master/llitt/dn42">this</a> repository.</p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>
</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/nixos.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/nixos.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
