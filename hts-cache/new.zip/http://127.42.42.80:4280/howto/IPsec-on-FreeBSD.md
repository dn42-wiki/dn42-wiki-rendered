<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-309be032396e783b13a47df58f389b7c8e11c2b2d42640560b874f677c25f6e5.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">

  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/IPsec-on-FreeBSD.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-f05401ee374f0c7f48fc2bc08e30b4f4db705861fd5895ed70998683b383bfb5.js" type="text/javascript"></script>
  

  <title>IPsec-on-FreeBSD</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>IPsec-on-FreeBSD</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/IPsec-on-FreeBSD.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <a class="btn btn-sm" id="minibutton-home" href="/">
      Home
    </a>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/overview"
          id="minibutton-overview"
        >
          Overview
        </a>

        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/latest_changes"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </a>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          href="/gollum/history/howto/IPsec-on-FreeBSD.md/"
          id="minibutton-history"
        >
          History
        </a>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    IPsec-on-FreeBSD
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="ipsec-on-freebsd" href="#ipsec-on-freebsd"></a>IPsec on FreeBSD</h1>

<p>These instructions are for IPsec in transport mode not IPsec in tunnel mode. IPsec in tunnel mode requires a too tight coupling with the routing table for dynamic routing because the policies can only be specified based on source/destination address and protocol not based on interfaces.</p>

<h2><a class="anchor" id="requirements" href="#requirements"></a>Requirements</h2>

<ul>
<li>Root access to both endpoints.</li>
<li>Static IPv4 addresses for both endpoints unless you want to write a small shell script as hook for racoon.</li>
<li>At least one static IPv4 on at least one endpoint unless you hate yourself.</li>
</ul>

<h2><a class="anchor" id="kernel-configuration" href="#kernel-configuration"></a>Kernel configuration</h2>

<p>The FreeBSD GENERIC kernel lacks support for in-kernel IPsec processing. Add this two lines to your kernel config and (re-)build your own kernel.
If you're new to FreeBSD check Chapters <a href="http://www.freebsd.org/doc/handbook/ipsec.html">15.9.1</a> and <a href="http://www.freebsd.org/doc/handbook/kernelconfig.html">9</a> of the FreeBSD handbook.
</p><pre class="highlight"><code><span class="n">options</span>   <span class="n">IPSEC</span>        <span class="c">#IP security
</span><span class="n">device</span>    <span class="n">crypto</span></code></pre>
Reboot into your new kernel.

<h2><a class="anchor" id="userland-configuration" href="#userland-configuration"></a>Userland configuration</h2>

<p>Install the racoon daemon. It's included in the <a href="http://www.freshports.org/security/ipsec-tools/">security/ipsec-tools</a> port.
Racoon is pain in the ass to configure the first time because it's error messages aren't helping and the complexity of IPsec. Don't let this stop you.
</p><pre class="highlight"><code><span class="n">path</span>    <span class="n">pre_shared_key</span>  <span class="s2">"/usr/local/etc/racoon/psk"</span>;
<span class="n">path</span>    <span class="n">certificate</span>     <span class="s2">"/usr/local/etc/racoon/certs"</span>;
<span class="n">log</span>     <span class="n">info</span>;

<span class="n">listen</span> {
        <span class="n">isakmp</span>          <span class="n">a</span>.<span class="n">b</span>.<span class="n">c</span>.<span class="n">d</span> [<span class="m">500</span>];
        <span class="n">isakmp_natt</span>     <span class="n">a</span>.<span class="n">b</span>.<span class="n">c</span>.<span class="n">d</span> [<span class="m">4500</span>];
}

<span class="n">padding</span> {
        <span class="n">strict_check</span>    <span class="n">on</span>;
}

<span class="n">timer</span> {
        <span class="n">natt_keepalive</span>   <span class="m">5</span> <span class="n">sec</span>;
        <span class="n">interval</span>         <span class="m">3</span> <span class="n">sec</span>;
        <span class="n">phase1</span>          <span class="m">45</span> <span class="n">sec</span>; <span class="c"># give embedded CPUs time to finish RSA operations
</span>        <span class="n">phase2</span>          <span class="m">45</span> <span class="n">sec</span>;
}

<span class="n">remote</span> <span class="n">b</span>.<span class="n">c</span>.<span class="n">d</span>.<span class="n">e</span> [<span class="m">500</span>] {
        <span class="n">exchange_mode</span>           <span class="n">main</span>;
        <span class="n">proposal_check</span>          <span class="n">strict</span>;
        <span class="n">my_identifier</span>           <span class="n">asn1dn</span>;
        <span class="n">peers_identifier</span>        <span class="n">asn1dn</span>;
        <span class="n">lifetime</span>                <span class="n">time</span> <span class="m">1</span> <span class="n">hour</span>;
        <span class="n">certificate_type</span>        <span class="n">x509</span> <span class="s2">"self.crt"</span> <span class="s2">"self.key"</span>;
        <span class="n">peers_certfile</span>          <span class="n">x509</span> <span class="s2">"peer.crt"</span>;
        <span class="n">ca_type</span>                 <span class="n">x509</span> <span class="s2">"ca.crt"</span>;
        <span class="n">verify_cert</span>             <span class="n">on</span>;
        <span class="n">send_cert</span>               <span class="n">off</span>; <span class="c"># neither send
</span>        <span class="n">send_cr</span>                 <span class="n">off</span>; <span class="c"># nor request a crt to be send
</span>
        <span class="n">proposal</span> {
                <span class="n">encryption_algorithm</span>    <span class="n">aes</span> <span class="m">256</span>;
                <span class="n">hash_algorithm</span>          <span class="n">sha256</span>;
                <span class="n">authentication_method</span>   <span class="n">rsasig</span>;
                <span class="n">dh_group</span>                <span class="n">modp4096</span>;
        }
}

<span class="n">sainfo</span> (<span class="n">address</span> <span class="n">a</span>.<span class="n">b</span>.<span class="n">c</span>.<span class="n">d</span> <span class="n">gre</span> <span class="n">address</span> <span class="n">b</span>.<span class="n">c</span>.<span class="n">d</span>.<span class="n">e</span> <span class="n">gre</span>) {
        <span class="n">pfs_group</span>                       <span class="n">modp4096</span>;
        <span class="n">lifetime</span>                        <span class="n">time</span> <span class="m">1</span> <span class="n">hour</span>;
        <span class="n">encryption_algorithm</span>            <span class="n">aes</span> <span class="m">256</span>;
        <span class="n">authentication_algorithm</span>        <span class="n">hmac_sha1</span>;
}
</code></pre>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
<li>
<p><a href="/Home" rel="nofollow">Home</a></p>

<ul>
<li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
<li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
<li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
<li><a href="/howto/Bird-communities" rel="nofollow">BGP communities</a></li>
<li><a href="/FAQ" rel="nofollow">FAQ</a></li>
</ul>
</li>
<li>
<p>How-To</p>

<ul>
<li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
<li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
<li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
<li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
<li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
<li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
<li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
<li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
<li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
<li>
<a href="/howto/Bird" rel="nofollow">Bird</a> / <a href="/howto/Bird2" rel="nofollow">Bird2</a>
</li>
<li><a href="/howto/Quagga" rel="nofollow">Quagga</a></li>
<li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
<li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
<li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
<li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
<li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
<li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
<li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
</ul>
</li>
<li>
<p>Services</p>

<ul>
<li><a href="/services/IRC" rel="nofollow">IRC</a></li>
<li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
<li><a href="/services/DNS" rel="nofollow">DNS</a></li>
<li><a href="/services/IX2" rel="nofollow">IX</a></li>
<li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
<li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
<li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
<li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
<li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
<li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
<li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
</ul>
</li>
<li>
<p>Internal</p>

<ul>
<li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
<li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
<li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
<li>
<a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a><br />
</li>
<li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
</ul>
</li>
<li>
<p>External Tools</p>

<ul>
<li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
<li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
</ul>
</li>
</ul>

<hr />

	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p>Hosted by: <a href="mailto:xuu@sour.is" rel="nofollow">xuu</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">nurtic-vibe</a>, <a href="mailto:tom@xcv.vc" rel="nofollow">toBee</a>, <a href="mailto:dn42@burble.com" rel="nofollow">burble</a> | Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a></p>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/IPsec-on-FreeBSD.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/IPsec-on-FreeBSD.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
