<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/ROA-slash-RPKI.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>ROA-slash-RPKI</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>ROA-slash-RPKI</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/ROA-slash-RPKI.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/ROA-slash-RPKI.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    ROA-slash-RPKI
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h2><a class="anchor" id="what-is-roa" href="#what-is-roa"></a>What is ROA?</h2>

<p>A Route Origination Authorization details which AS is authorised to advertise which originating IP prefixes. A ROA may also include prefix length information.</p>

<h2><a class="anchor" id="what-is-rpki" href="#what-is-rpki"></a>What is RPKI?</h2>

<p>Resource Public Key Infrastructure is basically a framework for securing the routing infrastructure.<br />
It provides a way to connect number resource information to a trust anchor.</p>

<h2><a class="anchor" id="what-is-rtr" href="#what-is-rtr"></a>What is RTR?</h2>

<p>The Resource Public Key Infrastructure (RPKI) to Router Protocol provides a way for a router to access RPKI validation information.<br />
It provides the router with validity information regarding prefix origination:</p>

<ul>
  <li>VALID<br />
The route announcement is covered by a ROA and the announcing AS is validated</li>
  <li>INVALID<br />
The route announcement is covered by a ROA and the announcing AS is invalid (possibly hijacking)</li>
  <li>UNKNOWN<br />
There exists no ROA for the route announcement</li>
</ul>

<h2><a class="anchor" id="how-can-i-implement-roa-on-dn42" href="#how-can-i-implement-roa-on-dn42"></a>How can I implement ROA on dn42?</h2>

<p>On dn42 we generate ROA information from the dn42 registry.<br />
ROA json/bird files can be generated using <a href="https://git.burble.com/burble.dn42/dn42regsrv">dn42regsrv</a>.
It is also possible to integrate this with a RTR cache server such as <a href="https://github.com/cloudflare/gortr">gortr</a>.</p>

<h3><a class="anchor" id="dn42regsrv" href="#dn42regsrv"></a>dn42regsrv</h3>

<p>You can find a hosted example of dn42regsrv at <a href="https://explorer.burble.com/">https://explorer.burble.com/</a></p>

<p>Instructions on how to host dn42regsrv yourself can be found on the git repo of <a href="https://git.burble.com/burble.dn42/dn42regsrv">dn42regsrv</a>.</p>

<p>You can also run dn42regsrv via docker (then available at 127.0.0.1:8042):
</p><pre class="highlight"><code>git checkout https://git.burble.com/burble.dn42/dn42regsrv.git <span class="nb">.</span>
<span class="nb">cd </span>contrib/docker
./build.sh
docker-compose up <span class="nt">-d</span></code></pre>

<p>Documentation for the api endpoints can be found here: <a href="https://git.burble.com/burble.dn42/dn42regsrv/src/master/API.md">https://git.burble.com/burble.dn42/dn42regsrv/src/master/API.md</a></p>

<h3><a class="anchor" id="gortr" href="#gortr"></a>gortr</h3>

<p>burble kindly provides ready-to-use files for gortr here:</p>

<p><a href="https://dn42.burble.com/roa/dn42_roa_46.json">https://dn42.burble.com/roa/dn42_roa_46.json</a></p>

<p>You can use these to simply run gortr via docker:</p>

<pre class="highlight"><code>docker run <span class="nt">-ti</span> <span class="nt">-p</span> 8082:8082 cloudflare/gortr <span class="nt">-cache</span> https://dn42.burble.com/roa/dn42_roa_46.json <span class="nt">-verify</span><span class="o">=</span><span class="nb">false</span> <span class="nt">-checktime</span><span class="o">=</span><span class="nb">false</span> <span class="nt">-bind</span> :8082</code></pre>

<h3><a class="anchor" id="rtrtr" href="#rtrtr"></a>rtrtr</h3>

<p>rtrtr is a RTR server from NLNet Labs. It's compatible with the dn42regsrv ROA-JSON or burbles provided one (https://dn42.burble.com/roa/dn42_roa_46.json) too.</p>

<p>NLNet Labs provides an official docker image. You just have to bind mount a suitable configuration file:</p>

<pre class="highlight"><code>docker run <span class="nt">-d</span> <span class="nt">-v</span> /etc/rtrtr.conf:/etc/rtrtr.conf <span class="nt">-p</span> 323:323/tcp nlnetlabs/rtrtr <span class="nt">-c</span> /etc/rtrtr.conf</code></pre>

<p>This is a working configuration file for dn42. Maybe change the listen addresses:</p>

<pre class="highlight"><code><span class="n">log_level</span> = <span class="s2">"debug"</span>
<span class="n">log_target</span> = <span class="s2">"stderr"</span>
<span class="n">http</span>-<span class="n">listen</span> = []
[<span class="n">units</span>.<span class="n">dn42</span>-<span class="n">json</span>]
<span class="n">type</span> = <span class="s2">"json"</span>
<span class="n">uri</span> = <span class="s2">"https://dn42.burble.com/roa/dn42_roa_46.json"</span>
<span class="n">refresh</span> = <span class="m">600</span>
[<span class="n">targets</span>.<span class="n">dn42</span>-<span class="n">rtr</span>]
<span class="n">type</span> = <span class="s2">"rtr"</span>
<span class="n">listen</span> = [<span class="s2">"0.0.0.0:323"</span>, <span class="s2">"[::]:323"</span>]
<span class="n">unit</span> = <span class="s2">"dn42-json"</span></code></pre>

<p>For more information cosult the official documentation: <a href="https://rtrtr.docs.nlnetlabs.nl/en/stable/">https://rtrtr.docs.nlnetlabs.nl/en/stable/</a></p>

<h3><a class="anchor" id="kioubit-s-dn42-registry-wizard" href="#kioubit-s-dn42-registry-wizard"></a>Kioubit's DN42 Registry Wizard</h3>

<p><a href="https://github.com/Kioubit/dn42_registry_wizard">DN42 Registry Wizard</a> is a comprehensive tool for DN42 registry interactions. <strong>Unlike other solutions, it can parse the registry and host an RTR server all-in-one</strong> without requiring separate components.</p>

<h4><a class="anchor" id="all-in-one-rtr-server" href="#all-in-one-rtr-server"></a>All-in-One RTR Server</h4>

<pre class="highlight"><code><span class="c"># Clone the DN42 registry</span>
git clone https://git.dn42.dev/dn42/registry.git

<span class="c"># Start RTR server directly from registry</span>
./registry_wizard &lt;path to registry&gt; rtr 

<span class="c"># Setup a cronjob to continously update the registry and notify registry_wizard</span>
git fetch <span class="nt">--all</span>
git reset <span class="nt">--hard</span> origin/master
<span class="nb">kill</span> <span class="nt">-SIGUSR1</span> <span class="s2">"</span><span class="si">$(</span>pidof <span class="s1">'registry_wizard'</span><span class="si">)</span><span class="s2">"</span></code></pre>

<pre class="highlight"><code>Usage: registry_wizard &lt;registry_root&gt; rtr [OPTIONS]

Options:
  -p, --port &lt;port&gt;        Port to listen on [default: 9323]
      --refresh &lt;refresh&gt;  RTR refresh timing [default: 3600]
      --expire &lt;expire&gt;    RTR expire timing [default: 7200]
      --retry &lt;retry&gt;      RTR retry timing [default: 600]
  -h, --help               Print help</code></pre>

<h3><a class="anchor" id="other-tools-generators" href="#other-tools-generators"></a>Other tools / generators</h3>
<ul>
  <li>bauen1's dn42-roagen: <a href="https://gitlab.com/bauen1/dn42-roagen">https://gitlab.com/bauen1/dn42-roagen</a>
</li>
  <li>Kioubit's registry wizard: <a href="https://github.com/Kioubit/dn42_registry_wizard">https://github.com/Kioubit/dn42_registry_wizard</a>
</li>
  <li>chuangzhu's pure bash script: <a href="https://paste.sr.ht/~chuang/e98d2fe791de68a6cf5aade7877cd0dbc1cdb84e">https://paste.sr.ht/~chuang/e98d2fe791de68a6cf5aade7877cd0dbc1cdb84e</a>
</li>
</ul>

<h3><a class="anchor" id="this-is-all-to-complicated-is-there-an-easy-all-in-one-package-for-rtr" href="#this-is-all-to-complicated-is-there-an-easy-all-in-one-package-for-rtr"></a>This is all to complicated, is there an easy all-in-one package for RTR?</h3>

<p>TODO: Publish docker-compose-yml to git for gortr+dn42regsrv</p>

<h3><a class="anchor" id="how-do-i-integrate-rtr-with-my-bgp-implementation" href="#how-do-i-integrate-rtr-with-my-bgp-implementation"></a>How do I integrate RTR with my BGP implementation</h3>

<p>You have to consult the documentation of your implementation for that. We will provide configuration examples on the specific pages.</p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/Policies" rel="nofollow">Policies</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
      <li><a href="/Links" rel="nofollow">Links</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
      <li><a href="/howto/GeoFeed" rel="nofollow">GeoFeed</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/dns/Overview" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">RPKI</a></li>
      <li><a href="/services/exchanges/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Pingables" rel="nofollow">Pingables</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/ca/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>, <a href="https://iedon.net/post/24" rel="nofollow">IEDON-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>, <a href="https://dn42.jp/" rel="nofollow">dn42.jp</a> (wiki-go)</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/ROA-slash-RPKI.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/ROA-slash-RPKI.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
