<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/ROA-slash-RPKI.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>ROA-slash-RPKI</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>ROA-slash-RPKI</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/ROA-slash-RPKI.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/ROA-slash-RPKI.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    ROA-slash-RPKI
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h2><a class="anchor" id="what-is-roa" href="#what-is-roa"></a>What is ROA?</h2>

<p>A Route Origination Authorization details which AS is authorised to advertise which originating IP prefixes. A ROA may also include prefix length information.</p>

<h2><a class="anchor" id="what-is-rpki" href="#what-is-rpki"></a>What is RPKI?</h2>

<p>Resource Public Key Infrastructure is basically a framework for securing the routing infrastructure.<br />
It provides a way to connect number resource information to a trust anchor.</p>

<h2><a class="anchor" id="what-is-rtr" href="#what-is-rtr"></a>What is RTR?</h2>

<p>The Resource Public Key Infrastructure (RPKI) to Router Protocol provides a way for a router to access RPKI validation information.<br />
It provides the router with validity information regarding prefix origination:</p>

<ul>
  <li>VALID<br />
The route announcement is covered by a ROA and the announcing AS is validated</li>
  <li>INVALID<br />
The route announcement is covered by a ROA and the announcing AS is invalid (possibly hijacking)</li>
  <li>UNKNOWN<br />
There exists no ROA for the route announcement</li>
</ul>

<h2><a class="anchor" id="how-can-i-implement-roa-on-dn42" href="#how-can-i-implement-roa-on-dn42"></a>How can I implement ROA on dn42?</h2>

<p>On dn42 we generate ROA information from the dn42 registry.<br />
ROA json/bird files can be generated using <a href="https://git.burble.com/burble.dn42/dn42regsrv">dn42regsrv</a>.
It is also possible to integrate this with a RTR cache server such as <a href="https://github.com/cloudflare/gortr">gortr</a>.</p>

<h3><a class="anchor" id="dn42regsrv" href="#dn42regsrv"></a>dn42regsrv</h3>

<p>You can find a hosted example of dn42regsrv at <a href="https://explorer.burble.com/">https://explorer.burble.com/</a></p>

<p>Instructions on how to host dn42regsrv yourself can be found on the git repo of <a href="https://git.burble.com/burble.dn42/dn42regsrv">dn42regsrv</a>.</p>

<p>You can also run dn42regsrv via docker (then available at 127.0.0.1:8042):
</p><pre class="highlight"><code>git checkout https://git.burble.com/burble.dn42/dn42regsrv.git <span class="nb">.</span>
<span class="nb">cd </span>contrib/docker
./build.sh
docker-compose up <span class="nt">-d</span></code></pre>

<p>Documentation for the api endpoints can be found here: <a href="https://git.burble.com/burble.dn42/dn42regsrv/src/master/API.md">https://git.burble.com/burble.dn42/dn42regsrv/src/master/API.md</a></p>

<h3><a class="anchor" id="gortr" href="#gortr"></a>gortr</h3>

<p>burble kindly provides ready-to-use files for gortr here:</p>

<p><a href="https://dn42.burble.com/roa/dn42_roa_46.json">https://dn42.burble.com/roa/dn42_roa_46.json</a></p>

<p>You can use these to simply run gortr via docker:</p>

<pre class="highlight"><code>docker run <span class="nt">-ti</span> <span class="nt">-p</span> 8082:8082 cloudflare/gortr <span class="nt">-cache</span> https://dn42.burble.com/roa/dn42_roa_46.json <span class="nt">-verify</span><span class="o">=</span><span class="nb">false</span> <span class="nt">-checktime</span><span class="o">=</span><span class="nb">false</span> <span class="nt">-bind</span> :8082</code></pre>

<h3><a class="anchor" id="rtrtr" href="#rtrtr"></a>rtrtr</h3>

<p>rtrtr is a RTR server from NLNet Labs. It's compatible with the dn42regsrv ROA-JSON or burbles provided one (https://dn42.burble.com/roa/dn42_roa_46.json) too.</p>

<p>NLNet Labs provides an official docker image. You just have to bind mount a suitable configuration file:</p>

<pre class="highlight"><code>docker run <span class="nt">-d</span> <span class="nt">-v</span> /etc/rtrtr.conf:/etc/rtrtr.conf <span class="nt">-p</span> 323:323/tcp nlnetlabs/rtrtr <span class="nt">-c</span> /etc/rtrtr.conf</code></pre>

<p>This is a working configuration file for dn42. Maybe change the listen addresses:</p>

<pre class="highlight"><code><span class="n">log_level</span> = <span class="s2">"debug"</span>
<span class="n">log_target</span> = <span class="s2">"stderr"</span>
<span class="n">http</span>-<span class="n">listen</span> = []
[<span class="n">units</span>.<span class="n">dn42</span>-<span class="n">json</span>]
<span class="n">type</span> = <span class="s2">"json"</span>
<span class="n">uri</span> = <span class="s2">"https://dn42.burble.com/roa/dn42_roa_46.json"</span>
<span class="n">refresh</span> = <span class="m">600</span>
[<span class="n">targets</span>.<span class="n">dn42</span>-<span class="n">rtr</span>]
<span class="n">type</span> = <span class="s2">"rtr"</span>
<span class="n">listen</span> = [<span class="s2">"0.0.0.0:323"</span>, <span class="s2">"[::]:323"</span>]
<span class="n">unit</span> = <span class="s2">"dn42-json"</span></code></pre>

<p>For more information cosult the official documentation: <a href="https://rtrtr.docs.nlnetlabs.nl/en/stable/">https://rtrtr.docs.nlnetlabs.nl/en/stable/</a></p>

<h3><a class="anchor" id="other-tools-generators" href="#other-tools-generators"></a>Other tools / generators</h3>
<ul>
  <li>bauen1's dn42-roagen: <a href="https://gitlab.com/bauen1/dn42-roagen">https://gitlab.com/bauen1/dn42-roagen</a>
</li>
  <li>Kioubit's registry wizard: <a href="https://git.dn42.dev/Kioubit/RegistryWizard">https://git.dn42.dev/Kioubit/RegistryWizard</a>
</li>
  <li>chuangzhu's pure bash script: <a href="https://paste.sr.ht/~chuang/e98d2fe791de68a6cf5aade7877cd0dbc1cdb84e">https://paste.sr.ht/~chuang/e98d2fe791de68a6cf5aade7877cd0dbc1cdb84e</a>
</li>
</ul>

<h3><a class="anchor" id="this-is-all-to-complicated-is-there-an-easy-all-in-one-package-for-rtr" href="#this-is-all-to-complicated-is-there-an-easy-all-in-one-package-for-rtr"></a>This is all to complicated, is there an easy all-in-one package for RTR?</h3>

<p>TODO: Publish docker-compose-yml to git for gortr+dn42regsrv</p>

<h3><a class="anchor" id="how-do-i-integrate-rtr-with-my-bgp-implementation" href="#how-do-i-integrate-rtr-with-my-bgp-implementation"></a>How do I integrate RTR with my BGP implementation</h3>

<p>You have to consult the documentation of your implementation for that. We will provide configuration examples on the specific pages.</p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/ROA-slash-RPKI.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/ROA-slash-RPKI.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
