<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/mikrotik.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>mikrotik</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>mikrotik</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/mikrotik.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/mikrotik.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    mikrotik
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="how-to-connect-to-dn42-using-mikrotik-routeros" href="#how-to-connect-to-dn42-using-mikrotik-routeros"></a>How to connect to dn42 using Mikrotik RouterOS</h1>

<h2><a class="anchor" id="legend" href="#legend"></a>Legend</h2>

<ul>
  <li>1.1.1.1 - peer external IP</li>
  <li>2.2.2.2 - your external IP</li>
  <li>A private /30 range for the GRE endpoints: 192.168.200.128/30</li>
  <li>192.168.200.129 - remote GRE IPv4 address</li>
  <li>192.168.200.130 - local GRE IPv4 address</li>
  <li>fd42:c644:5222:3222::40 - remote GRE IPv6 address</li>
  <li>fd42:c644:5222:3222::41 - local GRE IPv6 address</li>
  <li>YOUR_AS - your AS number (numbers only)</li>
  <li>PEER_AS - peer AS number (numbers only)</li>
</ul>

<h2><a class="anchor" id="routeros-limitations" href="#routeros-limitations"></a>RouterOS limitations</h2>

<ul>
  <li>IPSec only supports IKEv1</li>
  <li>OpenVPN only works in tcp mode</li>
  <li>OpenVPN does not support LZO compression</li>
  <li>You can't use /31 subnet for Point-to-Point (PtP) links</li>
</ul>

<p>Mikrotik/RouterOS can't handle very well /32 on Point-to-Point links (like GRE). There is a <a href="/howto/mikrotik/ptp32">separate howto</a> to explain how to setup /32 between in a GRE link (or even a OpenVPN). What is the easy way? Just use any /30 on the GRE Link, either from your assigned DN42 pool address or use a private address like 192.168. Please don't choose from 172.16.0.0/12 or 10.0.0.0/8 because they may overlap with DN42 or ChaosVPN.</p>

<p>RouterOS v7.2 has some nasty bugs when using PTP configuration or IPv6 link local addresses as NEXTHOP. It won't work (confirmed for v7.2 by their support staff).</p>

<h2><a class="anchor" id="tunnel" href="#tunnel"></a>Tunnel</h2>

<h3><a class="anchor" id="ipsec" href="#ipsec"></a>IPSec</h3>
<p>First, let's add IPSec peer and encryption policy.<br />
Peer most likely provided you with encryption details.<br />
If not, ask them about it.
Here we're gonna use aes256-sha256-modp1536</p>

<pre class="highlight"><code>/ip ipsec peer
add address=1.1.1.1 comment=gre-dn42-peer dh-group=modp1536 \ 
enc-algorithm=aes-256 hash-algorithm=sha256 local-address=2.2.2.2 secret=PASSWORD
</code></pre>
<pre class="highlight"><code>/ip ipsec policy
add comment=gre-dn42-peer dst-address=1.1.1.1/32 proposal=dn42 protocol=gre \ 
sa-dst-address=1.1.1.1 sa-src-address=2.2.2.2 src-address=2.2.2.2/32</code></pre>

<h3><a class="anchor" id="gre" href="#gre"></a>GRE</h3>
<p>Pretty straightforward here</p>

<pre class="highlight"><code>/interface gre
add allow-fast-path=no comment="DN42 somepeer" local-address=2.2.2.2 name=gre-dn42-peer \
remote-address=1.1.1.1</code></pre>

<h3><a class="anchor" id="ips-inside-the-gre-tunnel" href="#ips-inside-the-gre-tunnel"></a>IPs inside the GRE tunnel</h3>
<p>Your peer most likely provided you with IP adresses for GRE tunnel.<br />
As I said before, you can't use /31 for PtP links, so, in the "easy way" we will be using /30.
If you want to avoid wasting a whole /30 for your peering, please check the <a href="/howto/mikrotik/ptp32">point-to-point configuration for RouterOS</a></p>

<p>Add the IP your peer provided you:</p>

<h4><a class="anchor" id="ipv4" href="#ipv4"></a>IPv4</h4>

<pre class="highlight"><code>/ip address
add address=192.168.200.130/30 interface=gre-dn42-peer network=192.168.200.128</code></pre>

<h4><a class="anchor" id="ipv6" href="#ipv6"></a>IPv6</h4>
<p>Here we can use /127, so it's simple:</p>

<pre class="highlight"><code>/ipv6 address
add address=fdc8:c633:5319:3300::41/127 advertise=no interface=gre-dn42-peer</code></pre>

<p>If you configured everything correctly, you should be able to ping</p>

<h2><a class="anchor" id="bgp" href="#bgp"></a>BGP</h2>

<h3><a class="anchor" id="filters" href="#filters"></a>Filters</h3>
<p>Both BGP and routing filters were redone from the ground up on RoS 7.x
The official migration guide can be found <a href="https://help.mikrotik.com/docs/display/ROS/Routing">here</a></p>

<p>It's a good idea to setup filters for BGP instances, both IN (accept advertises) and OUT (send advertises)<br />
In this example, we will be filtering IN: 192.168.0.0/16 and 169.254.0.0/16<br />
OUT: 192.168.0.0/16 and 169.254.0.0/16, you really don't want to advertise this networks.<br />
This filter will not only catch /8 or /16 networks, but smaller networks inside this subnets as well.</p>

<h4><a class="anchor" id="ros-6-x" href="#ros-6-x"></a>RoS 6.x</h4>
<pre class="highlight"><code>/routing filter
add action=discard address-family=ip chain=dn42-in prefix=192.168.0.0/16 prefix-length=16-32 protocol=bgp
add action=discard address-family=ip chain=dn42-in prefix=169.254.0.0/16 prefix-length=16-32 protocol=bgp
add action=discard address-family=ip chain=dn42-out prefix=192.168.0.0/16 prefix-length=16-32 protocol=bgp
add action=discard address-family=ip chain=dn42-out prefix=169.254.0.0/16 prefix-length=16-32 protocol=bgp</code></pre>

<p>If you want only DN42 connection, you can filter IN 10.0.0.0/8 (ChaosVPN / freifunk networks):</p>

<pre class="highlight"><code>/routing filter
add action=discard address-family=ip chain=dn42-in prefix=10.0.0.0/8 prefix-length=8-32 protocol=bgp</code></pre>

<h4><a class="anchor" id="ros-7-x" href="#ros-7-x"></a>RoS 7.x</h4>
<pre class="highlight"><code>/routing filter rule
add chain=dn42-in rule="if (dst in 192.168.0.0/16 &amp;&amp; dst-len &gt; 16) { reject }"
add chain=dn42-in rule="if (dst in 169.254.0.0/1 &amp;&amp; dst-len &gt; 16) { reject }"
add chain=dn42-out rule="if (dst in 192.168.0.0/16 &amp;&amp; dst-len &gt; 16) { reject }"
add chain=dn42-out rule="if (dst in 169.254.0.0/1 &amp;&amp; dst-len &gt; 16) { reject }"</code></pre>

<p>If you want only DN42 connection, you can filter IN 10.0.0.0/8 (ChaosVPN / freifunk networks):</p>

<pre class="highlight"><code>/routing filter
add chain=dn42-in rule="if (dst in 10.0.0.0 &amp;&amp; dst-len &gt; 8) { reject }"
</code></pre>

<h3><a class="anchor" id="bgp-1" href="#bgp-1"></a>BGP</h3>
<p>Now, for actual BGP configuration.</p>

<h4><a class="anchor" id="ros-v6" href="#ros-v6"></a>RoS v6</h4>
<pre class="highlight"><code>/routing bgp instance
set default disabled=yes
add as=YOUR_AS client-to-client-reflection=no name=bgp-dn42-somename out-filter=dn42-in router-id=1.1.1.1</code></pre>
Let's add some peers. Right now we have just one, but we still need two connections - to IPv4 and IPv6

<p>IPv4:
</p><pre class="highlight"><code>/routing bgp peer
add comment="DN42: somepeer IPv4" in-filter=dn42-in instance=bgp-dn42-somename multihop=yes \
name=dn42-somepeer-ipv4 out-filter=dn42-out remote-address=192.168.200.129 remote-as=PEER_AS \
route-reflect=yes ttl=default</code></pre>
IPv6 (if needed):

<pre class="highlight"><code>/routing bgp peer
add address-families=ipv6 comment="DN42: somepeer IPv6" in-filter=dn42-in \ 
instance=bgp-dn42-somename multihop=yes name=dn42-somepeer-ipv6 out-filter=dn42-out \ 
remote-address=fd42:c644:5222:3222::40 remote-as=PEER_AS route-reflect=yes ttl=default</code></pre>

<p>Also, as a note, Mikrotik RoS 6.x doesn't deal well with BGP running over link-local addresses (the address starting with fe80). You need to use a fd42:: address in your BGP session, otherwise, BGP will not install any received route.</p>

<h4><a class="anchor" id="bgp-advertisements" href="#bgp-advertisements"></a>BGP Advertisements</h4>
<p>You want to advertise your allocated network (most likely), it's very simple:</p>

<pre class="highlight"><code>/routing bgp network
add network=YOUR_ALLOCATED_SUBNET synchronize=no</code></pre>
You can repeat that with as much IPv4 and IPv6 networks which you own.

<h4><a class="anchor" id="ros-7-x-1" href="#ros-7-x-1"></a>RoS 7.x</h4>

<p>First difference from v 6.x: There is no "network" menu. We advertise our networks now by adding them to the firewall address-list and referencing in the BGP configuration. Also, we can only advertise networks that are part of our static routes. Of course, we can still propagate routes received from others peers.</p>

<p>Adding a network list:
</p><pre class="highlight"><code>IPv4
/ip firewall address-list
add address=YOUR_ALLOCATED_SUBNET list=DN42_allocated_v4

IPv6
/ipv6 firewall address-list
add address=YOUR_ALLOCATED_SUBNET list=DN42_allocated_v6</code></pre>

<p>Adding a static route to your full allocated network:
</p><pre class="highlight"><code>/ipv6 route
add blackhole disabled=no distance=1 dst-address=YOUR_ALLOCATED_SUBNET</code></pre>

<p>Let's create a template for DN42. It isn't strictly necessary, but makes our life easier.
</p><pre class="highlight"><code>/routing bgp template
add afi=ipv4 as=YOUR_AS_NUMBER name=DN42_template_v4 output.network=DN42_allocated_v4 router-id=1.1.1.1
add afi=ipv6 as=YOUR_AS_NUMBER name=DN42_template_v6 output.network=DN42_allocated_v6 router-id=1.1.1.1</code></pre>

<p>Now is time to add one peer:</p>

<p>Another difference from RoS v6.x is that v7.x can use link-local adresses (validated with RoS 7.14.3, 7.18.1, 7.18.2 and 7.19rc2). The trick is to add "%INTERFACE" after the address, where "INTERFACE" is the name of the interface the link-local is allocated to - or the interface used to get to that remote link-local. So, if You want to listen on fe80::1 on the "myPeer" interface, the address would be "fe80::1%myPeer".</p>

<p>RoS 7.17 and newer can set the link local address.</p>

<pre class="highlight"><code>IPv4 peer
add address-families=ipv4 disabled=no input.filter=dn42-in \
local.address=ADDRESS_YOUR_PEER_USE_TO_CONNECT_ON_YOU .role=ebgp \
multihop=yes name=PEER_NAME output.filter-chain=dn42-out \
.network=DN42_allocated_v4 remote.address=YOUR_PEER_REMOTE_ADDRESS \
.as=PEER_AS_NUMBER routing-table=main templates=DN42_template_v4

IPv6 peer
add address-families=ipv6 disabled=no input.filter=dn42-in \
local.address=ADDRESS_YOUR_PEER_USE_TO_CONNECT_ON_YOU .role=ebgp \
multihop=yes name=PEER_NAME output.filter-chain=dn42-out \
.network=DN42_allocated_v6 remote.address=YOUR_PEER_REMOTE_ADDRESS \
.as=PEER_AS_NUMBER routing-table=main templates=DN42_template_v6</code></pre>

<h2><a class="anchor" id="split-dns" href="#split-dns"></a>Split DNS</h2>
<p>Separate dns requests for dn42 tld from your default dns traffic with L7 filter in Mikrotik.
Change network and LAN GW to mach your network configuration.</p>

<pre class="highlight"><code>/ip firewall layer7-protocol
add name=DN42-DNS regexp="\\x04dn42.\\x01"
/ip firewall nat
add action=src-nat chain=srcnat comment="NAT to DN42 DNS" dst-address=172.23.0.53 dst-port=53 protocol=udp src-address=192.168.0.0/24 to-addresses=192.168.0.1
add action=dst-nat chain=dstnat dst-address-type=local dst-port=53 layer7-protocol=DN42-DNS protocol=udp src-address=192.168.0.0/24 to-addresses=172.23.0.53 to-ports=53
</code></pre>
Since version 6.47 have added functionality that can redirect DNS queries according to special rules. If you used to do Layer-7 rules in the firewall, now it's simple and elegant:
<pre class="highlight"><code>/ip dns static
add comment=DN42 forward-to=172.23.0.53 regexp=".*\\.dn42" type=FWD</code></pre>

<h1><a class="anchor" id="how-to-connect-to-dn42-using-mikrotik-routeros-1" href="#how-to-connect-to-dn42-using-mikrotik-routeros-1"></a>How to connect to dn42 using Mikrotik RouterOS</h1>

<h2><a class="anchor" id="legend-1" href="#legend-1"></a>Legend</h2>

<ul>
  <li>1.1.1.1 - peer external IP</li>
  <li>2.2.2.2 - your external IP</li>
  <li>A private /30 range for the GRE endpoints: 192.168.200.128/30</li>
  <li>192.168.200.129 - remote GRE IPv4 address</li>
  <li>192.168.200.130 - local GRE IPv4 address</li>
  <li>fd42:c644:5222:3222::40 - remote GRE IPv6 address</li>
  <li>fd42:c644:5222:3222::41 - local GRE IPv6 address</li>
  <li>YOUR_AS - your AS number (numbers only)</li>
  <li>PEER_AS - peer AS number (numbers only)</li>
</ul>

<h2><a class="anchor" id="routeros-limitations-1" href="#routeros-limitations-1"></a>RouterOS limitations</h2>

<ul>
  <li>IPSec only supports IKEv1</li>
  <li>OpenVPN only works in tcp mode</li>
  <li>OpenVPN does not support LZO compression</li>
  <li>You can't use /31 subnet for Point-to-Point (PtP) links</li>
</ul>

<p>Mikrotik/RouterOS can't handle very well /32 on Point-to-Point links (like GRE). There is a <a href="/howto/mikrotik/ptp32">separate howto</a> to explain how to setup /32 between in a GRE link (or even a OpenVPN). What is the easy way? Just use any /30 on the GRE Link, either from your assigned DN42 pool address or use a private address like 192.168. Please don't choose from 172.16.0.0/12 or 10.0.0.0/8 because they may overlap with DN42 or ChaosVPN.</p>

<p>RouterOS v7.2 has some nasty bugs when using PTP configuration or IPv6 link local addresses as NEXTHOP. It won't work (confirmed for v7.2 by their support staff).</p>

<h2><a class="anchor" id="tunnel-1" href="#tunnel-1"></a>Tunnel</h2>

<h3><a class="anchor" id="ipsec-1" href="#ipsec-1"></a>IPSec</h3>
<p>First, let's add IPSec peer and encryption policy.<br />
Peer most likely provided you with encryption details.<br />
If not, ask them about it.
Here we're gonna use aes256-sha256-modp1536</p>

<pre class="highlight"><code>/ip ipsec peer
add address=1.1.1.1 comment=gre-dn42-peer dh-group=modp1536 \ 
enc-algorithm=aes-256 hash-algorithm=sha256 local-address=2.2.2.2 secret=PASSWORD
</code></pre>
<pre class="highlight"><code>/ip ipsec policy
add comment=gre-dn42-peer dst-address=1.1.1.1/32 proposal=dn42 protocol=gre \ 
sa-dst-address=1.1.1.1 sa-src-address=2.2.2.2 src-address=2.2.2.2/32</code></pre>

<h3><a class="anchor" id="gre-1" href="#gre-1"></a>GRE</h3>
<p>Pretty straightforward here</p>

<pre class="highlight"><code>/interface gre
add allow-fast-path=no comment="DN42 somepeer" local-address=2.2.2.2 name=gre-dn42-peer \
remote-address=1.1.1.1</code></pre>

<h3><a class="anchor" id="ips-inside-the-gre-tunnel-1" href="#ips-inside-the-gre-tunnel-1"></a>IPs inside the GRE tunnel</h3>
<p>Your peer most likely provided you with IP adresses for GRE tunnel.<br />
As I said before, you can't use /31 for PtP links, so, in the "easy way" we will be using /30.
If you want to avoid wasting a whole /30 for your peering, please check the <a href="/howto/mikrotik/ptp32">point-to-point configuration for RouterOS</a></p>

<p>Add the IP your peer provided you:</p>

<h4><a class="anchor" id="ipv4-1" href="#ipv4-1"></a>IPv4</h4>

<pre class="highlight"><code>/ip address
add address=192.168.200.130/30 interface=gre-dn42-peer network=192.168.200.128</code></pre>

<h4><a class="anchor" id="ipv6-1" href="#ipv6-1"></a>IPv6</h4>
<p>Here we can use /127, so it's simple:</p>

<pre class="highlight"><code>/ipv6 address
add address=fdc8:c633:5319:3300::41/127 advertise=no interface=gre-dn42-peer</code></pre>

<p>If you configured everything correctly, you should be able to ping</p>

<h2><a class="anchor" id="bgp-2" href="#bgp-2"></a>BGP</h2>

<h3><a class="anchor" id="filters-1" href="#filters-1"></a>Filters</h3>
<p>Both BGP and routing filters were redone from the ground up on RoS 7.x
The official migration guide can be found <a href="https://help.mikrotik.com/docs/display/ROS/Routing">here</a></p>

<p>It's a good idea to setup filters for BGP instances, both IN (accept advertises) and OUT (send advertises)<br />
In this example, we will be filtering IN: 192.168.0.0/16 and 169.254.0.0/16<br />
OUT: 192.168.0.0/16 and 169.254.0.0/16, you really don't want to advertise this networks.<br />
This filter will not only catch /8 or /16 networks, but smaller networks inside this subnets as well.</p>

<h4><a class="anchor" id="ros-6-x-1" href="#ros-6-x-1"></a>RoS 6.x</h4>
<pre class="highlight"><code>/routing filter
add action=discard address-family=ip chain=dn42-in prefix=192.168.0.0/16 prefix-length=16-32 protocol=bgp
add action=discard address-family=ip chain=dn42-in prefix=169.254.0.0/16 prefix-length=16-32 protocol=bgp
add action=discard address-family=ip chain=dn42-out prefix=192.168.0.0/16 prefix-length=16-32 protocol=bgp
add action=discard address-family=ip chain=dn42-out prefix=169.254.0.0/16 prefix-length=16-32 protocol=bgp</code></pre>

<p>If you want only DN42 connection, you can filter IN 10.0.0.0/8 (ChaosVPN / freifunk networks):</p>

<pre class="highlight"><code>/routing filter
add action=discard address-family=ip chain=dn42-in prefix=10.0.0.0/8 prefix-length=8-32 protocol=bgp</code></pre>

<h4><a class="anchor" id="ros-7-x-2" href="#ros-7-x-2"></a>RoS 7.x</h4>
<pre class="highlight"><code>/routing filter rule
add chain=dn42-in rule="if (dst in 192.168.0.0/16 &amp;&amp; dst-len &gt; 16) { reject }"
add chain=dn42-in rule="if (dst in 169.254.0.0/1 &amp;&amp; dst-len &gt; 16) { reject }"
add chain=dn42-out rule="if (dst in 192.168.0.0/16 &amp;&amp; dst-len &gt; 16) { reject }"
add chain=dn42-out rule="if (dst in 169.254.0.0/1 &amp;&amp; dst-len &gt; 16) { reject }"</code></pre>

<p>If you want only DN42 connection, you can filter IN 10.0.0.0/8 (ChaosVPN / freifunk networks):</p>

<pre class="highlight"><code>/routing filter
add chain=dn42-in rule="if (dst in 10.0.0.0 &amp;&amp; dst-len &gt; 8) { reject }"
</code></pre>

<h3><a class="anchor" id="bgp-3" href="#bgp-3"></a>BGP</h3>
<p>Now, for actual BGP configuration.</p>

<h4><a class="anchor" id="ros-v6-1" href="#ros-v6-1"></a>RoS v6</h4>
<pre class="highlight"><code>/routing bgp instance
set default disabled=yes
add as=YOUR_AS client-to-client-reflection=no name=bgp-dn42-somename out-filter=dn42-in router-id=1.1.1.1</code></pre>
Let's add some peers. Right now we have just one, but we still need two connections - to IPv4 and IPv6

<p>IPv4:
</p><pre class="highlight"><code>/routing bgp peer
add comment="DN42: somepeer IPv4" in-filter=dn42-in instance=bgp-dn42-somename multihop=yes \
name=dn42-somepeer-ipv4 out-filter=dn42-out remote-address=192.168.200.129 remote-as=PEER_AS \
route-reflect=yes ttl=default</code></pre>
IPv6 (if needed):

<pre class="highlight"><code>/routing bgp peer
add address-families=ipv6 comment="DN42: somepeer IPv6" in-filter=dn42-in \ 
instance=bgp-dn42-somename multihop=yes name=dn42-somepeer-ipv6 out-filter=dn42-out \ 
remote-address=fd42:c644:5222:3222::40 remote-as=PEER_AS route-reflect=yes ttl=default</code></pre>

<p>Also, as a note, Mikrotik RoS 6.x doesn't deal well with BGP running over link-local addresses (the address starting with fe80). You need to use a fd42:: address in your BGP session, otherwise, BGP will not install any received route.</p>

<h4><a class="anchor" id="bgp-advertisements-1" href="#bgp-advertisements-1"></a>BGP Advertisements</h4>
<p>You want to advertise your allocated network (most likely), it's very simple:</p>

<pre class="highlight"><code>/routing bgp network
add network=YOUR_ALLOCATED_SUBNET synchronize=no</code></pre>
You can repeat that with as much IPv4 and IPv6 networks which you own.

<h4><a class="anchor" id="ros-7-x-3" href="#ros-7-x-3"></a>RoS 7.x</h4>

<p>First difference from v 6.x: There is no "network" menu. We advertise our networks now by adding them to the firewall address-list and referencing in the BGP configuration. Also, we can only advertise networks that are part of our static routes. Of course, we can still propagate routes received from others peers.</p>

<p>Adding a network list:
</p><pre class="highlight"><code>IPv4
/ip firewall address-list
add address=YOUR_ALLOCATED_SUBNET list=DN42_allocated_v4

IPv6
/ipv6 firewall address-list
add address=YOUR_ALLOCATED_SUBNET list=DN42_allocated_v6</code></pre>

<p>Adding a static route to your full allocated network:
</p><pre class="highlight"><code>/ipv6 route
add blackhole disabled=no distance=1 dst-address=YOUR_ALLOCATED_SUBNET</code></pre>

<p>Let's create a template for DN42. It isn't strictly necessary, but makes our life easier.
</p><pre class="highlight"><code>/routing bgp template
add afi=ipv4 as=YOUR_AS_NUMBER name=DN42_template_v4 output.network=DN42_allocated_v4 router-id=1.1.1.1
add afi=ipv6 as=YOUR_AS_NUMBER name=DN42_template_v6 output.network=DN42_allocated_v6 router-id=1.1.1.1</code></pre>

<p>Now is time to add one peer:</p>

<p>Another difference from RoS v6.x is that v7.x can use link-local adresses (validated with RoS 7.14.3, 7.18.1, 7.18.2 and 7.19rc2). The trick is to add "%INTERFACE" after the address, where "INTERFACE" is the name of the interface the link-local is allocated to - or the interface used to get to that remote link-local. So, if You want to listen on fe80::1 on the "myPeer" interface, the address would be "fe80::1%myPeer".</p>

<p>RoS 7.17 and newer can set the link local address.</p>

<pre class="highlight"><code>IPv4 peer
add address-families=ipv4 disabled=no input.filter=dn42-in \
local.address=ADDRESS_YOUR_PEER_USE_TO_CONNECT_ON_YOU .role=ebgp \
multihop=yes name=PEER_NAME output.filter-chain=dn42-out \
.network=DN42_allocated_v4 remote.address=YOUR_PEER_REMOTE_ADDRESS \
.as=PEER_AS_NUMBER routing-table=main templates=DN42_template_v4

IPv6 peer
add address-families=ipv6 disabled=no input.filter=dn42-in \
local.address=ADDRESS_YOUR_PEER_USE_TO_CONNECT_ON_YOU .role=ebgp \
multihop=yes name=PEER_NAME output.filter-chain=dn42-out \
.network=DN42_allocated_v6 remote.address=YOUR_PEER_REMOTE_ADDRESS \
.as=PEER_AS_NUMBER routing-table=main templates=DN42_template_v6</code></pre>

<h2><a class="anchor" id="split-dns-1" href="#split-dns-1"></a>Split DNS</h2>
<p>Separate dns requests for dn42 tld from your default dns traffic with L7 filter in Mikrotik.
Change network and LAN GW to mach your network configuration.</p>

<pre class="highlight"><code>/ip firewall layer7-protocol
add name=DN42-DNS regexp="\\x04dn42.\\x01"
/ip firewall nat
add action=src-nat chain=srcnat comment="NAT to DN42 DNS" dst-address=172.23.0.53 dst-port=53 protocol=udp src-address=192.168.0.0/24 to-addresses=192.168.0.1
add action=dst-nat chain=dstnat dst-address-type=local dst-port=53 layer7-protocol=DN42-DNS protocol=udp src-address=192.168.0.0/24 to-addresses=172.23.0.53 to-ports=53
</code></pre>
Since version 6.47 have added functionality that can redirect DNS queries according to special rules. If you used to do Layer-7 rules in the firewall, now it's simple and elegant:
<pre class="highlight"><code>/ip dns static
add comment=DN42 forward-to=172.23.0.53 regexp=".*\\.dn42" type=FWD</code></pre>

<h2><a class="anchor" id="specifying-bgp-communities-v7" href="#specifying-bgp-communities-v7"></a>Specifying BGP Communities (v7)</h2>

<pre class="highlight"><code>/routing/filter/community-list
add list=dn42 communities=64511:41
add list=dn42 communities=64511:5

/routing/filter/rule/
add chain=dn42-out rule="append bgp-communities dn42"</code></pre>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
      <li><a href="/Links" rel="nofollow">Links</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
      <li><a href="/howto/GeoFeed" rel="nofollow">GeoFeed</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/DNS" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">RPKI</a></li>
      <li><a href="/services/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
      <li><a href="/services/Registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
      <li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
    </ul>
  </li>
  <li>Historical
    <ul>
      <li><a href="/historical/Bird" rel="nofollow">Bird 1</a></li>
      <li><a href="/historical/Quagga" rel="nofollow">Quagga</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://hedgedoc.dn42.eu" rel="nofollow">HedgeDoc</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/mikrotik.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/mikrotik.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
