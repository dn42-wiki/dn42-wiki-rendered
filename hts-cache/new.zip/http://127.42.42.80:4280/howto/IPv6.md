<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-309be032396e783b13a47df58f389b7c8e11c2b2d42640560b874f677c25f6e5.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">

  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/IPv6.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-f05401ee374f0c7f48fc2bc08e30b4f4db705861fd5895ed70998683b383bfb5.js" type="text/javascript"></script>
  

  <title>IPv6</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>IPv6</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/IPv6.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <a class="btn btn-sm" id="minibutton-home" href="/">
      Home
    </a>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/overview"
          id="minibutton-overview"
        >
          Overview
        </a>

        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/latest_changes"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </a>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          href="/gollum/history/howto/IPv6.md/"
          id="minibutton-history"
        >
          History
        </a>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    IPv6
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <p><em>Work in progress</em></p>

<h2><a class="anchor" id="introduction" href="#introduction"></a>Introduction</h2>

<p>DN42 is a somewhat unique undertaking, and a great way to learn about networking and routing techs.
If you feel like spicing the challenge up a bit, why not get familiar with IPv6 at the same time ?</p>

<p>There's nothing too different from IPv4, except one major point: it's a separate network space, and therefore you might not be able to reach the IPv4-part of DN42. That is, without NAT64, proxies, etc.. (read more below!) or if you're running dual-stack, both IPv4 and IPv6 at the same time.</p>

<h2><a class="anchor" id="getting-started" href="#getting-started"></a>Getting Started</h2>

<p>If you're already running IPv4 on DN42, here's how to get started:</p>

<ul>
<li>Register an inet6num block on the registry. A /56-size prefix is good, but with the space available in IPv6 space, you can probably go for /48</li>
<li>Setup your interfaces to use them</li>
<li>Negociate with your v6-capable peers to setup peering sessions to allow your v6 prefixes</li>
<li>???</li>
<li>Profit!</li>
</ul>

<p>If not, you can follow the instructions on the <a href="Getting-Started">Getting Started</a> page, as they'll mostly apply to IPv6 aswell.</p>

<h2><a class="anchor" id="what-can-i-do-on-dn42-v6" href="#what-can-i-do-on-dn42-v6"></a>What can i do on DN42-v6 ?</h2>

<p>A fair share of the services are available through IPv6. However some of the well known addresses might not work, so you'll have to find alternative services.</p>

<p>Quick list of some native-IPv6-capable services:</p>

<ul>
<li>Anycast <a href="whois.dn42">whois.dn42</a>
</li>
<li>DNS, including anycast</li>
<li>Media boards, including DN42-Chan</li>
<li>torrents.dn42</li>
<li>wiki.dn42/internal.dn42</li>
<li>Dn42 Exchange: admin.dn42-ix.tk</li>
</ul>

<p>What doesn't work (yet?): </p>

<ul>
<li>Search engines, none seems to support IPv6 currently</li>
<li>Pretty much everything from Freifunk and ChaosVPN</li>
<li>Any services hosted by e-utp.dn42 </li>
</ul>

<h2><a class="anchor" id="accessing-legacy-services-from-an-ipv6-only-stack" href="#accessing-legacy-services-from-an-ipv6-only-stack"></a>Accessing legacy services from an IPv6-only stack</h2>

<p>In order to access legacy IPv4 services from the IPv6 side of DN42, you're going to need some kind of service to jump from one to the other.
This can typically be done in two ways:</p>

<ul>
<li>A dual-stack Proxy with Remote DNS</li>
<li>A dual-stack Router with NAT64, plus DNS64 services</li>
</ul>

<p>It's important to note that since these services require IPv4 connectivity, you can't set them up yourself if you are running IPv6-only. You'll need to ask another DN42 participant to be your provider for these services, effectively using his node as a gateway/proxy.</p>

<h3><a class="anchor" id="with-a-socks5-proxy-and-remote-dns" href="#with-a-socks5-proxy-and-remote-dns"></a>With a SOCKS5 proxy and Remote DNS</h3>

<p>Just set it up like you would usually. Any IPv4 connection going through the proxy will be made to the proxy by IPv6, then from the proxy to target using IPv4.</p>

<h3><a class="anchor" id="nat64-dns64" href="#nat64-dns64"></a>NAT64+DNS64</h3>

<p>In order to maintain backward compatibility, a number of methods have been used to be able to reach IPv4 space from IPv6. NAT-PT was deprecated, so this mostly leaves us with NAT64.
NAT64 simply consists in embedding IPv4 addresses after an IPv6 prefix, and mapping the whole prefix to the whole of IPv4 space. Thanksfully, that's easily doable because we have 128-bit wide addresses in IPv6. As the name implies, we however have to perform Dynamic-NAT on the IPv4 side to squeeze all the incoming v6 space in v4 addresses (though it should be possible to run 1-1 mappings, but in that case, why not get a v4 address and NAT to it to begin with?)</p>

<p>Currently, NAT64 support in DN42 is non-existant, though there are ongoing experimentations with it. Technically, it is possible to announce a global anycast prefix for NAT64, allowing seamless IPv4 connectivity from any properly configured IPv6 host, or any using the DNS64 (which can also be setup on the anycast servers).</p>

<p>DNS64 itself simply allow to synthetizes AAAA records from the received usual A records. Because DNS runs at the transport level and does not care for Layer 3 triffles, this is a service that you can run on your Nameserver even without being Dual-Stack capable. (TODO: DNS64 Howto with BIND9)
As such, any address that can only resolve to IPv4 will now also resolve to an address corresponding to it through the NAT64 prefix.</p>

<h2><a class="anchor" id="routing-to-internet-and-dn42" href="#routing-to-internet-and-dn42"></a>Routing to Internet and DN42</h2>

<p>So now that you've got IPv6 setup for DN42, you'd like to start using it on the Internet aswell. Or maybe you already do. But how to use your services on both public Internet and DN42 ?</p>

<h3><a class="anchor" id="with-npt" href="#with-npt"></a>With NPT</h3>

<p>A first approach is to use NPT: Network Prefix Translation. Yes, this sounds a lot like NAT, but fear not: it does not have most of its problems as it is fully stateless. Initially, the purpose of NPT was to allow multi-homing without an ASN: how can you be reachable through several prefixes allocated by different ISPs ? The IPv6-way of doing it would be to assign multiple addresses from the multiple prefixes to all your nodes, but isn't that just too complicated ?</p>

<p>Enter NPT. Address your services using a reserved private block, and map that block to a public block upon routing to internet. 
For example, if you've been assigned a public /48 prefix, and want to be reachable on DN42 aswell, you can use only ULA addresses from DN42 internally (or your own!), then map them to outside prefixes. Note that they'll need to all use the same prefix size to maintain the one-to-one mapping, so you may have to subnet the public prefix.</p>

<p>In Linux's netfilter, this can be implemented through the use of the NETMAP target, for the example above:
</p><pre class="highlight"><code>ip6tables -t nat -A POSTROUTING -d 2000::/3 -s &lt;DN42-PREFIX&gt;:&lt;SUBNET&gt;::/56 -j NETMAP --to &lt;PUBLIC-PREFIX&gt;:&lt;SUBNET&gt;::/56; # Map ULA to the public prefix for outgoing packets
ip6tables -t nat -A PREROUTING -s 2000::/3 -d &lt;PUBLIC-PREFIX&gt;:&lt;SUBNET&gt;::/56 -j NETMAP --to &lt;DN42-PREFIX&gt;:&lt;SUBNET&gt;::/56; # Map public prefix to ULA for incoming packets</code></pre>

<h3><a class="anchor" id="with-multiple-prefixes" href="#with-multiple-prefixes"></a>With Multiple Prefixes</h3>

<h2><a class="anchor" id="more-info" href="#more-info"></a>More Info</h2>

<p>This page is a work in progress. Please contact Fira if you feel like more information should be added here! Also see ASN 4242423218 for an example of IPv6-only AS on DN42.</p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
<li>
<a href="/Home" rel="nofollow">Home</a>

<ul>
<li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
<li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
<li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
<li><a href="/howto/Bird-communities" rel="nofollow">BGP communities</a></li>
<li><a href="/FAQ" rel="nofollow">FAQ</a></li>
</ul>
</li>
</ul>

<ul>
<li>
<p>How-To</p>

<ul>
<li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
<li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
<li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
<li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
<li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
<li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
<li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
<li>
<a href="/howto/Bird" rel="nofollow">Bird</a> / <a href="/howto/Bird2" rel="nofollow">Bird2</a>
</li>
<li><a href="/howto/Quagga" rel="nofollow">Quagga</a></li>
<li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
<li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
<li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
<li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
<li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
<li><a href="/howto/vyos" rel="nofollow">VyOS</a></li>
<li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
</ul>
</li>
<li>
<p>Services</p>

<ul>
<li><a href="/services/IRC" rel="nofollow">IRC</a></li>
<li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
<li><a href="/services/DNS" rel="nofollow">DNS</a></li>
<li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
<li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
<li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
<li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
<li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
<li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
<li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
</ul>
</li>
<li>
<p>Internal</p>

<ul>
<li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
<li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
<li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
<li>
<a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a><br />
</li>
<li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
</ul>
</li>
<li>
<p>External Tools</p>

<ul>
<li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
<li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
</ul>
</li>
</ul>

<hr />

	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p>Hosted by: <a href="mailto:xuu@sour.is" rel="nofollow">xuu</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">nurtic-vibe</a>, <a href="mailto:tom@xcv.vc" rel="nofollow">toBee</a>, <a href="mailto:dn42@burble.com" rel="nofollow">burble</a> | Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a></p>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/IPv6.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/IPv6.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
