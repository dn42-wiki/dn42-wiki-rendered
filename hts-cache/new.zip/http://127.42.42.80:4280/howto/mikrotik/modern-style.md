<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/mikrotik/modern-style.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>modern-style</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>modern-style</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/mikrotik/modern-style.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/mikrotik/modern-style.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    modern-style
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/mikrotik/">mikrotik</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <p>This page is a scratchpad for a fully modernised (2026) config running on the latest version of RouterOS (7.22.1). It will use wireguard, BGP with Multihop and Extended Nexthop, and link-local addressing for address space efficiency.</p>

<h1><a class="anchor" id="wireguard-tunnel-setup" href="#wireguard-tunnel-setup"></a>Wireguard tunnel setup</h1>

<p>Wireguard seems to be the most popular option for peering now, so we'll use that. The first step is to setup a Wireguard interface. You can use a single interface for all connections if you want, but I prefer to make one for each peer, as it can make problems easier to debug.</p>

<p>For the sake of this example we'll pretend we're peering with Kioubit, one of the most-connected and easiest to connect-with systems on DN42.</p>

<h2><a class="anchor" id="create-the-interface" href="#create-the-interface"></a>Create the interface</h2>

<p>We have to do this first so we can gather the connection details, which will be used to setup the peering.</p>

<p>The standard port for Wireguard listeners is 51820, but you can use anything you like. An MTU of 1420 is recommended to avoid fragmentation and firewall issues.</p>

<pre class="highlight"><code>/interface wireguard
add name=DN42-KIOUBIT listen-port=51820 mtu=1420</code></pre>

<p>Without any extra parameters, it'll automatically generate a new private and public key for you. Grab the public key, you'll need that to setup your peering connection.
</p><pre class="highlight"><code>/interface/wireguard/print where name="DN42-KIOUBIT"

[furinkan@helian] &gt; /interface/wireguard/print where name="DN42-KIOUBIT"       
 0  R name="DN42-KIOUBIT" mtu=1420 listen-port=51820 public-key="mGRGoKPl6fRffzUovFp/8AoOtHjCrWeEMN9/9NsVp2Q="</code></pre>

<h2><a class="anchor" id="exchange-connection-parameters" href="#exchange-connection-parameters"></a>Exchange connection parameters</h2>

<p>If connecting to a system with a self-serve automatic peering interface, now is the time to use it.</p>

<p>You will need:</p>
<ul>
  <li>Your AS number</li>
  <li>Your public IP address that they can connect to</li>
  <li>Your listening port for Wireguard, eg. 51820 as above</li>
  <li>Your public key for your Wireguard interface</li>
  <li>An IPv4 address for your local end of the tunnel, this is often an address in your DN42 address allocation, but can also be any private-range address like 192.168.x.x; however this may be optional if you use…</li>
  <li>An IPv6 address for your local end of the tunnel. Unlike IPv4, it's possible to use a pure link-local address, like <code>fe80::1234</code>
</li>
  <li>To know if your BGP daemon supports the Multihop and Extended Next Hop capabilities</li>
</ul>

<p>You will receive:</p>
<ul>
  <li>Their AS number</li>
  <li>Their public IP address and port to use for the wireguard connection</li>
  <li>Their Wireguard public key</li>
  <li>The IPv4 and/or IPv6 address for the remote end of the tunnel</li>
</ul>

<h2><a class="anchor" id="add-the-wireguard-peer" href="#add-the-wireguard-peer"></a>Add the Wireguard peer</h2>

<pre class="highlight"><code>/interface wireguard peers
add name=DN42-KIOUBIT interface=&lt;THE_INTERFACE_YOU_CREATED_EARLIER&gt; endpoint-address=&lt;THEIR_PUBLIC_ADDRESS&gt; endpoint-port=&lt;THEIR_WIREGUARD_PORT&gt; public-key="&lt;THEIR_WIREGUARD_PUBLIC_KEY&gt;" allowed-address=fd00::/8,fe80::/10,172.20.0.0/14</code></pre>

<p>At this point the tunnel should come up on its own, assuming the other end is already configured. However, it's not useful yet without an IP address attached to it.</p>

<h2><a class="anchor" id="add-an-ip-address-to-your-end-of-the-tunnel" href="#add-an-ip-address-to-your-end-of-the-tunnel"></a>Add an IP address to your end of the tunnel</h2>

<p>Once the tunnel is established you will need an address at each end of the link for routing to work. In this Kioubit example we only need an IPv6 address, because we can route IPv4 traffic between IPv6 BGP peers.</p>

<p>Kioubit is using fe80::ade0 on the remote end of the tunnel. We also chose a link-local address for our end of the tunnel, it's <code>fe80::</code> plus the last four digits of our AS number. You'll notice that the remote address does not need to be adjacent at all - this is the beauty of IPv6 link-local addressing.
</p><pre class="highlight"><code>/ipv6 address
add address=fe80::2762/128 interface=DN42-KIOUBIT advertise=no</code></pre>

<p>If you're using an IPv4 address, you can attach it to the loopback interface. This allows the address to be reused for multiple peering connections, without being "owned" by any of the wireguard interfaces.
</p><pre class="highlight"><code>/ip/address
add address=172.31.254.254 interface=lo</code></pre>

<h2><a class="anchor" id="test-connectivity" href="#test-connectivity"></a>Test connectivity</h2>

<p>You should be able to ping the remote end of the tunnel now. If so, packets can make it there and back, correctly routed. Notice that we're appending the interface name to the IP address. This is necessary for IPv6 link-local addresses because the system doesn't know which interface to send the pings out of.
</p><pre class="highlight"><code>[furinkan@helian] &gt; ping fe80::ade0%DN42-KIOUBIT
  SEQ HOST                                     SIZE TTL TIME       STATUS
    0 fe80::ade0                                 56  64 133ms383us echo reply
    1 fe80::ade0                                 56  64 136ms229us echo reply
    sent=2 received=2 packet-loss=0% min-rtt=133ms383us avg-rtt=134ms806us max-rtt=136ms229us</code></pre>

<p>If you're using IPv4 inside the tunnel, it'll look something like this:
</p><pre class="highlight"><code>[furinkan@helian] &gt; ping 172.20.53.105%DN42-KIOUBIT
  SEQ HOST                                     SIZE TTL TIME       STATUS
    0 172.20.53.105                              56  64 133ms544us
    1 172.20.53.105                              56  64 131ms672us
    2 172.20.53.105                              56  64 133ms521us
    sent=3 received=3 packet-loss=0% min-rtt=131ms672us avg-rtt=132ms912us max-rtt=133ms544us</code></pre>

<p>Notice that we specified the egress interface again, you don't normally do this with IPv4 addresses. The router doesn't know how to get to the destination because it doesn't belong to a known subnet - it doesn't have a route!</p>

<p>We'll add a static route to fix this:
</p><pre class="highlight"><code>/ip route
add dst-address=172.20.53.105/32 gateway=DN42-KIOUBIT

[furinkan@helian] &gt; ping 172.20.53.105
  SEQ HOST                                     SIZE TTL TIME       STATUS
    0 172.20.53.105                              56  64 131ms152us
    1 172.20.53.105                              56  64 131ms128us
    sent=2 received=2 packet-loss=0% min-rtt=131ms128us avg-rtt=131ms140us max-rtt=131ms152us</code></pre>

<p>That's better. Now we're ready for some BGP peering.</p>

<h1><a class="anchor" id="setup-bgp" href="#setup-bgp"></a>Setup BGP</h1>

<p>We'll create an instance for DN42, some basic route filters for security, a template to hold common DN42 peering settings, then finally the actual peering connection.</p>

<h2><a class="anchor" id="instance" href="#instance"></a>Instance</h2>

<p>An important part of the routing protocols is your router's ID, a 32-bit value usually written like an IPv4 address. It's common convention to use your router's IP address as the router ID, so we'll do that here too. I've picked the highest IP address in our IPv4 allocation as the router's IP, which we'll also use as the router's ID.</p>

<p>This gives a text label to our router ID:
</p><pre class="highlight"><code>/routing id
add id=172.22.124.62 name=my-DN42-router select-dynamic-id=""</code></pre>

<p>Create the BGP instance, which will identify itself with your AS number:
</p><pre class="highlight"><code>/routing bgp instance
add as=424242&lt;YOUR_ASN&gt; name=DN42 router-id=my-DN42-router</code></pre>

<h2><a class="anchor" id="route-filters" href="#route-filters"></a>Route filters</h2>

<p>Filters are necessary to prevent other people from hijacking our routing table. A malicious peer could send routes that override your default route to public internet services like Google, government services, your online banking, etc.</p>

<p>These rules are reasonably tight, you can tighten or relax them as desired. <a href="/Interconnections">Interconnected networks'</a> IPv4 ranges are included as well, if you don't want then you can ignore that rule.
</p><pre class="highlight"><code>/routing filter rule
add chain=dn42-in comment="reject prefixes clashing with home network" disabled=no rule="if (dst in 192.168.0.0/16 &amp;&amp; dst-len &gt;= 16) { reject }"
add chain=dn42-in comment="reject v4 auto-addressing prefixes" rule="if (dst in 169.254.0.0/16 &amp;&amp; dst-len &gt;= 16) { reject }"
add chain=dn42-in comment="accept DN42 v4 prefixes" disabled=no rule="if (dst in 172.20.0.0/14) { accept }"
add chain=dn42-in comment="accept DN42 interconnected network v4 prefixes" disabled=no rule="if (dst in 10.0.0.0/8) { accept }"
add chain=dn42-in comment="accept DN42 and interconnected v6 prefixes" disabled=no rule="if (dst in fd00::/8) { accept }"</code></pre>

<pre class="highlight"><code>/routing filter rule
add chain=dn42-out comment="don't advertise our home network" rule="if (dst in 192.168.0.0/16 &amp;&amp; dst-len &gt;= 16) { reject }"
add chain=dn42-out comment="don't advertise v4 auto-addressing prefixes" rule="if (dst in 169.254.0.0/16 &amp;&amp; dst-len &gt;= 16) { reject }"
add chain=dn42-out comment="tag my prefixes with community" disabled=no rule="if ( dst in 172.20.0.0/14 &amp;&amp; bgp-communities-empty ) { append bgp-communities DN42-communities; }"
add chain=dn42-out comment="advertise DN42 v4 prefixes" disabled=no rule="if (dst in 172.20.0.0/14) { accept }"
add chain=dn42-out comment="advertise DN42 interconnected network v4 prefixes" disabled=no rule="if (dst in 10.0.0.0/8) { accept }"
add chain=dn42-out comment="tag my IPv6 prefixes with community" disabled=no rule="if ( dst in fd00::/8 &amp;&amp; bgp-communities-empty ) { append bgp-communities DN42-communities; }"
add chain=dn42-out comment="advertise DN42 and interconnected v6 prefixes" disabled=no rule="if (dst in fd00::/8) { accept }"</code></pre>

<h2><a class="anchor" id="connection-template" href="#connection-template"></a>Connection template</h2>

<p>WIP</p>

<p>Create a template with the common BGP settings used for DN42:
</p><pre class="highlight"><code>/routing bgp template
set DN42-thighhighs afi=ip,ipv6 as=424242&lt;YOUR_ASN&gt; input.filter=dn42-in multihop=yes name=DN42-thighhighs output.filter-chain=dn42-out .redistribute=connected,bgp routing-table=main</code></pre>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>, <a href="https://iedon.net/post/24" rel="nofollow">IEDON-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>, <a href="https://dn42.jp/" rel="nofollow">dn42.jp</a> (wiki-go)</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/mikrotik/modern-style.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/mikrotik/modern-style.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
