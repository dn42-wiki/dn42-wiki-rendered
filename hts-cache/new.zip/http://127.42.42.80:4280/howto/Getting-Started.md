<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/Getting-Started.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Getting-Started</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Getting-Started</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/Getting-Started.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/Getting-Started.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Getting-Started
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <p>You want to join dn42, but you don't know where to start. This guide gives general guidelines about dn42 and routing in general, but it assumes that you are knowledgeable with routing.</p>

<h1><a class="anchor" id="requirements" href="#requirements"></a>Requirements</h1>

<ul>
  <li>you have at least one router running 24/7. Any Linux or BSD box can be turned into a router. If your home router runs OpenWRT, you might consider using it for dn42.</li>
  <li>your router is able to establish network tunnels over the Internet (Wireguard, GRE, OpenVPN, IPSec, Tinc…). Beware, your network operator might filter this kind of traffic, e.g. in schools or universities.</li>
  <li>you are generally knowledgeable with networking and routing (i.e. you've heard about BGP, IGP, forwarding, and you're willing to configure a BGP router such as FRR or Bird)</li>
</ul>

<h1><a class="anchor" id="formalities" href="#formalities"></a>Formalities</h1>

<p>Don't worry, it's not as tedious as registering with a RIR ;)</p>

<h2><a class="anchor" id="subscribe-to-the-mailing-list" href="#subscribe-to-the-mailing-list"></a>Subscribe to the mailing list</h2>

<p>This is important, as it allows to stay up-to-date on best practices, new services, security issues…</p>

<p>See <a href="/contact#contact_mailing-list">Contact</a> to subscribe.</p>

<h2><a class="anchor" id="fill-in-the-registry" href="#fill-in-the-registry"></a>Fill in the registry</h2>

<p>You must create several objects in the DN42 registry: <a href="https://git.dn42.dev/dn42/registry">https://git.dn42.dev/dn42/registry</a></p>

<p>The registry is a git repository, objects are created by forking the main repository, making your changes and then submitting a pull request for review. There are detailed instructions in the registry <a href="https://git.dn42.dev/dn42/registry/src/branch/master/README.md">README</a> how to do this. See also the the generic git documentation <a href="https://git-scm.com/book/en/v2/Git-Basics-Working-with-Remotes">git documentation</a> and guides on <a href="https://help.github.com/en/github/using-git">github</a> for how to use git to work with remote repositories.</p>

<p>While filling out the objects in the DN42 registry make sure to refer to the <a href="https://explorer.dn42.dev/#/schema">schema</a> to speed up the review process.</p>

<p>When submitting your pull request, you must squash multiple changes to a single commit, again there are instructions in the <a href="https://git.dn42.dev/dn42/registry/src/branch/master/README.md">README</a> for how to do this.</p>

<p>Remember to add authentication to your <code>mntner</code> object, and <a href="/howto/Registry-Authentication">sign your commit</a></p>

<p>The registry includes a number of scripts to help check your request:</p>

<ul>
  <li>
<code>fmt-my-stuff &lt;FOO&gt;-MNT</code>: automatically fixes minor formatting errors</li>
  <li>
<code>check-my-stuff &lt;FOO&gt;-MNT</code>: validates your objects against the registry schema</li>
  <li>
<code>check-pol origin/master &lt;FOO&gt;-MNT</code>: checks for policy violations</li>
  <li>
<code>squash-my-commits</code>: automatically update and squash your local commits</li>
  <li>
<code>sign-my-commit</code>: sign your commit using a pgp key or standard SSH signing</li>
</ul>

<p>The registry maintainers run the checking scripts against each request, so please run these yourself first to check for simple errors.</p>

<p>Do browse through the registry and look at the <a href="https://git.dn42.dev/dn42/registry/pulls">pull request queue</a> to see examples, understand how the process works and see the types of questions asked by the registry maintainers.</p>

<p><em>You should not use the gitea web interface to edit files, doing so would create a large number of commits and prevents running of the registry scripts</em></p>

<hr />

<p>This example assumes that your name is <code>&lt;FOO&gt;</code>, part of an organisation called <code>&lt;ORG-FOO&gt;</code> (for instance, your hackerspace). <em>Organisation objects are not required if your are registering as an individual</em>. Obviously, these should be replaced by the appropriate values in all examples below.</p>

<p>We will create several types of objects:</p>
<ul>
  <li>
<strong>maintainer</strong> objects, which are authenticated so that only you can edit your own objects</li>
  <li>
<strong>person</strong> objects, which describe people or organisations and provide contact information</li>
  <li>and <strong>resource</strong> objects (AS number, IP subnet, DNS zone, etc).</li>
</ul>

<p>All objects are simple text files in the specific subfolders, but the files do have a particular format. The files should use spaces and not tabs, and the attribute values must start on the 20th column.</p>

<h3><a class="anchor" id="create-a-maintainer-object" href="#create-a-maintainer-object"></a>Create a maintainer object</h3>

<p>Create a <code>mntner</code> object in <code>data/mntner/</code> named <code>&lt;FOO&gt;-MNT</code>. It will be used to edit all the objects that are under your responsibility.</p>

<ul>
  <li>use <code>&lt;FOO&gt;-MNT</code> as <code>mnt-by</code>, otherwise, you won't be able to edit your maintainer object.</li>
  <li>Add an 'auth' attribute so that changes to your objects can be verified.</li>
</ul>

<p>The <code>auth</code> attribute is used to verify changes to your object. There is a separate page on <a href="/howto/Registry-Authentication">registry authentication</a> which details what to include in your mntner object, how to sign and verify your commits.</p>

<p>Common authentication methods are:</p>
<ul>
  <li>PGP Key: <code>auth: pgp-fingerprint &lt;pgp-fingerprint&gt;</code>
</li>
  <li>SSH Key: <code>auth: ssh-{rsa,ed25519} &lt;key&gt;</code>
</li>
</ul>

<p>Example: data/mntner/FOO-MNT
</p><pre class="highlight"><code><span class="n">mntner</span>:             <span class="n">FOO</span>-<span class="n">MNT</span>
<span class="n">admin</span>-<span class="n">c</span>:            <span class="n">FOO</span>-<span class="n">DN42</span>
<span class="n">tech</span>-<span class="n">c</span>:             <span class="n">FOO</span>-<span class="n">DN42</span>
<span class="n">mnt</span>-<span class="n">by</span>:             <span class="n">FOO</span>-<span class="n">MNT</span>
<span class="n">auth</span>:               <span class="n">pgp</span>-<span class="n">fingerprint</span> <span class="m">0123456789</span><span class="n">ABCDEF0123456789ABCDEF01234567</span>
<span class="n">source</span>:             <span class="n">DN42</span></code></pre>

<h3><a class="anchor" id="create-person-objects" href="#create-person-objects"></a>Create person objects</h3>

<p>Create a  <code>person</code> object in <code>data/person/</code> for <strong>yourself</strong> (not your organisation/hackerspace/whatever).</p>

<ul>
  <li>use something like <code>&lt;FOO&gt;-DN42</code> as <code>nic-hdl</code>, it should end with <code>-DN42</code>.</li>
  <li>the <code>person</code> field is more freeform, you may use your nickname or even real name here.</li>
  <li>provide an email.</li>
  <li>you may provide additional ways of contacting you, using one or more <code>contact</code> field. For instance <code>xmpp:luke@theforce.net</code>, <code>irc:luke42@hackint</code>, <code>twitter: TheGreatLuke</code>.</li>
  <li>you may wish to add other fields, such as <code>pgp-fingerprint</code>, <code>remarks</code>, and so on.</li>
  <li>don't forget to set <code>mnt-by</code> to <code>&lt;FOO&gt;-MNT</code>.</li>
</ul>

<p><strong>Data Privacy</strong></p>

<p>Contact attributes are optional but DN42 is a dynamic network and being able to contact users is really important if there are changes or problems. However, please also be aware that the DN42 registry is a public resource and you must assume that any details provided will be made public and cannot be fully removed. If this is a concern for you, please do not provide bogus contact details; simply provide anonymous details that are specific for use within DN42 or leave them out entirely.</p>

<p>Example: data/person/FOO-DN42
</p><pre class="highlight"><code><span class="n">person</span>:             <span class="n">John</span> <span class="n">Doe</span>
<span class="n">e</span>-<span class="n">mail</span>:             <span class="n">john</span>.<span class="n">doe</span>@<span class="n">example</span>.<span class="n">com</span>
<span class="n">nic</span>-<span class="n">hdl</span>:            <span class="n">FOO</span>-<span class="n">DN42</span>
<span class="n">mnt</span>-<span class="n">by</span>:             <span class="n">FOO</span>-<span class="n">MNT</span>
<span class="n">source</span>:             <span class="n">DN42</span></code></pre>

<hr />

<p><em>(Optional)</em>
<strong>Organisations are not required if you are joining dn42 as an individual</strong></p>

<p>If you intend to register resources for an organisation (e.g. your hackerspace), you must also create an <code>organisation</code> object for your organisation:</p>

<ul>
  <li>
<code>organisation</code> is of the form <code>&lt;ORG-FOO&gt;</code>.</li>
  <li>
<code>org-name</code> should be the name of your organisation.</li>
  <li>
<code>e-mail</code> should be a contact address for your organisation, or maybe a mailing list (but people should be able to send email without subscribing).</li>
  <li>
<code>admin-c</code>, <code>tech-c</code>, and <code>abuse-c</code> may point to <code>person</code> objects responsible for the respective role in your organisation.</li>
  <li>you may provide a website (<code>www</code> field).</li>
  <li>don't forget to set <code>mnt-by</code> to <code>&lt;FOO&gt;-MNT</code>, since you're managing this object on behalf of your organisation.</li>
</ul>

<p>Example: data/organisation/ORG-EXAMPLE
</p><pre class="highlight"><code><span class="n">organisation</span>:       <span class="n">ORG</span>-<span class="n">FOO</span>
<span class="n">org</span>-<span class="n">name</span>:           <span class="n">Foo</span> <span class="n">Organisation</span>
<span class="n">admin</span>-<span class="n">c</span>:            <span class="n">FOO</span>-<span class="n">DN42</span>
<span class="n">tech</span>-<span class="n">c</span>:             <span class="n">FOO</span>-<span class="n">DN42</span>
<span class="n">mnt</span>-<span class="n">by</span>:             <span class="n">FOO</span>-<span class="n">MNT</span>
<span class="n">source</span>:             <span class="n">DN42</span></code></pre>

<h3><a class="anchor" id="guidelines-for-resource-objects" href="#guidelines-for-resource-objects"></a>Guidelines for resource objects</h3>

<p>From now on, you should use:</p>

<ul>
  <li>
<code>admin-c: &lt;FOO&gt;-DN42</code> and <code>tech-c: &lt;FOO&gt;-DN42</code> for your own resources.</li>
  <li>
<code>admin-c: &lt;FOO&gt;-DN42</code>, <code>tech-c: &lt;FOO&gt;-DN42</code> and <code>org: &lt;ORG-FOO&gt;</code> for the resources of your organisation.</li>
  <li>
<code>mnt-by: &lt;FOO&gt;-MNT</code> for all objects, so that you can edit them later.</li>
</ul>

<p>This applies to AS numbers, network prefixes, routes, DNS records…</p>

<h3><a class="anchor" id="register-an-as-number" href="#register-an-as-number"></a>Register an AS number</h3>

<p>To register an AS number, create an <code>as-name</code> object in <code>data/aut-num/</code>.
<code>as-name</code> should be a name for your AS.</p>

<p>Your AS number can be chosen arbitrarily in the dn42 ASN space, see the <a href="https://git.dn42.dev/dn42/registry/src/master/data/as-block">as-block objects</a> in the registry.</p>

<p><strong>You should allocate your AS number in the 4242420000-4242423999 range</strong></p>

<p><a href="https://explorer.burble.com/free#/asn">dn42regsrv</a> includes a page for finding free ASN. For a list of currently assigned AS numbers browse the registry data/aut-num/ directory or <a href="https://explorer.burble.com/#/aut-num/">online</a>.</p>

<p>If you intend to use an ASN outside of the native dn42 ranges, please check that it doesn't clash with the [Freifunk AS-Numbers] (http://wiki.freifunk.net/AS-Nummern) or other networks (ChaosVPN, etc).</p>

<p>Internet ASNs may be used, but you must take care to clearly separate Internet and DN42 routes and prevent routes leaking between the networks. For Internet ASNs, the <code>source</code> attribute must be the originating registry and you will be required to prove you are the owner of the ASN.</p>

<p>If unsure, ask on the mailing list or IRC.</p>

<p>Example: data/aut-num/AS4242423999
</p><pre class="highlight"><code><span class="n">aut</span>-<span class="n">num</span>:            <span class="n">AS4242423999</span>
<span class="n">as</span>-<span class="n">name</span>:            <span class="n">AS</span>-<span class="n">FOO</span>-<span class="n">DN42</span>
<span class="n">admin</span>-<span class="n">c</span>:            <span class="n">FOO</span>-<span class="n">DN42</span>
<span class="n">tech</span>-<span class="n">c</span>:             <span class="n">FOO</span>-<span class="n">DN42</span>
<span class="n">mnt</span>-<span class="n">by</span>:             <span class="n">FOO</span>-<span class="n">MNT</span>
<span class="n">source</span>:             <span class="n">DN42</span></code></pre>

<h3><a class="anchor" id="register-a-network-prefix" href="#register-a-network-prefix"></a>Register a network prefix</h3>

<h4><a class="anchor" id="ipv6" href="#ipv6"></a>IPv6</h4>

<p>To register an IPv6 prefix, you create an <code>inet6num</code> object. dn42 uses the fd00::/8 (<a href="https://tools.ietf.org/html/rfc4193">ULA</a>) range. A single /48 allocation is typical and will likely provide more than enough room for all devices you will ever connect. The smallest announceable prefix length is /64.</p>

<p>dn42 is interconnected with other networks, like icvpn, which also use the same ULA range so a registration in the dn42 registry can't prevent IPv6 conflicts. A fully random prefix (see <a href="https://tools.ietf.org/html/rfc4193">RFC4193</a>) is recommended; finding a conflict and needing to renumber your network is no fun.</p>

<p>A few websites can generate random ULA prefixes for you:</p>

<ul>
  <li><a href="https://explorer.burble.com/free#/6">dn42regsrv</a></li>
  <li><a href="https://simpledns.com/private-ipv6">SimpleDNS</a></li>
  <li><a href="https://www.ultratools.com/tools/rangeGenerator">Ultratools</a></li>
</ul>

<p>or a small script is available: <a href="https://git.dn42.dev/netravnen/dn42-repo-utils/src/master/ulagen.py">ulagen.py</a></p>

<p>example: data/inet6num/fd35:4992:6a6d::_48
</p><pre class="highlight"><code><span class="n">inet6num</span>:           <span class="n">fd35</span>:<span class="m">4992</span>:<span class="m">6</span><span class="n">a6d</span>:<span class="m">0000</span>:<span class="m">0000</span>:<span class="m">0000</span>:<span class="m">0000</span>:<span class="m">0000</span> - <span class="n">fd35</span>:<span class="m">4992</span>:<span class="m">6</span><span class="n">a6d</span>:<span class="n">ffff</span>:<span class="n">ffff</span>:<span class="n">ffff</span>:<span class="n">ffff</span>:<span class="n">ffff</span>
<span class="n">cidr</span>:               <span class="n">fd35</span>:<span class="m">4992</span>:<span class="m">6</span><span class="n">a6d</span>::/<span class="m">48</span>
<span class="n">netname</span>:            <span class="n">FOO</span>-<span class="n">NETWORK</span>
<span class="n">descr</span>:              <span class="n">Network</span> <span class="n">of</span> <span class="n">FOO</span>
<span class="n">country</span>:            <span class="n">XD</span>
<span class="n">admin</span>-<span class="n">c</span>:            <span class="n">FOO</span>-<span class="n">DN42</span>
<span class="n">tech</span>-<span class="n">c</span>:             <span class="n">FOO</span>-<span class="n">DN42</span>
<span class="n">mnt</span>-<span class="n">by</span>:             <span class="n">FOO</span>-<span class="n">MNT</span>
<span class="n">status</span>:             <span class="n">ASSIGNED</span>
<span class="n">source</span>:             <span class="n">DN42</span></code></pre>

<h4><a class="anchor" id="ipv4-legacy" href="#ipv4-legacy"></a>IPv4 (Legacy)</h4>

<p>If you also want to register an IPv4 network prefix, simply create an <code>inetnum</code> object.</p>

<p>You may choose your network prefix in one of the currently open netblocks. You can get a list of unassigned subnets on the following site, please mind the allocation guideline below.</p>

<ul>
  <li><a href="https://explorer.burble.com/free#/4">Free blocks in dn42regsrv</a></li>
  <li><a href="https://dn42.us/peers/free">Open Netblocks</a></li>
</ul>

<p>If there are no free subnets of the size you want, you may split a larger block as required.</p>

<p>Check the registry (data/inetnum) to make sure no-one else has allocated the same prefix. There are some IP ranges that are not open for assignments or are reserved for specific uses, so you should also check that the parent block has an 'open' policy. A quick and simple way to see the block policies is to run <code>grep "^policy" data/inetnum/*</code>.</p>

<table>
  <thead>
    <tr>
      <th style="text-align:right;">Size</th>
      <th style="text-align:left;">Comment</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:right;">/29</td>
      <td style="text-align:left;">starter pack</td>
    </tr>
    <tr>
      <td style="text-align:right;">/28</td>
      <td style="text-align:left;">usually enough</td>
    </tr>
    <tr>
      <td style="text-align:right;"><strong>/27</strong></td>
      <td style="text-align:left;"><strong>default allocation</strong></td>
    </tr>
    <tr>
      <td style="text-align:right;">/26</td>
      <td style="text-align:left;">usually enough</td>
    </tr>
    <tr>
      <td style="text-align:right;">/25</td>
      <td style="text-align:left;">still a lot of IPs!</td>
    </tr>
    <tr>
      <td style="text-align:right;">/24</td>
      <td style="text-align:left;">are you an organization?</td>
    </tr>
  </tbody>
</table>

<p>The current guideline is to allocate a /27 or smaller by default, keeping space for up to a /26 if possible. Don't allocate more than a /25 worth of addresses and please <strong>think before you allocate</strong>.</p>

<p>dn42 typically uses point-to-point addressing in VPN tunnels making transit network unnecessary, a single IP address per host should be sufficient. If you are going to have 2-3 servers, a /28 is plenty; same will go for most home-networks. You cannot, however, allocate prefixes smaller than /29. dn42 is not the public internet, but our IPv4-space is valuable too!</p>

<p>If you need a /24 or larger, please ask in the IRC chan or on the mailing list and expect to provide justification. You should also ensure the range you've requested is in a suitable block.</p>

<p><strong>Note:</strong> Reverse DNS works with <em>any</em> prefix length, as long as your <a href="/services/DNS">recursive nameserver</a> supports <a href="https://www.ietf.org/rfc/rfc2317.txt">RFC 2317</a>. Don't go for a /24 <em>just to have RDNS</em>.</p>

<p>example: data/inetnum/172.20.150.0_27
</p><pre class="highlight"><code><span class="n">inetnum</span>:            <span class="m">172</span>.<span class="m">20</span>.<span class="m">150</span>.<span class="m">0</span> - <span class="m">172</span>.<span class="m">20</span>.<span class="m">150</span>.<span class="m">31</span>
<span class="n">cidr</span>:               <span class="m">172</span>.<span class="m">20</span>.<span class="m">150</span>.<span class="m">0</span>/<span class="m">27</span>
<span class="n">netname</span>:            <span class="n">FOO</span>-<span class="n">NETWORK</span>
<span class="n">descr</span>:              <span class="n">Network</span> <span class="n">of</span> <span class="n">FOO</span>
<span class="n">country</span>:            <span class="n">XD</span>
<span class="n">admin</span>-<span class="n">c</span>:            <span class="n">FOO</span>-<span class="n">DN42</span>
<span class="n">tech</span>-<span class="n">c</span>:             <span class="n">FOO</span>-<span class="n">DN42</span>
<span class="n">mnt</span>-<span class="n">by</span>:             <span class="n">FOO</span>-<span class="n">MNT</span>
<span class="n">status</span>:             <span class="n">ASSIGNED</span>
<span class="n">source</span>:             <span class="n">DN42</span></code></pre>

<h4><a class="anchor" id="create-route-objects" href="#create-route-objects"></a>Create route objects</h4>

<p>If you plan to announce your prefixes in dn42, which you probably want in most cases, you will also need to create a <code>route6</code> object for ipv6 prefixes and a <code>route</code> object for ipv4 prefixes. This information is used for Route Origin Authorization (ROA) checks. If you skip this step, your network will probably get filtered by most major peers.  Checking ROA will prevent (accidental) hijacking of other people's prefixes.</p>

<p>example: data/route6/fd35:4992:6a6d::_48
</p><pre class="highlight"><code><span class="n">route6</span>:             <span class="n">fd35</span>:<span class="m">4992</span>:<span class="m">6</span><span class="n">a6d</span>::/<span class="m">48</span>
<span class="n">origin</span>:             <span class="n">AS4242423999</span>
<span class="n">max</span>-<span class="n">length</span>:         <span class="m">48</span>
<span class="n">mnt</span>-<span class="n">by</span>:             <span class="n">FOO</span>-<span class="n">MNT</span>
<span class="n">source</span>:             <span class="n">DN42</span></code></pre>

<p>example data/route/172.20.150.0_27:
</p><pre class="highlight"><code><span class="n">route</span>:              <span class="m">172</span>.<span class="m">20</span>.<span class="m">150</span>.<span class="m">0</span>/<span class="m">27</span>
<span class="n">origin</span>:             <span class="n">AS4242423999</span>
<span class="n">max</span>-<span class="n">length</span>:         <span class="m">27</span>
<span class="n">mnt</span>-<span class="n">by</span>:             <span class="n">FOO</span>-<span class="n">MNT</span>
<span class="n">source</span>:             <span class="n">DN42</span></code></pre>
<strong>Note</strong>: the "max-length" should be the same as the prefix length (i.e. 27 for default ipv4 allocation size and 48 for default ipv6 allocation size) except if you have special needs in announcing larger prefixes

<h4><a class="anchor" id="dns-and-domain-registration" href="#dns-and-domain-registration"></a>DNS and Domain Registration</h4>

<p><em>(Optional)</em>
To register a domain name, create a <code>dns</code> object in the data/dns directory.
Domain names and nserver attributes must be lowercase.</p>

<p>example: data/dns/foo.dn42
</p><pre class="highlight"><code><span class="n">domain</span>:             <span class="n">foo</span>.<span class="n">dn42</span>
<span class="n">admin</span>-<span class="n">c</span>:            <span class="n">FOO</span>-<span class="n">DN42</span>
<span class="n">tech</span>-<span class="n">c</span>:             <span class="n">FOO</span>-<span class="n">DN42</span>
<span class="n">mnt</span>-<span class="n">by</span>:             <span class="n">FOO</span>-<span class="n">MNT</span>
<span class="n">nserver</span>:            <span class="n">ns1</span>.<span class="n">foo</span>.<span class="n">dn42</span> <span class="m">172</span>.<span class="m">20</span>.<span class="m">150</span>.<span class="m">1</span>
<span class="n">nserver</span>:            <span class="n">ns1</span>.<span class="n">foo</span>.<span class="n">dn42</span> <span class="n">fd35</span>:<span class="m">4992</span>:<span class="m">6</span><span class="n">a6d</span>:<span class="m">53</span>::<span class="m">1</span>
<span class="n">nserver</span>:            <span class="n">ns2</span>.<span class="n">foo</span>.<span class="n">dn42</span> <span class="m">172</span>.<span class="m">20</span>.<span class="m">150</span>.<span class="m">2</span>
<span class="n">nserver</span>:            <span class="n">ns2</span>.<span class="n">foo</span>.<span class="n">dn42</span> <span class="n">fd35</span>:<span class="m">4992</span>:<span class="m">6</span><span class="n">a6d</span>:<span class="m">53</span>::<span class="m">2</span>
<span class="n">source</span>:             <span class="n">DN42</span></code></pre>

<p>You can also add DNSSEC delegations using <code>ds-rdata</code> attributes to your domain:</p>

<pre class="highlight"><code><span class="n">ds</span>-<span class="n">rdata</span>:           <span class="m">61857</span> <span class="m">13</span> <span class="m">2</span> <span class="n">bd35e3efe3325d2029fb652e01604a48b677cc2f44226eeabee54b456c67680c</span></code></pre>

<p>For reverse DNS, add <code>nserver</code> attributes to you inet{,6}num objects:</p>

<pre class="highlight"><code><span class="n">inet6num</span>:           <span class="n">fd35</span>:<span class="m">4992</span>:<span class="m">6</span><span class="n">a6d</span>:<span class="m">0000</span>:<span class="m">0000</span>:<span class="m">0000</span>:<span class="m">0000</span>:<span class="m">0000</span> - <span class="n">fd35</span>:<span class="m">4992</span>:<span class="m">6</span><span class="n">a6d</span>:<span class="n">ffff</span>:<span class="n">ffff</span>:<span class="n">ffff</span>:<span class="n">ffff</span>:<span class="n">ffff</span>
<span class="n">cidr</span>:               <span class="n">fd35</span>:<span class="m">4992</span>:<span class="m">6</span><span class="n">a6d</span>::/<span class="m">48</span>
<span class="n">netname</span>:            <span class="n">FOO</span>-<span class="n">NETWORK</span>
<span class="n">descr</span>:              <span class="n">Network</span> <span class="n">of</span> <span class="n">FOO</span>
<span class="n">country</span>:            <span class="n">XD</span>
<span class="n">admin</span>-<span class="n">c</span>:            <span class="n">FOO</span>-<span class="n">DN42</span>
<span class="n">tech</span>-<span class="n">c</span>:             <span class="n">FOO</span>-<span class="n">DN42</span>
<span class="n">mnt</span>-<span class="n">by</span>:             <span class="n">FOO</span>-<span class="n">MNT</span>
<span class="n">status</span>:             <span class="n">ASSIGNED</span>
<span class="n">nserver</span>:            <span class="n">ns1</span>.<span class="n">foo</span>.<span class="n">dn42</span>
<span class="n">nserver</span>:            <span class="n">ns2</span>.<span class="n">foo</span>.<span class="n">dn42</span>
<span class="n">source</span>:             <span class="n">DN42</span></code></pre>

<h1><a class="anchor" id="get-some-peers" href="#get-some-peers"></a>Get some peers</h1>

<p>In dn42, there is no real distinction between peering and transit: in most cases, everybody serves as an upstream provider to all their peers.  Note that if you have very slow connectivity to the Internet, you may want to avoid providing transit between your peers, which can be done by filtering or prepending your ASN. For the sake of sane routing, try to peer with people on the same continent to avoid inefficient routing, &lt;50ms is a good rule of thumb. You can also look into Bird communities if you are using Bird to mark the latency for the <a href="/howto/BGP-communities">link</a>.</p>

<p>You can use the <a href="https://peerfinder.dn42.dev/">Public node directory</a> to help you find potential peers close to you.</p>

<p>You can then contact them on IRC or by email. In case you're really at loss, you can also ask for peers on the mailing list.</p>

<h2><a class="anchor" id="establishing-tunnels" href="#establishing-tunnels"></a>Establishing tunnels</h2>

<p>Unless your dn42 peers are on the same network, you must establish tunnels. Choose anything you like: Wireguard, OpenVPN, GRE, GRE + IPSec, IPIP, Tinc, …</p>

<p>There is some documentation in this wiki, like <a href="/howto/GRE-plus-IPsec">gre-plus-ipsec</a>.</p>

<h2><a class="anchor" id="running-a-routing-daemon" href="#running-a-routing-daemon"></a>Running a routing daemon</h2>

<p>You need a BGP daemon to exchange routes with peers. Common choices are BIRD and FRR, but you can use anything: OpenBGPD, XORP, ExaBGP. See the <a href="/FAQ#frequently-asked-questions_what-bgp-daemon-should-i-use">FAQ</a> for guidance.</p>

<p>You can find <a href="/howto/Bird2">configuration examples for Bird here</a>.</p>

<h2><a class="anchor" id="configuration-examples" href="#configuration-examples"></a>Configuration Examples</h2>

<ul>
  <li>
    <p><a href="/howto/networksettings">Important Network configuration</a></p>
  </li>
  <li>VPN/Tunnel:
    <ul>
      <li><a href="/howto/wireguard">Wireguard</a></li>
      <li><a href="/howto/openvpn">Openvpn</a></li>
      <li><a href="/howto/tinc">Tinc</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys">IPsec with public key authentication</a></li>
    </ul>
  </li>
  <li>BGP:
    <ul>
      <li><a href="/howto/Bird2">Bird</a></li>
      <li><a href="/howto/frr">FRR</a></li>
      <li><a href="/howto/OpenBGPD">OpenBGPD</a></li>
    </ul>
  </li>
  <li>Router specific:
    <ul>
      <li><a href="/howto/OpenWRT">dn42 on OpenWRT</a></li>
      <li><a href="/howto/EdgeOS-Config-Example">EdgeOS Configuration</a></li>
      <li><a href="/howto/EdgeOS-GRE-IPsec-Example">EdgeOS GRE/IPsec Example</a></li>
      <li><a href="/howto/BGP-on-Extreme-Summit1i">BGP on Extreme Networks Summit 1i</a></li>
    </ul>
  </li>
</ul>

<h1><a class="anchor" id="configure-dns" href="#configure-dns"></a>Configure DNS</h1>

<p>See <a href="/services/DNS">Services DNS</a>.</p>

<h1><a class="anchor" id="use-and-provide-services" href="#use-and-provide-services"></a>Use and provide services</h1>

<p>See <a href="/internal/Internal-Services">internal</a> for internal services.</p>

<h3><a class="anchor" id="router-specific" href="#router-specific"></a>Router-specific</h3>

<ul>
  <li><a href="/howto/OpenWRT">OpenWRT</a></li>
  <li><a href="/howto/EdgeOS-Config-Example">EdgeOS configuration</a></li>
  <li><a href="/howto/EdgeOS-GRE-IPsec-Example">EdgeOS GRE/IPsec</a></li>
</ul>

<h2><a class="anchor" id="configure-dns-1" href="#configure-dns-1"></a>Configure DNS</h2>

<p>See <a href="/services/DNS">DNS services</a>.</p>

<h2><a class="anchor" id="use-and-provide-services-1" href="#use-and-provide-services-1"></a>Use and provide services</h2>

<p>See <a href="/internal/Internal-Services">internal services</a> for available services.</p>

<p>Don't hesitate to provide interesting services, but <em>please</em>, document them on the wiki! Otherwise, nobody will be able to use them as they won't know they exist.</p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/DNS" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">RPKI</a></li>
      <li><a href="/services/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
      <li><a href="/services/Registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
      <li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
    </ul>
  </li>
  <li>Historical
    <ul>
      <li><a href="/historical/Bird" rel="nofollow">Bird 1</a></li>
      <li><a href="/historical/Quagga" rel="nofollow">Quagga</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://hedgedoc.dn42.eu" rel="nofollow">HedgeDoc</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/Getting-Started.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/Getting-Started.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
