<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/IPsec-with-PublicKeys.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>IPsec-with-PublicKeys</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>IPsec-with-PublicKeys</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/IPsec-with-PublicKeys.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/IPsec-with-PublicKeys.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    IPsec-with-PublicKeys
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="ipsec-with-public-key-authentication" href="#ipsec-with-public-key-authentication"></a>IPsec with public key authentication</h1>
<h2><a class="anchor" id="stop-using-pre-shared-keys" href="#stop-using-pre-shared-keys"></a>Stop using pre-shared keys!</h2>
<h3><a class="anchor" id="pre-shared-keys-suck-because-reasons" href="#pre-shared-keys-suck-because-reasons"></a>Pre-shared keys suck, because <em>reasons</em>
</h3>

<ul>
  <li>
<strong>The key must be kept secret</strong>, which means it must be shared only over a secure channel e.g. PGP, face-to-face</li>
  <li>Most implementations will accept insecure (too short, too simple) keys</li>
  <li>The <a href="http://www.sersc.org/journals/IJAST/vol8/2.pdf" title="Vulnerabilities of VPN using IPSec and Defensive Measures">insecure</a> <a href="http://carnal0wnage.attackresearch.com/2011/12/aggressive-mode-vpn-ike-scan-psk-crack.html" title="Aggressive Mode VPN -- IKE-Scan, PSK-Crack, and Cain">IKE</a> <a href="http://rayas-security.blogspot.com/2013/06/ipsec-vpn-main-mode-vs-aggressive-mode.html" title="IPsec VPN, Main mode Vs Aggressive mode">aggressive mode</a> must be used to support distinct PSKs for multiple dynamic peers, or</li>
  <li>All dynamic peers must use the same PSK in order to use the more secure IKE main mode</li>
</ul>

<h3><a class="anchor" id="public-keys-are-better" href="#public-keys-are-better"></a>Public keys are <em>better</em>
</h3>
<ul>
  <li>They can be transmitted over insecure channels without compromising security</li>
  <li>No need to generate a new key for each connection; just send the same public key to each new peer</li>
  <li>Most implementations generate keys using high quality random numbers by default; one must <em>try</em> to generate an insecure key</li>
  <li>Dynamic peers can all have distinct public keys and still use IKE main mode</li>
</ul>

<h3><a class="anchor" id="so-why-isn-t-everyone-using-public-keys-already" href="#so-why-isn-t-everyone-using-public-keys-already"></a>So why isn't everyone using public keys already?</h3>
<ul>
  <li>The various IKE implementations don't all use the same format to represent public keys <em>(but we can <strong>easily</strong> <a href="#Conversion-tool">convert</a> between them)</em>
</li>
  <li>Documentation on <a href="#How-To-examples">how to</a>, and why you should, configure public keys instead of PSKs is lacking <em>(which is why this page exists)</em>
</li>
  <li>Some implementations don't expose the ability to use public keys directly, only allowing a choice between PSKs and X.509 certificates</li>
</ul>

<h3><a class="anchor" id="public-keys-means-certificates-right-certificates-are-hard" href="#public-keys-means-certificates-right-certificates-are-hard"></a>Public keys means certificates, right? Certificates are hard :(</h3>
<p>Many IKE implementations support manually configuring trusted public keys, without having to create a CA, generate CSRs, sign certificates, or remember/look up the commands to do those things.</p>

<p>Keep in mind that certificates are just public keys wrapped with some extra metadata so that your router can automatically verify that it belongs to someone you trust. Certificates are useful for instances where there are so many peers that it's infeasible to manually configure each one's public key, such as a "road warrior" configuration or DMVPN. In those scenarios it makes sense to set up a Certificate Authority to handle it.</p>

<h2><a class="anchor" id="ok-fine-how-do-i-public-key" href="#ok-fine-how-do-i-public-key"></a>Ok fine, how do I public key?</h2>
<h3><a class="anchor" id="conversion-tool" href="#conversion-tool"></a>Conversion tool</h3>
<p>Different implementations use different formats to represent public keys, and it's necessary to be able to convert between them.
A script for that purpose can be found in this git repository: <a href="https://github.com/zeroae/pubkey-converter">github.com/zeroae/pubkey-converter</a> (it can also be <a href="https://raw.githubusercontent.com/zeroae/pubkey-converter/master/pubkey-converter.pl">downloaded directly here</a>).</p>

<h3><a class="anchor" id="how-to-examples" href="#how-to-examples"></a>How-To examples</h3>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">Implementation</th>
      <th style="text-align:right;">Key format</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;"><a href="/howto/IPsecWithPublicKeys/strongSwan5Example">strongSwan &gt;= 5.0.0</a></td>
      <td style="text-align:right;">PEM</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="/howto/IPsecWithPublicKeys/CiscoIOSExample">Cisco IOS</a></td>
      <td style="text-align:right;">Hexadecimal DER</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="/howto/IPsecWithPublicKeys/RouterOSExample">Mikrotik RouterOS</a></td>
      <td style="text-align:right;">PEM</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="/howto/IPsecWithPublicKeys/OpenBSDExample">OpenBSD</a></td>
      <td style="text-align:right;">PEM</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="/howto/IPsecWithPublicKeys/RacoonExample">Racoon</a></td>
      <td style="text-align:right;">Base64 RFC 3110</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="/howto/IPsecWithPublicKeys/strongSwan4Example">strongSwan &lt; 5.0.0</a></td>
      <td style="text-align:right;">Base64 RFC 3110</td>
    </tr>
    <tr>
      <td style="text-align:left;"><a href="/howto/IPsecWithPublicKeys/VyOSExample">VyOS/EdgeOS</a></td>
      <td style="text-align:right;">Base64 RFC 3110</td>
    </tr>
  </tbody>
</table>

<h3><a class="anchor" id="notes" href="#notes"></a>Notes</h3>
<ol>
  <li>Best practice is to generate the private key on the router itself, and not transfer it to another machine. This part should be kept secret!</li>
  <li>Generate a key of at least 2048 bits, preferably 4096 if both ends support it.</li>
  <li>Some implementations support more than one key format. The examples here only show how to use one of them (usually PEM) for brevity.</li>
  <li>RFC 3110 format is the same as that described in RFC 2537. The former obsoletes the latter.</li>
</ol>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>, <a href="https://iedon.net/post/24" rel="nofollow">IEDON-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>, <a href="https://dn42.jp/" rel="nofollow">dn42.jp</a> (wiki-go), <a href="https://dn42.net/" rel="nofollow">dn42.net</a>
</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/IPsec-with-PublicKeys.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/IPsec-with-PublicKeys.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
