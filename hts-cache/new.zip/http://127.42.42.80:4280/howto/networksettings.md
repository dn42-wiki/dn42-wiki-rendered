<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/networksettings.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>networksettings</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>networksettings</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/networksettings.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/networksettings.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    networksettings
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h2><a class="anchor" id="important-rules-for-linux" href="#important-rules-for-linux"></a>Important rules for Linux</h2>

<p>The first rule of dn42: Always disable <code>rp_filter</code>.</p>

<p>The second rule of dn42: Always disable <code>rp_filter</code>.</p>

<p>The third rule of dn42: Allow ip forwarding!</p>

<p>No seriously, in case some packets are dropped, first check if your settings are correct.</p>

<p><code>rp_filter</code> also known as reverse path filtering is a security measure. 
When the route to return a packet uses a different interface than it arrived from, the packet is dropped. 
Some attackers will set a wrong return address on their packets. This security measure was created to address when this happens. Core internet routing can however be asymmetric. This means that packets can take different routes on the return path.
That is why <code>rp_filter</code> needs to be disabled.</p>

<p><strong>Note</strong> using sysctl is not persistent. Depending on your linux distribution put it into <code>/etc/sysctl.conf</code> or <code>/etc/sysctl.d</code><br />
<em>(see also the note below if you are running Debian Trixie or your OS is using systemd-sysctl)</em></p>

<pre class="highlight"><code>sysctl <span class="nt">-w</span> net.ipv4.conf.all.rp_filter<span class="o">=</span>0 net.ipv4.conf.default.rp_filter<span class="o">=</span>0</code></pre>

<p>Check that its really disabled:
</p><pre class="highlight"><code>sysctl <span class="nt">-a</span> | <span class="nb">grep </span>rp_filter</code></pre>

<p><strong>Note</strong> The max value from <code>conf/{all,interface}/rp_filter</code> is used when doing source validation on the <code>{interface}</code>. In case you don't want to disable <code>rp_filter</code> for the entire system, the correct setup is to set both <code>net.ipv4.conf.all.rp_filter=0</code> and <code>net.ipv4.conf.{interface}.rp_filter=0</code>, where <code>{interface}</code> is your vpn interface.</p>

<p>Also the following options must be set.
</p><pre class="highlight"><code><span class="nv">$ </span>sysctl <span class="nt">-w</span> net.ipv4.ip_forward<span class="o">=</span>1 net.ipv4.conf.all.forwarding<span class="o">=</span>1 net.ipv6.conf.all.forwarding<span class="o">=</span>1</code></pre>

<p>Check that ALL your vpn interfaces allow ip forwarding for ipv6/ipv4.
</p><pre class="highlight"><code><span class="nv">$ </span>sysctl <span class="nt">-a</span> | <span class="nb">grep </span>forwarding</code></pre>

<p><strong>systemd-sysctl</strong></p>

<p>systemd-sysctl parses files in <strong>lexical ordering</strong> regardless of which directory they are in.<br />
See the <a href="https://www.freedesktop.org/software/systemd/man/latest/sysctl.d.html#Configuration%20Directories%20and%20Precedence">sysctl.d documentation</a> for more details on this; the documentation also notes:</p>

<p><em>It is recommended to use the range 10-40 for configuration files in /usr/ and the range 60-90 for configuration files in /etc/ and /run/, to make sure that local and transient configuration files will always take priority over configuration files shipped by the OS vendor.</em></p>

<p>Debian Trixie ships with a <code>/usr/lib/sysctl.d/50-default.conf</code> file which sets rp_filter to 2.</p>

<p>The net result is you must ensure that the filenames you create in /etc/sysctl.d for overrides are lexically after '50-default.conf' or your settings will not have any effect. Additionally for Debian Trixie and newer, you should consider also setting <code>net.ipv4.conf.*.rp_filter=0</code> to override the per-interface defaults.</p>

<h2><a class="anchor" id="note-on-firewalls-conntrack-and-asymmetric-routing" href="#note-on-firewalls-conntrack-and-asymmetric-routing"></a>Note on firewalls, conntrack and asymmetric routing</h2>

<p>Do not configure iptables/nftables to drop packets with invalid conntrack state in forward chain.</p>

<p>In some cases your router will not see traffic from both sides e.g. requests are sent via different path not including your networks
but responses are forwarded via your network. This will prevent conntrack from assigning any meaningful state information to these packets
and your firewall will drop it if it is configured to drop packets with invalid state.</p>

<h2><a class="anchor" id="avoiding-issues-with-peer-addressing" href="#avoiding-issues-with-peer-addressing"></a>Avoiding Issues with Peer Addressing</h2>

<p>When configuring BGP peers in dn42, be cautious about using DN42 IP addresses as peer addresses, particularly in the following scenario:</p>
<ul>
  <li>You are NOT using extended next hop</li>
  <li>You ARE using the same IP for other services</li>
</ul>

<h3><a class="anchor" id="the-problem" href="#the-problem"></a>The Problem</h3>
<p>If your peering link goes down (while the interface remains configured), your peer may have a static route for your service IP via the non-functional tunnel interface. This can make your services inaccessible, even if you have other working peers, because:</p>
<ul>
  <li>The static route typically has higher priority than BGP routes</li>
  <li>Wireguard interfaces don't automatically go down when peers are unreachable</li>
  <li>Traffic might be routed through peers with broken static routes</li>
</ul>

<p>This is especially likely to occur if your peers are major transit providers within DN42.</p>

<h3><a class="anchor" id="solutions" href="#solutions"></a>Solutions</h3>
<p>To avoid this issue, use one of these approaches:</p>
<ol>
  <li>Use extended next hop in BGP configuration</li>
  <li>Use non-DN42 addresses for BGP peering</li>
  <li>Use different IPs for services than for peering</li>
  <li>De-couple services from specific nodes</li>
</ol>

<h2><a class="anchor" id="mtu-anycast-and-tcp-mss-clamping" href="#mtu-anycast-and-tcp-mss-clamping"></a>MTU, Anycast and TCP MSS Clamping</h2>

<p>In DN42, you are almost always running over tunnels (WireGuard, GRE, etc.). Different routers and tunnels may use different MTU. Combined with Anycast, this creates a specific failure mode for Path MTU Discovery (PMTUD).</p>

<h3><a class="anchor" id="the-anycast-pmtud-blackhole" href="#the-anycast-pmtud-blackhole"></a>The Anycast PMTUD Blackhole</h3>

<p>When a router sends an ICMPv6 "Packet Too Big" (PTB) message to an Anycast address, the network may route that ICMP packet to a different Anycast instance than the one that sent the original data. As a result, the actual sender never learns to reduce its packet size, leading to "hanging" connections that pass the TCP handshake but fail when transferring data.</p>

<h3><a class="anchor" id="the-solution-mss-clamping" href="#the-solution-mss-clamping"></a>The Solution: MSS Clamping</h3>

<p>To ensure stability, you must clamp the TCP Maximum Segment Size (MSS) on all nodes. This forces the TCP handshake to negotiate a segment size that fits within your smallest link MTU, bypassing the need for PMTUD.</p>

<p>It is highly recommended to set this on both <code>FORWARD</code> and <code>OUTPUT</code> chains of all routers.</p>

<p>Using nftables (recommended):
</p><pre class="highlight"><code>chain forward {
    type filter hook forward priority filter; policy accept;
    tcp flags syn tcp option maxseg size set rt mtu
}
chain output {
    type filter hook output priority filter; policy accept;
    tcp flags syn tcp option maxseg size set rt mtu
}</code></pre>

<p>Using ip(6)tables:
</p><pre class="highlight"><code># For IPv4
iptables -t mangle -A FORWARD -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu
iptables -t mangle -A OUTPUT -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu

# For IPv6
ip6tables -t mangle -A FORWARD -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu
ip6tables -t mangle -A OUTPUT -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --clamp-mss-to-pmtu</code></pre>

<h2><a class="anchor" id="other-non-trivial-pitfalls" href="#other-non-trivial-pitfalls"></a>Other Non-Trivial Pitfalls</h2>

<ul>
  <li>
    <p><strong>accept_local sysctl settings</strong>: When running anycast services on routers, ensure the accept_local sysctl is enabled. Without this setting, a router might drop transit traffic from other origins that has the anycasted IP as the source address, breaking connectivity through your network for those services.</p>
  </li>
  <li>
    <p><strong>Inadequate source IP filtering</strong>: Services with public internet access require careful source IP filtering. For example, a DNS server in DN42 might receive requests with spoofed source IPs from inside DN42 that appear to come from public internet addresses. Without proper filtering, your server could respond to these spoofed requests, potentially participating in reflection attacks or exposing internal services to the public internet.</p>
  </li>
</ul>

<p>Happy Routing!</p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/networksettings.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/networksettings.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
