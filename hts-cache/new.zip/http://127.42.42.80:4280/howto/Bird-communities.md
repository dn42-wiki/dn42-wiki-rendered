<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-309be032396e783b13a47df58f389b7c8e11c2b2d42640560b874f677c25f6e5.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">

  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/Bird-communities.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-f05401ee374f0c7f48fc2bc08e30b4f4db705861fd5895ed70998683b383bfb5.js" type="text/javascript"></script>
  

  <title>Bird-communities</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Bird-communities</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/Bird-communities.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <a class="btn btn-sm" id="minibutton-home" href="/">
      Home
    </a>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/overview"
          id="minibutton-overview"
        >
          Overview
        </a>

        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/latest_changes"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </a>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          href="/gollum/history/howto/Bird-communities.md/"
          id="minibutton-history"
        >
          History
        </a>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Bird-communities
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <p>Bird is a commonly used BGP daemon. This page provides configuration and help for using BGP communities with Bird for dn42.</p>

<p>Communities can be used to prioritize traffic based on different flags, in DN42 we are using communities to prioritize based on latency, bandwidth and encryption. Please note that everyone should be using community 64511.</p>

<p>The community is applied to the route when it is imported and exported, therefore you need to change your bird configuration, in /etc/bird/peers4 if you followed the Bird guide.</p>

<p>The filter helpers can be stored in a separate file, for example /etc/bird/community_filters.conf.</p>

<p>Below, you will see an example config for peers4 based on the original filter implementation by Jplitza.</p>

<p>To properly assign the right community to your peer, please reference the table below. If you are running your own network and peering internally, please also apply the communities inside your network.</p>

<h2><a class="anchor" id="bgp-community-criteria" href="#bgp-community-criteria"></a>BGP community criteria</h2>
<p></p><pre class="highlight"><code>(64511, 1) :: latency \in (0, 2.7ms]
(64511, 2) :: latency \in (2.7ms, 7.3ms]
(64511, 3) :: latency \in (7.3ms, 20ms]
(64511, 4) :: latency \in (20ms, 55ms]
(64511, 5) :: latency \in (55ms, 148ms]
(64511, 6) :: latency \in (148ms, 403ms]
(64511, 7) :: latency \in (403ms, 1097ms]
(64511, 8) :: latency \in (1097ms, 2981ms]
(64511, 9) :: latency &gt; 2981ms
(64511, x) :: latency \in [exp(x-1), exp(x)] ms (for x &lt; 10)

(64511, 21) :: bw &gt;= 0.1mbit
(64511, 22) :: bw &gt;= 1mbit
(64511, 23) :: bw &gt;= 10mbit
(64511, 24) :: bw &gt;= 100mbit
(64511, 25) :: bw &gt;= 1000mbit
(64511, 2x) :: bw &gt;= 10^(x-2) mbit
bw = min(up,down) for asymmetric connections

(64511, 31) :: not encrypted
(64511, 32) :: encrypted with unsafe vpn solution
(64511, 33) :: encrypted with safe vpn solution (but no PFS - the usual OpenVPN p2p configuration falls in this category)
(64511, 34) :: encrypted with safe vpn solution with PFS (Perfect Forward Secrecy)

Propagation:
- - for latency pick max(received_route.latency, link_latency)
- - for encryption and bandwidth pick min between received BGP community and peer link</code></pre>
For example, if your peer is 12ms away and the link speed between you is 250Mbit/s and you are peering using OpenVPN P2P, then the community string would be (3, 24, 33).

<p>Two utilities which measure round trip time and calculate community values automatically are provided, written in  <a href="https://github.com/Mic92/bird-dn42/blob/master/bgp-community.rb">ruby</a> and <a href="https://github.com/nixnodes/bird/blob/master/misc/dn42-comgen.c">C</a>.</p>

<pre class="highlight"><code>$ ruby bgp-community.rb --help
USAGE: bgp-community.rb host mbit_speed unencrypted|unsafe|encrypted|pfs
    -6, --ipv6                       Assume ipv6 for ping
$ ruby bgp-community.rb 212.129.13.123 300 encrypted
  # 15 ms, 300 mbit/s, encrypted tunnel (updated: 2016-02-11)
  import where dn42_import_filter(3,24,33);
  export where dn42_export_filter(3,24,33);
$ ruby bgp-community.rb -6 dn42-2.higgsboson.tk 1000 pfs
  # 11 ms, 1000 mbit/s, pfs tunnel (updated: 2016-02-11)
  import where dn42_import_filter(3,25,34);
  export where dn42_export_filter(3,25,34);</code></pre>

<h3><a class="anchor" id="route-origin" href="#route-origin"></a>Route Origin</h3>
<p>There are two type of route origin: <code>region</code> and <code>country</code></p>

<h4><a class="anchor" id="region" href="#region"></a>Region</h4>
<p>The range <code>41-70</code> is assigned to the region property.
The communities for route origin region were first defined in <a href="https://lists.nox.tf/pipermail/dn42/2015-December/001259.html">December 2015</a> and further extended in <a href="https://groups.io/g/dn42/topic/91226190">May 2022</a>:</p>

<pre class="highlight"><code>(64511, 41) :: Europe
(64511, 42) :: North America-E
(64511, 43) :: North America-C
(64511, 44) :: North America-W
(64511, 45) :: Central America
(64511, 46) :: South America-E
(64511, 47) :: South America-W
(64511, 48) :: Africa-N (above Sahara)
(64511, 49) :: Africa-S (below Sahara)
(64511, 50) :: Asia-S (IN,PK,BD)
(64511, 51) :: Asia-SE (TH,SG,PH,ID,MY)
(64511, 52) :: Asia-E (JP,CN,KR)
(64511, 53) :: Pacific&amp;Oceania (AU,NZ,FJ)
(64511, 54) :: Antarctica
(64511, 55) :: Asia-N (RU)
(64511, 56) :: Asia-W (IR,TR,UAE)
(64511, 57) :: Central Asia (AF,UZ,KZ)</code></pre>

<h4><a class="anchor" id="country" href="#country"></a>Country</h4>
<p>The range <code>1000-1999</code> is assigned to the country property. Here we use <a href="https://github.com/lukes/ISO-3166-Countries-with-Regional-Codes/blob/master/all/all.csv">ISO-3166-1 numeric</a> country codes, adding <code>1000</code> to each value to get the country origin community:</p>

<pre class="highlight"><code>(64511, 1124) :: Canada
(64511, 1156) :: China
(64511, 1158) :: Taiwan
(64511, 1250) :: France
(64511, 1276) :: Germany
(64511, 1344) :: Hong Kong
(64511, 1392) :: Japan
(64511, 1528) :: Netherlands
(64511, 1578) :: Norway
(64511, 1643) :: Russian Federation
(64511, 1702) :: Singapore
(64511, 1756) :: Switzerland
(64511, 1826) :: United Kingdom
(64511, 1840) :: United States of America
# etc. Please follow the ISO-3166-1 Numeric standard
# https://github.com/lukes/ISO-3166-Countries-with-Regional-Codes/blob/master/all/all.csv</code></pre>

<p>You need to add following lines to your config(s):</p>
<ul>
  <li>
<code>define DN42_REGION = $VALUE_FROM_ABOVE</code> to your node's config (where OWNAS and OWNIP are set)</li>
  <li>
<code>if source = RTS_STATIC then bgp_community.add((64511, DN42_REGION));</code>
just above <code>update_flags</code> in <code>dn42_export_filter</code> function</li>
  <li>Unlike the other community values, <strong>the DN42_REGION community should only be set on routes originating from your network!</strong> (This is what the <code>source = RTS_STATIC</code> check does).
    <ul>
      <li>Otherwise, if you export routes across multiple regions within your network, you may be sending incorrect origin information to other peers.</li>
    </ul>
  </li>
</ul>

<h2><a class="anchor" id="example-configurations" href="#example-configurations"></a>Example configurations</h2>
<p></p><pre class="highlight"><code># /etc/bird/peers4/tombii.conf
protocol bgp tombii from dnpeers {
  neighbor 172.23.102.x as 4242420321;
  import where dn42_import_filter(3,24,33);
  export where dn42_export_filter(3,24,33);
};</code></pre>
<pre class="highlight"><code>#/etc/bird/community_filters.conf
function update_latency(int link_latency) {
  bgp_community.add((64511, link_latency));
       if (64511, 9) ~ bgp_community then { bgp_community.delete([(64511, 1..8)]); return 9; }
  else if (64511, 8) ~ bgp_community then { bgp_community.delete([(64511, 1..7)]); return 8; }
  else if (64511, 7) ~ bgp_community then { bgp_community.delete([(64511, 1..6)]); return 7; }
  else if (64511, 6) ~ bgp_community then { bgp_community.delete([(64511, 1..5)]); return 6; }
  else if (64511, 5) ~ bgp_community then { bgp_community.delete([(64511, 1..4)]); return 5; }
  else if (64511, 4) ~ bgp_community then { bgp_community.delete([(64511, 1..3)]); return 4; }
  else if (64511, 3) ~ bgp_community then { bgp_community.delete([(64511, 1..2)]); return 3; }
  else if (64511, 2) ~ bgp_community then { bgp_community.delete([(64511, 1..1)]); return 2; }
  else return 1;
}

function update_bandwidth(int link_bandwidth) {
  bgp_community.add((64511, link_bandwidth));
       if (64511, 21) ~ bgp_community then { bgp_community.delete([(64511, 22..29)]); return 21; }
  else if (64511, 22) ~ bgp_community then { bgp_community.delete([(64511, 23..29)]); return 22; }
  else if (64511, 23) ~ bgp_community then { bgp_community.delete([(64511, 24..29)]); return 23; }
  else if (64511, 24) ~ bgp_community then { bgp_community.delete([(64511, 25..29)]); return 24; }
  else if (64511, 25) ~ bgp_community then { bgp_community.delete([(64511, 26..29)]); return 25; }
  else if (64511, 26) ~ bgp_community then { bgp_community.delete([(64511, 27..29)]); return 26; }
  else if (64511, 27) ~ bgp_community then { bgp_community.delete([(64511, 28..29)]); return 27; }
  else if (64511, 28) ~ bgp_community then { bgp_community.delete([(64511, 29..29)]); return 28; }
  else return 29;
}

function update_crypto(int link_crypto) {
  bgp_community.add((64511, link_crypto));
       if (64511, 31) ~ bgp_community then { bgp_community.delete([(64511, 32..34)]); return 31; }
  else if (64511, 32) ~ bgp_community then { bgp_community.delete([(64511, 33..34)]); return 32; }
  else if (64511, 33) ~ bgp_community then { bgp_community.delete([(64511, 34..34)]); return 33; }
  else return 34;
}

function update_flags(int link_latency; int link_bandwidth; int link_crypto)
int dn42_latency;
int dn42_bandwidth;
int dn42_crypto;
{
  dn42_latency = update_latency(link_latency);
  dn42_bandwidth = update_bandwidth(link_bandwidth) - 20;
  dn42_crypto = update_crypto(link_crypto) - 30;
  # replace 4 with your calculated bandwidth value
  if dn42_bandwidth &gt; 4 then dn42_bandwidth = 4;
  return true;
}

# Combines filter from local4.conf/local6.conf and filter4.conf/filter6.conf,
# which means, these must included before this file

function dn42_import_filter(int link_latency; int link_bandwidth; int link_crypto) {
  if is_valid_network() &amp;&amp; !is_self_net() then {
    update_flags(link_latency, link_bandwidth, link_crypto);
    accept;
  }
  reject;
}

function dn42_export_filter(int link_latency; int link_bandwidth; int link_crypto) {
  if is_valid_network() then {
    update_flags(link_latency, link_bandwidth, link_crypto);
    accept;
  }
  reject;
}
</code></pre>
Please remember to include /etc/bird/community_filters.conf in your bird.conf/birdc6.conf
<pre class="highlight"><code>
# local configuration
######################
include "bird/local4.conf";

# filter helpers
#################

include "/etc/bird/filter4.conf";
include "/etc/bird/community_filters.conf";</code></pre>

<hr />

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li><a href="/Home" rel="nofollow">Home</a></li>
  <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
  <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
  <li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
  <li><a href="/howto/Bird-communities" rel="nofollow">BGP communities</a></li>
  <li>
    <p><a href="/FAQ" rel="nofollow">FAQ</a></p>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li>
<a href="/howto/Bird" rel="nofollow">Bird</a> / <a href="/howto/Bird2" rel="nofollow">Bird2</a>
</li>
      <li><a href="/howto/Quagga" rel="nofollow">Quagga</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/vyos" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/DNS" rel="nofollow">DNS</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
      <li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:xuu@sour.is" rel="nofollow">xuu</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">nurtic-vibe</a>, <a href="mailto:tom@xcv.vc" rel="nofollow">toBee</a>, <a href="mailto:dn42@burble.com" rel="nofollow">burble</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>
</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/Bird-communities.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/Bird-communities.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
