<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/Static-routes-on-Windows.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Static-routes-on-Windows</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Static-routes-on-Windows</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/Static-routes-on-Windows.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/Static-routes-on-Windows.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Static-routes-on-Windows
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <p>Modern versions of Windows do not support OSPF and manually adding static routes every time after a reboot is annoying. Below is a batch script you can edit and run to help make adding routes easier. This script assumes that your BGP router and Windows computer are on the same LAN.</p>

<pre class="highlight"><code>@echo off
REM fill <span class="k">in </span>YOUR network information
REM right click and RUN AS ADMIN

REM our entire private network address space
<span class="nb">set </span><span class="nv">networkv4</span><span class="o">=</span>172.20.0.0
<span class="nb">set </span><span class="nv">networkv4mask</span><span class="o">=</span>255.252.0.0
<span class="nb">set </span><span class="nv">networkv6</span><span class="o">=</span>fd00::/8

REM our IPv4 subnet info
<span class="nb">set </span><span class="nv">subnetv4</span><span class="o">=</span>172.20.184.240
<span class="nb">set </span><span class="nv">subnetv4mask</span><span class="o">=</span>255.255.255.248
<span class="nb">set </span><span class="nv">gateway4</span><span class="o">=</span>172.20.184.241

REM our IPv6 subnet info
<span class="nb">set </span><span class="nv">subnetv6</span><span class="o">=</span>fd43:6d1:3ee2::/48
<span class="nb">set </span><span class="nv">gateway6</span><span class="o">=</span>fd43:6d1:3ee2:1000::1

REM our address <span class="k">for </span>this machine
<span class="nb">set </span><span class="nv">yournetaddr</span><span class="o">=</span>172.20.184.242
<span class="nb">set </span><span class="nv">yournetaddr6</span><span class="o">=</span>fd43:6d1:3ee2:1000::2/128

REM add IPs
REM <span class="k">if </span>different change wlan0 to YOUR interface name
REM first line here is <span class="k">for </span>my LAN. Ignore it.
netsh interface ipv4 add address <span class="s2">"wlan0"</span> 192.168.2.254 255.255.255.0
netsh interface ipv4 add address <span class="s2">"wlan0"</span> %yournetaddr% %subnetv4mask%
netsh interface ipv6 add address <span class="s2">"wlan0"</span> %yournetaddr6%

REM add IPv4 routes
route <span class="nt">-4</span> add %subnetv4% mask %subnetv4mask% %gateway4%
route <span class="nt">-4</span> add %networkv4% mask %networkv4mask% %gateway4%

REM add IPv6 routes
route <span class="nt">-6</span> add %gateway6% ::
route <span class="nt">-6</span> add %subnetv6% %gateway6%
REM this last route wasn<span class="s1">'t working without manually filling in the info.
REM I don'</span>t know why.. Broken line commented out.
REM route <span class="nt">-6</span> add %networkv6% %gateway6%
route <span class="nt">-6</span> add fd00::/8 fd43:6d1:3ee2:1000::1

<span class="nb">echo </span>Press enter to check your IPv4 routing table
<span class="nb">echo </span>Do not forget to add static routes to this computer on your BGP router!
<span class="nb">echo </span>Example: <span class="s2">"root@router:~# ip route add 172.20.184.242 dev wlan0"</span>
<span class="nb">echo </span>Example: <span class="s2">"root@router:~# ip route add fd43:6d1:3ee2:1000::2/128 dev wlan0"</span>
pause
cls
route <span class="nt">-4</span> print
<span class="nb">echo </span>Press enter to check your IPv6 routing table
pause
cls
route <span class="nt">-6</span> print
<span class="nb">echo </span>Press enter to try to ping gateway
pause
cls
ping %gateway4%
pause
ping %gateway6%
pause</code></pre>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/Static-routes-on-Windows.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/Static-routes-on-Windows.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
