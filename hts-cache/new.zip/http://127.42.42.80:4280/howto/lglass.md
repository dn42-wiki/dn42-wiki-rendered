<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/lglass.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>lglass</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>lglass</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/lglass.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/lglass.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    lglass
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <p>lglass is a Python software package designed for Internet Registries like the DN42. You can generate zone files for DNS and rDNS IPv4/v6, and handle the registry. It is available on GitHub as free software:</p>

<pre class="highlight"><code><span class="nv">$ </span>git clone git://github.com/fritz0705/lglass.git</code></pre>

<h2><a class="anchor" id="links" href="#links"></a>Links</h2>
<ul>
  <li><a href="https://github.com/fritz0705/lglass">Fritz Gihub repo</a></li>
  <li><a href="http://lglass.flonet.dn42/">lglass Manual</a></li>
</ul>

<h2><a class="anchor" id="running-your-own-whois-daemon" href="#running-your-own-whois-daemon"></a>Running your own Whois daemon</h2>

<p>lglass provides an event-based whois daemon with internal caching, which was written in Python. It is very simple to run an instance:</p>

<pre class="highlight"><code><span class="nv">$ </span>./bin/lglass-whoisd</code></pre>

<p>without the configfile:</p>

<pre class="highlight"><code><span class="nv">$ </span>./bin/lglass-regtool whoisd <span class="nt">-H</span> <span class="nv">$HOST</span> <span class="nt">-p</span> <span class="nv">$PORT</span></code></pre>

<pre class="highlight"><code>usage: lglass-whoisd [-h] [-4] [-6] [--host HOST] [--port PORT]
                     [--cidr] [--no-cidr] [--inverse] [--no-inverse]

optional arguments:
    -h, --help            show this help message and exit
    -4                    Listen on IPv4
    -6                    Listen on IPv6
    --host HOST, -H HOST  Listen on host
    --port PORT, -p PORT  Listen on port
    --cidr, -c            Perform CIDR matching on queries
    --no-cidr             Do not perform CIDR matching on queries
    --inverse, -i         Perform inverse matching on queries
    --no-inverse          Do not perform inverse matching on queries</code></pre>

<h2><a class="anchor" id="generate-zone-files" href="#generate-zone-files"></a>Generate zone files</h2>

<p>lglass also provides a script to generate zone files from the registry. It's named zonegen.py and requires a registry dump from Monotone.</p>

<p>To generate DNS zones:</p>

<pre class="highlight"><code><span class="nv">$ </span>./bin/lglass-zonegen <span class="nt">-d</span> <span class="nv">$PATH_TO_DATA_DIR</span> <span class="nt">-n</span> ns1... <span class="nt">-n</span> ns2... <span class="nt">-e</span> foo.bar.com dns <span class="nt">-z</span> dn42</code></pre>

<p>To generate IPv4 rDNS zones:</p>

<pre class="highlight"><code><span class="nv">$ </span>./bin/lglass-zonegen <span class="nt">-d</span> <span class="nv">$PATH_TO_DATA_DIR</span> <span class="nt">-n</span> ns1... <span class="nt">-n</span> ns2... <span class="nt">-e</span> foo.bar.com rdns4 <span class="nt">-N</span> 172.22.0.0/16</code></pre>

<p>To generate IPv6 rDNS zones:
</p><pre class="highlight"><code><span class="nv">$ </span>./bin/lglass-zonegen <span class="nt">-d</span> <span class="nv">$PATH_TO_DATA_DIR</span> <span class="nt">-n</span> ns1... <span class="nt">-n</span> ns2... <span class="nt">-e</span> foo.bar.com rdns6 <span class="nt">-N</span> fd00::/8</code></pre>

<h2><a class="anchor" id="reformat-rpsl-files" href="#reformat-rpsl-files"></a>Reformat RPSL files</h2>

<p>You can also reformat RPSL files using lglass by using the lglass.rpsl module:</p>

<pre class="highlight"><code><span class="nv">$ </span>./bin/lglass-rpsl &lt; <span class="nv">$DATA</span>/inetnum/172.22.0.53_32</code></pre>

<p>lglass.rpsl also supports in-place operation:</p>

<pre class="highlight"><code><span class="nv">$ </span>./bin/lglass-rpsl <span class="nt">-i</span> <span class="nv">$DATA</span>/inetnum/172.22.0.53_32</code></pre>

<p>This opens the file, reads the content into memory, seeks to position 0, writes the formatted object and truncates the file.
Simple web interface</p>

<p>lglass also comes with a simple web interface written in Python3 using Bottle and Jinja2. It also provides a binary to run it using wsgiref:
</p><pre class="highlight"><code><span class="nv">$ </span>./bin/lglass-web</code></pre>

<p>Furthermore you can use any WSGI server like Gunicorn by using lglass.web.application:app as WSGI callback. You can provide a path to the configuration file in the environment variable <code>LGLASS_WEB_CFG</code>.</p>

<h2><a class="anchor" id="configuration" href="#configuration"></a>Configuration</h2>

<p>The configuration file format is JSON and allows configuration of the database chain, the listen parameters, the custom messages and the process management.</p>

<table>
  <thead>
    <tr>
      <th>Option</th>
      <th style="text-align:left;">Meaning</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>listen.host</td>
      <td style="text-align:left;">IP address for listening socket (Default: ::)</td>
    </tr>
    <tr>
      <td>listen.port</td>
      <td style="text-align:left;">TCP port for listening socket (Default: 4343)</td>
    </tr>
    <tr>
      <td>listen.protocol</td>
      <td style="text-align:left;">Protocol for listening socket (4 or 6, by default 6)</td>
    </tr>
    <tr>
      <td>database</td>
      <td style="text-align:left;">Array of database URLs to initialize database chain</td>
    </tr>
    <tr>
      <td>database.types</td>
      <td style="text-align:left;">Array of object types in database (Default: undefined) <br />Default chain:<br />[<br />  "whois+lglass.database.file+file:.",<br />  "whois+lglass.database.cidr+cidr:",<br />  "whois+lglass.database.schema+schema:",<br />  "whois+lglass.database.cache+cached:"<br />]</td>
    </tr>
    <tr>
      <td>messages.preamble</td>
      <td style="text-align:left;">String preamble for whois responses</td>
    </tr>
    <tr>
      <td>messages.help</td>
      <td style="text-align:left;">String help message for help requests</td>
    </tr>
    <tr>
      <td>process.user</td>
      <td style="text-align:left;">User to change after initialization</td>
    </tr>
    <tr>
      <td>process.group</td>
      <td style="text-align:left;">Group to change after initialization</td>
    </tr>
    <tr>
      <td>process.pidfile</td>
      <td style="text-align:left;">Path to PID file</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="rpsl" href="#rpsl"></a>RPSL</h2>
<ul>
  <li>Routing Policy Specification Language <a href="https://tools.ietf.org/html/rfc2622">RFC2622</a>
</li>
  <li>Routing Policy Specification Language next generation (RPSLng) <a href="https://tools.ietf.org/html/rfc4012">RFC4012</a>
</li>
  <li><a href="http://www.ripe.net/data-tools/db/rpsl">http://www.ripe.net/data-tools/db/rpsl</a></li>
  <li><a href="http://www.ripe.net/data-tools/db/rpsl/transition-to-rpsl-version-of-the-ripe-database">http://www.ripe.net/data-tools/db/rpsl/transition-to-rpsl-version-of-the-ripe-database</a></li>
</ul>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/Policies" rel="nofollow">Policies</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
      <li><a href="/Links" rel="nofollow">Links</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
      <li><a href="/howto/GeoFeed" rel="nofollow">GeoFeed</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/dns/Overview" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">RPKI</a></li>
      <li><a href="/services/exchanges/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Pingables" rel="nofollow">Pingables</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/ca/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>, <a href="https://iedon.net/post/24" rel="nofollow">IEDON-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>, <a href="https://dn42.jp/" rel="nofollow">dn42.jp</a> (wiki-go)</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/lglass.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/lglass.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
