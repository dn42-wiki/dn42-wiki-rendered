<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/EdgeOS-GRE-IPsec-Example.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>EdgeOS-GRE-IPsec-Example</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>EdgeOS-GRE-IPsec-Example</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/EdgeOS-GRE-IPsec-Example.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/EdgeOS-GRE-IPsec-Example.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    EdgeOS-GRE-IPsec-Example
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/DNS" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">RPKI</a></li>
      <li><a href="/services/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
      <li><a href="/services/Registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
      <li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
    </ul>
  </li>
  <li>Historical
    <ul>
      <li><a href="/historical/Bird" rel="nofollow">Bird 1</a></li>
      <li><a href="/historical/Quagga" rel="nofollow">Quagga</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://hedgedoc.dn42.eu" rel="nofollow">HedgeDoc</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>
</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/EdgeOS-GRE-IPsec-Example.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/EdgeOS-GRE-IPsec-Example.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
