<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-309be032396e783b13a47df58f389b7c8e11c2b2d42640560b874f677c25f6e5.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">

  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/openvpn.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-f05401ee374f0c7f48fc2bc08e30b4f4db705861fd5895ed70998683b383bfb5.js" type="text/javascript"></script>
  

  <title>openvpn</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>openvpn</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/openvpn.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <a class="btn btn-sm" id="minibutton-home" href="/">
      Home
    </a>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/overview"
          id="minibutton-overview"
        >
          Overview
        </a>

        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/latest_changes"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </a>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          href="/gollum/history/howto/openvpn.md/"
          id="minibutton-history"
        >
          History
        </a>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    openvpn
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="example-configuration-for-direct-peer-to-peer" href="#example-configuration-for-direct-peer-to-peer"></a>Example Configuration for direct peer to peer</h1>

<ul>
<li>Replace <code>&lt;PEER_NAME&gt;</code> with a self chosen name to identify this peer</li>
<li>Replace <code>&lt;PROTO&gt;</code> with either <code>udp</code> or <code>udp6</code>, depending if you reach your remote peer with ipv4 o ipv6</li>
<li>Replace <code>&lt;REMOTE_HOST&gt;</code> with the public ip address of your peer</li>
<li>Replace <code>&lt;REMOTE_PORT&gt;</code> with the port number, where your peer's openvpn daemon listen for traffic</li>
<li>Replace <code>&lt;LOCAL_HOST&gt;</code> with your public ip</li>
<li>Replace <code>&lt;INTERFACE_NAME&gt;</code> with a self chosen name, this will be the name of your network interface (tun device) for this peering</li>
<li>Replace <code>&lt;LOCAL_GATEWAY_IP&gt;</code> with your own dn42 ip address</li>
<li>Replace <code>&lt;REMOTE_GATEWAY_IP&gt;</code> with dn42 ip address of your peer</li>
<li>
<code>&lt;LOCAL_GATEWAY_IPV6&gt; &lt;REMOTE_GATEWAY_IPV6&gt;</code> same as ipv4, but both ip addresses needs to be in the same subnet. For simplicity you can always use an address from link-local ipv6 range (fe80::/64)</li>
</ul>

<pre class="highlight"><code><span class="c">#/etc/openvpn/&lt;PEER_NAME&gt;
</span><span class="n">proto</span>       &lt;<span class="n">PROTO</span>&gt;
<span class="n">mode</span>        <span class="n">p2p</span>
<span class="n">remote</span>      &lt;<span class="n">REMOTE_HOST</span>&gt;
<span class="n">rport</span>       &lt;<span class="n">REMOTE_PORT</span>&gt;
<span class="n">local</span>       &lt;<span class="n">LOCAL_HOST</span>&gt;
<span class="n">lport</span>       &lt;<span class="n">LOCAL_PORT</span>&gt;
<span class="n">dev</span>-<span class="n">type</span>    <span class="n">tun</span>
<span class="n">tun</span>-<span class="n">ipv6</span>
<span class="n">resolv</span>-<span class="n">retry</span> <span class="n">infinite</span>
<span class="n">dev</span>         &lt;<span class="n">INTERFACE_NAME</span>&gt;
<span class="n">comp</span>-<span class="n">lzo</span>
<span class="n">persist</span>-<span class="n">key</span>
<span class="n">persist</span>-<span class="n">tun</span>
<span class="n">cipher</span> <span class="n">aes</span>-<span class="m">256</span>-<span class="n">cbc</span>
<span class="n">ifconfig</span>-<span class="n">ipv6</span> &lt;<span class="n">LOCAL_GATEWAY_IPV6</span>&gt; &lt;<span class="n">REMOTE_GATEWAY_IPV6</span>&gt;
<span class="n">ifconfig</span> &lt;<span class="n">LOCAL_GATEWAY_IP</span>&gt;  &lt;<span class="n">REMOTE_GATEWAY_IP</span>&gt;
<span class="n">secret</span> /<span class="n">etc</span>/<span class="n">openvpn</span>/&lt;<span class="n">PEER_NAME</span>&gt;.<span class="n">key</span>

<span class="c"># The secret can also be included inline with the config by 
#   wrapping it in &lt;secret&gt;&lt;/secret&gt; tags.
# &lt;secret&gt;
# ... Key File contents go here ...
</span><span class="err">#</span> &lt;/<span class="n">secret</span>&gt;</code></pre>

<p>then create a new key and share it with your peer</p>

<pre class="highlight"><code><span class="nv">$ </span>openvpn <span class="nt">--genkey</span> <span class="nt">--secret</span> /etc/openvpn/&lt;PEER_NAME&gt;.key</code></pre>

<h1><a class="anchor" id="example-configuration-if-one-peer-has-a-floating-ip" href="#example-configuration-if-one-peer-has-a-floating-ip"></a>Example Configuration if one peer has a floating ip</h1>

<h2><a class="anchor" id="peer-with-fixed-ip" href="#peer-with-fixed-ip"></a>peer with fixed ip</h2>

<pre class="highlight"><code><span class="n">proto</span>       &lt;<span class="n">PROTO</span>&gt;
<span class="n">mode</span>        <span class="n">p2p</span>
<span class="n">dev</span>-<span class="n">type</span>    <span class="n">tun</span>
<span class="n">comp</span>-<span class="n">lzo</span>
<span class="n">dev</span>  &lt;<span class="n">INTERFACE_NAME</span>&gt;
<span class="n">persist</span>-<span class="n">key</span>
<span class="n">persist</span>-<span class="n">tun</span>
<span class="n">tun</span>-<span class="n">ipv6</span>
<span class="n">cipher</span> <span class="n">aes</span>-<span class="m">256</span>-<span class="n">cbc</span>
<span class="n">resolv</span>-<span class="n">retry</span> <span class="n">infinite</span>
<span class="n">float</span>
<span class="n">port</span> &lt;<span class="n">LOCAL_PORT</span>&gt;
<span class="n">ifconfig</span>-<span class="n">ipv6</span> &lt;<span class="n">LOCAL_GATEWAY_IPV6</span>&gt; &lt;<span class="n">REMOTE_GATEWAY_IPV6</span>&gt;
<span class="n">ifconfig</span>  &lt;<span class="n">LOCAL_GATEWAY_IP</span>&gt;  &lt;<span class="n">REMOTE_GATEWAY_IP</span>&gt;
<span class="n">secret</span> /<span class="n">etc</span>/<span class="n">openvpn</span>/&lt;<span class="n">PEER_NAME</span>&gt;.<span class="n">key</span></code></pre>

<h2><a class="anchor" id="peer-with-floating-ip" href="#peer-with-floating-ip"></a>peer with floating ip</h2>

<ul>
<li>Notice the local gateway ip of your peer is your remote gateway ip and 
his remote gateway is your local gateway</li>
<li>
<code>&lt;REMOTE_HOST&gt;</code> is the ip address of your peer</li>
<li>
<code>&lt;REMOTE_PORT&gt;</code> is openvpn port, where your peer listen for traffic</li>
</ul>

<pre class="highlight"><code><span class="n">proto</span>       &lt;<span class="n">PROTO</span>&gt;
<span class="n">mode</span>        <span class="n">p2p</span>
<span class="n">remote</span>      &lt;<span class="n">REMOTE_HOST</span>&gt;
<span class="n">rport</span>       &lt;<span class="n">REMOTE_PORT</span>&gt;
<span class="n">lport</span>       <span class="n">float</span>
<span class="n">dev</span>-<span class="n">type</span>    <span class="n">tun</span>
<span class="n">tun</span>-<span class="n">ipv6</span>
<span class="n">dev</span>         &lt;<span class="n">INTERFACE_NAME</span>&gt;
<span class="n">comp</span>-<span class="n">lzo</span>
<span class="n">persist</span>-<span class="n">key</span>
<span class="n">persist</span>-<span class="n">tun</span>
<span class="n">cipher</span> <span class="n">aes</span>-<span class="m">256</span>-<span class="n">cbc</span>
<span class="n">resolv</span>-<span class="n">retry</span> <span class="n">infinite</span>
<span class="n">ifconfig</span>  &lt;<span class="n">LOCAL_GATEWAY_IP</span>&gt;  &lt;<span class="n">REMOTE_GATEWAY_IP</span>&gt;
<span class="n">ifconfig</span>-<span class="n">ipv6</span> &lt;<span class="n">LOCAL_GATEWAY_IPV6</span>&gt; &lt;<span class="n">LOCAL_GATEWAY_IPV6</span>&gt;
<span class="n">secret</span> /<span class="n">etc</span>/<span class="n">openvpn</span>/&lt;<span class="n">PEER_NAME</span>&gt;.<span class="n">key</span></code></pre>

<h1><a class="anchor" id="example-configuration-for-connecting-roaming-clients-to-dn42" href="#example-configuration-for-connecting-roaming-clients-to-dn42"></a>Example configuration for connecting roaming clients to dn42</h1>

<p>Clients connect using certificates, and simply get attributed dn42 IPs in the order they connect.  This is useful for roaming clients, where you don't really care which IP you have.  Note that once a client has connected for the first time, it will keep the same IP on subsequent connections (option <code>ifconfig-pool-persist</code>).</p>

<h2><a class="anchor" id="server-configuration" href="#server-configuration"></a>Server configuration</h2>

<p>Replace <code>&lt;PORT&gt;</code> with the UDP port you want OpenVPN to listen to, and change the IP ranges (<code>ifconfig</code> and <code>route-gateway</code> options).</p>

<pre class="highlight"><code><span class="n">mode</span> <span class="n">server</span>
<span class="n">tls</span>-<span class="n">server</span>

<span class="n">dh</span> <span class="n">dh2048</span>.<span class="n">pem</span>
<span class="n">cipher</span> <span class="n">aes</span>-<span class="m">256</span>-<span class="n">cbc</span>

<span class="n">ca</span> <span class="n">keys</span>/<span class="n">ca</span>.<span class="n">crt</span>
<span class="n">cert</span> <span class="n">keys</span>/<span class="n">roaming</span>-<span class="n">dn42</span>.<span class="n">crt</span>
<span class="n">key</span> <span class="n">keys</span>/<span class="n">roaming</span>-<span class="n">dn42</span>.<span class="n">key</span>

<span class="n">client</span>-<span class="n">config</span>-<span class="n">dir</span> /<span class="n">etc</span>/<span class="n">openvpn</span>/<span class="n">roaming</span>

<span class="n">dev</span> <span class="n">tun</span>-<span class="n">roaming</span>
<span class="n">persist</span>-<span class="n">tun</span>
<span class="n">tun</span>-<span class="n">ipv6</span>
<span class="n">tun</span>-<span class="n">mtu</span> <span class="m">1500</span>
<span class="n">fragment</span> <span class="m">1300</span>
<span class="n">mssfix</span>
<span class="n">log</span> /<span class="n">var</span>/<span class="n">log</span>/<span class="n">openvpn</span>-<span class="n">dn42</span>-<span class="n">roaming</span>.<span class="n">log</span>
<span class="n">status</span> /<span class="n">var</span>/<span class="n">log</span>/<span class="n">openvpn</span>-<span class="n">dn42</span>-<span class="n">roaming</span>-<span class="n">status</span>.<span class="n">log</span> <span class="m">60</span>

<span class="c"># Should work for both IPv4 and IPv6
</span><span class="n">proto</span> <span class="n">udp6</span>
<span class="n">port</span> &lt;<span class="n">PORT</span>&gt;

<span class="c"># IPv6
###tun-ipv6
###push tun-ipv6
###ifconfig-ipv6 2001:db8:42:42::1 2001:db8:42:42::2
###ifconfig-ipv6-pool 2001:db8:42:42::3/64
</span>
<span class="n">topology</span> <span class="n">subnet</span>
<span class="n">push</span> <span class="s2">"topology subnet"</span>

<span class="n">keepalive</span> <span class="m">10</span> <span class="m">60</span>

<span class="c"># That's 172.22.X.144/28 (172.22.X.144 to 172.22.X.159)
</span><span class="n">ifconfig</span> <span class="m">172</span>.<span class="m">22</span>.<span class="n">X</span>.<span class="m">145</span> <span class="m">255</span>.<span class="m">255</span>.<span class="m">255</span>.<span class="m">240</span>
<span class="n">ifconfig</span>-<span class="n">pool</span> <span class="m">172</span>.<span class="m">22</span>.<span class="n">X</span>.<span class="m">146</span> <span class="m">172</span>.<span class="m">22</span>.<span class="n">X</span>.<span class="m">158</span> <span class="m">255</span>.<span class="m">255</span>.<span class="m">255</span>.<span class="m">240</span>

<span class="n">ifconfig</span>-<span class="n">pool</span>-<span class="n">persist</span> <span class="n">pool</span>-<span class="n">persist</span>.<span class="n">txt</span>

<span class="n">push</span> <span class="s2">"route-gateway 172.22.X.145"</span>
<span class="n">push</span> <span class="s2">"route 172.22.0.0 255.254.0.0"</span> 
<span class="c">###push "route 172.31.0.0 255.255.0.0" 
</span><span class="err">###</span><span class="n">push</span> <span class="s2">"route 10.0.0.0 255.0.0.0"</span> </code></pre>

<h2><a class="anchor" id="client-configuration" href="#client-configuration"></a>Client configuration</h2>

<p>Change <code>&lt;SERVER&gt;</code> and <code>&lt;PORT&gt;</code>.</p>

<pre class="highlight"><code><span class="n">client</span>

<span class="n">ca</span>   <span class="n">ca</span>.<span class="n">crt</span>
<span class="n">cert</span> <span class="n">myclient</span>.<span class="n">crt</span>
<span class="n">key</span>  <span class="n">myclient</span>.<span class="n">key</span>

<span class="n">dev</span> <span class="n">tun</span>
<span class="n">proto</span> <span class="n">udp6</span>
<span class="n">cipher</span> <span class="n">aes</span>-<span class="m">256</span>-<span class="n">cbc</span>

<span class="n">remote</span> &lt;<span class="n">SERVER</span>&gt; &lt;<span class="n">PORT</span>&gt;

<span class="n">tun</span>-<span class="n">mtu</span> <span class="m">1500</span>
<span class="n">fragment</span> <span class="m">1300</span>
<span class="n">mssfix</span>

<span class="n">route</span>-<span class="n">delay</span> <span class="m">2</span>
<span class="n">nobind</span>
<span class="n">persist</span>-<span class="n">key</span>
<span class="n">persist</span>-<span class="n">tun</span>
<span class="n">resolv</span>-<span class="n">retry</span> <span class="n">infinite</span>

<span class="n">verb</span> <span class="m">3</span></code></pre>

<h2><a class="anchor" id="certificate-management" href="#certificate-management"></a>Certificate management</h2>

<p>Use easy-rsa, it's easy to use.  Below is a very short description, find a real tutorial if you don't know how it works.</p>

<p>Build the CA: <code>. vars</code>, <code>./build-ca</code>, then generate the server key: <code>./build-key-server roaming-dn42</code>.</p>

<p>Then, for each client, generate a private key and a certificate: <code>./build-key myclient</code>.  The Common Name is the only important information (it will be used to identify the client, for instance in the logs).</p>

<h1><a class="anchor" id="see-also" href="#see-also"></a>See also</h1>

<ul>
<li><a href="/howto/networksettings">Network settings</a></li>
</ul>

<h1><a class="anchor" id="external-links" href="#external-links"></a>External Links</h1>

<ul>
<li>
<p>multicast: </p>

<ul>
<li><strong>OpenVPN</strong></li>
<li><a href="https://community.openvpn.net/openvpn/ticket/79">Optimizations for multicast over TAP w/ OpenVPN</a></li>
<li><p><a href="http://forums.openvpn.net/topic8036.html">Sending multicast over a openvpn tunnel</a></p></li>
<li><p><strong>RFC</strong></p></li>
<li><a href="https://tools.ietf.org/html/rfc3306">IPv6 - RFC3306</a></li>
<li><a href="https://en.wikipedia.org/wiki/Multicast_address#GLOP_addressing">IPv4 - multicast</a></li>
<li><a href="http://labs.spritelink.net/glop">IPv4 - GLOB calculator</a></li>
<li><a href="http://tools.ietf.org/html/rfc3180">RFC3108 GLOP Addressing in 233/8</a></li>
<li><a href="https://tools.ietf.org/html/rfc3138">RFC3138 Extended Assignments in 233/8</a></li>
</ul>
</li>
</ul>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
<li>
<p><a href="/Home" rel="nofollow">Home</a></p>

<ul>
<li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
<li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
<li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
<li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
<li><a href="/FAQ" rel="nofollow">FAQ</a></li>
</ul>
</li>
<li>
<p>How-To</p>

<ul>
<li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
<li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
<li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
<li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
<li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
<li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
<li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
<li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
<li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
<li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
<li><a href="/howto/Quagga" rel="nofollow">Quagga</a></li>
<li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
<li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
<li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
<li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
<li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
<li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
<li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
<li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
</ul>
</li>
<li>
<p>Services</p>

<ul>
<li><a href="/services/IRC" rel="nofollow">IRC</a></li>
<li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
<li><a href="/services/DNS" rel="nofollow">DNS</a></li>
<li><a href="/services/IX-Collection" rel="nofollow">IX Collection</a></li>
<li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
<li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
<li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
<li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
<li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
<li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
<li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
</ul>
</li>
<li>
<p>Internal</p>

<ul>
<li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
<li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
<li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
<li>
<a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a><br />
</li>
<li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
</ul>
</li>
<li>
<p>Historical</p>

<ul>
<li><a href="/historical/Bird" rel="nofollow">Bird 1</a></li>
</ul>
</li>
<li>
<p>External Tools</p>

<ul>
<li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
<li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
</ul>
</li>
</ul>

<hr />

	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p>Hosted by: <a href="mailto:xuu@sour.is" rel="nofollow">xuu</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">nurtic-vibe</a>, <a href="mailto:tom@xcv.vc" rel="nofollow">toBee</a>, <a href="mailto:dn42@burble.com" rel="nofollow">burble</a> | Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a></p>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/openvpn.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/openvpn.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
