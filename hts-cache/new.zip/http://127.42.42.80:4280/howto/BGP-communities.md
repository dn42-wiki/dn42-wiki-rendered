<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/BGP-communities.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>BGP-communities</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>BGP-communities</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/BGP-communities.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/BGP-communities.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    BGP-communities
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <p>Bird2 is a commonly used BGP daemon. This page provides configuration and help for using BGP communities with Bird2 for dn42.</p>

<p>Communities can be used to prioritize traffic based on different flags, in DN42 we are using communities to prioritize based on latency, bandwidth and encryption. Please note that everyone should be using community 64511.</p>

<p>The community is applied to the route when it is imported and exported, therefore you need to change your bird configuration
in /etc/bird/peers/*</p>

<p>The filter helpers can be stored in a separate file, for example /etc/bird/community_filters.conf.</p>

<p>Below, you will see an example config for peers based on the original filter implementation by Jplitza.
Additionally the below configuration applied BGP MED on exports using the communities
as an example for what they can be used for. 
This is based on mk16's lab implemenation at <a href="https://mk16.de/blog/lab-en/">https://mk16.de/blog/lab-en/</a></p>

<p>To properly assign the right community to your peer, please reference the table below. If you are running your own network and peering internally, please also apply the communities inside your network.</p>

<h2><a class="anchor" id="bgp-community-criteria" href="#bgp-community-criteria"></a>BGP community criteria</h2>
<pre class="highlight"><code>(<span class="m">64511</span>, <span class="m">1</span>) :: <span class="n">latency</span> \<span class="n">in</span> (<span class="m">0</span>, <span class="m">2</span>.<span class="m">7</span><span class="n">ms</span>]
(<span class="m">64511</span>, <span class="m">2</span>) :: <span class="n">latency</span> \<span class="n">in</span> (<span class="m">2</span>.<span class="m">7</span><span class="n">ms</span>, <span class="m">7</span>.<span class="m">3</span><span class="n">ms</span>]
(<span class="m">64511</span>, <span class="m">3</span>) :: <span class="n">latency</span> \<span class="n">in</span> (<span class="m">7</span>.<span class="m">3</span><span class="n">ms</span>, <span class="m">20</span><span class="n">ms</span>]
(<span class="m">64511</span>, <span class="m">4</span>) :: <span class="n">latency</span> \<span class="n">in</span> (<span class="m">20</span><span class="n">ms</span>, <span class="m">55</span><span class="n">ms</span>]
(<span class="m">64511</span>, <span class="m">5</span>) :: <span class="n">latency</span> \<span class="n">in</span> (<span class="m">55</span><span class="n">ms</span>, <span class="m">148</span><span class="n">ms</span>]
(<span class="m">64511</span>, <span class="m">6</span>) :: <span class="n">latency</span> \<span class="n">in</span> (<span class="m">148</span><span class="n">ms</span>, <span class="m">403</span><span class="n">ms</span>]
(<span class="m">64511</span>, <span class="m">7</span>) :: <span class="n">latency</span> \<span class="n">in</span> (<span class="m">403</span><span class="n">ms</span>, <span class="m">1097</span><span class="n">ms</span>]
(<span class="m">64511</span>, <span class="m">8</span>) :: <span class="n">latency</span> \<span class="n">in</span> (<span class="m">1097</span><span class="n">ms</span>, <span class="m">2981</span><span class="n">ms</span>]
(<span class="m">64511</span>, <span class="m">9</span>) :: <span class="n">latency</span> &gt; <span class="m">2981</span><span class="n">ms</span>
(<span class="m">64511</span>, <span class="n">x</span>) :: <span class="n">latency</span> \<span class="n">in</span> [<span class="n">exp</span>(<span class="n">x</span>-<span class="m">1</span>), <span class="n">exp</span>(<span class="n">x</span>)] <span class="n">ms</span> (<span class="n">for</span> <span class="n">x</span> &lt; <span class="m">10</span>)

(<span class="m">64511</span>, <span class="m">21</span>) :: <span class="n">bw</span> &gt;= <span class="m">0</span>.<span class="m">1</span><span class="n">mbit</span>
(<span class="m">64511</span>, <span class="m">22</span>) :: <span class="n">bw</span> &gt;= <span class="m">1</span><span class="n">mbit</span>
(<span class="m">64511</span>, <span class="m">23</span>) :: <span class="n">bw</span> &gt;= <span class="m">10</span><span class="n">mbit</span>
(<span class="m">64511</span>, <span class="m">24</span>) :: <span class="n">bw</span> &gt;= <span class="m">100</span><span class="n">mbit</span>
(<span class="m">64511</span>, <span class="m">25</span>) :: <span class="n">bw</span> &gt;= <span class="m">1000</span><span class="n">mbit</span>
(<span class="m">64511</span>, <span class="m">2</span><span class="n">x</span>) :: <span class="n">bw</span> &gt;= <span class="m">10</span>^(<span class="n">x</span>-<span class="m">2</span>) <span class="n">mbit</span>
<span class="n">bw</span> = <span class="n">min</span>(<span class="n">up</span>,<span class="n">down</span>) <span class="n">for</span> <span class="n">asymmetric</span> <span class="n">connections</span>

(<span class="m">64511</span>, <span class="m">31</span>) :: <span class="n">not</span> <span class="n">encrypted</span>
(<span class="m">64511</span>, <span class="m">32</span>) :: <span class="n">encrypted</span> <span class="n">with</span> <span class="n">unsafe</span> <span class="n">vpn</span> <span class="n">solution</span>
(<span class="m">64511</span>, <span class="m">33</span>) :: <span class="n">encrypted</span> <span class="n">with</span> <span class="n">safe</span> <span class="n">vpn</span> <span class="n">solution</span> (<span class="n">but</span> <span class="n">no</span> <span class="n">PFS</span> - <span class="n">the</span> <span class="n">usual</span> <span class="n">OpenVPN</span> <span class="n">p2p</span> <span class="n">configuration</span> <span class="n">falls</span> <span class="n">in</span> <span class="n">this</span> <span class="n">category</span>)
(<span class="m">64511</span>, <span class="m">34</span>) :: <span class="n">encrypted</span> <span class="n">with</span> <span class="n">safe</span> <span class="n">vpn</span> <span class="n">solution</span> <span class="n">with</span> <span class="n">PFS</span> (<span class="n">Perfect</span> <span class="n">Forward</span> <span class="n">Secrecy</span>)

<span class="n">Propagation</span>:
- - <span class="n">for</span> <span class="n">latency</span> <span class="n">pick</span> <span class="n">max</span>(<span class="n">received_route</span>.<span class="n">latency</span>, <span class="n">link_latency</span>)
- - <span class="n">for</span> <span class="n">encryption</span> <span class="n">and</span> <span class="n">bandwidth</span> <span class="n">pick</span> <span class="n">min</span> <span class="n">between</span> <span class="n">received</span> <span class="n">BGP</span> <span class="n">community</span> <span class="n">and</span> <span class="n">peer</span> <span class="n">link</span></code></pre>
For example, if your peer is 12ms away and the link speed between you is 250Mbit/s and you are peering using OpenVPN P2P, then the community string would be (3, 24, 33).

<p>Two utilities which measure round trip time and calculate community values automatically are provided, written in  <a href="https://github.com/Mic92/bird-dn42/blob/master/bgp-community.rb">ruby</a> and <a href="https://github.com/nixnodes/bird/blob/master/misc/dn42-comgen.c">C</a>.</p>

<p><strong>Note: In general, the link latency metric only reflects the latency of the <em>immediate</em> link, and not the overall latency from following a path</strong>. A route may traverse multiple internal routers once it enters an AS, and because this is invisible to BGP, it's best to treat latency values as informational only and not use them to make routing decisions.</p>

<pre class="highlight"><code><span class="nv">$ </span>ruby bgp-community.rb <span class="nt">--help</span>
USAGE: bgp-community.rb host mbit_speed unencrypted|unsafe|encrypted|pfs
    <span class="nt">-6</span>, <span class="nt">--ipv6</span>                       Assume ipv6 <span class="k">for </span>ping
<span class="nv">$ </span>ruby bgp-community.rb 212.129.13.123 300 encrypted
  <span class="c"># 15 ms, 300 mbit/s, encrypted tunnel (updated: 2016-02-11)</span>
  import where dn42_import_filter<span class="o">(</span>3,24,33<span class="o">)</span><span class="p">;</span>
  <span class="nb">export </span>where dn42_export_filter<span class="o">(</span>3,24,33<span class="o">)</span><span class="p">;</span>
<span class="nv">$ </span>ruby bgp-community.rb <span class="nt">-6</span> dn42-2.higgsboson.tk 1000 pfs
  <span class="c"># 11 ms, 1000 mbit/s, pfs tunnel (updated: 2016-02-11)</span>
  import where dn42_import_filter<span class="o">(</span>3,25,34<span class="o">)</span><span class="p">;</span>
  <span class="nb">export </span>where dn42_export_filter<span class="o">(</span>3,25,34<span class="o">)</span><span class="p">;</span></code></pre>

<h3><a class="anchor" id="route-origin" href="#route-origin"></a>Route Origin</h3>
<p>There are two type of route origin: <code>region</code> and <code>country</code></p>

<h4><a class="anchor" id="region" href="#region"></a>Region</h4>
<p>The range <code>41-70</code> is assigned to the region property.
The communities for route origin region were first defined in <a href="https://lists.nox.tf/pipermail/dn42/2015-December/001259.html">December 2015</a> and further extended in <a href="https://groups.io/g/dn42/topic/91226190">May 2022</a>:</p>

<pre class="highlight"><code>(<span class="m">64511</span>, <span class="m">41</span>) :: <span class="n">Europe</span>
(<span class="m">64511</span>, <span class="m">42</span>) :: <span class="n">North</span> <span class="n">America</span>-<span class="n">E</span>
(<span class="m">64511</span>, <span class="m">43</span>) :: <span class="n">North</span> <span class="n">America</span>-<span class="n">C</span>
(<span class="m">64511</span>, <span class="m">44</span>) :: <span class="n">North</span> <span class="n">America</span>-<span class="n">W</span>
(<span class="m">64511</span>, <span class="m">45</span>) :: <span class="n">Central</span> <span class="n">America</span>
(<span class="m">64511</span>, <span class="m">46</span>) :: <span class="n">South</span> <span class="n">America</span>-<span class="n">E</span>
(<span class="m">64511</span>, <span class="m">47</span>) :: <span class="n">South</span> <span class="n">America</span>-<span class="n">W</span>
(<span class="m">64511</span>, <span class="m">48</span>) :: <span class="n">Africa</span>-<span class="n">N</span> (<span class="n">above</span> <span class="n">Sahara</span>)
(<span class="m">64511</span>, <span class="m">49</span>) :: <span class="n">Africa</span>-<span class="n">S</span> (<span class="n">below</span> <span class="n">Sahara</span>)
(<span class="m">64511</span>, <span class="m">50</span>) :: <span class="n">Asia</span>-<span class="n">S</span> (<span class="n">IN</span>,<span class="n">PK</span>,<span class="n">BD</span>)
(<span class="m">64511</span>, <span class="m">51</span>) :: <span class="n">Asia</span>-<span class="n">SE</span> (<span class="n">TH</span>,<span class="n">SG</span>,<span class="n">PH</span>,<span class="n">ID</span>,<span class="n">MY</span>)
(<span class="m">64511</span>, <span class="m">52</span>) :: <span class="n">Asia</span>-<span class="n">E</span> (<span class="n">JP</span>,<span class="n">CN</span>,<span class="n">KR</span>,<span class="n">TW</span>,<span class="n">HK</span>)
(<span class="m">64511</span>, <span class="m">53</span>) :: <span class="n">Pacific</span>&amp;<span class="n">Oceania</span> (<span class="n">AU</span>,<span class="n">NZ</span>,<span class="n">FJ</span>)
(<span class="m">64511</span>, <span class="m">54</span>) :: <span class="n">Antarctica</span>
(<span class="m">64511</span>, <span class="m">55</span>) :: <span class="n">Asia</span>-<span class="n">N</span> (<span class="n">RU</span>)
(<span class="m">64511</span>, <span class="m">56</span>) :: <span class="n">Asia</span>-<span class="n">W</span> (<span class="n">IR</span>,<span class="n">TR</span>,<span class="n">UAE</span>)
(<span class="m">64511</span>, <span class="m">57</span>) :: <span class="n">Central</span> <span class="n">Asia</span> (<span class="n">AF</span>,<span class="n">UZ</span>,<span class="n">KZ</span>)</code></pre>

<h4><a class="anchor" id="country" href="#country"></a>Country</h4>
<p>The range <code>1000-1999</code> is assigned to the country property. Here we use <a href="https://github.com/lukes/ISO-3166-Countries-with-Regional-Codes/blob/master/all/all.csv">ISO-3166-1 numeric</a> country codes, adding <code>1000</code> to each value to get the country origin community:</p>

<pre class="highlight"><code>(<span class="m">64511</span>, <span class="m">1124</span>) :: <span class="n">Canada</span>
(<span class="m">64511</span>, <span class="m">1156</span>) :: <span class="n">China</span>
(<span class="m">64511</span>, <span class="m">1158</span>) :: <span class="n">Taiwan</span>
(<span class="m">64511</span>, <span class="m">1250</span>) :: <span class="n">France</span>
(<span class="m">64511</span>, <span class="m">1276</span>) :: <span class="n">Germany</span>
(<span class="m">64511</span>, <span class="m">1344</span>) :: <span class="n">Hong</span> <span class="n">Kong</span>
(<span class="m">64511</span>, <span class="m">1392</span>) :: <span class="n">Japan</span>
(<span class="m">64511</span>, <span class="m">1528</span>) :: <span class="n">Netherlands</span>
(<span class="m">64511</span>, <span class="m">1578</span>) :: <span class="n">Norway</span>
(<span class="m">64511</span>, <span class="m">1643</span>) :: <span class="n">Russian</span> <span class="n">Federation</span>
(<span class="m">64511</span>, <span class="m">1702</span>) :: <span class="n">Singapore</span>
(<span class="m">64511</span>, <span class="m">1756</span>) :: <span class="n">Switzerland</span>
(<span class="m">64511</span>, <span class="m">1826</span>) :: <span class="n">United</span> <span class="n">Kingdom</span>
(<span class="m">64511</span>, <span class="m">1840</span>) :: <span class="n">United</span> <span class="n">States</span> <span class="n">of</span> <span class="n">America</span></code></pre>
etc. Please follow the ISO-3166-1 Numeric standard
<a href="https://github.com/lukes/ISO-3166-Countries-with-Regional-Codes/blob/master/all/all.csv">https://github.com/lukes/ISO-3166-Countries-with-Regional-Codes/blob/master/all/all.csv</a>.

<p>You need to add following lines to your config(s):</p>
<ul>
  <li>
<code>define DN42_REGION = $VALUE_FROM_ABOVE</code> to your node's config (where OWNAS and OWNIP are set)</li>
  <li>
<code>if source = RTS_STATIC then bgp_community.add((64511, DN42_REGION));</code>
just above <code>update_flags</code> in <code>dn42_export_filter</code> function</li>
  <li>Unlike the other community values, <strong>the DN42_REGION community should only be set on routes originating from your network!</strong> (This is what the <code>source = RTS_STATIC</code> check does).
    <ul>
      <li>Otherwise, if you export routes across multiple regions within your network, you may be sending incorrect origin information to other peers.
This is not applicable  for the below example configurations
that have it included, since networks usually use the region to do 
routing policies like cold_potato.
        <h2><a class="anchor" id="example-configuration-for-bird2" href="#example-configuration-for-bird2"></a>Example configuration for BIRD2</h2>
        <pre class="highlight"><code><span class="n">function</span> <span class="n">update_latency</span>(<span class="n">int</span> <span class="n">link_latency</span>) -&gt; <span class="n">int</span> {
  <span class="n">bgp_community</span>.<span class="n">add</span>((<span class="m">64511</span>, <span class="n">link_latency</span>));
       <span class="n">if</span> (<span class="m">64511</span>, <span class="m">9</span>) ~ <span class="n">bgp_community</span> <span class="n">then</span> { <span class="n">bgp_community</span>.<span class="n">delete</span>([(<span class="m">64511</span>, <span class="m">1</span>..<span class="m">8</span>)]); <span class="n">return</span> <span class="m">9</span>; }
  <span class="n">else</span> <span class="n">if</span> (<span class="m">64511</span>, <span class="m">8</span>) ~ <span class="n">bgp_community</span> <span class="n">then</span> { <span class="n">bgp_community</span>.<span class="n">delete</span>([(<span class="m">64511</span>, <span class="m">1</span>..<span class="m">7</span>)]); <span class="n">return</span> <span class="m">8</span>; }
  <span class="n">else</span> <span class="n">if</span> (<span class="m">64511</span>, <span class="m">7</span>) ~ <span class="n">bgp_community</span> <span class="n">then</span> { <span class="n">bgp_community</span>.<span class="n">delete</span>([(<span class="m">64511</span>, <span class="m">1</span>..<span class="m">6</span>)]); <span class="n">return</span> <span class="m">7</span>; }
  <span class="n">else</span> <span class="n">if</span> (<span class="m">64511</span>, <span class="m">6</span>) ~ <span class="n">bgp_community</span> <span class="n">then</span> { <span class="n">bgp_community</span>.<span class="n">delete</span>([(<span class="m">64511</span>, <span class="m">1</span>..<span class="m">5</span>)]); <span class="n">return</span> <span class="m">6</span>; }
  <span class="n">else</span> <span class="n">if</span> (<span class="m">64511</span>, <span class="m">5</span>) ~ <span class="n">bgp_community</span> <span class="n">then</span> { <span class="n">bgp_community</span>.<span class="n">delete</span>([(<span class="m">64511</span>, <span class="m">1</span>..<span class="m">4</span>)]); <span class="n">return</span> <span class="m">5</span>; }
  <span class="n">else</span> <span class="n">if</span> (<span class="m">64511</span>, <span class="m">4</span>) ~ <span class="n">bgp_community</span> <span class="n">then</span> { <span class="n">bgp_community</span>.<span class="n">delete</span>([(<span class="m">64511</span>, <span class="m">1</span>..<span class="m">3</span>)]); <span class="n">return</span> <span class="m">4</span>; }
  <span class="n">else</span> <span class="n">if</span> (<span class="m">64511</span>, <span class="m">3</span>) ~ <span class="n">bgp_community</span> <span class="n">then</span> { <span class="n">bgp_community</span>.<span class="n">delete</span>([(<span class="m">64511</span>, <span class="m">1</span>..<span class="m">2</span>)]); <span class="n">return</span> <span class="m">3</span>; }
  <span class="n">else</span> <span class="n">if</span> (<span class="m">64511</span>, <span class="m">2</span>) ~ <span class="n">bgp_community</span> <span class="n">then</span> { <span class="n">bgp_community</span>.<span class="n">delete</span>([(<span class="m">64511</span>, <span class="m">1</span>..<span class="m">1</span>)]); <span class="n">return</span> <span class="m">2</span>; }
  <span class="n">else</span> <span class="n">return</span> <span class="m">1</span>;
}


<span class="n">function</span> <span class="n">update_bandwidth</span>(<span class="n">int</span> <span class="n">link_bandwidth</span>) -&gt; <span class="n">int</span> {
  <span class="n">bgp_community</span>.<span class="n">add</span>((<span class="m">64511</span>, <span class="n">link_bandwidth</span>));
       <span class="n">if</span> (<span class="m">64511</span>, <span class="m">21</span>) ~ <span class="n">bgp_community</span> <span class="n">then</span> { <span class="n">bgp_community</span>.<span class="n">delete</span>([(<span class="m">64511</span>, <span class="m">22</span>..<span class="m">29</span>)]); <span class="n">return</span> <span class="m">21</span>; }
  <span class="n">else</span> <span class="n">if</span> (<span class="m">64511</span>, <span class="m">22</span>) ~ <span class="n">bgp_community</span> <span class="n">then</span> { <span class="n">bgp_community</span>.<span class="n">delete</span>([(<span class="m">64511</span>, <span class="m">23</span>..<span class="m">29</span>)]); <span class="n">return</span> <span class="m">22</span>; }
  <span class="n">else</span> <span class="n">if</span> (<span class="m">64511</span>, <span class="m">23</span>) ~ <span class="n">bgp_community</span> <span class="n">then</span> { <span class="n">bgp_community</span>.<span class="n">delete</span>([(<span class="m">64511</span>, <span class="m">24</span>..<span class="m">29</span>)]); <span class="n">return</span> <span class="m">23</span>; }
  <span class="n">else</span> <span class="n">if</span> (<span class="m">64511</span>, <span class="m">24</span>) ~ <span class="n">bgp_community</span> <span class="n">then</span> { <span class="n">bgp_community</span>.<span class="n">delete</span>([(<span class="m">64511</span>, <span class="m">25</span>..<span class="m">29</span>)]); <span class="n">return</span> <span class="m">24</span>; }
  <span class="n">else</span> <span class="n">if</span> (<span class="m">64511</span>, <span class="m">25</span>) ~ <span class="n">bgp_community</span> <span class="n">then</span> { <span class="n">bgp_community</span>.<span class="n">delete</span>([(<span class="m">64511</span>, <span class="m">26</span>..<span class="m">29</span>)]); <span class="n">return</span> <span class="m">25</span>; }
  <span class="n">else</span> <span class="n">if</span> (<span class="m">64511</span>, <span class="m">26</span>) ~ <span class="n">bgp_community</span> <span class="n">then</span> { <span class="n">bgp_community</span>.<span class="n">delete</span>([(<span class="m">64511</span>, <span class="m">27</span>..<span class="m">29</span>)]); <span class="n">return</span> <span class="m">26</span>; }
  <span class="n">else</span> <span class="n">if</span> (<span class="m">64511</span>, <span class="m">27</span>) ~ <span class="n">bgp_community</span> <span class="n">then</span> { <span class="n">bgp_community</span>.<span class="n">delete</span>([(<span class="m">64511</span>, <span class="m">28</span>..<span class="m">29</span>)]); <span class="n">return</span> <span class="m">27</span>; }
  <span class="n">else</span> <span class="n">if</span> (<span class="m">64511</span>, <span class="m">28</span>) ~ <span class="n">bgp_community</span> <span class="n">then</span> { <span class="n">bgp_community</span>.<span class="n">delete</span>([(<span class="m">64511</span>, <span class="m">29</span>..<span class="m">29</span>)]); <span class="n">return</span> <span class="m">28</span>; }
  <span class="n">else</span> <span class="n">return</span> <span class="m">29</span>;
}

<span class="n">function</span> <span class="n">update_crypto</span>(<span class="n">int</span> <span class="n">link_crypto</span>) -&gt; <span class="n">int</span> {
  <span class="n">bgp_community</span>.<span class="n">add</span>((<span class="m">64511</span>, <span class="n">link_crypto</span>));
       <span class="n">if</span> (<span class="m">64511</span>, <span class="m">31</span>) ~ <span class="n">bgp_community</span> <span class="n">then</span> { <span class="n">bgp_community</span>.<span class="n">delete</span>([(<span class="m">64511</span>, <span class="m">32</span>..<span class="m">34</span>)]); <span class="n">return</span> <span class="m">31</span>; }
  <span class="n">else</span> <span class="n">if</span> (<span class="m">64511</span>, <span class="m">32</span>) ~ <span class="n">bgp_community</span> <span class="n">then</span> { <span class="n">bgp_community</span>.<span class="n">delete</span>([(<span class="m">64511</span>, <span class="m">33</span>..<span class="m">34</span>)]); <span class="n">return</span> <span class="m">32</span>; }
  <span class="n">else</span> <span class="n">if</span> (<span class="m">64511</span>, <span class="m">33</span>) ~ <span class="n">bgp_community</span> <span class="n">then</span> { <span class="n">bgp_community</span>.<span class="n">delete</span>([(<span class="m">64511</span>, <span class="m">34</span>..<span class="m">34</span>)]); <span class="n">return</span> <span class="m">33</span>; }
  <span class="n">else</span> <span class="n">return</span> <span class="m">34</span>;
}
<span class="c">#Remove the following function if you do not want to advertize your region in the BGP community.
</span><span class="n">function</span> <span class="n">update_geo_flags</span>() -&gt; <span class="n">bool</span> {
    <span class="n">if</span> <span class="n">is_self_net</span>() || <span class="n">is_self_net_v6</span>() <span class="n">then</span> {
        <span class="n">bgp_community</span>.<span class="n">add</span>((<span class="m">64511</span>, <span class="n">DN_REGION_GEO</span>));
	    <span class="n">bgp_community</span>.<span class="n">add</span>((<span class="m">64511</span>, <span class="n">DN_REGION_COUNTRY</span>));
    }
}
<span class="n">function</span> <span class="n">update_flags</span>(<span class="n">int</span> <span class="n">link_latency</span>; <span class="n">int</span> <span class="n">link_bandwidth</span>; <span class="n">int</span> <span class="n">link_crypto</span>) -&gt; <span class="n">bool</span>
<span class="n">int</span> <span class="n">dn42_latency</span>;
<span class="n">int</span> <span class="n">dn42_bandwidth</span>;
<span class="n">int</span> <span class="n">dn42_crypto</span>;
{
  <span class="n">dn42_latency</span> = <span class="n">update_latency</span>(<span class="n">link_latency</span>);
  <span class="n">dn42_bandwidth</span> = <span class="n">update_bandwidth</span>(<span class="n">link_bandwidth</span>) - <span class="m">20</span>;
  <span class="n">dn42_crypto</span> = <span class="n">update_crypto</span>(<span class="n">link_crypto</span>) - <span class="m">30</span>;
  <span class="c"># replace 4 with your calculated bandwidth value
</span>  <span class="n">if</span> <span class="n">dn42_bandwidth</span> &gt; <span class="m">4</span> <span class="n">then</span> <span class="n">dn42_bandwidth</span> = <span class="m">4</span>;
  <span class="n">return</span> <span class="n">true</span>;
}

<span class="c">#Uses ROA, which means it should be imported before these functions
</span>
<span class="n">function</span> <span class="n">dn42_import_filter</span>(<span class="n">int</span> <span class="n">link_latency</span>; <span class="n">int</span> <span class="n">link_bandwidth</span>; <span class="n">int</span> <span class="n">link_crypto</span>) {
  <span class="c"># IPv4 routes with ROA
</span>  <span class="n">if</span> <span class="n">is_valid_network</span>() &amp;&amp; !<span class="n">is_self_net</span>() <span class="n">then</span> {
    <span class="n">if</span> (<span class="n">roa_check</span>(<span class="n">dn42_roa</span>, <span class="n">net</span>, <span class="n">bgp_path</span>.<span class="n">last</span>) != <span class="n">ROA_VALID</span>) <span class="n">then</span> {
      <span class="c"># Reject when unknown or invalid according to ROA
</span>      <span class="n">print</span> <span class="s2">"[dn42] IPv4 ROA check failed for "</span>, <span class="n">net</span>, <span class="s2">" ASN "</span>, <span class="n">bgp_path</span>.<span class="n">last</span>;
      <span class="n">reject</span>;
    }

    <span class="n">update_flags</span>(<span class="n">link_latency</span>, <span class="n">link_bandwidth</span>, <span class="n">link_crypto</span>);

    <span class="n">if</span> (<span class="n">bgp_path</span>.<span class="n">len</span> = <span class="m">1</span>) <span class="n">then</span>
      <span class="n">bgp_local_pref</span> = <span class="n">bgp_local_pref</span> + <span class="m">500</span>;

    <span class="n">accept</span>;
  }

  <span class="c"># IPv6 routes with ROA
</span>  <span class="n">if</span> <span class="n">is_valid_network_v6</span>() &amp;&amp; !<span class="n">is_self_net_v6</span>() <span class="n">then</span> {
    <span class="n">if</span> (<span class="n">roa_check</span>(<span class="n">dn42_roa_v6</span>, <span class="n">net</span>, <span class="n">bgp_path</span>.<span class="n">last</span>) != <span class="n">ROA_VALID</span>) <span class="n">then</span> {
      <span class="c"># Reject when unknown or invalid according to ROA
</span>      <span class="n">print</span> <span class="s2">"[dn42] IPv6 ROA check failed for "</span>, <span class="n">net</span>, <span class="s2">" ASN "</span>, <span class="n">bgp_path</span>.<span class="n">last</span>;
      <span class="n">reject</span>;
    }

    <span class="n">update_flags</span>(<span class="n">link_latency</span>, <span class="n">link_bandwidth</span>, <span class="n">link_crypto</span>);

    <span class="n">if</span> (<span class="n">bgp_path</span>.<span class="n">len</span> = <span class="m">1</span>) <span class="n">then</span>
      <span class="n">bgp_local_pref</span> = <span class="n">bgp_local_pref</span> + <span class="m">500</span>;

    <span class="n">accept</span>;
  }

  <span class="c"># Re
</span>  <span class="n">reject</span>;
}
<span class="n">function</span> <span class="n">dn42_export_filter</span>(<span class="n">int</span> <span class="n">link_latency</span>; <span class="n">int</span> <span class="n">link_bandwidth</span>; <span class="n">int</span> <span class="n">link_crypto</span>) {
  <span class="n">if</span> <span class="n">is_valid_network</span>() || <span class="n">is_valid_network_v6</span>() <span class="n">then</span> {
    <span class="n">update_flags</span>(<span class="n">link_latency</span>, <span class="n">link_bandwidth</span>, <span class="n">link_crypto</span>);
    <span class="n">update_geo_flags</span>();
    <span class="n">bgp_med</span> = <span class="m">0</span>;
    <span class="n">bgp_med</span> = <span class="n">bgp_med</span> + ( ( <span class="m">4</span> - ( <span class="n">link_crypto</span> - <span class="m">30</span> ) ) * <span class="m">600</span> );
    <span class="n">bgp_med</span> = <span class="n">bgp_med</span> + ( ( <span class="m">9</span> - ( <span class="n">link_bandwidth</span> - <span class="m">20</span> ) ) * <span class="m">100</span>);
    <span class="n">bgp_med</span> = <span class="n">bgp_med</span> + ( ( <span class="n">link_latency</span> - <span class="m">1</span>) * <span class="m">300</span>);

    <span class="n">accept</span>;
  }
  <span class="n">reject</span>;
}
</code></pre>
And in your /etc/bird/peers/example.conf peer where  your  parameters as as such
11 ms, 1000 mbit/s, pfs tunnel example with MP-BGP with ENH
<pre class="highlight"><code><span class="n">protocol</span> <span class="n">bgp</span> <span class="n">example</span> <span class="n">from</span> <span class="n">dnpeers</span> {
    <span class="n">neighbor</span> <span class="n">neighbor</span> &lt;<span class="n">neighborip</span>&gt;&lt;%<span class="n">interface</span> <span class="n">if</span> <span class="n">Link</span> <span class="n">Local</span> <span class="n">is</span> <span class="n">used</span>&gt; <span class="n">as</span> &lt;<span class="n">AUT_NUM</span>&gt;;
    <span class="n">ipv4</span> {
        <span class="n">extended</span> <span class="n">next</span> <span class="n">hop</span> <span class="n">on</span>;
		<span class="n">import</span> <span class="n">where</span> <span class="n">dn42_import_filter</span>(<span class="m">3</span>,<span class="m">25</span>,<span class="m">34</span>);
		<span class="n">export</span> <span class="n">where</span> <span class="n">dn42_export_filter</span>(<span class="m">3</span>,<span class="m">25</span>,<span class="m">34</span>);
    };

    <span class="n">ipv6</span> {
		<span class="n">import</span> <span class="n">where</span> <span class="n">dn42_import_filter</span>(<span class="m">3</span>,<span class="m">25</span>,<span class="m">34</span>);
		<span class="n">export</span> <span class="n">where</span> <span class="n">dn42_export_filter</span>(<span class="m">3</span>,<span class="m">25</span>,<span class="m">34</span>);
    };</code></pre>
Please remember to include /etc/bird/community_filters.conf and to define your GEO regions in your bird.conf 
<pre class="highlight"><code><span class="c"># local configuration
######################
# In the variable header or anywhere before the include for the community filters add
</span><span class="n">define</span> <span class="n">DN_REGION_GEO</span> = <span class="n">xx</span>;
<span class="n">define</span> <span class="n">DN_REGION_COUNTRY</span> = <span class="n">xxxx</span>;
<span class="c">#If you wish to add the BGP Geographical Communities.
</span>
<span class="c">#before you import your peers add  the community filters eg
#include "/etc/bird/community_filters.conf";
#include "/etc/bird/peers/*";
</span><span class="n">include</span> <span class="s2">"/etc/bird/community_filters.conf"</span>;</code></pre>
      </li>
    </ul>
  </li>
</ul>

<hr />

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
      <li><a href="/Links" rel="nofollow">Links</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
      <li><a href="/howto/GeoFeed" rel="nofollow">GeoFeed</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/DNS" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">RPKI</a></li>
      <li><a href="/services/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
      <li><a href="/services/Registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
      <li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
    </ul>
  </li>
  <li>Historical
    <ul>
      <li><a href="/historical/Bird" rel="nofollow">Bird 1</a></li>
      <li><a href="/historical/Quagga" rel="nofollow">Quagga</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://hedgedoc.dn42.eu" rel="nofollow">HedgeDoc</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>, <a href="https://iedon.net/post/24" rel="nofollow">IEDON-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>, <a href="https://dn42.jp/" rel="nofollow">dn42.jp</a> (wiki-go)</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/BGP-communities.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/BGP-communities.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
