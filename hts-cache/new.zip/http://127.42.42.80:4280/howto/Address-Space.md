<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-309be032396e783b13a47df58f389b7c8e11c2b2d42640560b874f677c25f6e5.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">

  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/Address-Space.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-f05401ee374f0c7f48fc2bc08e30b4f4db705861fd5895ed70998683b383bfb5.js" type="text/javascript"></script>
  

  <title>Address-Space</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Address-Space</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/Address-Space.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <a class="btn btn-sm" id="minibutton-home" href="/">
      Home
    </a>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/overview"
          id="minibutton-overview"
        >
          Overview
        </a>

        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/latest_changes"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </a>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          href="/gollum/history/howto/Address-Space.md/"
          id="minibutton-history"
        >
          History
        </a>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Address-Space
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <p>DN42 uses network addresses in the <a href="https://tools.ietf.org/html/rfc1918">rfc1918</a> and <a href="https://tools.ietf.org/html/rfc4193">ULA</a> ranges. These are described in detail within the sections below. </p>

<p>The <a href="https://git.dn42.dev/dn42/registry">DN42 registry</a> is the authoritative source of information on address space assignment. Within the registry, the DN42 address space is divided in to blocks based on <em>policies</em> that define how the addresses may be used. Policies are defined in <code>inetnum</code> and <code>inet6num</code> objects and can be:</p>

<ul>
<li>
<strong>open</strong> - users may request prefixes in this range, subject to any constraints that are described in the <code>remark</code> attributes</li>
<li>
<strong>closed</strong> - these ranges cannot be assigned</li>
<li>
<strong>reserved</strong> - these ranges are reserved for future use</li>
<li>
<strong>ask</strong> - these ranges are for specific uses, please ask on the mailing list before requesting assignments</li>
</ul>

<p>A simple way to see all the active policies in the registry is to search the registry content for policy attributes:</p>

<pre class="highlight"><code><span class="nb">grep</span> <span class="nt">-r</span> ^policy data/inet<span class="o">{</span>,6<span class="o">}</span>num/</code></pre>

<p>The <a href="https://git.dn42.dev/dn42/registry/src/master/data/filter.txt">filter.txt</a> and <a href="https://git.dn42.dev/dn42/registry/src/master/data/filter6.txt">filter6.txt</a> files within the registry detail the network wide constraints on what address ranges are in use together with the global limits on what can be announced. </p>

<p><code>inetnum</code> and <code>inet6num</code> objects within the registry are used to describe the allocation of address space to users. <code>route</code> and <code>route6</code> objects in the registry are used to validate routing announcements through <a href="https://wiki.dn42/howto/Bird#route-origin-authorization">ROA</a>. </p>

<p>In addition to the native DN42 address ranges, the registry also contains allocations for the address space used by affiliate networks. These are updated by a regular <a href="https://git.dn42.dev/dn42/registry-sync">sync script</a>. </p>

<p>Globally routable prefixes are not supported in DN42; they are denied via the registry filter{6,}.txt files and many networks will filter both announcements and traffic for prefixes that are outside of the allowable ranges.</p>

<h1><a class="anchor" id="ipv6-address-space" href="#ipv6-address-space"></a>IPv6 Address Space</h1>

<p>DN42 uses the fd00::/8 ULA range for IPv6 addresses. Apart from a block of addresses reserved for anycast (fd42:d42:d42::/48), the whole fd00::/8 block has an open policy and users are free to request any prefix in this range, that is not already allocated. </p>

<p><strong>The DN42 registry is not authoritative for the fd00::/8 range</strong></p>

<p>DN42 is interconnected with other networks, like icvpn, which also use the same ULA range and many users will also use this range for their own networks. A registration in the dn42 registry cannot prevent IPv6 conflicts, so a fully random prefix (see <a href="https://tools.ietf.org/html/rfc4193">RFC4193</a>) is strongly recommended. If an address conflict is found, then needing to renumber your network is no fun.</p>

<h1><a class="anchor" id="ipv4-address-space" href="#ipv4-address-space"></a>IPv4 Address Space</h1>

<p>DN42 uses the 172.20.0.0/14 range for IPv4 addresses. As with the public internet, IPv4 space is more limited and users are encouraged to conserve space where possible. A typical assignment in DN42 is a /27 and any requests for assignments larger than /24 must provide justification. </p>

<p>Unlike the IPv6 address space, the DN42 IPv4 space is not fully open for assignment to users; some ranges are intended for specific uses and other ranges are reserved. See the policy section, below. Users should always check the policy in the registry before requesting a prefix to be assigned. </p>

<p>There are other IPv4 ranges in use within DN42 related to the affiliate networks, see the <a href="https://git.dn42.dev/dn42/registry/src/master/data/filter.txt">filter.txt</a> file in the registry. </p>

<h2><a class="anchor" id="ipv4-policies" href="#ipv4-policies"></a>IPv4 Policies</h2>

<p>The diagram below shows the allocation policies for the DN42 address space. </p>

<p><img src="images/PolicyMap.png" alt="Policy Map Image" /></p>

<p>Specific policy restrictions:</p>

<table>
<thead>
<tr>
<th>Prefix</th>
<th>Usage</th>
</tr>
</thead>
<tbody>
<tr>
<td>172.20.0.0/24<br />172.21.0.0/24<br />172.22.0.0/24<br />172.23.0.0/24</td>
<td>Reserved for anycast addresses</td>
</tr>
<tr>
<td>172.20.240.0/20<br />172.22.240.0/20</td>
<td>Reserved for transfer networks</td>
</tr>
<tr>
<td>172.20.64.0/18</td>
<td>Reserved for allocations larger than /23, up to /21</td>
</tr>
<tr>
<td>172.22.0.0/18</td>
<td>Reserved for allocations of /24 or larger, up to /21</td>
</tr>
<tr>
<td>172.23.16.0/21</td>
<td>Closed to new allocations</td>
</tr>
<tr>
<td>172.21.0.0/18<br />172.21.128.0/17<br />172.22.192.0/18</td>
<td>Reserved for future use</td>
</tr>
</tbody>
</table>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
<li>
<a href="/Home" rel="nofollow">Home</a>

<ul>
<li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
<li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
<li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
<li><a href="/howto/Bird-communities" rel="nofollow">BGP communities</a></li>
<li><a href="/FAQ" rel="nofollow">FAQ</a></li>
</ul>
</li>
</ul>

<ul>
<li>
<p>How-To</p>

<ul>
<li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
<li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
<li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
<li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
<li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
<li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
<li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
<li>
<a href="/howto/Bird" rel="nofollow">Bird</a> / <a href="/howto/Bird2" rel="nofollow">Bird2</a>
</li>
<li><a href="/howto/Quagga" rel="nofollow">Quagga</a></li>
<li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
<li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
<li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
<li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
<li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
<li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
<li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
</ul>
</li>
<li>
<p>Services</p>

<ul>
<li><a href="/services/IRC" rel="nofollow">IRC</a></li>
<li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
<li><a href="/services/DNS" rel="nofollow">DNS</a></li>
<li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
<li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
<li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
<li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
<li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
<li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
<li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
</ul>
</li>
<li>
<p>Internal</p>

<ul>
<li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
<li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
<li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
<li>
<a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a><br />
</li>
<li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
</ul>
</li>
<li>
<p>External Tools</p>

<ul>
<li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
<li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
</ul>
</li>
</ul>

<hr />

	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p>Hosted by: <a href="mailto:xuu@sour.is" rel="nofollow">xuu</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">nurtic-vibe</a>, <a href="mailto:tom@xcv.vc" rel="nofollow">toBee</a>, <a href="mailto:dn42@burble.com" rel="nofollow">burble</a> | Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a></p>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/Address-Space.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/Address-Space.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
