<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/Munin.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Munin</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Munin</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/Munin.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/Munin.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Munin
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h2><a class="anchor" id="number-of-routes-by-as" href="#number-of-routes-by-as"></a>Number of routes by AS</h2>

<p>IPv4:
</p><pre class="highlight"><code><span class="c">#!/bin/bash</span>
<span class="k">if</span> <span class="o">[</span> <span class="s2">"</span><span class="nv">$1</span><span class="s2">"</span> <span class="o">=</span> <span class="s2">"config"</span> <span class="o">]</span><span class="p">;</span><span class="k">then
	</span><span class="nb">echo </span>graph_title Number of routes
	<span class="nb">echo </span>graph_vlabel num. routes
	<span class="nb">echo </span>graph_category network
	<span class="nb">echo </span>graph_scale no
	<span class="k">for </span>AS <span class="k">in</span> <span class="si">$(</span>ip r|sed <span class="s1">'s/.* dev //;s/ .*//'</span>|sort|uniq <span class="nt">-c</span>|grep as|awk <span class="s1">'{print $2}'</span><span class="si">)</span><span class="p">;</span><span class="k">do
		</span><span class="nb">echo</span> <span class="nv">$AS</span>.label <span class="nv">$AS</span>
	<span class="k">done
else
	</span>ip r|sed <span class="s1">'s/.* dev //;s/ .*//'</span>|sort|uniq <span class="nt">-c</span>|grep as|awk <span class="s1">'{print $2".value "$1}'</span>
<span class="k">fi</span></code></pre>

<p>IPv6:
</p><pre class="highlight"><code><span class="c">#!/bin/bash</span>
<span class="k">if</span> <span class="o">[</span> <span class="s2">"</span><span class="nv">$1</span><span class="s2">"</span> <span class="o">=</span> <span class="s2">"config"</span> <span class="o">]</span><span class="p">;</span><span class="k">then
	</span><span class="nb">echo </span>graph_title Number of routes
	<span class="nb">echo </span>graph_vlabel num. routes
	<span class="nb">echo </span>graph_category network
	<span class="nb">echo </span>graph_scale no
	<span class="k">for </span>AS <span class="k">in</span> <span class="si">$(</span>ip <span class="nt">-6</span> r|sed <span class="s1">'s/.* dev //;s/ .*//'</span>|sort|uniq <span class="nt">-c</span>|grep as|awk <span class="s1">'{print $2}'</span><span class="si">)</span><span class="p">;</span><span class="k">do
		</span><span class="nb">echo</span> <span class="nv">$AS</span>.label <span class="nv">$AS</span>
	<span class="k">done
else
	</span>ip <span class="nt">-6</span> r|sed <span class="s1">'s/.* dev //;s/ .*//'</span>|sort|uniq <span class="nt">-c</span>|grep as|awk <span class="s1">'{print $2".value "$1}'</span>
<span class="k">fi</span></code></pre>
(hint: The difference just the -6 on the ip command)

<h2><a class="anchor" id="graph-routes-and-activity-for-every-neighbour" href="#graph-routes-and-activity-for-every-neighbour"></a>Graph routes and activity for every neighbour</h2>

<p>This munin-plugin makes it very easy to graph the announced routes and activity for each neighbour over time:<br />
<a href="https://github.com/luben/bird-multigraph-plugin">https://github.com/luben/bird-multigraph-plugin</a></p>

<p>It's also possible to get notified by Munin when a problem with the peering persists. You have to define a critical value in line 138: 
</p><pre class="highlight"><code>imported.critical 1:</code></pre>
This will send execute the command (set in munin-node.conf) to alert you, if the imported route count falls under 1.

<p>You might also want to change line 125 from 
</p><pre class="highlight"><code>graph_title $proto-&gt;{title} routes</code></pre>
to
<pre class="highlight"><code>graph_title $name routes</code></pre>

<p>Example installation:
<a href="http://stats.tbspace.de/munin-cgi/munin-cgi-graph/tbspace.de/server.tbspace.de/dn42_crest_routes-day.png">http://stats.tbspace.de/munin-cgi/munin-cgi-graph/tbspace.de/server.tbspace.de/dn42_crest_routes-day.png</a></p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/Munin.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/Munin.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
