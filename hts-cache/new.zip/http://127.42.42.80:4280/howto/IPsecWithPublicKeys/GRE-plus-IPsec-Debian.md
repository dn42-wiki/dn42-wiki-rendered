<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/IPsecWithPublicKeys/GRE-plus-IPsec-Debian.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>GRE-plus-IPsec-Debian</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>GRE-plus-IPsec-Debian</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/IPsecWithPublicKeys/GRE-plus-IPsec-Debian.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/IPsecWithPublicKeys/GRE-plus-IPsec-Debian.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    GRE-plus-IPsec-Debian
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/IPsecWithPublicKeys/">IPsecWithPublicKeys</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="gre-ipsec-on-debian-based-distros" href="#gre-ipsec-on-debian-based-distros"></a>GRE + IPsec on Debian based distros</h1>

<ul>
  <li>Install racoon from ipsec-tools.</li>
  <li>Define an IPsec security policy in /etc/ipsec-tools.conf</li>
  <li>Load the IPsec security policy into the IPsec security policy database.</li>
  <li>Configure the racoon daemon.</li>
  <li>Configure a GRE tunnel.</li>
</ul>

<h2><a class="anchor" id="used-resources-in-this-example" href="#used-resources-in-this-example"></a>Used resources in this example:</h2>
<ul>
  <li>tunnel endpoints: 1.2.3.4 and 5.6.7.8</li>
  <li>internal IPv4 addresses: 10.0.0.1 and 10.0.0.2</li>
</ul>

<h2><a class="anchor" id="define-an-ipsec-security-policy" href="#define-an-ipsec-security-policy"></a>Define an IPsec security policy</h2>
<p>Example policy on 1.2.3.4:
</p><pre class="highlight"><code><span class="c">#!/usr/sbin/setkey -f</span>
spdadd 1.2.3.4 5.6.7.8 gre <span class="nt">-P</span> out ipsec esp/transport//require<span class="p">;</span>
spdadd 5.6.7.8 1.2.3.4 gre <span class="nt">-P</span> <span class="k">in  </span>ipsec esp/transport//require<span class="p">;</span></code></pre>
Change the direction on 5.6.7.8.

<h2><a class="anchor" id="load-the-ipsec-security-policy-into-the-ipsec-security-policy-database" href="#load-the-ipsec-security-policy-into-the-ipsec-security-policy-database"></a>Load the IPsec security policy into the IPsec security policy database</h2>
<p>Load the policy with the setkey command.
</p><pre class="highlight"><code>setkey <span class="nt">-f</span> /etc/ipsec-tools.conf</code></pre>
Afterward check the policy database with:
<pre class="highlight"><code>setkey <span class="nt">-DP</span></code></pre>

<h2><a class="anchor" id="configure-the-racoon-daemon" href="#configure-the-racoon-daemon"></a>Configure the racoon daemon</h2>
<p>An example /etc/racoon/racoon.conf.
</p><pre class="highlight"><code><span class="n">path</span> <span class="n">pre_shared_key</span> <span class="s2">"/etc/racoon/psk.txt"</span>;
<span class="n">path</span> <span class="n">certificate</span>    <span class="s2">"/etc/racoon/certs"</span>;
<span class="n">log</span> <span class="n">info</span>;

<span class="n">listen</span> {
  <span class="c"># replace with local tunnel endpoint
</span>  <span class="n">isakmp</span>      <span class="m">1</span>.<span class="m">2</span>.<span class="m">3</span>.<span class="m">4</span> [<span class="m">500</span>];
  <span class="n">isakmp_natt</span> <span class="m">1</span>.<span class="m">2</span>.<span class="m">3</span>.<span class="m">4</span> [<span class="m">4500</span>];
}

<span class="c"># replace with remote tunnel endpoint
</span><span class="n">remote</span> <span class="m">5</span>.<span class="m">6</span>.<span class="m">7</span>.<span class="m">8</span> [<span class="m">500</span>] {
  <span class="n">exchange_mode</span>    <span class="n">main</span>;
  <span class="n">proposal_check</span>   <span class="n">strict</span>;
  <span class="n">my_identifier</span>    <span class="n">asn1dn</span>;
  <span class="n">peers_identifier</span> <span class="n">asn1dn</span>;
  <span class="n">lifetime</span>         <span class="n">time</span> <span class="m">1</span> <span class="n">hour</span>;
  <span class="n">certificate_type</span> <span class="n">x509</span> <span class="s2">"local.crt"</span> <span class="s2">"local.key"</span>;
  <span class="n">peers_certfile</span>   <span class="n">x509</span> <span class="s2">"remote.crt"</span>;
  <span class="n">ca_type</span>          <span class="n">x509</span> <span class="s2">"ca.crt"</span>;
  <span class="n">verify_cert</span>      <span class="n">on</span>;
  <span class="n">send_cert</span>        <span class="n">off</span>;
  <span class="n">send_cr</span>          <span class="n">off</span>;

  <span class="n">proposal</span> {
    <span class="n">encryption_algorithm</span>  <span class="n">aes</span> <span class="m">256</span>;
    <span class="n">hash_algorithm</span>        <span class="n">sha256</span>;
    <span class="n">authentication_method</span> <span class="n">rsasig</span>;
    <span class="n">dh_group</span>              <span class="n">modp4096</span>;
  }
}

<span class="c"># local tunnel endpoint, GRE ip protocol number, remote tunnel endpoint, GRE ip protocol number
</span><span class="n">sainfo</span> <span class="n">address</span> <span class="m">1</span>.<span class="m">2</span>.<span class="m">3</span>.<span class="m">4</span> <span class="m">47</span> <span class="n">address</span> <span class="m">5</span>.<span class="m">6</span>.<span class="m">7</span>.<span class="m">8</span> <span class="m">47</span> {
  <span class="n">pfs_group</span>                <span class="n">modp4096</span>;
  <span class="n">lifetime</span>                 <span class="n">time</span> <span class="m">1</span> <span class="n">hour</span>;
  <span class="n">encryption_algorithm</span>     <span class="n">aes</span> <span class="m">256</span>;
  <span class="n">authentication_algorithm</span> <span class="n">hmac_sha1</span>;
  <span class="n">compression_algorithm</span>    <span class="n">deflate</span>;
}</code></pre>

<h2><a class="anchor" id="configure-a-gre-tunnel" href="#configure-a-gre-tunnel"></a>Configure a GRE tunnel</h2>
<p>Add this to /etc/network/interfaces:
</p><pre class="highlight"><code>auto gre1
iface gre1 inet tunnel
  mode gre
  netmask 255.255.255.255
  address 10.0.0.1
  dstaddr 10.0.0.2
  endpoint 5.6.7.8
  local 1.2.3.4
  ttl 255</code></pre>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/Policies" rel="nofollow">Policies</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
      <li><a href="/Links" rel="nofollow">Links</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
      <li><a href="/howto/GeoFeed" rel="nofollow">GeoFeed</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/dns/Overview" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">RPKI</a></li>
      <li><a href="/services/exchanges/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Pingables" rel="nofollow">Pingables</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/ca/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>, <a href="https://iedon.net/post/24" rel="nofollow">IEDON-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>, <a href="https://dn42.jp/" rel="nofollow">dn42.jp</a> (wiki-go)</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/IPsecWithPublicKeys/GRE-plus-IPsec-Debian.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/IPsecWithPublicKeys/GRE-plus-IPsec-Debian.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
