<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/IPsecWithPublicKeys/GRE-plus-IPsec-Debian.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>GRE-plus-IPsec-Debian</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>GRE-plus-IPsec-Debian</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/IPsecWithPublicKeys/GRE-plus-IPsec-Debian.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/IPsecWithPublicKeys/GRE-plus-IPsec-Debian.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    GRE-plus-IPsec-Debian
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/IPsecWithPublicKeys/">IPsecWithPublicKeys</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="gre-ipsec-on-debian-based-distros" href="#gre-ipsec-on-debian-based-distros"></a>GRE + IPsec on Debian based distros</h1>

<ul>
  <li>Install racoon from ipsec-tools.</li>
  <li>Define an IPsec security policy in /etc/ipsec-tools.conf</li>
  <li>Load the IPsec security policy into the IPsec security policy database.</li>
  <li>Configure the racoon daemon.</li>
  <li>Configure a GRE tunnel.</li>
</ul>

<h2><a class="anchor" id="used-resources-in-this-example" href="#used-resources-in-this-example"></a>Used resources in this example:</h2>
<ul>
  <li>tunnel endpoints: 1.2.3.4 and 5.6.7.8</li>
  <li>internal IPv4 addresses: 10.0.0.1 and 10.0.0.2</li>
</ul>

<h2><a class="anchor" id="define-an-ipsec-security-policy" href="#define-an-ipsec-security-policy"></a>Define an IPsec security policy</h2>
<p>Example policy on 1.2.3.4:
</p><pre class="highlight"><code><span class="c">#!/usr/sbin/setkey -f</span>
spdadd 1.2.3.4 5.6.7.8 gre <span class="nt">-P</span> out ipsec esp/transport//require<span class="p">;</span>
spdadd 5.6.7.8 1.2.3.4 gre <span class="nt">-P</span> <span class="k">in  </span>ipsec esp/transport//require<span class="p">;</span></code></pre>
Change the direction on 5.6.7.8.

<h2><a class="anchor" id="load-the-ipsec-security-policy-into-the-ipsec-security-policy-database" href="#load-the-ipsec-security-policy-into-the-ipsec-security-policy-database"></a>Load the IPsec security policy into the IPsec security policy database</h2>
<p>Load the policy with the setkey command.
</p><pre class="highlight"><code>setkey <span class="nt">-f</span> /etc/ipsec-tools.conf</code></pre>
Afterward check the policy database with:
<pre class="highlight"><code>setkey <span class="nt">-DP</span></code></pre>

<h2><a class="anchor" id="configure-the-racoon-daemon" href="#configure-the-racoon-daemon"></a>Configure the racoon daemon</h2>
<p>An example /etc/racoon/racoon.conf.
</p><pre class="highlight"><code><span class="n">path</span> <span class="n">pre_shared_key</span> <span class="s2">"/etc/racoon/psk.txt"</span>;
<span class="n">path</span> <span class="n">certificate</span>    <span class="s2">"/etc/racoon/certs"</span>;
<span class="n">log</span> <span class="n">info</span>;

<span class="n">listen</span> {
  <span class="c"># replace with local tunnel endpoint
</span>  <span class="n">isakmp</span>      <span class="m">1</span>.<span class="m">2</span>.<span class="m">3</span>.<span class="m">4</span> [<span class="m">500</span>];
  <span class="n">isakmp_natt</span> <span class="m">1</span>.<span class="m">2</span>.<span class="m">3</span>.<span class="m">4</span> [<span class="m">4500</span>];
}

<span class="c"># replace with remote tunnel endpoint
</span><span class="n">remote</span> <span class="m">5</span>.<span class="m">6</span>.<span class="m">7</span>.<span class="m">8</span> [<span class="m">500</span>] {
  <span class="n">exchange_mode</span>    <span class="n">main</span>;
  <span class="n">proposal_check</span>   <span class="n">strict</span>;
  <span class="n">my_identifier</span>    <span class="n">asn1dn</span>;
  <span class="n">peers_identifier</span> <span class="n">asn1dn</span>;
  <span class="n">lifetime</span>         <span class="n">time</span> <span class="m">1</span> <span class="n">hour</span>;
  <span class="n">certificate_type</span> <span class="n">x509</span> <span class="s2">"local.crt"</span> <span class="s2">"local.key"</span>;
  <span class="n">peers_certfile</span>   <span class="n">x509</span> <span class="s2">"remote.crt"</span>;
  <span class="n">ca_type</span>          <span class="n">x509</span> <span class="s2">"ca.crt"</span>;
  <span class="n">verify_cert</span>      <span class="n">on</span>;
  <span class="n">send_cert</span>        <span class="n">off</span>;
  <span class="n">send_cr</span>          <span class="n">off</span>;

  <span class="n">proposal</span> {
    <span class="n">encryption_algorithm</span>  <span class="n">aes</span> <span class="m">256</span>;
    <span class="n">hash_algorithm</span>        <span class="n">sha256</span>;
    <span class="n">authentication_method</span> <span class="n">rsasig</span>;
    <span class="n">dh_group</span>              <span class="n">modp4096</span>;
  }
}

<span class="c"># local tunnel endpoint, GRE ip protocol number, remote tunnel endpoint, GRE ip protocol number
</span><span class="n">sainfo</span> <span class="n">address</span> <span class="m">1</span>.<span class="m">2</span>.<span class="m">3</span>.<span class="m">4</span> <span class="m">47</span> <span class="n">address</span> <span class="m">5</span>.<span class="m">6</span>.<span class="m">7</span>.<span class="m">8</span> <span class="m">47</span> {
  <span class="n">pfs_group</span>                <span class="n">modp4096</span>;
  <span class="n">lifetime</span>                 <span class="n">time</span> <span class="m">1</span> <span class="n">hour</span>;
  <span class="n">encryption_algorithm</span>     <span class="n">aes</span> <span class="m">256</span>;
  <span class="n">authentication_algorithm</span> <span class="n">hmac_sha1</span>;
  <span class="n">compression_algorithm</span>    <span class="n">deflate</span>;
}</code></pre>

<h2><a class="anchor" id="configure-a-gre-tunnel" href="#configure-a-gre-tunnel"></a>Configure a GRE tunnel</h2>
<p>Add this to /etc/network/interfaces:
</p><pre class="highlight"><code>auto gre1
iface gre1 inet tunnel
  mode gre
  netmask 255.255.255.255
  address 10.0.0.1
  dstaddr 10.0.0.2
  endpoint 5.6.7.8
  local 1.2.3.4
  ttl 255</code></pre>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/IPsecWithPublicKeys/GRE-plus-IPsec-Debian.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/IPsecWithPublicKeys/GRE-plus-IPsec-Debian.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
