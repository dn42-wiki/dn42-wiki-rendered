<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/telephony42-Asterisk.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>telephony42-Asterisk</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>telephony42-Asterisk</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/telephony42-Asterisk.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/telephony42-Asterisk.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    telephony42-Asterisk
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="getting-started-with-telephony42-asterisk" href="#getting-started-with-telephony42-asterisk"></a>Getting Started with telephony42 (Asterisk)</h1>

<p>This guide will help you quickly deploy a working Asterisk PBX. By the end of this tutorial, you will be able to make and receive calls in telephony42.</p>

<h2><a class="anchor" id="prerequisites" href="#prerequisites"></a>Prerequisites</h2>

<p>Before configuring Asterisk, ensure you have:</p>

<ol>
  <li>An allocated telephony42 (<code>+042</code>) number prefix registered in the registry (e.g., <code>+04240000</code>).</li>
  <li>DNS NAPTR records correctly configured on your zone in <code>tel.dn42</code>.</li>
</ol>

<p>Example of wildcard NAPTR record to route any calls to your PBX at <code>pbx.yourdomain.dn42</code> with SIP port <code>5060</code>:</p>

<pre class="highlight"><span class="err">*.0.0.0.0.4.2.4.0.tel.dn42. IN NAPTR 100 10 "u" "E2U+sip" "!^(.*)$!sip:\\1@pbx.yourdomain.dn42:5060!" .</span></pre>

<h2><a class="anchor" id="installation-notes" href="#installation-notes"></a>Installation notes</h2>

<h3><a class="anchor" id="debian-ubuntu" href="#debian-ubuntu"></a>Debian / Ubuntu</h3>

<p>Asterisk is available in the official repositories. (For Debian, you need to install packages from <code>sid</code> repository)</p>

<pre class="highlight"><code>apt update
apt <span class="nb">install </span>asterisk</code></pre>

<h3><a class="anchor" id="alpine" href="#alpine"></a>Alpine</h3>

<pre class="highlight"><code>apk add asterisk</code></pre>

<h3><a class="anchor" id="docker-docker-compose" href="#docker-docker-compose"></a>Docker (<code>docker compose</code>)</h3>

<pre class="highlight"><code><span class="na">services</span><span class="pi">:</span>
  <span class="na">asterisk</span><span class="pi">:</span>
    <span class="na">image</span><span class="pi">:</span> <span class="s">andrius/asterisk:stable</span>
    <span class="na">container_name</span><span class="pi">:</span> <span class="s">asterisk42</span>
    <span class="na">network_mode</span><span class="pi">:</span> <span class="s">host</span>
    <span class="na">volumes</span><span class="pi">:</span>
      <span class="pi">-</span> <span class="s">./config:/etc/asterisk</span>
    <span class="na">restart</span><span class="pi">:</span> <span class="s">unless-stopped</span></code></pre>

<h1><a class="anchor" id="example-configuration" href="#example-configuration"></a>Example configuration</h1>

<p>Asterisk relies on many configuration files. This guide will focus only on two main config files:</p>
<ul>
  <li>
<code>pjsip.conf</code>: Network, Endpoints, and Authentication</li>
  <li>
<code>extensions.conf</code>: Dialplan and Routing</li>
</ul>

<p>When copying the configurations below, replace the following variables (remove the brackets):</p>
<ul>
  <li>
<code>&lt;OWN_IPv4&gt;</code>: Your dn42 IPv4 address (e.g., <code>172.20.X.X</code>)</li>
  <li>
<code>&lt;OWN_IPv6&gt;</code>: Your dn42 IPv6 address (e.g., <code>fdXX::X</code>)</li>
  <li>
<code>&lt;OWN_PREFIX&gt;</code>: Your telephony prefix (e.g., <code>+04240000</code>)</li>
  <li>
<code>&lt;EXT_NAME&gt;</code>: Name for your extension (e.g., <code>0001</code> or <code>my-phone</code>)</li>
  <li>
<code>&lt;FULL_NUMBER&gt;</code>: The full <code>+042</code> number for your extension (e.g., <code>+042400000001</code>)</li>
  <li>
<code>&lt;SECRET_PASS&gt;</code>: A strong password</li>
</ul>

<h2><a class="anchor" id="pjsip-pjsip-conf" href="#pjsip-pjsip-conf"></a>PJSIP (<code>pjsip.conf</code>)</h2>

<p>This file defines how Asterisk listens to the network, sets up templates for devices, creates your local extension, and prepares an anonymous endpoint to catch incoming ENUM calls.</p>

<pre class="highlight"><code><span class="nn">[global]</span>
<span class="py">type</span><span class="p">=</span><span class="s">global</span>
<span class="c">; verified peers first
</span><span class="py">endpoint_identifier_order</span><span class="p">=</span><span class="s">auth_username,username,ip</span>

<span class="c">; ==========================================
; Transports
; ==========================================
</span>
<span class="nn">[transport-udp4]</span>
<span class="py">type</span><span class="p">=</span><span class="s">transport</span>
<span class="py">protocol</span><span class="p">=</span><span class="s">udp</span>
<span class="py">bind</span><span class="p">=</span><span class="s">&lt;OWN_IPv4&gt;:5060</span>
<span class="py">local_net</span><span class="p">=</span><span class="s">172.20.0.0/14</span>
<span class="py">local_net</span><span class="p">=</span><span class="s">172.31.0.0/16</span>
<span class="py">local_net</span><span class="p">=</span><span class="s">10.0.0.0/8</span>

<span class="nn">[transport-udp6]</span>
<span class="py">type</span><span class="p">=</span><span class="s">transport</span>
<span class="py">protocol</span><span class="p">=</span><span class="s">udp</span>
<span class="py">bind</span><span class="p">=</span><span class="s">[&lt;OWN_IPv6&gt;]:5060</span>
<span class="py">local_net</span><span class="p">=</span><span class="s">fd00::/8</span>

<span class="c">; ==========================================
; Templates
; ==========================================
</span>
<span class="nn">[phone-template]</span><span class="err">(!)</span>
<span class="py">type</span><span class="p">=</span><span class="s">endpoint</span>
<span class="py">context</span><span class="p">=</span><span class="s">context-local          ; Incoming calls from this phone go here</span>
<span class="py">allow</span><span class="p">=</span><span class="s">!all,opus,g722,alaw,ulaw ; Prioritize Opus and G.722 HD audio</span>
<span class="py">rtp_symmetric</span><span class="p">=</span><span class="s">yes</span>
<span class="py">force_rport</span><span class="p">=</span><span class="s">yes</span>
<span class="py">rewrite_contact</span><span class="p">=</span><span class="s">yes</span>
<span class="py">direct_media</span><span class="p">=</span><span class="s">no                ; Proxy media through PBX to prevent NAT issues</span>
<span class="py">trust_id_inbound</span><span class="p">=</span><span class="s">yes</span>
<span class="py">send_pai</span><span class="p">=</span><span class="s">yes</span>

<span class="c">; ==========================================
; Local Extensions
; ==========================================
</span>
<span class="c">; Replace variables to create an extension names &lt;EXT_NAME&gt;
</span><span class="nn">[&lt;EXT_NAME&gt;]</span><span class="err">(phone-template)</span>
<span class="py">auth</span><span class="p">=</span><span class="s">&lt;EXT_NAME&gt;</span>
<span class="py">aors</span><span class="p">=</span><span class="s">&lt;EXT_NAME&gt;</span>
<span class="py">callerid</span><span class="p">=</span><span class="s">"My Name"</span> <span class="s">&lt;&lt;FULL_NUMBER&gt;&gt;</span>

<span class="nn">[&lt;EXT_NAME&gt;]</span>
<span class="py">type</span><span class="p">=</span><span class="s">auth</span>
<span class="py">auth_type</span><span class="p">=</span><span class="s">userpass</span>
<span class="py">username</span><span class="p">=</span><span class="s">&lt;EXT_NAME&gt;</span>
<span class="py">password</span><span class="p">=</span><span class="s">&lt;SECRET_PASS&gt;</span>

<span class="nn">[&lt;EXT_NAME&gt;]</span>
<span class="py">type</span><span class="p">=</span><span class="s">aor</span>
<span class="py">max_contacts</span><span class="p">=</span><span class="s">3   ; Allow 3 devices to register simultaneously</span>
<span class="py">remove_existing</span><span class="p">=</span><span class="s">yes</span>

<span class="c">; ==========================================
; Incoming calls via ENUM
; ==========================================
</span>
<span class="nn">[peer-enum-inbound]</span>
<span class="py">type</span><span class="p">=</span><span class="s">endpoint</span>
<span class="py">context</span><span class="p">=</span><span class="s">context-enum   ; Send unknown incoming calls to ENUM context</span>
<span class="py">allow</span><span class="p">=</span><span class="s">!all,opus,g722,alaw,ulaw</span>
<span class="py">rtp_symmetric</span><span class="p">=</span><span class="s">yes</span>
<span class="py">force_rport</span><span class="p">=</span><span class="s">yes</span>
<span class="py">rewrite_contact</span><span class="p">=</span><span class="s">yes</span>
<span class="py">direct_media</span><span class="p">=</span><span class="s">no</span>

<span class="nn">[peer-enum-inbound-id]</span>
<span class="py">type</span><span class="p">=</span><span class="s">identify</span>
<span class="py">endpoint</span><span class="p">=</span><span class="s">peer-enum-inbound</span>
<span class="c">; match all dn42 subnets
</span><span class="py">match</span><span class="p">=</span><span class="s">172.20.0.0/14</span>
<span class="py">match</span><span class="p">=</span><span class="s">172.31.0.0/16</span>
<span class="py">match</span><span class="p">=</span><span class="s">10.0.0.0/8</span>
<span class="py">match</span><span class="p">=</span><span class="s">fd00::/8</span>

<span class="c">; ==========================================
; Outgoing calls via ENUM
; ==========================================
</span>
<span class="nn">[peer-enum-outbound]</span>
<span class="py">type</span><span class="p">=</span><span class="s">endpoint</span>
<span class="py">allow</span><span class="p">=</span><span class="s">!all,opus,g722,alaw,ulaw</span>
<span class="py">send_pai</span><span class="p">=</span><span class="s">yes</span></code></pre>

<h2><a class="anchor" id="dialplan-extensions-conf" href="#dialplan-extensions-conf"></a>Dialplan (<code>extensions.conf</code>)</h2>

<p>The file tells Asterisk how to route numbers. It is divided into serveral contexts.</p>

<pre class="highlight"><code><span class="nn">[globals]</span>
<span class="c">; (Optional) Global variables can go here
</span>
<span class="c">; ==========================================
; Inbound Routing
; ==========================================
</span>
<span class="c">; Calls originating from your own network.
</span><span class="nn">[context-local]</span>

<span class="c">; 4 digits -&gt; call local extension
</span><span class="py">exten</span> <span class="p">=</span><span class="s">&gt; _XXXX,1,Goto(ext-local,${EXTEN},1)</span>

<span class="c">; starts with 042 -&gt; add + and route out
</span><span class="py">exten</span> <span class="p">=</span><span class="s">&gt; _042X.,1,Goto(ext-routing,+${EXTEN},1)</span>

<span class="c">; standard +042 dialing -&gt; route out
</span><span class="py">exten</span> <span class="p">=</span><span class="s">&gt; _+042X.,1,Goto(ext-routing,${EXTEN},1)</span>

<span class="c">; Catch-all -&gt; add +042 and route out
</span><span class="py">exten</span> <span class="p">=</span><span class="s">&gt; _X!,1,Goto(ext-routing,+042${EXTEN},1)</span>


<span class="c">; Calls originating from external networks via ENUM.
</span><span class="nn">[context-enum]</span>

<span class="c">; starts with 00 -&gt; replace with + and route out
</span><span class="py">exten</span> <span class="p">=</span><span class="s">&gt; _00X!,1,Goto(ext-routing,+${EXTEN:2},1)</span>

<span class="c">; starts with + -&gt; route out
</span><span class="py">exten</span> <span class="p">=</span><span class="s">&gt; _+X!,1,Goto(ext-routing,${EXTEN},1)</span>

<span class="c">; Catch-all -&gt; add + and route out
</span><span class="py">exten</span> <span class="p">=</span><span class="s">&gt; _X!,1,Goto(ext-routing,+${EXTEN},1)</span>


<span class="c">; ==========================================
; Outbound &amp; Local Routing
; ==========================================
</span>
<span class="c">; Calls destined for local networks.
</span><span class="nn">[ext-local]</span>
<span class="c">; route &lt;OWN_PREFIX&gt;0001 calls to your local extension &lt;EXT_NAME&gt;
</span><span class="py">exten</span> <span class="p">=</span><span class="s">&gt; 0001,1,Dial(PJSIP/&lt;EXT_NAME&gt;,30)  ; </span>


<span class="c">; Inter-PBX routing for both inbound and outbound calls.
</span><span class="nn">[ext-routing]</span>

<span class="c">; route calls destined for your prefix
</span><span class="py">exten</span> <span class="p">=</span><span class="s">&gt; _&lt;OWN_PREFIX&gt;.,1,Goto(ext-local,${EXTEN:9},1)</span>

<span class="c">; other external calls -&gt; do ENUM lookup on tel.dn42
</span><span class="py">exten</span> <span class="p">=</span><span class="s">&gt; _+042X.,1,Set(TARGET_URI=${ENUMLOOKUP(${EXTEN},sip,,,tel.dn42)})</span>
 <span class="c">; if found, dial via our outbound endpoint
</span> <span class="py">same</span> <span class="p">=</span><span class="s">&gt; n,ExecIf($["${TARGET_URI}"!=""]?Dial(PJSIP/peer-enum-outbound/sip:${TARGET_URI},60))</span>
 <span class="c">; if unallocated or failed, naturally hangup
</span> <span class="py">same</span> <span class="p">=</span><span class="s">&gt; n,Hangup()</span></code></pre>

<p>Apply your configuration by entering the Asterisk CLI:</p>

<pre class="highlight"><code>asterisk <span class="nt">-rx</span> <span class="s1">'core reload'</span></code></pre>

<h1><a class="anchor" id="setting-up-your-extension" href="#setting-up-your-extension"></a>Setting up your extension</h1>

<p>You can now connect a softphone (like MicroSIP, Zoiper, or Linphone) or a hardware IP Phone/ATA using the following details:</p>

<ul>
  <li>Domain / Server: pbx.yourdomain.dn42 / <code>&lt;OWN_IPv4&gt;</code> or <code>&lt;OWN_IPv6&gt;</code>
</li>
  <li>Port: 5060 (UDP)</li>
  <li>Username: <code>&lt;EXT_NAME&gt;</code>
</li>
  <li>Password: <code>&lt;SECRET_PASS&gt;</code>
</li>
</ul>

<p>Once connected, ask a friend in telephony42 to call your <code>&lt;FULL_NUMBER&gt;</code>.</p>

<p><em>Tip: Install and use <code>sngrep -c</code> in your PBX's terminal to visually monitor SIP traffic if calls fail.</em></p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/Policies" rel="nofollow">Policies</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
      <li><a href="/Links" rel="nofollow">Links</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
      <li><a href="/howto/GeoFeed" rel="nofollow">GeoFeed</a></li>
      <li><a href="/howto/telephony42-Asterisk" rel="nofollow">Telephony42 (Asterisk)</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/dns/Overview" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">ROA + RPKI</a></li>
      <li><a href="/services/exchanges/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Pingables" rel="nofollow">Pingables</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/ca/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>, <a href="https://iedon.net/post/24" rel="nofollow">IEDON-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>, <a href="https://dn42.jp/" rel="nofollow">dn42.jp</a> (wiki-go)</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/telephony42-Asterisk.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/telephony42-Asterisk.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
