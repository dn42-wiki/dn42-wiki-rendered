<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'howto/EdgeOS-Config.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>EdgeOS-Config</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>EdgeOS-Config</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/howto/EdgeOS-Config.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/howto/EdgeOS-Config.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    EdgeOS-Config
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/howto/">howto</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="edgeos" href="#edgeos"></a>EdgeOS</h1>

<p>This document describes some possibilities for connecting to dn42 using an Ubiquiti EdgeRouter:</p>

<ul>
  <li>IPv4/IPv6 tunnel via:
    <ul>
      <li>OpenVPN - support built into EdgeOS already - covered below</li>
      <li>IPsec/IKEv2 - support built into EdgeOS already - not covered here</li>
      <li>QuickTun - see <a href="https://github.com/neilalexander/vyatta-quicktun">vyatta-quicktun package</a> - not covered here</li>
    </ul>
  </li>
  <li>Route exchange using BGP</li>
  <li>DNS resolution for the .dn42 TLD</li>
</ul>

<h2><a class="anchor" id="first-steps" href="#first-steps"></a>First Steps</h2>

<ol>
  <li>Create the required objects in the Registry - see <a href="/howto/Getting-Started">Getting Started</a>
</li>
  <li>Find a peer - ask nicely in <a href="/services/IRC">IRC</a>!</li>
  <li>Get the following details:
    <ul>
      <li>Tunnel configuration (OpenVPN, IPsec, QuickTun)</li>
      <li>AS numbers</li>
    </ul>
  </li>
</ol>

<h3><a class="anchor" id="tunnel-configuration" href="#tunnel-configuration"></a>Tunnel Configuration</h3>

<h3><a class="anchor" id="openvpn" href="#openvpn"></a>OpenVPN</h3>

<p>Using the below as examples:</p>

<pre class="highlight"><code>Own ASN: AS111111
Own IPv4 Space: 172.AA.AA.64/27
Own IPv6 Space: fdBB:BBBB:CCCC::/48
Own IPv4 If-Address: 172.AA.AA.65
Own IPv6 If-Address: fdBB:BBBB:CCCC::1

Peer OpenVPN Remote Address: 172.X.X.X  //that's the peers OpenVPN IF IP
Peer OpenVPN Remote Host: X.X.X.Y  //that's the peers clearnet IP
Peer OpenVPN IP for you: fdAA::BBB/64
Peer OpenVPN IP: fdAA::CC
Peer OpenVPN Port: 1194
Peer OpenVPN encryption: aes256
Peer ASN: AS222222
Peer BGP Neighbour IPv4: Z.Z.Z.Z
Peer BGP Neighbour IPv6: fdAA::CC</code></pre>

<h4><a class="anchor" id="copy-openvpn-key-to-the-edgerouter" href="#copy-openvpn-key-to-the-edgerouter"></a>Copy OpenVPN key to the EdgeRouter</h4>

<p>Copy the VPN key to <code>/config/auth/SomeSharedKey.key</code>:</p>

<pre class="highlight"><code><span class="nb">sudo cat</span> <span class="o">&gt;</span> /config/auth/SomeSharedKey.key</code></pre>

<p>Paste the key in the terminal window, hit return once and kill <code>cat</code> with CTRL+C. Then type <code>exit</code>.</p>

<h4><a class="anchor" id="create-ipv4-openvpn-interface" href="#create-ipv4-openvpn-interface"></a>Create IPv4 OpenVPN Interface</h4>

<p>Create the OpenVPN virtual interface, i.e. using <code>vtun0</code>:</p>

<pre class="highlight"><code>configure
set interfaces openvpn vtun0
set interfaces openvpn vtun0 mode site-to-site
set interfaces openvpn vtun0 local-port 1194
set interfaces openvpn vtun0 remote-port 1194
set interfaces openvpn vtun0 local-address 172.AA.AA.65
set interfaces openvpn vtun0 remote-address 172.X.X.X
set interfaces openvpn vtun0 remote-host X.X.X.Y
set interfaces openvpn vtun0 shared-secret-key-file /config/auth/SomeSharedKey.key
set interfaces openvpn vtun0 encryption aes256

set interfaces openvpn vtun0 openvpn-option "--comp-lzo"  //if your peer support compression

commit
save
exit</code></pre>

<p>The OpenVPN tunnel should now be up and running.</p>

<p>Check it with:</p>

<pre class="highlight"><code>show interfaces openvpn
show interfaces openvpn detail
show openvpn status site-to-site</code></pre>

<h3><a class="anchor" id="create-bgp-session" href="#create-bgp-session"></a>Create BGP Session</h3>

<h4><a class="anchor" id="open-firewall" href="#open-firewall"></a>Open Firewall</h4>

<p>You need to open the firewall to local for the tunnel Interface on port 179/tcp</p>

<h4><a class="anchor" id="configure-the-bgp-neighbor" href="#configure-the-bgp-neighbor"></a>Configure the BGP Neighbor</h4>

<p>When entering AS numbers, do not include the "AS" prefix, i.e. enter AS111111 as just 111111.</p>

<p>Build the BGP session with your peer:</p>

<pre class="highlight"><code>configure
set protocols bgp 111111 neighbor Z.Z.Z.Z remote-as 222222
set protocols bgp 111111 neighbor Z.Z.Z.Z soft-reconfiguration inbound
set protocols bgp 111111 neighbor Z.Z.Z.Z update-source 172.AA.AA.65
commit
save</code></pre>

<p>Check that the BGP session has come up:</p>

<pre class="highlight"><code>show ip bgp summary</code></pre>

<h4><a class="anchor" id="create-blackhole-route" href="#create-blackhole-route"></a>Create Blackhole Route</h4>

<p>so bgp can announce the route</p>

<pre class="highlight"><code>set protocols static route 172.AA.AA.64/27 blackhole
commit
save</code></pre>

<h4><a class="anchor" id="announce-route-to-bgp" href="#announce-route-to-bgp"></a>Announce Route to BGP</h4>

<pre class="highlight"><code>set protocols bgp 111111 network 172.A.A.64/27
commit
save
exit</code></pre>

<p>You should now be able to see networks being advertised to your peer:</p>

<pre class="highlight"><code>show ip bgp neighbors Z.Z.Z.Z advertised-routes</code></pre>

<h3><a class="anchor" id="set-dns-forwarding" href="#set-dns-forwarding"></a>Set DNS Forwarding</h3>

<p>Try to ping <code>172.23.0.53</code> (anycast DNS resolver). If you get a response then you are good to continue.</p>

<p>Add the DNS forwarder:</p>

<pre class="highlight"><code>configure
set service dns forwarding options server=/23.172.in-addr.arpa/172.23.0.53
set service dns forwarding options server=/22.172.in-addr.arpa/172.23.0.53
set service dns forwarding options server=/dn42/172.23.0.53
commit
save
exit</code></pre>

<h3><a class="anchor" id="create-nat-rule" href="#create-nat-rule"></a>Create NAT rule</h3>

<pre class="highlight"><code>set service nat rule 5013 outbound-interface vtun0
set service nat rule 5013 type masquerade
set service nat rule 5013 description "Masquerade for dn42"</code></pre>

<p>You should now be able to access .dn42 domains.</p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="howto/EdgeOS-Config.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/howto/EdgeOS-Config.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
