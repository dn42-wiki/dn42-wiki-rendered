<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-309be032396e783b13a47df58f389b7c8e11c2b2d42640560b874f677c25f6e5.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">

  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'services/Automatic-CA.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-f05401ee374f0c7f48fc2bc08e30b4f4db705861fd5895ed70998683b383bfb5.js" type="text/javascript"></script>
  

  <title>Automatic-CA</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Automatic-CA</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/services/Automatic-CA.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <a class="btn btn-sm" id="minibutton-home" href="/">
      Home
    </a>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/overview"
          id="minibutton-overview"
        >
          Overview
        </a>

        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/latest_changes"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </a>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          href="/gollum/history/services/Automatic-CA.md/"
          id="minibutton-history"
        >
          History
        </a>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Automatic-CA
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/services/">services</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="dn42-acme-ca" href="#dn42-acme-ca"></a>DN42 ACME CA</h1>

<p>Certificates can be automatically generated with the <a href="http://acme.dn42">ACME-CA</a> using <a href="https://github.com/acmesh-official/acme.sh">acme.sh</a> or <a href="https://github.com/go-acme/lego">lego</a>. More information can be found on <a href="http://acme.dn42/">acme.dn42</a></p>

<h1><a class="anchor" id="dn42-self-serve-ca" href="#dn42-self-serve-ca"></a>DN42 Self-Serve CA</h1>

<p>This client is used for automating the process of requesting TLS certificates. (Available via: <a href="https://ca.dn42/ca-client">dn42</a>, <a href="https://ca.dn42.us/ca-client">iana</a>, <a href="anon@git.dn42:dn42/ca-client">git</a>) </p>

<h2><a class="anchor" id="validation-process" href="#validation-process"></a>VALIDATION PROCESS</h2>

<p>The process validates ownership by verifying control of both a users MNT object in the registry and the authoritative DNS server. 
The following steps take place in creating a signed certificate.</p>

<p><em>User Flow</em></p>

<ol>
<li>User generates a 2048+ bit rsa key and CSR for their MNT object.</li>
<li>User generates a sha256 hash of the rsa public key (commonly known as a <a href="https://developer.mozilla.org/en-US/docs/Web/Security/Public_Key_Pinning">public keypin</a>) and adds it as a remark in their MNT</li>
<li>User submits the csr to the CA to validate and sign. </li>
<li>CA checks for the keypin in their MNT object (if it does not find it in the local copy of the <a href="https://ca.dn42/reg/mntner/">monotone repo</a> it will check against io.nixnodes.dn42)</li>
<li>(optional) CA revokes prior certificate as superseded.</li>
<li>CA signs and returns the user certificate.</li>
</ol>

<p><em>Server Flow</em></p>

<ol>
<li>User generates a 2048+ bit rsa key and CSR for the dns CN. Also including any SAN domains.</li>
<li>User generates a sha256 hash of the rsa public key (commonly known as a <a href="https://developer.mozilla.org/en-US/docs/Web/Security/Public_Key_Pinning">public keypin</a>) and adds it as a txt record in their DNS.</li>
<li>User uses the user certificate to authenticate and submits the csr to the CA to validate and sign. </li>
<li>CA checks for the user keypin in their MNT object (if it does not find it in the local copy of the <a href="https://ca.dn42/reg/mntner/">monotone repo</a> it will check against io.nixnodes.dn42)</li>
<li>CA checks the dns records for the CN and each SAN for the tls keypin.</li>
<li>(optional) CA revokes prior certificate as superseded.</li>
<li>CA signs and returns the tls certificate.</li>
</ol>

<p><em>User Renewals</em></p>

<p>User certificates are signed for 180 days. To renew follow the steps above starting from number 3.</p>

<p><em>Server renewals</em></p>

<p>Server certificates are signed for 45 days. To renew follow the steps above starting from number 3. </p>

<p><em>Certificate Revocations</em></p>

<ol>
<li>User uses the user certificate to authenticate and submits the serial and revoke reason to CA.</li>
<li>CA checks user keypin in their MNT object (if it does not find it in the local copy of the <a href="https://ca.dn42/reg/mntner/">monotone repo</a> it will check against io.nixnodes.dn42)</li>
<li>CA checks that owner in certificate matches.</li>
<li>CA revokes certificate and updates revocation list.</li>
</ol>

<h2><a class="anchor" id="install" href="#install"></a>INSTALL</h2>

<p>get the script here: </p>

<p>curl <a href="https://ca.dn42/ca.dn42">https://ca.dn42/ca.dn42</a> &gt; ca.dn42; chmod +x ca.dn42</p>

<p>available via git: anon@git.dn42:dn42/ca-client</p>

<h2><a class="anchor" id="known-issues" href="#known-issues"></a>KNOWN ISSUES</h2>

<h3><a class="anchor" id="openssl-prior-to-1-0-2-returns-ssl-certificate-problem-permitted-subtree-violation" href="#openssl-prior-to-1-0-2-returns-ssl-certificate-problem-permitted-subtree-violation"></a>openssl prior to 1.0.2 returns "SSL certificate problem: permitted subtree violation"</h3>

<p>The way openssl validated name constraints prevented it from accepting dns names that started with a dot.
Because the name constraint is "DNS:.dn42" it fails to validate.</p>

<p><a href="https://groups.google.com/forum/#!topic/mailing.openssl.dev/drG3U-S4iaE">Read more on this mailing list thread</a></p>

<h3><a class="anchor" id="x-509-nameconstraints-on-certificates-not-supported-on-os-x" href="#x-509-nameconstraints-on-certificates-not-supported-on-os-x"></a>X.509 nameConstraints on certificates not supported on OS X</h3>

<p>Browsers and clients that rely on Apple's <a href="https://developer.apple.com/library/mac/documentation/Security/Reference/secureTransportRef/">Secure Transport</a> library does not support X.509's nameConstraints.</p>

<p>Read more on this <a href="http://security.stackexchange.com/a/97133">stack exchange post</a></p>

<h2><a class="anchor" id="how-to-run" href="#how-to-run"></a>How to Run</h2>

<pre class="highlight"><code>Usage:  # OWNER is your MNT handle.
   ./ca.dn42 user-gen OWNER EMAIL          # Output to OWNER.csr and OWNER.key
   ./ca.dn42 user-sig OWNER                # Output to OWNER.crt and OWNER.p12
   ./ca.dn42 tls-gen DNS OWNER EMAIL [SAN] # Output to OWNER_DNS.csr and OWNER.key
   ./ca.dn42 tls-sig DNS OWNER             # Output to OWNER_DNS.crt and OWNER_DNS.p12
   ./ca.dn42 revoke OWNER CERTFILE [REASON]


Revoke Reasons: unspecified, keyCompromise, affiliationChanged,
   superseded, cessationOfOperation, certificateHold, removeFromCRL

Environtment Options:
   DN42CA_PKCS12 = 1                # Generate pkcs12 file for certificate.</code></pre>

<h2><a class="anchor" id="example" href="#example"></a>Example</h2>

<p>Generate the user key</p>

<pre class="highlight"><code>$ ./ca.dn42 user-gen XUU-MNT xuu@sour.is
Generating a 2048 bit RSA private key
...............................+++
.........................+++
writing new private key to 'XUU-MNT.key'
-----
=
= You need to have this pin added to your mnt object before proceeding to the next step.
=
|MNT Key Pin| remarks: pin-sha256:HdqCid0sedWXX3Q0uG98rYjJyTNOzaT13WfWpr1GvIw=</code></pre>

<h3><a class="anchor" id="sign-the-user-key" href="#sign-the-user-key"></a>Sign the user key</h3>

<pre class="highlight"><code>$ ./ca.dn42 user-sign XUU-MNT xuu@sour.is
== USER CERT ==
   C:XD
   O:dn42
   OU:dn42 Certificate Authority
   CN:XUU-MNT
   emailAddress:xuu@sour.is
   owner:XUU-MNT
   pin-sha256:HdqCid0sedWXX3Q0uG98rYjJyTNOzaT13WfWpr1GvIw=
OK https://ca.dn42/crt/XUU-MNT.crt
Enter Export Password:
Verifying - Enter Export Password:</code></pre>

<h3><a class="anchor" id="generate-the-server-key" href="#generate-the-server-key"></a>Generate the server key</h3>

<pre class="highlight"><code>$ ./ca.dn42 tls-gen ca.dn42 XUU-MNT xuu@sour.is DNS:ca.dn42

Generating a 2048 bit RSA private key
...........................................+++
.......................+++
writing new private key to 'XUU-MNT_ca.dn42.key'
-----
writing RSA key
=
= |DNS Key Pin| You need to have this pin added to your dns records  before proceeding to the next step.
=
_dn42_tlsverify.ca.dn42. IN TXT XUU-MNT:pin-sha256:Qu/X5GNqOo05TdL7oexkamE34OUuDE60T+f0xc60UPQ=</code></pre>

<p>After you set this TXT-Record for your domain, you can verify it with the following command (by replacing the domain with your own):</p>

<pre class="highlight"><code>$ dig +short TXT _dn42_tlsverify.ca.dn42.
"XUU-MNT:pin-sha256:Qu/X5GNqOo05TdL7oexkamE34OUuDE60T+f0xc60UPQ="</code></pre>

<h3><a class="anchor" id="sign-the-server-key" href="#sign-the-server-key"></a>Sign the server key</h3>

<pre class="highlight"><code>$ ./ca.dn42 tls-sign ca.dn42 XUU-MNT
== USER CERT ==
   C:XD 
   O:dn42 
   OU:dn42 Certificate Authority 
   CN:XUU-MNT 
   emailAddress:xuu@sour.is 
   owner:XUU-MNT 
   pin-sha256:HdqCid0sedWXX3Q0uG98rYjJyTNOzaT13WfWpr1GvIw= 
== DNS CSR ==
   C:XD 
   O:dn42 
   OU:dn42 Certificate Authority 
   CN:ca.dn42 
   emailAddress:xuu@sour.is 
   owner:XUU-MNT 
   pin-sha256:Qu/X5GNqOo05TdL7oexkamE34OUuDE60T+f0xc60UPQ= 
== DNS Tests ==
   CN Record: ca.dn42 PASSED
   SAN Record: ca.dn42 PASSED
OK https://ca.dn42/crt/XUU-MNT_ca.dn42.crt
Enter Export Password: ****
Verifying - Enter Export Password: ****</code></pre>

<p>The generated certificate will be valid for 3 months, to renew it simply run <code>./ca.dn42 tls-sign ca.dn42 XUU-MNT</code> again. This could be also automated in cron:</p>

<pre class="highlight"><code>0 0 1 * * /etc/ssl/dn42/ca.dn42 tls-sign wiki.dn42 MIC92-MNT</code></pre>

<p>or with a systemd timer:</p>

<pre class="highlight"><code># update-dn42-ca.timer
[Timer]
OnBootSec=1h
OnUnitActiveSec=1w
Persistent=yes

[Install]
WantedBy=timers.target</code></pre>

<pre class="highlight"><code>[Service]
Type=oneshot
WorkingDirectory=/etc/ssl/dn42
ExecStart=/etc/ssl/dn42/ca.dn42 tls-sign wiki.dn42 MIC92-MNT
# accept multiple ExecStart lines for other certificates
# ExecStart=/etc/ssl/dn42/ca.dn42 tls-sign foobar.dn42 MIC92-MNT
ExecStart=/usr/bin/nginx -s reload</code></pre>

<h3><a class="anchor" id="revoke-a-certificate" href="#revoke-a-certificate"></a>Revoke a certificate.</h3>

<pre class="highlight"><code>$ ./ca.dn42 revoke XUU-MNT XUU-MNT.crt 
== USER CERT ==
   C:XD 
   O:dn42 
   OU:dn42 Certificate Authority 
   CN:XUU-MNT 
   emailAddress:xuu@sour.is 
   owner:XUU-MNT 
   pin-sha256:HdqCid0sedWXX3Q0uG98rYjJyTNOzaT13WfWpr1GvIw= 
== REVOKE CERT ==
OK</code></pre>

<h3><a class="anchor" id="certificate-transparency" href="#certificate-transparency"></a>Certificate transparency</h3>

<p>All issued certificates will be logged to <a href="https://teams.dn42/dn42/channels/tls-certificates">xuu's mattermost instance</a>.</p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
<li>
<p><a href="/Home" rel="nofollow">Home</a></p>

<ul>
<li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
<li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
<li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
<li><a href="/howto/Bird-communities" rel="nofollow">BGP communities</a></li>
<li><a href="/FAQ" rel="nofollow">FAQ</a></li>
</ul>
</li>
<li>
<p>How-To</p>

<ul>
<li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
<li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
<li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
<li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
<li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
<li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
<li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
<li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
<li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
<li>
<a href="/howto/Bird" rel="nofollow">Bird</a> / <a href="/howto/Bird2" rel="nofollow">Bird2</a>
</li>
<li><a href="/howto/Quagga" rel="nofollow">Quagga</a></li>
<li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
<li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
<li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
<li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
<li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
<li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
<li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
</ul>
</li>
<li>
<p>Services</p>

<ul>
<li><a href="/services/IRC" rel="nofollow">IRC</a></li>
<li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
<li><a href="/services/DNS" rel="nofollow">DNS</a></li>
<li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
<li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
<li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
<li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
<li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
<li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
<li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
</ul>
</li>
<li>
<p>Internal</p>

<ul>
<li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
<li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
<li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
<li>
<a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a><br />
</li>
<li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
</ul>
</li>
<li>
<p>External Tools</p>

<ul>
<li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
<li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
</ul>
</li>
</ul>

<hr />

	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p>Hosted by: <a href="mailto:xuu@sour.is" rel="nofollow">xuu</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">nurtic-vibe</a>, <a href="mailto:tom@xcv.vc" rel="nofollow">toBee</a>, <a href="mailto:dn42@burble.com" rel="nofollow">burble</a> | Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a></p>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="services/Automatic-CA.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/services/Automatic-CA.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
