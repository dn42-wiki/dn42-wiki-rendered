<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'services/Automatic-CA.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Automatic-CA</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Automatic-CA</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/services/Automatic-CA.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/services/Automatic-CA.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Automatic-CA
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/services/">services</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="dn42-acme-ca" href="#dn42-acme-ca"></a>DN42 ACME CA</h1>

<p>Certificates can be automatically generated with the <a href="https://burble.dn42/services/acme/">ACME-CA</a> using <a href="https://github.com/acmesh-official/acme.sh">acme.sh</a> or <a href="https://github.com/go-acme/lego">lego</a> or <a href="https://caddyserver.com/">Caddy</a>. More information can be found on <a href="https://burble.dn42/services/acme/">https://burble.dn42/services/acme/</a></p>

<h1><a class="anchor" id="dn42-self-serve-ca" href="#dn42-self-serve-ca"></a>DN42 Self-Serve CA</h1>

<p>This client is used for automating the process of requesting TLS certificates. (Available via: <a href="https://ca.dn42/ca-client">dn42</a>, <a href="https://ca.dn42.us/ca-client">iana</a>, <a href="anon@git.dn42:dn42/ca-client">git</a>)</p>

<h2><a class="anchor" id="validation-process" href="#validation-process"></a>VALIDATION PROCESS</h2>

<p>The process validates ownership by verifying control of both a users MNT object in the registry and the authoritative DNS server. 
The following steps take place in creating a signed certificate.</p>

<p><em>User Flow</em></p>

<ol>
  <li>User generates a 2048+ bit rsa key and CSR for their MNT object.</li>
  <li>User generates a sha256 hash of the rsa public key (commonly known as a <a href="https://developer.mozilla.org/en-US/docs/Web/Security/Public_Key_Pinning">public keypin</a>) and adds it as a remark in their MNT</li>
  <li>User submits the csr to the CA to validate and sign.</li>
  <li>CA checks for the keypin in their MNT object (if it does not find it in the local copy of the <a href="https://ca.dn42/reg/mntner/">monotone repo</a> it will check against io.nixnodes.dn42)</li>
  <li>(optional) CA revokes prior certificate as superseded.</li>
  <li>CA signs and returns the user certificate.</li>
</ol>

<p><em>Server Flow</em></p>

<ol>
  <li>User generates a 2048+ bit rsa key and CSR for the dns CN. Also including any SAN domains.</li>
  <li>User generates a sha256 hash of the rsa public key (commonly known as a <a href="https://developer.mozilla.org/en-US/docs/Web/Security/Public_Key_Pinning">public keypin</a>) and adds it as a txt record in their DNS.</li>
  <li>User uses the user certificate to authenticate and submits the csr to the CA to validate and sign.</li>
  <li>CA checks for the user keypin in their MNT object (if it does not find it in the local copy of the <a href="https://ca.dn42/reg/mntner/">monotone repo</a> it will check against io.nixnodes.dn42)</li>
  <li>CA checks the dns records for the CN and each SAN for the tls keypin.</li>
  <li>(optional) CA revokes prior certificate as superseded.</li>
  <li>CA signs and returns the tls certificate.</li>
</ol>

<p><em>User Renewals</em></p>

<p>User certificates are signed for 180 days. To renew follow the steps above starting from number 3.</p>

<p><em>Server renewals</em></p>

<p>Server certificates are signed for 45 days. To renew follow the steps above starting from number 3.</p>

<p><em>Certificate Revocations</em></p>

<ol>
  <li>User uses the user certificate to authenticate and submits the serial and revoke reason to CA.</li>
  <li>CA checks user keypin in their MNT object (if it does not find it in the local copy of the <a href="https://ca.dn42/reg/mntner/">monotone repo</a> it will check against io.nixnodes.dn42)</li>
  <li>CA checks that owner in certificate matches.</li>
  <li>CA revokes certificate and updates revocation list.</li>
</ol>

<h2><a class="anchor" id="install" href="#install"></a>INSTALL</h2>

<p>get the script here:</p>

<pre class="highlight"><code>curl https://ca.dn42/ca.dn42 <span class="o">&gt;</span> ca.dn42<span class="p">;</span> <span class="nb">chmod</span> +x ca.dn42</code></pre>

<p>available via git: anon@git.dn42:dn42/ca-client</p>

<h2><a class="anchor" id="known-issues" href="#known-issues"></a>KNOWN ISSUES</h2>

<h3><a class="anchor" id="openssl-prior-to-1-0-2-returns-ssl-certificate-problem-permitted-subtree-violation" href="#openssl-prior-to-1-0-2-returns-ssl-certificate-problem-permitted-subtree-violation"></a>openssl prior to 1.0.2 returns "SSL certificate problem: permitted subtree violation"</h3>

<p>The way openssl validated name constraints prevented it from accepting dns names that started with a dot.
Because the name constraint is "DNS:.dn42" it fails to validate.</p>

<p><a href="https://groups.google.com/forum/#!topic/mailing.openssl.dev/drG3U-S4iaE">Read more on this mailing list thread</a></p>

<h3><a class="anchor" id="x-509-nameconstraints-on-certificates-not-supported-on-os-x" href="#x-509-nameconstraints-on-certificates-not-supported-on-os-x"></a>X.509 nameConstraints on certificates not supported on OS X</h3>

<p>Browsers and clients that rely on Apple's <a href="https://developer.apple.com/library/mac/documentation/Security/Reference/secureTransportRef/">Secure Transport</a> library does not support X.509's nameConstraints.</p>

<p>Read more on this <a href="http://security.stackexchange.com/a/97133">stack exchange post</a></p>

<h2><a class="anchor" id="how-to-run" href="#how-to-run"></a>How to Run</h2>

<pre class="highlight"><code>Usage:  # OWNER is your MNT handle.
   ./ca.dn42 user-gen OWNER EMAIL          # Output to OWNER.csr and OWNER.key
   ./ca.dn42 user-sig OWNER                # Output to OWNER.crt and OWNER.p12
   ./ca.dn42 tls-gen DNS OWNER EMAIL [SAN] # Output to OWNER_DNS.csr and OWNER.key
   ./ca.dn42 tls-sig DNS OWNER             # Output to OWNER_DNS.crt and OWNER_DNS.p12
   ./ca.dn42 revoke OWNER CERTFILE [REASON]


Revoke Reasons: unspecified, keyCompromise, affiliationChanged,
   superseded, cessationOfOperation, certificateHold, removeFromCRL

Environtment Options:
   DN42CA_PKCS12 = 1                # Generate pkcs12 file for certificate.</code></pre>

<h2><a class="anchor" id="example" href="#example"></a>Example</h2>

<p>Generate the user key</p>

<pre class="highlight"><code><span class="nv">$ </span>./ca.dn42 user-gen XUU-MNT xuu@sour.is
Generating a 2048 bit RSA private key
...............................+++
.........................+++
writing new private key to <span class="s1">'XUU-MNT.key'</span>
<span class="nt">-----</span>
<span class="o">=</span>
<span class="o">=</span> You need to have this pin added to your mnt object before proceeding to the next step.
<span class="o">=</span>
|MNT Key Pin| remarks: pin-sha256:HdqCid0sedWXX3Q0uG98rYjJyTNOzaT13WfWpr1GvIw<span class="o">=</span></code></pre>

<h3><a class="anchor" id="sign-the-user-key" href="#sign-the-user-key"></a>Sign the user key</h3>

<pre class="highlight"><code><span class="nv">$ </span>./ca.dn42 user-sign XUU-MNT xuu@sour.is
<span class="o">==</span> USER CERT <span class="o">==</span>
   C:XD
   O:dn42
   OU:dn42 Certificate Authority
   CN:XUU-MNT
   emailAddress:xuu@sour.is
   owner:XUU-MNT
   pin-sha256:HdqCid0sedWXX3Q0uG98rYjJyTNOzaT13WfWpr1GvIw<span class="o">=</span>
OK https://ca.dn42/crt/XUU-MNT.crt
Enter Export Password:
Verifying - Enter Export Password:</code></pre>

<h3><a class="anchor" id="generate-the-server-key" href="#generate-the-server-key"></a>Generate the server key</h3>

<pre class="highlight"><code><span class="nv">$ </span>./ca.dn42 tls-gen ca.dn42 XUU-MNT xuu@sour.is DNS:ca.dn42

Generating a 2048 bit RSA private key
...........................................+++
.......................+++
writing new private key to <span class="s1">'XUU-MNT_ca.dn42.key'</span>
<span class="nt">-----</span>
writing RSA key
<span class="o">=</span>
<span class="o">=</span> |DNS Key Pin| You need to have this pin added to your dns records  before proceeding to the next step.
<span class="o">=</span>
_dn42_tlsverify.ca.dn42. IN TXT XUU-MNT:pin-sha256:Qu/X5GNqOo05TdL7oexkamE34OUuDE60T+f0xc60UPQ<span class="o">=</span></code></pre>

<p>After you set this TXT-Record for your domain, you can verify it with the following command (by replacing the domain with your own):</p>

<pre class="highlight"><code><span class="nv">$ </span>dig +short TXT _dn42_tlsverify.ca.dn42.
<span class="s2">"XUU-MNT:pin-sha256:Qu/X5GNqOo05TdL7oexkamE34OUuDE60T+f0xc60UPQ="</span></code></pre>

<h3><a class="anchor" id="sign-the-server-key" href="#sign-the-server-key"></a>Sign the server key</h3>

<pre class="highlight"><code><span class="nv">$ </span>./ca.dn42 tls-sign ca.dn42 XUU-MNT
<span class="o">==</span> USER CERT <span class="o">==</span>
   C:XD 
   O:dn42 
   OU:dn42 Certificate Authority 
   CN:XUU-MNT 
   emailAddress:xuu@sour.is 
   owner:XUU-MNT 
   pin-sha256:HdqCid0sedWXX3Q0uG98rYjJyTNOzaT13WfWpr1GvIw<span class="o">=</span> 
<span class="o">==</span> DNS CSR <span class="o">==</span>
   C:XD 
   O:dn42 
   OU:dn42 Certificate Authority 
   CN:ca.dn42 
   emailAddress:xuu@sour.is 
   owner:XUU-MNT 
   pin-sha256:Qu/X5GNqOo05TdL7oexkamE34OUuDE60T+f0xc60UPQ<span class="o">=</span> 
<span class="o">==</span> DNS Tests <span class="o">==</span>
   CN Record: ca.dn42 PASSED
   SAN Record: ca.dn42 PASSED
OK https://ca.dn42/crt/XUU-MNT_ca.dn42.crt
Enter Export Password: <span class="k">****</span>
Verifying - Enter Export Password: <span class="k">****</span></code></pre>

<p>The generated certificate will be valid for 3 months, to renew it simply run <code>./ca.dn42 tls-sign ca.dn42 XUU-MNT</code> again. This could be also automated in cron:</p>

<pre class="highlight"><code>0 0 1 <span class="k">*</span> <span class="k">*</span> /etc/ssl/dn42/ca.dn42 tls-sign wiki.dn42 MIC92-MNT</code></pre>

<p>or with a systemd timer:</p>

<pre class="highlight"><code><span class="c"># update-dn42-ca.timer
</span>[<span class="n">Timer</span>]
<span class="n">OnBootSec</span>=<span class="m">1</span><span class="n">h</span>
<span class="n">OnUnitActiveSec</span>=<span class="m">1</span><span class="n">w</span>
<span class="n">Persistent</span>=<span class="n">yes</span>

[<span class="n">Install</span>]
<span class="n">WantedBy</span>=<span class="n">timers</span>.<span class="n">target</span></code></pre>

<pre class="highlight"><code>[<span class="n">Service</span>]
<span class="n">Type</span>=<span class="n">oneshot</span>
<span class="n">WorkingDirectory</span>=/<span class="n">etc</span>/<span class="n">ssl</span>/<span class="n">dn42</span>
<span class="n">ExecStart</span>=/<span class="n">etc</span>/<span class="n">ssl</span>/<span class="n">dn42</span>/<span class="n">ca</span>.<span class="n">dn42</span> <span class="n">tls</span>-<span class="n">sign</span> <span class="n">wiki</span>.<span class="n">dn42</span> <span class="n">MIC92</span>-<span class="n">MNT</span>
<span class="c"># accept multiple ExecStart lines for other certificates
# ExecStart=/etc/ssl/dn42/ca.dn42 tls-sign foobar.dn42 MIC92-MNT
</span><span class="n">ExecStart</span>=/<span class="n">usr</span>/<span class="n">bin</span>/<span class="n">nginx</span> -<span class="n">s</span> <span class="n">reload</span></code></pre>

<h3><a class="anchor" id="revoke-a-certificate" href="#revoke-a-certificate"></a>Revoke a certificate.</h3>

<pre class="highlight"><code><span class="nv">$ </span>./ca.dn42 revoke XUU-MNT XUU-MNT.crt 
<span class="o">==</span> USER CERT <span class="o">==</span>
   C:XD 
   O:dn42 
   OU:dn42 Certificate Authority 
   CN:XUU-MNT 
   emailAddress:xuu@sour.is 
   owner:XUU-MNT 
   pin-sha256:HdqCid0sedWXX3Q0uG98rYjJyTNOzaT13WfWpr1GvIw<span class="o">=</span> 
<span class="o">==</span> REVOKE CERT <span class="o">==</span>
OK</code></pre>

<h3><a class="anchor" id="certificate-transparency" href="#certificate-transparency"></a>Certificate transparency</h3>
<p>All issued certificates will be logged to <a href="https://teams.dn42/dn42/channels/tls-certificates">xuu's mattermost instance</a>.</p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>, <a href="https://iedon.net/post/24" rel="nofollow">IEDON-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>, <a href="https://dn42.jp/" rel="nofollow">dn42.jp</a> (wiki-go)</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="services/Automatic-CA.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/services/Automatic-CA.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
