<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'services/Distributed-Wiki-New.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Distributed-Wiki-New</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Distributed-Wiki-New</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/services/Distributed-Wiki-New.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/services/Distributed-Wiki-New.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Distributed-Wiki-New
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/services/">services</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="the-new-distributed-wiki" href="#the-new-distributed-wiki"></a>The New Distributed Wiki</h1>

<blockquote>
  <p>This document replaces the legacy Gollum/ExaBGP setup notes. It explains how to deploy the Go-based wiki mirror while keeping the original structure for easy comparison.</p>
</blockquote>

<p>Thanks to <a href="https://git.dn42.dev/wiki/wiki-ng">wiki-ng</a>, based on their work, <a href="https://github.com/iedon/dn42-wiki-go">dn42-wiki-go</a> can provide both static site generation and live edit.</p>

<h2><a class="anchor" id="overview" href="#overview"></a>Overview</h2>

<p><code>dn42-wiki-go</code> provides a statically rendered, Git-backed documentation site for dn42. The binary can run in two modes:</p>

<ul>
  <li>
<strong>Live mode</strong> (the default) serves HTTP directly, watches the upstream Git repository, and rebuilds pages on change.</li>
  <li>
<strong>Static build mode (<code>live=false or run with --build</code>)</strong> produces pre-rendered HTML into <code>dist/</code> once, suitable for delivery by any web server.</li>
</ul>

<p>Nginx or another TLS proxy is still recommended for public access, but the application ships with native HTTPS and webhook support.</p>

<h2><a class="anchor" id="prerequisites" href="#prerequisites"></a>Prerequisites</h2>

<ul>
  <li>A stable dn42-connected host with enough CPU and disk to cache the Git repository and generated site (<code>~500 MB</code>).</li>
  <li>Operational Git access to <code>git.dn42.dev/wiki/wiki</code> (read-only for mirrors, write access if you contribute edits).</li>
  <li>Software:
    <ul>
      <li>
<a href="https://go.dev/dl/">Go ≥ 1.24</a> (only needed for building from source).</li>
      <li>
<a href="https://git-scm.com/">Git</a>.</li>
      <li>Optional but recommended: <a href="https://nginx.org/">Nginx</a> or <a href="https://caddyserver.com/">Caddy</a> for TLS termination.</li>
      <li>Optional: <a href="https://docs.docker.com/">Docker</a> / <a href="https://docs.docker.com/compose/">Docker Compose</a> if you prefer containers.</li>
    </ul>
  </li>
  <li>Solid operational knowledge—production mirrors are expected to run reliably and coordinate with the dn42 maintainers.</li>
</ul>

<h2><a class="anchor" id="network" href="#network"></a>Network</h2>

<ul>
  <li>The daemon listens on the address configured in <code>config.json</code> (<code>listen</code>, default <code>:8080</code>). Use firewalling or a reverse proxy to expose the service on your chosen anycast/unicast IPs.</li>
  <li>You may terminate HTTPS in-process (set <code>enableTLS</code>, <code>tlsCert</code>, <code>tlsKey</code>) or offload TLS to Nginx/Caddy.</li>
  <li>If you operate an anycast mirror, advertise <code>172.23.0.80/32</code> and <code>fd42:d42:d42:80::1/64</code> only when the health checks succeed. ExaBGP or native BGP daemons work well; see the <em>Monitoring &amp; Routing</em> section.</li>
</ul>

<h2><a class="anchor" id="repository-synchronisation" href="#repository-synchronisation"></a>Repository Synchronisation</h2>

<p>The wiki content lives in Git. The application already performs periodic pulls (configured via <code>git.pullIntervalSec</code>) and exposes a webhook for faster updates. You still need an initial clone and credentials.</p>

<h3><a class="anchor" id="initial-clone" href="#initial-clone"></a>Initial clone</h3>

<pre class="highlight"><code>git clone git@git.dn42.dev:wiki/wiki.git repo</code></pre>

<p>Populate <code>config.json</code> with the same <code>remote</code> URL and point <code>git.localDirectory</code> at the clone (default <code>./repo</code>).</p>

<h3><a class="anchor" id="optional-external-sync-script" href="#optional-external-sync-script"></a>Optional external sync script</h3>

<p>If you want an <strong>independent</strong> watchdog, a minimal cron job keeps the repository fresh:</p>

<pre class="highlight"><code><span class="c">#!/bin/sh</span>
<span class="nb">set</span> <span class="nt">-euo</span> pipefail
<span class="nb">cd</span> /srv/dn42-wiki/repo
/usr/bin/git pull <span class="nt">--ff-only</span>
/usr/bin/git push  <span class="c"># if you have write access</span></code></pre>

<p>Schedule it every 5–15 minutes. Avoid overlapping with the built-in poll interval to reduce churn.</p>

<h2><a class="anchor" id="application-setup" href="#application-setup"></a>Application Setup</h2>

<ol>
  <li>Copy <code>config.example.json</code> to <code>config.json</code> and adjust:
    <ul>
      <li>
<code>live</code>: set <code>true</code> for mirrors that serve HTTP directly; set <code>false</code> to produce static HTML.</li>
      <li>
<code>editable</code>: mirrors that allow edits should be reachable from dn42 only.</li>
      <li>
<code>git.remote</code>: use your git.dn42 credentials. Leave empty to run against a local repository only.</li>
      <li>
<code>webhook.enabled</code>: enable for fast sync and provide a shared secret.</li>
      <li>
<code>webhook.polling</code>: set <code>enabled</code> and <code>endpoint</code> if you need active polling. <code>skipRemoteCert</code> lets you disable TLS verification for trusted endpoints. See also <code>dn42notifyd</code>.</li>
      <li>
<code>trustedProxies</code>: add your reverse proxy or load balancer networks.</li>
    </ul>
  </li>
  <li>Compile the binary:</li>
</ol>

<pre class="highlight"><code>./build.sh</code></pre>

<ol>
  <li>Launch the service:</li>
</ol>

<pre class="highlight"><code>./dn42-wiki-go <span class="nt">--config</span> ./config.json</code></pre>

<p>The first run performs a full static build into <code>dist/</code>. Subsequent requests serve directly from disk, and background pulls rebuild the output as needed.</p>

<h3><a class="anchor" id="static-only-build" href="#static-only-build"></a>Static-only build</h3>

<p>If you just need HTML assets:</p>

<pre class="highlight"><code>./dn42-wiki-go <span class="nt">--config</span> ./config.json <span class="nt">--build</span></code></pre>

<p>Deploy <code>dist/</code> with any web server or object store.</p>

<h3><a class="anchor" id="systemd-unit-example" href="#systemd-unit-example"></a>Systemd unit (example)</h3>

<p>See <a href="dn42-wiki-go.service">dn42-wiki-go.service</a> and <a href="dn42-wiki-go.socket">dn42-wiki-go.socket</a>.</p>

<p>Reload systemd, enable, and start the service.</p>

<h2><a class="anchor" id="reverse-proxy-tls" href="#reverse-proxy-tls"></a>Reverse Proxy / TLS</h2>

<p>Place a reverse proxy in front of the daemon for certificate management and to present the canonical hostnames.</p>

<p>The repository includes <code>nginx-vhost.conf</code> with a more complete example (HTTP -&gt; HTTPS redirect, QUIC, static asset caching, and API proxying). Adjust:</p>

<ul>
  <li>
<code>root</code> so it points at your rendered <code>dist/</code> directory when serving static files directly.</li>
  <li>
<code>proxy_pass</code> directives if you run the Go binary on a different port or on a Unix socket.</li>
  <li>Certificate paths, <code>X-SiteID</code>, and anycast/unicast listener addresses to match your deployment.</li>
</ul>

<p>To keep HPKP/HSTS behaviour consistent with the legacy setup, reuse the same headers. Coordinate DNS and certification with the dn42 Automatic CA workflow when exposing official mirrors.</p>

<h2><a class="anchor" id="docker-compose" href="#docker-compose"></a>Docker &amp; Compose</h2>

<p>The repository ships with a multi-stage <code>Dockerfile</code> and <code>docker-compose.yml</code>.</p>

<pre class="highlight"><code><span class="c"># Build and start</span>
docker compose up <span class="nt">--build</span> <span class="nt">-d</span>

<span class="c"># Logs</span>
docker compose logs <span class="nt">-f</span></code></pre>

<p>Bind-mount <code>./config/config.json</code> to override settings and use <code>./data/dist</code> plus <code>./data/repo</code> for persistent state. The container runs as a non-root user and exposes port <code>8080</code>.</p>

<h2><a class="anchor" id="webhooks-polling" href="#webhooks-polling"></a>Webhooks &amp; Polling</h2>

<ul>
  <li>
<code>/api/webhook/pull</code> and <code>/api/webhook/push</code> require the shared secret. Integrate them with your Git hosting or ExaBGP watchdog to trigger immediate pulls or pushes.</li>
  <li>The optional poller registers with a remote notification service specified in <code>webhook.polling.endpoint</code>. Set <code>skipRemoteCert</code> only if the endpoint uses self-signed certificates you trust.</li>
</ul>

<h2><a class="anchor" id="monitoring-routing" href="#monitoring-routing"></a>Monitoring &amp; Routing</h2>

<p>For anycast mirrors, advertise the service prefix only when the local HTTP endpoint is healthy. A trimmed-down watchdog using ExaBGP:</p>

<pre class="highlight"><code><span class="c">#!/bin/sh</span>
<span class="nb">set</span> <span class="nt">-eu</span>
check<span class="o">()</span> <span class="o">{</span>
  curl <span class="nt">-fsS</span> <span class="nt">--max-time</span> 5 https://127.0.0.1:8443/ | <span class="nb">grep</span> <span class="nt">-qi</span> <span class="s2">"dn42"</span>  <span class="c"># adjust scheme/port</span>
<span class="o">}</span>

announce<span class="o">()</span> <span class="o">{</span>
  <span class="nb">printf</span> <span class="s1">'announce route 172.23.0.80/32 next-hop %s\n'</span> <span class="s2">"</span><span class="nv">$NEXT_HOP</span><span class="s2">"</span>
  <span class="nb">printf</span> <span class="s1">'announce route fd42:d42:d42:80::/64 next-hop %s\n'</span> <span class="s2">"</span><span class="nv">$NEXT_HOP6</span><span class="s2">"</span>
<span class="o">}</span>

withdraw<span class="o">()</span> <span class="o">{</span>
  <span class="nb">printf</span> <span class="s1">'withdraw route 172.23.0.80/32 next-hop %s\n'</span> <span class="s2">"</span><span class="nv">$NEXT_HOP</span><span class="s2">"</span>
  <span class="nb">printf</span> <span class="s1">'withdraw route fd42:d42:d42:80::/64 next-hop %s\n'</span> <span class="s2">"</span><span class="nv">$NEXT_HOP6</span><span class="s2">"</span>
<span class="o">}</span>

<span class="nv">state</span><span class="o">=</span>down
<span class="k">while </span><span class="nb">sleep </span>30<span class="p">;</span> <span class="k">do
  if </span>check<span class="p">;</span> <span class="k">then</span>
    <span class="o">[</span> <span class="s2">"</span><span class="nv">$state</span><span class="s2">"</span> <span class="o">=</span> down <span class="o">]</span> <span class="o">&amp;&amp;</span> <span class="o">{</span> announce<span class="p">;</span> <span class="nv">state</span><span class="o">=</span>up<span class="p">;</span> <span class="o">}</span>
  <span class="k">else</span>
    <span class="o">[</span> <span class="s2">"</span><span class="nv">$state</span><span class="s2">"</span> <span class="o">=</span> up <span class="o">]</span> <span class="o">&amp;&amp;</span> <span class="o">{</span> withdraw<span class="p">;</span> <span class="nv">state</span><span class="o">=</span>down<span class="p">;</span> <span class="o">}</span>
  <span class="k">fi
done</span></code></pre>

<p>Run the script under an ExaBGP <code>process</code> stanza. Ensure your IGP routes traffic correctly to the service when announced.</p>

<h2><a class="anchor" id="maintenance-checklist" href="#maintenance-checklist"></a>Maintenance Checklist</h2>

<ul>
  <li>Monitor <code>dist/</code> age and <code>dn42-wiki-go</code> logs for build errors.</li>
  <li>Keep Go and system packages patched; rebuild after Go security releases.</li>
  <li>Track upstream configuration changes (<code>config.example.json</code>) and merge them into your <code>config.json</code>.</li>
  <li>Verify TLS certificates before expiry and renew via the Automatic CA process.</li>
  <li>Coordinate with other maintainers (mailing list/IRC) when adding or retiring mirrors.</li>
</ul>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/DNS" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">RPKI</a></li>
      <li><a href="/services/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
      <li><a href="/services/Registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
      <li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
    </ul>
  </li>
  <li>Historical
    <ul>
      <li><a href="/historical/Bird" rel="nofollow">Bird 1</a></li>
      <li><a href="/historical/Quagga" rel="nofollow">Quagga</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://hedgedoc.dn42.eu" rel="nofollow">HedgeDoc</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>
</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="services/Distributed-Wiki-New.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/services/Distributed-Wiki-New.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
