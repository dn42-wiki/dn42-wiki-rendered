<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-309be032396e783b13a47df58f389b7c8e11c2b2d42640560b874f677c25f6e5.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">

  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'services/DNS.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-f05401ee374f0c7f48fc2bc08e30b4f4db705861fd5895ed70998683b383bfb5.js" type="text/javascript"></script>
  

  <title>DNS</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>DNS</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/services/DNS.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <a class="btn btn-sm" id="minibutton-home" href="/">
      Home
    </a>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/overview"
          id="minibutton-overview"
        >
          Overview
        </a>

        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/latest_changes"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </a>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          href="/gollum/history/services/DNS.md/"
          id="minibutton-history"
        >
          History
        </a>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    DNS
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/services/">services</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="dn42-dns" href="#dn42-dns"></a>DN42 DNS</h1>

<p>This page covers guidance and examples on using DNS within DN42.</p>

<h2><a class="anchor" id="quick-start" href="#quick-start"></a>Quick Start</h2>

<p>It is recommended to run your own DNS resolver as this provides you with the most security and privacy. 
However, to get started, or if running your own resolver isn't desirable an anycast service
is available. The anycast service supports DNSSEC and will resolve public DNS names together with all the 
relevant DN42 and affiliated networks' names.</p>

<h3><a class="anchor" id="using-the-dns-anycast-service" href="#using-the-dns-anycast-service"></a>Using the DNS Anycast Service</h3>

<p>The DNS anycast service is provided by multiple operators, with each operator contributing to one of the two separate 
anycast services. By configuring both services, users get additional resiliency from having two, independent, resolvers.</p>

<table>
  <thead>
    <tr>
      <th>Name</th>
      <th>IPv4</th>
      <th>IPv6</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>a0.recursive-servers.dn42</td>
      <td>172.20.0.53</td>
      <td>fd42:d42:d42:54::1</td>
    </tr>
    <tr>
      <td>a3.recursive-servers.dn42</td>
      <td>172.23.0.53</td>
      <td>fd42:d42:d42:53::1</td>
    </tr>
  </tbody>
</table>

<p>To configure the service, ping both sets of addresses then set your primary nameserver to the lowest latency 
service and configure the other service as the secondary or backup nameserver.</p>

<p>Example resolv.conf, preferring a0.recursive-servers.dn42 and IPv4:</p>

<pre class="highlight"><code>nameserver 172.20.0.53
nameserver 172.23.0.53
nameserver fd42:d42:d42:54::1
nameserver fd42:d42:d42:53::1
search dn42</code></pre>

<p>Example resolv.conf, preferring a3.recursive-servers.dn42 and IPv6:</p>

<pre class="highlight"><code>nameserver fd42:d42:d42:53::1
nameserver fd42:d42:d42:54::1
nameserver 172.23.0.53
nameserver 172.20.0.53
option inet6       # Linux/glibc
family inet6 inet4 # BSD
search dn42</code></pre>

<h2><a class="anchor" id="advanced-configuration" href="#advanced-configuration"></a>Advanced Configuration</h2>

<p>There are multiple top level domains (TLDs) associated with DN42, its affiliated networks and for reverse DNS that must
be configured in order to run your own resolver. The registry is the authoritative source of active TLDs, but see also
this page <a href="/services/dns/External-DNS">dns/External-DNS</a> in the wiki.</p>

<h3><a class="anchor" id="split-horizon-dns" href="#split-horizon-dns"></a>Split horizon DNS</h3>

<p>In this configuration, you run your own, caching resolver but forward DN42 related queries (with recursion bit set) 
to the anycast service. Example configurations for different recursor implementations are included in the <a href="/services/dns/Configuration">dns/Configuration</a> page.</p>

<h3><a class="anchor" id="full-recursion" href="#full-recursion"></a>Full recursion</h3>

<p>Authoritative DNS for DN42 is provided by the *.delegation-servers.dn42 servers, see the DNS architecture here 
<a href="/services/New-DNS">New DNS</a> Delegations servers have full support for DNSSEC. Example configuration unbound implementations are included in the <a href="/services/dns/Configuration#resolver-setup">dns/Configuration</a> page.</p>

<h2><a class="anchor" id="further-information" href="#further-information"></a>Further Information</h2>

<ul>
  <li>
<a href="/services/dns/Configuration">dns/Configuration</a> - Forwarder/Resolver configuration examples</li>
  <li>
<a href="/services/New-DNS">New DNS</a> - current architecture</li>
  <li>
<a href="/services/dns/External-DNS">dns/External-DNS</a> - external DNS zones from interconnected networks</li>
  <li>
<a href="/services/Old-Hierarchical-DNS">Old Hierarchical DNS</a> - deprecated</li>
  <li>
<a href="/services/Original-DNS-(deprecated)">Original DNS (deprecated)</a> - deprecated</li>
</ul>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li><a href="/Home" rel="nofollow">Home</a></li>
  <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
  <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
  <li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
  <li><a href="/howto/Bird-communities" rel="nofollow">BGP communities</a></li>
  <li>
    <p><a href="/FAQ" rel="nofollow">FAQ</a></p>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li>
<a href="/howto/Bird" rel="nofollow">Bird</a> / <a href="/howto/Bird2" rel="nofollow">Bird2</a>
</li>
      <li><a href="/howto/Quagga" rel="nofollow">Quagga</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/vyos" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/DNS" rel="nofollow">DNS</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
      <li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:xuu@sour.is" rel="nofollow">xuu</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">nurtic-vibe</a>, <a href="mailto:tom@xcv.vc" rel="nofollow">toBee</a>, <a href="mailto:dn42@burble.com" rel="nofollow">burble</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>
</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="services/DNS.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/services/DNS.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
