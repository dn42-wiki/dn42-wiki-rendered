<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'services/Statistics.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Statistics</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Statistics</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/services/Statistics.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/services/Statistics.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Statistics
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/services/">services</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="statistics" href="#statistics"></a>Statistics</h1>

<h2><a class="anchor" id="irc" href="#irc"></a>IRC</h2>

<p>Channel statistics for #dn42@hackint are available at: <a href="https://dev.0l.dn42/stats/">https://dev.0l.dn42/stats/</a>.</p>

<h2><a class="anchor" id="scripts" href="#scripts"></a>Scripts</h2>

<h3><a class="anchor" id="number-of-prefixes-for-collectd" href="#number-of-prefixes-for-collectd"></a>Number of prefixes for collectd</h3>

<h4><a class="anchor" id="collectd-conf" href="#collectd-conf"></a>collectd.conf</h4>

<pre class="highlight"><code><span class="n">LoadPlugin</span> <span class="n">exec</span>
&lt;<span class="n">Plugin</span> <span class="n">exec</span>&gt;
   <span class="n">Exec</span> <span class="n">nobody</span> <span class="s2">"/etc/collectd/bgp_prefixes-quagga.sh"</span>
&lt;/<span class="n">Plugin</span>&gt;</code></pre>

<p>collectd refuses to exec scripts as root. On Debian vtysh is compiled with PAM support: adding nobody to the quaggavty group suffices.</p>

<h4><a class="anchor" id="bgp_prefixes-quagga-sh" href="#bgp_prefixes-quagga-sh"></a>bgp_prefixes-quagga.sh</h4>

<pre class="highlight"><code><span class="c">#!/bin/bash</span>

<span class="nv">INTERVAL</span><span class="o">=</span>10
<span class="nv">HOSTNAME</span><span class="o">=</span>dn42.hq.c3d2.de

<span class="k">while </span><span class="nb">true</span><span class="p">;</span> <span class="k">do
</span><span class="nv">n4</span><span class="o">=</span><span class="si">$(</span>vtysh <span class="nt">-d</span> bgpd <span class="nt">-c</span> <span class="s2">"show ip bgp"</span>|grep Total|sed <span class="nt">-e</span> <span class="s1">'s/Total number of prefixes //'</span><span class="si">)</span>
<span class="nv">n6</span><span class="o">=</span><span class="si">$(</span>vtysh <span class="nt">-d</span> bgpd <span class="nt">-c</span> <span class="s2">"show ipv6 bgp"</span>|grep Total|sed <span class="nt">-e</span> <span class="s1">'s/Total number of prefixes //'</span><span class="si">)</span>

<span class="nb">echo</span> <span class="s2">"PUTVAL </span><span class="nv">$HOSTNAME</span><span class="s2">/quagga-bgpd/routes-IPv4 interval=</span><span class="nv">$INTERVAL</span><span class="s2"> N:</span><span class="nv">$n4</span><span class="s2">"</span>
<span class="nb">echo</span> <span class="s2">"PUTVAL </span><span class="nv">$HOSTNAME</span><span class="s2">/quagga-bgpd/routes-IPv6 interval=</span><span class="nv">$INTERVAL</span><span class="s2"> N:</span><span class="nv">$n6</span><span class="s2">"</span>

<span class="nb">sleep</span> <span class="nv">$INTERVAL</span>
<span class="k">done</span></code></pre>

<h4><a class="anchor" id="number-of-prefixes-per-neighbour-for-bird" href="#number-of-prefixes-per-neighbour-for-bird"></a>Number of prefixes per neighbour for bird</h4>

<pre class="highlight"><code><span class="c">#!/bin/sh</span>
<span class="c">#</span>
<span class="c"># Collectd script for collecting the number of routes going through each</span>
<span class="c"># BGP neighour.  Works for bird.</span>
<span class="c">#</span>
<span class="c"># See https://dn42.net/Services-Statistics</span>

<span class="nv">INTERVAL</span><span class="o">=</span>60
<span class="nv">HOSTNAME</span><span class="o">=</span>mydn42router
<span class="o">[</span> <span class="nt">-n</span> <span class="s2">"</span><span class="nv">$COLLECTD_HOSTNAME</span><span class="s2">"</span> <span class="o">]</span> <span class="o">&amp;&amp;</span> <span class="nv">HOSTNAME</span><span class="o">=</span><span class="s2">"</span><span class="nv">$COLLECTD_HOSTNAME</span><span class="s2">"</span>

<span class="k">while </span><span class="nb">true
</span><span class="k">do
    </span>birdc <span class="s1">'show protocols "*"'</span> | <span class="nb">grep</span> <span class="s1">' BGP'</span> | <span class="nb">cut</span> <span class="nt">-d</span> <span class="s1">' '</span> <span class="nt">-f</span> 1 | <span class="k">while </span><span class="nb">read </span>neighbour
    <span class="k">do
        </span><span class="nv">nbroutes</span><span class="o">=</span><span class="si">$(</span>birdc <span class="s2">"show route protocol </span><span class="nv">$neighbour</span><span class="s2"> primary count"</span> | <span class="nb">grep</span> <span class="nt">-v</span> <span class="s1">'BIRD'</span> | <span class="nb">cut</span> <span class="nt">-d</span> <span class="s1">' '</span> <span class="nt">-f</span> 1<span class="si">)</span>
        <span class="nb">echo</span> <span class="s2">"PUTVAL </span><span class="nv">$HOSTNAME</span><span class="s2">/bird-bgpd/routes-</span><span class="nv">$neighbour</span><span class="s2"> interval=</span><span class="nv">$INTERVAL</span><span class="s2"> N:</span><span class="nv">$nbroutes</span><span class="s2">"</span>
    <span class="k">done</span>
    <span class="c"># FIXME: we probably count non-BGP routes here</span>
    <span class="nv">totalroutes</span><span class="o">=</span><span class="si">$(</span>birdc <span class="s2">"show route primary count"</span> | <span class="nb">grep</span> <span class="nt">-v</span> <span class="s1">'BIRD'</span> | <span class="nb">cut</span> <span class="nt">-d</span> <span class="s1">' '</span> <span class="nt">-f</span> 1<span class="si">)</span>
    <span class="nb">echo</span> <span class="s2">"PUTVAL </span><span class="nv">$HOSTNAME</span><span class="s2">/bird-bgpd/routes-all interval=</span><span class="nv">$INTERVAL</span><span class="s2"> N:</span><span class="nv">$totalroutes</span><span class="s2">"</span>
    <span class="nb">sleep</span> <span class="nv">$INTERVAL</span>
<span class="k">done</span></code></pre>

<h3><a class="anchor" id="munin-plugin" href="#munin-plugin"></a>munin plugin</h3>
<ul>
  <li>add the following to /etc/munin/plugin-conf.d/munin-node</li>
</ul>

<pre class="highlight"><code>[quagga_bgp]
user root</code></pre>

<ul>
  <li>place the script as quagga_bgp in /etc/munin/plugins</li>
</ul>

<pre class="highlight"><code><span class="c">#!/bin/sh</span>
<span class="c">#</span>
<span class="c">#</span>
<span class="c"># Munin Plugin to show quagga bgp4 routes</span>

<span class="c"># Standard Config Section Begin ##</span>
  <span class="k">if</span> <span class="o">[</span> <span class="s2">"</span><span class="nv">$1</span><span class="s2">"</span> <span class="o">=</span> <span class="s2">"autoconf"</span> <span class="o">]</span><span class="p">;</span> <span class="k">then
        </span><span class="nb">echo yes
        exit </span>0
  <span class="k">fi

  if</span> <span class="o">[</span> <span class="s2">"</span><span class="nv">$1</span><span class="s2">"</span> <span class="o">=</span> <span class="s2">"config"</span> <span class="o">]</span><span class="p">;</span> <span class="k">then

       </span><span class="nb">echo</span> <span class="s1">'graph_title Quagga BGP4 Routes'</span>
       <span class="nb">echo</span> <span class="s1">'graph_args --base 1000 -l 0'</span>
       <span class="nb">echo</span> <span class="s1">'graph_scale yes'</span>
       <span class="nb">echo</span> <span class="s1">'graph_vlabel Received routes via BGP4'</span>
       <span class="nb">echo</span> <span class="s1">'graph_category Network'</span>
       <span class="nb">echo</span> <span class="s1">'bgproutes.label Routes'</span>
       <span class="nb">echo</span> <span class="s1">'graph_info Route information provided by quagga daemon via vtysh'</span>
       <span class="nb">exit </span>0
  <span class="k">fi</span>
<span class="c"># Standard Config Section End ####</span>

<span class="c"># Measure Section Begin ##########</span>
  <span class="nv">data</span><span class="o">=(</span><span class="si">$(</span>vtysh <span class="nt">-c</span> <span class="s2">"show ip bgp"</span>|grep Total|cut <span class="nt">-d</span><span class="s2">" "</span> <span class="nt">-f5</span><span class="si">)</span><span class="o">)</span>

  <span class="k">if</span> <span class="o">[</span> <span class="s2">"</span><span class="nv">$data</span><span class="s2">"</span> <span class="o">=</span> <span class="s2">""</span> <span class="o">]</span><span class="p">;</span> <span class="k">then
     </span><span class="nb">echo </span>bgproutes.value    0
  <span class="k">else
     </span><span class="nb">echo </span>bgproutes.value    <span class="nv">$data</span>
  <span class="k">fi</span>
<span class="c"># Measure Section ##########</span></code></pre>
<ul>
  <li>restart munin-node</li>
</ul>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="services/Statistics.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/services/Statistics.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
