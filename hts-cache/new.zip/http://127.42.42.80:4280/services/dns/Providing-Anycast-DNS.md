<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'services/dns/Providing-Anycast-DNS.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Providing-Anycast-DNS</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Providing-Anycast-DNS</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/services/dns/Providing-Anycast-DNS.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/services/dns/Providing-Anycast-DNS.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Providing-Anycast-DNS
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/services/">services</a></li>
<li class="breadcrumb-item"><a href="/gollum/overview/services/dns/">dns</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="deprecated-please-have-a-look-at-hierarchical-dns-instead" href="#deprecated-please-have-a-look-at-hierarchical-dns-instead"></a>DEPRECATED - Please have a look at <a href="/services/Old-Hierarchical-DNS">Hierarchical DNS</a> instead</h1>

<p>You may want to participate in the anycast DNS cloud.</p>

<h2><a class="anchor" id="configuration" href="#configuration"></a>Configuration</h2>

<p>Configuration requirements for all members of the anycast group are:</p>
<ul>
  <li>maintain your own zones based on whois database (scripts included in monotone repository)</li>
  <li>allow recursion (including <code>.</code>)</li>
  <li>listen on a unicast IP too for testing/debugging reasons</li>
  <li>with bind, please use <code>minimal-responses yes;</code> (goes into <code>options</code>/<code>view</code>)</li>
</ul>

<p>It is <em>really</em> good to hang around in <a href="/services/IRC">IRC</a> to get things sorted out, if something doesn't work. Letting some people test your DNS behavior before joining the anycast-group is considered best practice - better safe than sorry.</p>

<ul>
  <li>
<strong>IP:</strong> 172.23.0.53</li>
  <li>
<strong>Announciation Subnet:</strong> 172.23.0.53/32</li>
</ul>

<h3><a class="anchor" id="generating-zone-files" href="#generating-zone-files"></a>Generating Zone Files</h3>

<p>There are a few different scripts for generating zone files. They have been written in a few different languages. Please keep in mind that RFC 2317 is what keeps people from registering a /24 <em>just to have RDNS</em>, so scripts that support it have a positive effect on address space usage.</p>

<table>
  <thead>
    <tr>
      <th><strong>Script</strong></th>
      <th><strong>Language</strong></th>
      <th><strong>Notes</strong></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>rfc2317.rb</td>
      <td>Ruby</td>
      <td> </td>
    </tr>
    <tr>
      <td>subnettr.py</td>
      <td>Python 3</td>
      <td>Author: xuu, forward &amp; reverse dns + RFC 2317</td>
    </tr>
    <tr>
      <td>zonegen.bind.php</td>
      <td>PHP</td>
      <td> </td>
    </tr>
    <tr>
      <td>zonegen.bind.sh</td>
      <td>Bash</td>
      <td> </td>
    </tr>
    <tr>
      <td>zonegen.rb</td>
      <td>Ruby</td>
      <td> </td>
    </tr>
    <tr>
      <td>zonegen.rdns.bind.sh</td>
      <td>Bash</td>
      <td> </td>
    </tr>
    <tr>
      <td>zonegen.rdns.tinydns.sh</td>
      <td>Bash</td>
      <td> </td>
    </tr>
    <tr>
      <td>zonegen.rev.bind.sh</td>
      <td>Bash</td>
      <td> </td>
    </tr>
    <tr>
      <td>zonegen.smallblockrdns.tinydns.sh</td>
      <td>Bash</td>
      <td> </td>
    </tr>
    <tr>
      <td>zonegen.tinydns.sh</td>
      <td>Bash</td>
      <td> </td>
    </tr>
    <tr>
      <td>zongen.v2.sh</td>
      <td>Sh</td>
      <td>Author: Martin89, forward &amp; reverse dns + RFC 2317</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="persons-providing-anycast-dns" href="#persons-providing-anycast-dns"></a>Persons providing anycast DNS</h2>

<table>
  <thead>
    <tr>
      <th><strong>Person</strong></th>
      <th><strong>Region</strong></th>
      <th style="text-align:center;"><strong>AS</strong></th>
      <th style="text-align:center;"><strong>Unicast Address</strong></th>
      <th><strong>Comments</strong></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>siska</td>
      <td>SI</td>
      <td style="text-align:center;">76103</td>
      <td style="text-align:center;">a.resolvers.nic.dn42 (172.22.177.70)</td>
      <td> </td>
    </tr>
    <tr>
      <td>xuu</td>
      <td>UT,US</td>
      <td style="text-align:center;">64737</td>
      <td style="text-align:center;">xuu.root.dn42   (172.22.141.132)</td>
      <td> </td>
    </tr>
    <tr>
      <td>xuu</td>
      <td>ON,CA</td>
      <td style="text-align:center;">64737</td>
      <td style="text-align:center;">souris.root.dn42 (172.22.141.180)</td>
      <td> </td>
    </tr>
    <tr>
      <td>Nurtic-Vibe</td>
      <td>EU</td>
      <td style="text-align:center;">4242420123</td>
      <td style="text-align:center;">ns1.grmml.dn42 (172.23.149.20)</td>
      <td> </td>
    </tr>
    <tr>
      <td>MWD</td>
      <td>AU</td>
      <td style="text-align:center;">4242420002</td>
      <td style="text-align:center;">nsr1.mwd.dn42 (172.23.227.20)</td>
      <td> </td>
    </tr>
    <tr>
      <td>Fritz</td>
      <td>??</td>
      <td style="text-align:center;">64712</td>
      <td style="text-align:center;">?? (??)</td>
      <td>Advertised over bgp</td>
    </tr>
    <tr>
      <td>prauscher</td>
      <td>DE</td>
      <td style="text-align:center;">64720</td>
      <td style="text-align:center;">prauscher.root.dn42 (172.22.120.1)</td>
      <td>advertised in BGP</td>
    </tr>
    <tr>
      <td>hax404</td>
      <td>DE</td>
      <td style="text-align:center;">76114</td>
      <td style="text-align:center;">chero.hax404.dn42 (172.23.136.65)</td>
      <td>advertised in BGP</td>
    </tr>
    <tr>
      <td>florianb</td>
      <td>AT</td>
      <td style="text-align:center;">4242423955</td>
      <td style="text-align:center;">resolver.flo.dn42 (172.20.2.65)</td>
      <td>advertisted in BGP</td>
    </tr>
  </tbody>
</table>

<h1><a class="anchor" id="ipv6-dns" href="#ipv6-dns"></a>IPv6 DNS</h1>

<p><strong>IP:</strong> fd42:d42:d42:53::1/64</p>

<p><a href="/services/IPv6-Anycast">IPv6 Anycast Info</a></p>

<h2><a class="anchor" id="persons-providing-anycast-dns-for-ipv6" href="#persons-providing-anycast-dns-for-ipv6"></a>Persons providing anycast DNS for IPv6</h2>

<table>
  <thead>
    <tr>
      <th><strong>Person</strong></th>
      <th><strong>Region</strong></th>
      <th style="text-align:center;"><strong>AS</strong></th>
      <th style="text-align:center;"><strong>Unicast Address</strong></th>
      <th><strong>Comments</strong></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>xuu</td>
      <td>UT,US</td>
      <td style="text-align:center;">64737</td>
      <td style="text-align:center;">xuu.root.dn42 (fdea:a15a:77b9:d42::53)</td>
      <td> </td>
    </tr>
    <tr>
      <td>xuu</td>
      <td>ON,CA</td>
      <td style="text-align:center;">64737</td>
      <td style="text-align:center;">souris.root.dn42 (fdea:a15a:77b9:53::1)</td>
      <td> </td>
    </tr>
    <tr>
      <td>Nurtic-Vibe</td>
      <td>EU</td>
      <td style="text-align:center;">4242420123</td>
      <td style="text-align:center;">ns1.grmml.dn42 (fd42:23:149:cccc::53)</td>
      <td> </td>
    </tr>
    <tr>
      <td>florianb</td>
      <td>AT</td>
      <td style="text-align:center;">4242423955</td>
      <td style="text-align:center;">resolver.flo.dn42 (fd42:d42:d42:53::1)</td>
      <td>advertisted in BGP</td>
    </tr>
  </tbody>
</table>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/Policies" rel="nofollow">Policies</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
      <li><a href="/Links" rel="nofollow">Links</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
      <li><a href="/howto/GeoFeed" rel="nofollow">GeoFeed</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/DNS/Overview" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">RPKI</a></li>
      <li><a href="/services/exchanges/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Pingables" rel="nofollow">Pingables</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/ca/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
      <li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
    </ul>
  </li>
  <li>Historical
    <ul>
      <li><a href="/historical/Bird" rel="nofollow">Bird 1</a></li>
      <li><a href="/historical/Quagga" rel="nofollow">Quagga</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://hedgedoc.dn42.eu" rel="nofollow">HedgeDoc</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>, <a href="https://iedon.net/post/24" rel="nofollow">IEDON-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>, <a href="https://dn42.jp/" rel="nofollow">dn42.jp</a> (wiki-go)</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="services/dns/Providing-Anycast-DNS.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/services/dns/Providing-Anycast-DNS.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
