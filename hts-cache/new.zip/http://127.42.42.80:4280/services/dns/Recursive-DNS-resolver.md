<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'services/dns/Recursive-DNS-resolver.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Recursive-DNS-resolver</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Recursive-DNS-resolver</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/services/dns/Recursive-DNS-resolver.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/services/dns/Recursive-DNS-resolver.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Recursive-DNS-resolver
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/services/">services</a></li>
<li class="breadcrumb-item"><a href="/gollum/overview/services/dns/">dns</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <p>If you want to run your own recursive DNS server, you must find upstream servers that are authoritative for the dn42 zones.</p>

<p>You may use some servers listed in the <a href="/services/dns/Providing-Anycast-DNS#Persons-providing-anycast-DNS">table of anycast servers</a>, or just use <code>172.22.119.160</code> and <code>172.22.119.163</code> (ns{1,2}.fritz.dn42).</p>

<h2><a class="anchor" id="configuration" href="#configuration"></a>Configuration</h2>

<h3><a class="anchor" id="unbound" href="#unbound"></a>Unbound</h3>

<p>Configuration for <code>unbound.conf</code></p>

<pre class="highlight"><code><span class="n">server</span>:
        <span class="n">local</span>-<span class="n">zone</span>: <span class="s2">"22.172.in-addr.arpa."</span> <span class="n">nodefault</span>
        <span class="n">local</span>-<span class="n">zone</span>: <span class="s2">"23.172.in-addr.arpa."</span> <span class="n">nodefault</span>

<span class="n">stub</span>-<span class="n">zone</span>:
        <span class="n">name</span>: <span class="s2">"dn42"</span>
        <span class="n">stub</span>-<span class="n">prime</span>: <span class="n">yes</span>
        <span class="n">stub</span>-<span class="n">addr</span>: <span class="m">172</span>.<span class="m">22</span>.<span class="m">119</span>.<span class="m">160</span>
        <span class="n">stub</span>-<span class="n">addr</span>: <span class="m">172</span>.<span class="m">22</span>.<span class="m">119</span>.<span class="m">163</span>

<span class="n">stub</span>-<span class="n">zone</span>:
        <span class="n">name</span>: <span class="s2">"22.172.in-addr.arpa"</span>
        <span class="n">stub</span>-<span class="n">prime</span>: <span class="n">yes</span>
        <span class="n">stub</span>-<span class="n">addr</span>: <span class="m">172</span>.<span class="m">22</span>.<span class="m">119</span>.<span class="m">160</span>
        <span class="n">stub</span>-<span class="n">addr</span>: <span class="m">172</span>.<span class="m">22</span>.<span class="m">119</span>.<span class="m">163</span>

<span class="n">stub</span>-<span class="n">zone</span>:
        <span class="n">name</span>: <span class="s2">"23.172.in-addr.arpa"</span>
        <span class="n">stub</span>-<span class="n">prime</span>: <span class="n">yes</span>
        <span class="n">stub</span>-<span class="n">addr</span>: <span class="m">172</span>.<span class="m">22</span>.<span class="m">119</span>.<span class="m">160</span>
        <span class="n">stub</span>-<span class="n">addr</span>: <span class="m">172</span>.<span class="m">22</span>.<span class="m">119</span>.<span class="m">163</span></code></pre>

<h3><a class="anchor" id="unbound-with-root-hints" href="#unbound-with-root-hints"></a>Unbound with root-hints</h3>
<p>Alternatively you can put dn42 root servers in the root-hints file for recursive resolving.</p>

<pre class="highlight"><code><span class="c"># /etc/unbound/unbound.conf.d/dn42.conf 
</span><span class="n">server</span>:
        <span class="c"># DNSSEC validation will fail
</span>        <span class="n">val</span>-<span class="n">permissive</span>-<span class="n">mode</span>: <span class="n">yes</span>
        <span class="c"># recursive queries for everyone
</span>        <span class="n">access</span>-<span class="n">control</span>: <span class="m">0</span>.<span class="m">0</span>.<span class="m">0</span>.<span class="m">0</span>/<span class="m">0</span> <span class="n">allow</span>
        <span class="c"># dn42 root servers
</span>        <span class="n">root</span>-<span class="n">hints</span>: /<span class="n">etc</span>/<span class="n">unbound</span>/<span class="n">dn42</span>.<span class="n">hints</span>
	<span class="c"># enable IPv6
</span>	<span class="n">do</span>-<span class="n">ip6</span>: <span class="n">yes</span>
	<span class="c"># allow reverse lookup of rfc1918 space, which includes the DN42 address space
</span>	<span class="n">unblock</span>-<span class="n">lan</span>-<span class="n">zones</span>: <span class="n">yes</span>
	<span class="n">insecure</span>-<span class="n">lan</span>-<span class="n">zones</span>: <span class="n">yes</span>

<span class="n">remote</span>-<span class="n">control</span>:
        <span class="n">control</span>-<span class="n">enable</span>: <span class="n">no</span></code></pre>

<p>The <code>/etc/unbound/dn42.hints</code> file:
</p><pre class="highlight"><code>.                                         <span class="n">NS</span>    <span class="n">a</span>.<span class="n">root</span>-<span class="n">servers</span>.<span class="n">dn42</span>.
<span class="n">a</span>.<span class="n">root</span>-<span class="n">servers</span>.<span class="n">dn42</span>.           <span class="m">3600000</span>    <span class="n">A</span>     <span class="m">172</span>.<span class="m">22</span>.<span class="m">177</span>.<span class="m">6</span>
.                                         <span class="n">NS</span>    <span class="n">m</span>.<span class="n">root</span>-<span class="n">servers</span>.<span class="n">dn42</span>.
<span class="n">m</span>.<span class="n">root</span>-<span class="n">servers</span>.<span class="n">dn42</span>.           <span class="m">3600000</span>    <span class="n">A</span>     <span class="m">172</span>.<span class="m">23</span>.<span class="m">67</span>.<span class="m">67</span>
.                                         <span class="n">NS</span>    <span class="n">t</span>.<span class="n">root</span>-<span class="n">servers</span>.<span class="n">dn42</span>.
<span class="n">t</span>.<span class="n">root</span>-<span class="n">servers</span>.<span class="n">dn42</span>.           <span class="m">3600000</span>    <span class="n">A</span>     <span class="m">172</span>.<span class="m">22</span>.<span class="m">102</span>.<span class="m">141</span>
.                                         <span class="n">NS</span>    <span class="n">x</span>.<span class="n">root</span>-<span class="n">servers</span>.<span class="n">dn42</span>.
<span class="n">x</span>.<span class="n">root</span>-<span class="n">servers</span>.<span class="n">dn42</span>.           <span class="m">3600000</span>    <span class="n">A</span>     <span class="m">172</span>.<span class="m">22</span>.<span class="m">141</span>.<span class="m">1</span></code></pre>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/Policies" rel="nofollow">Policies</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
      <li><a href="/Links" rel="nofollow">Links</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
      <li><a href="/howto/GeoFeed" rel="nofollow">GeoFeed</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/dns/Overview" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">RPKI</a></li>
      <li><a href="/services/exchanges/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Pingables" rel="nofollow">Pingables</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/ca/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
      <li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
    </ul>
  </li>
  <li>Historical
    <ul>
      <li><a href="/historical/Bird" rel="nofollow">Bird 1</a></li>
      <li><a href="/historical/Quagga" rel="nofollow">Quagga</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://hedgedoc.dn42.eu" rel="nofollow">HedgeDoc</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>, <a href="https://iedon.net/post/24" rel="nofollow">IEDON-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>, <a href="https://dn42.jp/" rel="nofollow">dn42.jp</a> (wiki-go)</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="services/dns/Recursive-DNS-resolver.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/services/dns/Recursive-DNS-resolver.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
