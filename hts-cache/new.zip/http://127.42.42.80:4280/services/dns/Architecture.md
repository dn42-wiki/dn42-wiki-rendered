<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'services/dns/Architecture.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Architecture</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Architecture</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/services/dns/Architecture.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/services/dns/Architecture.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Architecture
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/services/">services</a></li>
<li class="breadcrumb-item"><a href="/gollum/overview/services/dns/">dns</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="current-dns-architecture" href="#current-dns-architecture"></a>Current DNS Architecture</h1>

<p>After frequent issues with the <a href="/services/dns/historical/Old-Hierarchical-DNS">Old Hierarchical DNS</a> system in early 2018, work has started to build a new and more reliable DNS system. The main goals are:</p>
<ul>
  <li>Reliability and Consistency to avoid debugging very obscure issues that are also hard to reproduce.</li>
  <li>Low maintenance burden on operators.</li>
  <li>Proper DNSSEC support for everything.</li>
</ul>

<h1><a class="anchor" id="end-users" href="#end-users"></a>End Users</h1>
<p>It is <strong>strongly recommended</strong> to run your own resolver for security and privacy reasons. Setting it up and maintaining it should be easy, see <a href="/services/dns/Configuration">services/dns/Configuration</a>.</p>

<p>If running your own resolver is not possible or desirable, you can choose one or more instances from <a href="https://git.dn42.dev/dn42/registry/src/master/data/dns/recursive-servers.dn42">dns/recursive-servers.dn42 in the registry</a>. Please make sure you fully understand the consequences and fully trust these operators.</p>

<p>You can also use the globally anycasted a.recursive-servers.dn42 but you won't have any control over which instance you get. This is a <strong>very bad idea</strong> from a security standpoint.</p>

<h1><a class="anchor" id="instances" href="#instances"></a>Instances</h1>
<p>The system has two different components:</p>
<ul>
  <li>*.recursive-servers.dn42 and local resolvers responsible for handling queries from clients, validating DNSSEC and directing the queries at clearnet/dn42/ICVPN.</li>
  <li>*.delegation-servers.dn42 and *.master.delegation-servers.dn42 are a normal master-slave setup for providing the few official infrastructural zones.</li>
</ul>

<h2><a class="anchor" id="recursive-servers-dn42" href="#recursive-servers-dn42"></a>*.recursive-servers.dn42</h2>
<p>These are simple resolvers capable of resolving dn42 domains. Every operator gets a single letter name pointing to addresses assigned from their own address space and is strongly encouraged to use anycasting across multiple nodes to improve reliability. There is also the global anycast a.recursive-servers.dn42 which includes some/all other instances. Whether an *.recursive-servers.dn42 can resolve clearnet queries or not is decided by its operator but all a.recursive-servers.dn42 instances MUST resolve clearnet queries correctly. It is explicitly not supported to use clearnet nservers for dn42 zones and dn42 nservers for clearnet zones.</p>

<h2><a class="anchor" id="delegation-servers-dn42" href="#delegation-servers-dn42"></a>*.delegation-servers.dn42</h2>
<p>These are simple authoritative servers for the dn42 zone, rDNS and a few DNS infrastructure zones. Every operator gets a single letter name pointing to addresses assigned from their own address space and is strongly encouraged to use anycasting across multiple nodes to improve reliability. There is no anycast instance because that would make debugging much harder and *.recursive-servers.dn42 instances should do loadbalancing/failover across all instances listed in the registry.</p>

<h2><a class="anchor" id="master-delegation-servers-dn42" href="#master-delegation-servers-dn42"></a>*.master.delegation-servers.dn42</h2>
<p>These instances do not serve any clients. They poll the registry regularly and rebuild and resign (DNSSEC) the zones as needed. If any zone changes, all *.delegation-servers.dn42 instances are notified (<a href="https://tools.ietf.org/html/rfc1996">RFC1996</a>) which then load the new zone data over AXFR (<a href="https://tools.ietf.org/html/rfc5936">RFC5936</a>). The pool of masters is intentionally kept very small because of its much higher coordination needs and also the lacking support of a multi-master mode in many authoritative server implementations. The masters are only reachable over dedicated IPv6 assignments which are set up in a way that any master operator can hijack the address of a problematic master without having to wait for its operator to fix something.</p>

<h1><a class="anchor" id="running-your-own-instances" href="#running-your-own-instances"></a>Running your own instances</h1>
<ul>
  <li>If you want to run your own instances, make sure you are subscribed to the <a href="/contact">mailinglist</a>. It is also strongly recommended to join #dn42-dns@hackint. All changes are announced to the mailinglist but IRC makes debugging sessions much easier.</li>
  <li>Choose the implementation(s) you want to use. It should support at least AXFR+NOTIFY (<em>.delegation-servers.dn42) or DNSSEC (</em>.recursive-servers.dn42).</li>
  <li>Check if <a href="/TODO">TODO</a> already has configuration snippets for your implementation.
    <ul>
      <li>If yes, download it from there and include it in the main configuration.</li>
      <li>If not, then join us in #dn42-dns@hackint so we can add it together.</li>
    </ul>
  </li>
  <li>Verify that everything works:
    <ul>
      <li>For *.delegation-servers.dn42: Do an AXFR against all zones and compare with the result of an existing instance. The result should be identical.</li>
      <li>For *.recursive-servers.dn42: Query clearnet, dn42 and ICVPN domains including rDNS. Make sure that both signed and unsigned domains work properly.</li>
    </ul>
  </li>
  <li>(Optional) Choose your single letter name and ask in #dn42-dns@hackint to get it added to the registry. Once added to the list, you must implement changes announced to the mailinglist within a week (faster is obviously better) or you might get removed again. We try to keep maintenance work as low as possible but we can't do it without the cooperation of all operators!</li>
</ul>

<h1><a class="anchor" id="monitoring" href="#monitoring"></a>Monitoring</h1>
<p>burble is providing monitoring for the system. It does simple checks on all instances every minute and also logs all changes into #dn42-dns@hackint.
<a href="https://grafana.burble.com/d/E4iCaHoWk/dn42-dns-status?orgId=1&amp;refresh=1m">Monitoring page</a></p>

<h1><a class="anchor" id="dnssec" href="#dnssec"></a>DNSSEC</h1>
<p>There are currently two KSKs managed by BURBLE-MNT and JRB0001-MNT. They are used once per quarter to sign the DNSKEY RRset. Each master operator has one ZSK which is used to sign the zones (except for the DNSKEY RRset). This setup leads to bigger responses but allows each KSK holder to solve emergencies independently. The signatures of the DNSKEY RRset are valid until the end of the first month of the next quarter to give enough time for coordinating the next signing. All other signatures are valid for 3 days and replaced at least once per day.</p>

<p>The set of valid KSKs can be found in the registry.</p>

<h1><a class="anchor" id="see-also" href="#see-also"></a>See also</h1>

<ul>
  <li><a href="/services/dns/Overview">DNS Quick Start</a></li>
  <li>
<a href="/services/dns/historical/Old-Hierarchical-DNS">Old Hierarchical DNS</a> - deprecated</li>
  <li>
<a href="/services/dns/historical/Original-DNS-(deprecated)">Original DNS (deprecated)</a> - deprecated</li>
</ul>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="services/dns/Architecture.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/services/dns/Architecture.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
