<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'services/Certificate-Authority.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Certificate-Authority</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Certificate-Authority</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/services/Certificate-Authority.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/services/Certificate-Authority.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Certificate-Authority
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/services/">services</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="ssl-certificate-authority" href="#ssl-certificate-authority"></a>SSL Certificate Authority</h1>

<p>internal.dn42 is signed by an internally maintained CA that is only allowed to sign *.dn42 domains.
If you would like to have a certificate signed by this CA there is <a href="/services/Automatic-CA">an automated process to do so</a>. The CA is maintained by xuu@dn42.us.</p>

<p>If you are required to specify a license to clarify redistribution, then it <a href="https://groups.io/g/dn42/message/844">can be considered</a> as <a href="https://creativecommons.org/public-domain/cc0/">CC0</a>.</p>

<p>The CA certificate (<a href="https://ca.dn42/crt/root-ca.crt">dn42</a>, <a href="https://ca.dn42.us/crt/root-ca.crt">iana</a>):</p>

<pre class="highlight"><code>Certificate:
    Data:
        Version: 3 (0x2)
        Serial Number: 137808117760 (0x2016010000)
    Signature Algorithm: sha256WithRSAEncryption
        Issuer: C=XD, O=dn42, OU=dn42 Certificate Authority, CN=dn42 Root Authority CA
        Validity
            Not Before: Jan 16 00:12:04 2016 GMT
            Not After : Dec 31 23:59:59 2030 GMT
        Subject: C=XD, O=dn42, OU=dn42 Certificate Authority, CN=dn42 Root Authority CA
        Subject Public Key Info:
            Public Key Algorithm: rsaEncryption
                Public-Key: (2048 bit)
                Modulus:
                    00:c1:19:10:de:01:86:11:f1:82:0c:b0:d4:e5:ff:
                    9a:c8:e3:aa:f4:00:08:82:c0:cf:7f:05:7a:21:97:
                    c1:b5:8b:a3:d1:54:ee:fa:04:0f:77:d5:5c:98:4b:
                    d9:88:18:c1:17:10:92:e5:24:fa:ef:61:eb:5d:7b:
                    11:e5:be:ba:89:f2:60:c9:3b:82:05:3a:74:54:60:
                    23:66:1a:d8:cd:28:7b:f1:ea:55:25:9a:8c:04:a0:
                    ff:9d:48:54:4c:9d:bc:2d:a0:df:71:ae:64:47:0d:
                    e7:75:05:f4:c5:02:2a:d2:0c:be:a3:63:54:62:2b:
                    ad:29:eb:6a:08:a4:5e:a8:eb:f1:52:14:4e:d1:5d:
                    41:2f:d3:19:ba:e4:82:36:7a:d1:a3:f2:84:f6:07:
                    b2:f6:0c:30:db:db:76:ee:e9:14:05:c7:8f:75:b7:
                    3f:d5:d5:35:56:d0:92:44:df:26:1e:00:fa:ae:cb:
                    7a:c9:50:67:5d:69:f8:f9:fd:25:a7:1d:db:40:b1:
                    42:bc:45:57:e1:c9:1c:42:ba:69:80:1e:ea:25:99:
                    12:9f:6f:23:a3:d2:2e:4a:cd:15:e4:7c:49:f9:d1:
                    c0:f0:19:0c:15:50:ce:a6:51:bb:aa:16:b2:82:ec:
                    f4:61:44:8c:1c:dd:65:60:04:77:b0:4d:99:67:17:
                    fb:09
                Exponent: 65537 (0x10001)
        X509v3 extensions:
            X509v3 Key Usage: critical
                Certificate Sign, CRL Sign
            X509v3 Basic Constraints: critical
                CA:TRUE
            X509v3 Subject Key Identifier: 
                54:76:88:B2:C0:B5:30:D0:FC:4F:C9:6D:3B:F9:8C:55:11:AC:15:15
            X509v3 Authority Key Identifier: 
                keyid:54:76:88:B2:C0:B5:30:D0:FC:4F:C9:6D:3B:F9:8C:55:11:AC:15:15

            X509v3 Name Constraints: 
                Permitted:
                  DNS:.dn42
                  IP:172.20.0.0/255.252.0.0
                  IP:FD42:0:0:0:0:0:0:0/FFFF:0:0:0:0:0:0:0

    Signature Algorithm: sha256WithRSAEncryption
         5c:a4:3b:41:a0:81:69:e2:71:99:4d:75:4b:5a:20:0d:2a:d9:
         ec:ea:bc:8d:4f:b0:6c:f3:2e:41:1a:a0:75:f3:de:7e:3a:e0:
         a7:b9:db:cd:f5:16:e4:6a:cb:e7:cc:2a:8f:ee:7f:14:0a:a5:
         b5:f9:66:48:81:e5:68:1e:0c:a6:a3:3c:a7:2b:e3:95:cf:e3:
         63:15:0d:16:09:63:d9:66:31:3b:42:2e:7c:1a:e5:28:8e:5e:
         3d:9e:28:99:48:e9:47:86:11:e2:04:29:60:2b:96:95:99:ae:
         3f:ab:ff:3f:45:ab:7e:07:45:4e:4d:0b:18:40:3d:3b:02:9c:
         4e:a9:0f:a5:c2:3f:4a:30:77:ae:66:5c:b3:8d:b2:41:6b:e2:
         98:01:7d:e0:6b:52:70:4d:3d:b8:a9:48:f5:02:d2:d9:40:66:
         b6:5e:44:25:11:55:ac:31:02:d7:67:72:6a:6a:bc:74:34:5f:
         75:dc:9a:4f:83:28:40:e0:2a:dc:3f:41:43:5a:47:07:2b:b7:
         a7:3f:d0:15:a2:42:d7:30:22:f2:f6:e4:b4:f6:3b:38:ca:6b:
         4c:e7:3c:a4:70:cb:de:af:0a:14:ff:23:25:ca:04:cd:9e:49:
         c3:4b:e4:0a:b5:0b:84:b5:ef:b4:5b:63:07:47:63:cd:5c:50:
         0b:42:0a:a9
-----BEGIN CERTIFICATE-----
MIID8DCCAtigAwIBAgIFIBYBAAAwDQYJKoZIhvcNAQELBQAwYjELMAkGA1UEBhMC
WEQxDTALBgNVBAoMBGRuNDIxIzAhBgNVBAsMGmRuNDIgQ2VydGlmaWNhdGUgQXV0
aG9yaXR5MR8wHQYDVQQDDBZkbjQyIFJvb3QgQXV0aG9yaXR5IENBMCAXDTE2MDEx
NjAwMTIwNFoYDzIwMzAxMjMxMjM1OTU5WjBiMQswCQYDVQQGEwJYRDENMAsGA1UE
CgwEZG40MjEjMCEGA1UECwwaZG40MiBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkxHzAd
BgNVBAMMFmRuNDIgUm9vdCBBdXRob3JpdHkgQ0EwggEiMA0GCSqGSIb3DQEBAQUA
A4IBDwAwggEKAoIBAQDBGRDeAYYR8YIMsNTl/5rI46r0AAiCwM9/BXohl8G1i6PR
VO76BA931VyYS9mIGMEXEJLlJPrvYetdexHlvrqJ8mDJO4IFOnRUYCNmGtjNKHvx
6lUlmowEoP+dSFRMnbwtoN9xrmRHDed1BfTFAirSDL6jY1RiK60p62oIpF6o6/FS
FE7RXUEv0xm65II2etGj8oT2B7L2DDDb23bu6RQFx491tz/V1TVW0JJE3yYeAPqu
y3rJUGddafj5/SWnHdtAsUK8RVfhyRxCummAHuolmRKfbyOj0i5KzRXkfEn50cDw
GQwVUM6mUbuqFrKC7PRhRIwc3WVgBHewTZlnF/sJAgMBAAGjgaowgacwDgYDVR0P
AQH/BAQDAgEGMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFFR2iLLAtTDQ/E/J
bTv5jFURrBUVMB8GA1UdIwQYMBaAFFR2iLLAtTDQ/E/JbTv5jFURrBUVMEQGA1Ud
HgQ9MDugOTAHggUuZG40MjAKhwisFAAA//wAADAihyD9QgAAAAAAAAAAAAAAAAAA
//8AAAAAAAAAAAAAAAAAADANBgkqhkiG9w0BAQsFAAOCAQEAXKQ7QaCBaeJxmU11
S1ogDSrZ7Oq8jU+wbPMuQRqgdfPefjrgp7nbzfUW5GrL58wqj+5/FAqltflmSIHl
aB4MpqM8pyvjlc/jYxUNFglj2WYxO0IufBrlKI5ePZ4omUjpR4YR4gQpYCuWlZmu
P6v/P0WrfgdFTk0LGEA9OwKcTqkPpcI/SjB3rmZcs42yQWvimAF94GtScE09uKlI
9QLS2UBmtl5EJRFVrDEC12dyamq8dDRfddyaT4MoQOAq3D9BQ1pHByu3pz/QFaJC
1zAi8vbktPY7OMprTOc8pHDL3q8KFP8jJcoEzZ5Jw0vkCrULhLXvtFtjB0djzVxQ
C0IKqQ==
-----END CERTIFICATE-----</code></pre>

<h2><a class="anchor" id="testing-constraints" href="#testing-constraints"></a>Testing constraints</h2>

<p>The name constraints can be verified for example by using openssl:
</p><pre class="highlight"><code>openssl x509 <span class="nt">-in</span> dn42.crt <span class="nt">-text</span> <span class="nt">-noout</span></code></pre>
which will show among other things:
<pre class="highlight"><code>  X509v3 Name Constraints: 
    Permitted:
      DNS:.dn42</code></pre>

<h2><a class="anchor" id="importing-the-certificate" href="#importing-the-certificate"></a>Importing the certificate</h2>

<ul>
  <li>cacert have a comprehensive FAQ on how to import your own root certificates in <a href="http://wiki.cacert.org/FAQ/BrowserClients">browsers</a> and <a href="http://wiki.cacert.org/FAQ/ImportRootCert">other software</a>
</li>
</ul>

<h3><a class="anchor" id="archlinux" href="#archlinux"></a>Archlinux</h3>

<p>Install <code>ca-certificates-dn42</code> from <a href="https://aur.archlinux.org/packages/ca-certificates-dn42/">AUR</a></p>

<h3><a class="anchor" id="debian-ubuntu" href="#debian-ubuntu"></a>Debian/Ubuntu</h3>

<h4><a class="anchor" id="unofficial-debian-package" href="#unofficial-debian-package"></a>Unofficial Debian Package</h4>

<pre class="highlight"><code>wget https://ca.dn42.us/ca-dn42_20161122.0_all.deb
<span class="c"># If you're on a dn42-only network:</span>
<span class="c"># wget --no-check-certificate https://ca.dn42/ca-dn42_20161122.0_all.deb</span>
<span class="nb">sudo </span>dpkg <span class="nt">-i</span> ca-dn42_20161122.0_all.deb
<span class="nb">sudo </span>dpkg-reconfigure ca-certificates</code></pre>

<p>You will be asked which certificates you would like to enabled. By default, the dn42 root certifcate (dn42/root-ca.crt) is not enabled, be sure to enable it. This package is waiting for inclusion in Debian (Debian bug <a href="https://bugs.debian.org/cgi-bin/bugreport.cgi?bug=845351">#845351</a>).</p>

<h4><a class="anchor" id="manual-installation" href="#manual-installation"></a>Manual Installation</h4>

<pre class="highlight"><code><span class="nv">$ </span><span class="nb">mkdir</span> /usr/share/ca-certificates/extra
<span class="nv">$ </span><span class="nb">cat</span> <span class="o">&gt;</span> /usr/share/ca-certificates/extra/dn42.crt <span class="o">&lt;&lt;</span><span class="no">EOF</span><span class="sh">
-----BEGIN CERTIFICATE-----
MIID8DCCAtigAwIBAgIFIBYBAAAwDQYJKoZIhvcNAQELBQAwYjELMAkGA1UEBhMC
WEQxDTALBgNVBAoMBGRuNDIxIzAhBgNVBAsMGmRuNDIgQ2VydGlmaWNhdGUgQXV0
aG9yaXR5MR8wHQYDVQQDDBZkbjQyIFJvb3QgQXV0aG9yaXR5IENBMCAXDTE2MDEx
NjAwMTIwNFoYDzIwMzAxMjMxMjM1OTU5WjBiMQswCQYDVQQGEwJYRDENMAsGA1UE
CgwEZG40MjEjMCEGA1UECwwaZG40MiBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkxHzAd
BgNVBAMMFmRuNDIgUm9vdCBBdXRob3JpdHkgQ0EwggEiMA0GCSqGSIb3DQEBAQUA
A4IBDwAwggEKAoIBAQDBGRDeAYYR8YIMsNTl/5rI46r0AAiCwM9/BXohl8G1i6PR
VO76BA931VyYS9mIGMEXEJLlJPrvYetdexHlvrqJ8mDJO4IFOnRUYCNmGtjNKHvx
6lUlmowEoP+dSFRMnbwtoN9xrmRHDed1BfTFAirSDL6jY1RiK60p62oIpF6o6/FS
FE7RXUEv0xm65II2etGj8oT2B7L2DDDb23bu6RQFx491tz/V1TVW0JJE3yYeAPqu
y3rJUGddafj5/SWnHdtAsUK8RVfhyRxCummAHuolmRKfbyOj0i5KzRXkfEn50cDw
GQwVUM6mUbuqFrKC7PRhRIwc3WVgBHewTZlnF/sJAgMBAAGjgaowgacwDgYDVR0P
AQH/BAQDAgEGMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFFR2iLLAtTDQ/E/J
bTv5jFURrBUVMB8GA1UdIwQYMBaAFFR2iLLAtTDQ/E/JbTv5jFURrBUVMEQGA1Ud
HgQ9MDugOTAHggUuZG40MjAKhwisFAAA//wAADAihyD9QgAAAAAAAAAAAAAAAAAA
//8AAAAAAAAAAAAAAAAAADANBgkqhkiG9w0BAQsFAAOCAQEAXKQ7QaCBaeJxmU11
S1ogDSrZ7Oq8jU+wbPMuQRqgdfPefjrgp7nbzfUW5GrL58wqj+5/FAqltflmSIHl
aB4MpqM8pyvjlc/jYxUNFglj2WYxO0IufBrlKI5ePZ4omUjpR4YR4gQpYCuWlZmu
P6v/P0WrfgdFTk0LGEA9OwKcTqkPpcI/SjB3rmZcs42yQWvimAF94GtScE09uKlI
9QLS2UBmtl5EJRFVrDEC12dyamq8dDRfddyaT4MoQOAq3D9BQ1pHByu3pz/QFaJC
1zAi8vbktPY7OMprTOc8pHDL3q8KFP8jJcoEzZ5Jw0vkCrULhLXvtFtjB0djzVxQ
C0IKqQ==
-----END CERTIFICATE-----
</span><span class="no">EOF
</span><span class="nv">$ </span><span class="nb">echo</span> <span class="s2">"extra/dn42.crt"</span> <span class="o">&gt;&gt;</span> /etc/ca-certificates.conf
<span class="nv">$ </span>update-ca-certificates</code></pre>

<h2><a class="anchor" id="pki-store" href="#pki-store"></a>PKI Store</h2>

<p>All issued keys and crl information are posted at: <a href="https://ca.dn42/">https://ca.dn42/</a></p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>
</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="services/Certificate-Authority.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/services/Certificate-Authority.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
