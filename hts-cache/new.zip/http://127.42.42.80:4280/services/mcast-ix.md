<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'services/mcast-ix.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>mcast-ix</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>mcast-ix</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/services/mcast-ix.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/services/mcast-ix.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    mcast-ix
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/services/">services</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <p>we're planning to have a mcast-ix.dn42 somewhere in the cloud at #dn42 for years now…</p>

<p>now we have a pull req with cosmetical issues only: <a href="https://git.dn42.dev/dn42/registry/pulls/2575">https://git.dn42.dev/dn42/registry/pulls/2575</a></p>

<p>the main goal is to have a shared lan where ases can peer to each other with the following conditions:</p>
<ul>
  <li>pure ethernet</li>
  <li>low latency between the vms</li>
  <li>native support for jumbo frames</li>
  <li>possibility to private vlans between participants with the same conditions</li>
</ul>

<p>how to participate:</p>

<p>all you have to do is prepare a qcow2 or vmdk image and upload it to somewhere and ping nop-mnt (mc36 @ irc) with the url… i'll wget it once then boot up your vm connected to the switchport… you'll have raw dn42 reachability there and pat-ed clearnet to continue your installation or upgrades or to connect to the rest of your infra…</p>

<p>alternatively you can try remotely the ix by preparing the vm image and giving it a vnic pointing to a remote switch participating in the ix already.  "-netdev socket,id=a1,udp=vpn.nop.hu:998,localaddr=:1234 -device virtio-net-pci,netdev=a1,mac=as:df:as:df:as:df" 4 example nop-mnt's vpls instance running in a very different datacenter where the real ix located, plus your networking delays to that datacenter, is the sum packet loss, delay, etc… its just about to try out the ix before participating…</p>

<p>once finalized, only one thing to look for twice, the "console=ttyS0,115200n8" be present as a kernel parameter… plus that your only vnic at the real dc will be the above mentioned vpls instance, but now, with a much less delay/jitter/packetlosss…. if you need vnc access instead, just ask for it during the bringup phase….</p>

<p>if you need a private peering here between you and an other participant, just ask for a private ethernet connection…</p>

<p>consider enabling lldp on your interfaces because it helps speed up things on the switch moreover if you'll have more interfaces there then will help you too…</p>

<p>also consider enabling pim sparse mode on the ix and then you can have the rtp://172.23.199.110@232.2.3.2:1234/ stream</p>

<p>last but not least, always save your configs! there will be a daily recurring power cut sheduled to 21:00pm cest +-1minutes to have the infrastructure auto-upgraded…</p>

<p>the whole idea is to consider the following hypervisor configuration:</p>

<pre class="highlight"><code>dn42ix#show startup-config vdc
vdc definition vm-bri
 connect ethernet2825 vm-switch
 cpu host
 image /rtr/ix/bri.img
 memory 1024
 nic virtio-net-pci
 mac cafe.beef.b00b
 exit
vdc definition vm-clearnet
 local ethernet66602
 local ethernet66603
 connect ethernet66601 vm-switch
 exit
vdc definition vm-jlu5
 connect ethernet1080 vm-switch
 cpu host
 image /rtr/ix/jlu5.img
 cdrom /rtr/ix/jlu5.iso
 memory 1024
 exit
vdc definition vm-lare
 connect ethernet3035 vm-switch
 cpu host
 image /rtr/ix/lare.img
 memory 1024
 exit
vdc definition vm-nop
 connect ethernet1955 vm-switch
 exit
vdc definition vm-routeserver
 exit
vdc definition vm-switch
 connect ethernet1080 vm-jlu5
 connect ethernet1955 vm-nop
 connect ethernet2825 vm-bri
 connect ethernet3035 vm-lare
 connect ethernet66601 vm-clearnet
 exit

dn42ix#</code></pre>

<p>now you can have drop-in replacement vm-s to experiment with like whats it looks a like if the ix is provisioned on a juniper vsrx3 shitload or a cisco nxosv or plain freerouter in software mode or in p4dpdk mode….</p>

<p>then publishing a small report on r/networking on behalf of #dn42 measurements</p>

<p>and probably doing even more crazyer projects/experiment if we settle to have a proper dn42 ix finally with low latency shared vlan between the vms…</p>

<p>like a real ix…</p>

<p>static addressing plan, there is a randomized dhcp and slaac on the subnet but consider picking up a static ip and pere with that:</p>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">nick/mnter</th>
      <th style="text-align:left;">asn*</th>
      <th style="text-align:left;">your-ipv4-fixed-ip</th>
      <th style="text-align:left;">your-ipv6-fixed-ip</th>
      <th style="text-align:left;">your-ipv6-linklocal</th>
      <th style="text-align:left;">public lg</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">sw1-mcastix</td>
      <td style="text-align:left;">1951</td>
      <td style="text-align:left;">N/A</td>
      <td style="text-align:left;">N/A</td>
      <td style="text-align:left;">N/A</td>
      <td style="text-align:left;">TBD: SOON</td>
    </tr>
    <tr>
      <td style="text-align:left;">rs1-mcastix</td>
      <td style="text-align:left;">1951</td>
      <td style="text-align:left;">172.23.124.126/27</td>
      <td style="text-align:left;">fde0:93fa:7a0:c1ca::179/64</td>
      <td style="text-align:left;">fe80::200:bff:fead:beef</td>
      <td style="text-align:left;">TBD: SOON</td>
    </tr>
    <tr>
      <td style="text-align:left;">rtr1-badcorp</td>
      <td style="text-align:left;">1952</td>
      <td style="text-align:left;">172.23.124.97/27</td>
      <td style="text-align:left;">fde0:93fa:7a0:c1ca::666/64</td>
      <td style="text-align:left;">fe80::260:54ff:fe33:2178</td>
      <td style="text-align:left;">TBD: SOON</td>
    </tr>
    <tr>
      <td style="text-align:left;">rtr1-nop</td>
      <td style="text-align:left;">1955</td>
      <td style="text-align:left;">172.23.124.122/27</td>
      <td style="text-align:left;">fde0:93fa:7a0:c1ca::1955/64</td>
      <td style="text-align:left;">fe80::200:ccff:fe1e:c0de</td>
      <td style="text-align:left;">telnet sandbox.freertr.org</td>
    </tr>
    <tr>
      <td style="text-align:left;">rtr1-catgirls</td>
      <td style="text-align:left;">1411</td>
      <td style="text-align:left;">172.23.124.101/27</td>
      <td style="text-align:left;">fde0:93fa:7a0:c1ca:581a:fc3f:a2d0:828c/64</td>
      <td style="text-align:left;">fe80::1411:5</td>
      <td style="text-align:left;">TBD: SOON</td>
    </tr>
    <tr>
      <td style="text-align:left;">rtr1-catgirls2</td>
      <td style="text-align:left;">1411</td>
      <td style="text-align:left;">TBD</td>
      <td style="text-align:left;">TBD</td>
      <td style="text-align:left;">TBD</td>
      <td style="text-align:left;">TBD: SOON</td>
    </tr>
    <tr>
      <td style="text-align:left;">rtr1-lare</td>
      <td style="text-align:left;">3035</td>
      <td style="text-align:left;">172.23.124.114/27</td>
      <td style="text-align:left;">fde0:93fa:7a0:c1ca:0:42:4242:3035/64</td>
      <td style="text-align:left;">fe80::21f:45ff:fe11:7356</td>
      <td style="text-align:left;">clearnet: <a href="https://lg.lare.cc/">https://lg.lare.cc/</a> dn42: <a href="https://lg.lare.dn42/">https://lg.lare.dn42/</a>
</td>
    </tr>
    <tr>
      <td style="text-align:left;">rtr1-bri</td>
      <td style="text-align:left;">2825</td>
      <td style="text-align:left;">TBD</td>
      <td style="text-align:left;">TBD</td>
      <td style="text-align:left;">TBD</td>
      <td style="text-align:left;">TBD</td>
    </tr>
    <tr>
      <td style="text-align:left;">rtr1-jlu5</td>
      <td style="text-align:left;">1080</td>
      <td style="text-align:left;">TBD</td>
      <td style="text-align:left;">TBD</td>
      <td style="text-align:left;">TBD</td>
      <td style="text-align:left;">TBD</td>
    </tr>
    <tr>
      <td style="text-align:left;">rtr1-fl</td>
      <td style="text-align:left;">1975</td>
      <td style="text-align:left;">TBD</td>
      <td style="text-align:left;">TBD</td>
      <td style="text-align:left;">TBD</td>
      <td style="text-align:left;">TBD</td>
    </tr>
  </tbody>
</table>

<p>TBD: add yourself please here while keeping some ordering</p>

<p>*: so your as number xxxx shortened here, the rigthmost part after the 424242xxxx…. this also will be your ethernetXXXX and so on so just remember this by heart XD</p>

<table>
  <thead>
    <tr>
      <th style="text-align:left;">function</th>
      <th style="text-align:left;">console</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:left;">switch</td>
      <td style="text-align:left;">telnet ix.nop.dn42 20001</td>
    </tr>
    <tr>
      <td style="text-align:left;">route server 1</td>
      <td style="text-align:left;">telnet ix.nop.dn42 20002</td>
    </tr>
    <tr>
      <td style="text-align:left;">bad-corp-rtr1</td>
      <td style="text-align:left;">telnet ix.nop.dn42 20003</td>
    </tr>
  </tbody>
</table>

<p>public mrt dumps and config archive of the infra at <a href="http://ix.nop.dn42/">http://ix.nop.dn42/</a> here</p>

<p>it'll be shitload in the beginning but hopefully it could improve the common knowledge….</p>

<p>please consider joining #dn42-ix#2 to speed up sorting out potential issues, etc</p>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
      <li><a href="/Links" rel="nofollow">Links</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
      <li><a href="/howto/GeoFeed" rel="nofollow">GeoFeed</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/DNS" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">RPKI</a></li>
      <li><a href="/services/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
      <li><a href="/services/Registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
      <li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
    </ul>
  </li>
  <li>Historical
    <ul>
      <li><a href="/historical/Bird" rel="nofollow">Bird 1</a></li>
      <li><a href="/historical/Quagga" rel="nofollow">Quagga</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://hedgedoc.dn42.eu" rel="nofollow">HedgeDoc</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>, <a href="https://iedon.net/post/24" rel="nofollow">IEDON-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>, <a href="https://dn42.jp/" rel="nofollow">dn42.jp</a> (wiki-go)</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="services/mcast-ix.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/services/mcast-ix.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
