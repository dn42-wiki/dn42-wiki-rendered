<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'services/Looking-Glasses.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Looking-Glasses</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Looking-Glasses</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/services/Looking-Glasses.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/services/Looking-Glasses.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Looking-Glasses
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/services/">services</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="looking-glasses" href="#looking-glasses"></a>Looking Glasses</h1>

<p>This is the list of <strong>looking glasses</strong> available for the dn42 network. Some only display BGP information, while some others allow interactive queries (traceroute, details of a route, BGP-map visualisation, etc).</p>

<p>When a looking glass is described as <code>IPv4</code> or <code>IPv6</code>, it refers to the information displayed (or queried) by the looking glass, not to the reachability of the looking glass service itself.</p>

<p>Please sort by AS number.</p>

<table>
  <thead>
    <tr>
      <th style="text-align:center;">AS</th>
      <th style="text-align:left;">URL</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:center;">1955</td>
      <td style="text-align:left;">ext: <br />$ telnet lg.hbone.hu <br /> &gt; show ipv6 bgp 65535 vpnuni rd 65535:42 <br /> &gt; show ipv6 bgp 65535 vpnuni rd 65535:42 <br /> ext2: <a href="http://embed.ftelnet.ca/?Hostname=hbonelg.freertr.org&amp;Port=80&amp;AutoConnect=true&amp;ConnectionType=telnet&amp;Emulation=ansi-bbs&amp;VirtualKeyboard=auto">http://embed.ftelnet.ca/?Hostname=hbonelg.freertr.org&amp;Port=80&amp;AutoConnect=true&amp;ConnectionType=telnet&amp;Emulation=ansi-bbs&amp;VirtualKeyboard=auto</a> <br />this node have full v4/v6 unicast/multicast and some more fun tables from <a href="https://www.hbone.hu">https://www.hbone.hu</a> like inner ospfv2/v3, ldp and mpls-segment-routing states/trees, or the <a href="https://map.geant.org/">https://map.geant.org/</a> mdvpn routes and the looback0/32+label connectivity for them see the login banner for more things to look here</td>
    </tr>
    <tr>
      <td style="text-align:center;">64719</td>
      <td style="text-align:left;">ext: <a href="https://lg.dn42.lutoma.org">https://lg.dn42.lutoma.org</a> <br /> dn42: <a href="https://lg.lutoma.dn42">https://lg.lutoma.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">64737</td>
      <td style="text-align:left;">ext: <a href="https://lg.dn42.us">https://lg.dn42.us</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420020</td>
      <td style="text-align:left;">dn42: <a href="http://lg.not.dn42/">http://lg.not.dn42/</a> DN42 only dual-stack</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420150</td>
      <td style="text-align:left;">dn42 (multiple): <a href="https://darkpoint.dn42">https://darkpoint.dn42</a> <br /> ext (multiple): <a href="https://dn42.darkpoint.xyz">https://dn42.darkpoint.xyz</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420214</td>
      <td style="text-align:left;">dn42: <a href="https://lg.mashiro.dn42">https://lg.mashiro.dn42</a> <br /> ext: <a href="https://lg.origincode.me">https://lg.origincode.me</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420454</td>
      <td style="text-align:left;">dn42: <a href="http://edu.dn42/">http://edu.dn42/</a> <br /> ext: <a href="https://dn42.nedifinita.com/">https://dn42.nedifinita.com/</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420831</td>
      <td style="text-align:left;">ext: <a href="https://lg.dn42.tms.im">https://lg.dn42.tms.im</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420893</td>
      <td style="text-align:left;">dn42: <a href="http://lg.maiyun.dn42">http://lg.maiyun.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421023</td>
      <td style="text-align:left;">ext: <a href="https://network.owo.li/">https://network.owo.li/</a>  <br /> dn42: <a href="https://network.iris.dn42/">https://network.iris.dn42/</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421080</td>
      <td style="text-align:left;">ext: <a href="https://lg.highdef.network">https://lg.highdef.network</a> <br /> dn42: <a href="http://lg.highdef.dn42">http://lg.highdef.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421084</td>
      <td style="text-align:left;">ext: <a href="https://dn42-lg.darmstadt.freifunk.net">https://dn42-lg.darmstadt.freifunk.net</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421105</td>
      <td style="text-align:left;">dn42: <a href="http://lg.finarfin.dn42:8179/">http://lg.finarfin.dn42:8179/</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421123</td>
      <td style="text-align:left;">ext: <a href="https://dn42.ccp.ovh">https://dn42.ccp.ovh</a> <br /> dn42: <a href="http://n.dn42">http://n.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421197</td>
      <td style="text-align:left;">dn42: <a href="http://lg.scoopta.dn42">http://lg.scoopta.dn42</a> <br /> dn42: ssh rtr@rtr.scoopta.dn42 <br /> restricted frr shell</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421411</td>
      <td style="text-align:left;">ext: <a href="https://lg.famfo.xyz">https://lg.famfo.xyz</a> <br /> dn42: <a href="https://lg.catgirls.dn42">https://lg.catgirls.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421525</td>
      <td style="text-align:left;">ext: <a href="https://lg.alemal.se">https://lg.alemal.se</a> <br /> dn42: <a href="https://lg.alemal.dn42">https://lg.alemal.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421722</td>
      <td style="text-align:left;">ext: <a href="https://lg42.tchekda.fr">https://lg42.tchekda.fr</a> <br /> dn42: <a href="http://lg42.tchekda.dn42">http://lg42.tchekda.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421755</td>
      <td style="text-align:left;">ext: <a href="https://lg.sidingsmedia.com">https://lg.sidingsmedia.com</a> <br /> Interactive ping, traceroute, BGP routes, communities, AS path, RPKI state. IPv4 &amp; IPv6 support.</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421955</td>
      <td style="text-align:left;">dn42: <a href="http://lg.nop.dn42">http://lg.nop.dn42</a> <br /> dn42: telnet test.nop.dn42 <br /> ext: <a href="http://embed.ftelnet.ca/?Hostname=websock.freertr.org&amp;Port=80&amp;AutoConnect=true&amp;ConnectionType=telnet&amp;Emulation=ansi-bbs&amp;VirtualKeyboard=auto">http://embed.ftelnet.ca/?Hostname=websock.freertr.org&amp;Port=80&amp;AutoConnect=true&amp;ConnectionType=telnet&amp;Emulation=ansi-bbs&amp;VirtualKeyboard=auto</a> <br /> ext: <a href="http://sandbox.freertr.org">http://sandbox.freertr.org</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422016</td>
      <td style="text-align:left;">ext: <a href="https://lg.dn42.sidereal.ca">https://lg.dn42.sidereal.ca</a> <br /> dn42: <a href="https://lg.sidereal.dn42">https://lg.sidereal.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422092</td>
      <td style="text-align:left;">ext: <a href="https://lg.dn42.pebkac.gr">https://lg.dn42.pebkac.gr</a> <br /> dn42: <a href="http://lg.pebkac.dn42">http://lg.pebkac.dn42</a> <br /> IPv4 and IPv6</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422189</td>
      <td style="text-align:left;">ext: <a href="https://lg.iedon.net">https://lg.iedon.net</a> <br /> dn42: <a href="https://lg.iedon.dn42">https://lg.iedon.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422308</td>
      <td style="text-align:left;">ext: <a href="https://lg.dn42.mirsal.fr">https://lg.dn42.mirsal.fr</a> <br /> dn42: <a href="https://lg.mirsal.dn42">https://lg.mirsal.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422357</td>
      <td style="text-align:left;">ext: <a href="https://lg-dn42.defelo.de">https://lg-dn42.defelo.de</a> <br /> dn42: <a href="https://lg.defelo.dn42">https://lg.defelo.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422439</td>
      <td style="text-align:left;">ext: <a href="https://lg.dn42.saru.moe">https://lg.dn42.saru.moe</a> <br /> dn42: <a href="https://lg.saru.dn42">https://lg.saru.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422558</td>
      <td style="text-align:left;">ext: <a href="https://lg.dn42.derix.dev">https://lg.dn42.derix.dev</a> <br /> dn42: <a href="https://lg.derix.dn42">https://lg.derix.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422575</td>
      <td style="text-align:left;">dn42: <a href="https://lg.androw.dn42">https://lg.androw.dn42</a> <br /> ext: <a href="https://lg.androw.eu">https://lg.androw.eu</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422601</td>
      <td style="text-align:left;">dn42: <a href="http://lg.burble.dn42">http://lg.burble.dn42</a> <br /> ext: <a href="https://lg.burble.com">https://lg.burble.com</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422712</td>
      <td style="text-align:left;">dn42: <a href="https://lg.nuku.dn42">https://lg.nuku.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422717</td>
      <td style="text-align:left;">ext: <a href="https://lg.whojk.com">https://lg.whojk.com</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242423035</td>
      <td style="text-align:left;">ext: <a href="https://lg.lare.cc">https://lg.lare.cc</a> <br /> dn42: <a href="https://lg.lare.dn42">https://lg.lare.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242423088</td>
      <td style="text-align:left;">ext: <a href="https://lg.dn42.6700.cc">https://lg.dn42.6700.cc</a> <br /> dn42: <a href="http://lg.sun.dn42">http://lg.sun.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242423090</td>
      <td style="text-align:left;">dn42: <a href="http://lg.filmroellchen.dn42">http://lg.filmroellchen.dn42</a> <br /> IPv6-only</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242423152</td>
      <td style="text-align:left;">ext: <a href="https://lg.tatk.network">https://lg.tatk.network</a> <br /> dn42: <a href="http://lg.tatk.dn42">http://lg.tatk.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242423374</td>
      <td style="text-align:left;">ext: <a href="https://lg-dn42.baka.pub">https://lg-dn42.baka.pub</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242423377</td>
      <td style="text-align:left;">ext: <a href="https://lg-dn42.leziblog.com">https://lg-dn42.leziblog.com</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242423702</td>
      <td style="text-align:left;">ext: <a href="https://dn42-lg.launchpadx.top">https://dn42-lg.launchpadx.top</a> <br /> dn42: <a href="https://lg.lpnet0.dn42">https://lg.lpnet0.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242423797</td>
      <td style="text-align:left;">ext: <a href="https://dn42-lg.badaimweeb.me">https://dn42-lg.badaimweeb.me</a> <br /> dn42: <a href="https://lg.badaimweeb.dn42">https://lg.badaimweeb.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421331</td>
      <td style="text-align:left;">dn42: <a href="https://lg.nia.dn42">https://lg.nia.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242423310</td>
      <td style="text-align:left;">ext: <a href="https://lg.tmpfs.dev/">https://lg.tmpfs.dev/</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242423322</td>
      <td style="text-align:left;">ext: <a href="https://lg-dn42.vconet.top/">https://lg-dn42.vconet.top/</a>
</td>
    </tr>
  </tbody>
</table>

<h2><a class="anchor" id="down" href="#down"></a>Down</h2>

<p>These looking glasses were added to the table at some point, but now seem to be down (404, DNS broken, …)</p>

<table>
  <thead>
    <tr>
      <th style="text-align:center;">AS</th>
      <th style="text-align:left;">URL</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align:center;">64720</td>
      <td style="text-align:left;">ext: <a href="http://lg.prauscher.de">http://lg.prauscher.de</a> <br /> dn42: <a href="http://lg.prauscher.dn42">http://lg.prauscher.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">64766</td>
      <td style="text-align:left;">ext: <a href="http://ix.ucis.nl/routes.php">http://ix.ucis.nl/routes.php</a> <br /> dn42: <a href="http://ix.ucis.dn42/routes.php">http://ix.ucis.dn42/routes.php</a> <br /> IPv4 only.</td>
    </tr>
    <tr>
      <td style="text-align:center;">64835</td>
      <td style="text-align:left;">ext: <a href="http://lg.nordkapp-5.dn42">http://lg.nordkapp-5.dn42</a> <br /> dn42: <a href="http://172.22.235.4">http://172.22.235.4</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">65529</td>
      <td style="text-align:left;">ext: <a href="http://bgp.freifunk-bielefeld.de/ulg/ulg.py">http://bgp.freifunk-bielefeld.de/ulg/ulg.py</a> <br /> Interactive, BGP-map</td>
    </tr>
    <tr>
      <td style="text-align:center;">76103</td>
      <td style="text-align:left;">ext: <a href="http://lg.nixnodes.net">http://lg.nixnodes.net</a> <br /> dn42: <a href="http://lg.nixnodes.dn42">http://lg.nixnodes.dn42</a> <br /> IPv4 only.</td>
    </tr>
    <tr>
      <td style="text-align:center;">76142</td>
      <td style="text-align:left;">dn42: <a href="http://lg.ffdn.dn42">http://lg.ffdn.dn42</a> <br /> Interactive, BGP-map</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420013</td>
      <td style="text-align:left;">ext: <a href="http://dn42.netrik.de/de-fra1">http://dn42.netrik.de/de-fra1</a> <br /> dn42: <a href="http://172.22.232.5/de-fra1">http://172.22.232.5/de-fra1</a> <br /> Interactive, BGP-map</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420022</td>
      <td style="text-align:left;">dn42: <a href="http://mhm.dn42:5001">http://mhm.dn42:5001</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420101</td>
      <td style="text-align:left;">ext: <a href="http://core1.darmstadt.ccc.de">http://core1.darmstadt.ccc.de</a> <br /> ext: <a href="http://edge1.core.chaos-darmstadt.de">http://edge1.core.chaos-darmstadt.de</a> <br /> dn42: <a href="http://lg.cda.dn42">http://lg.cda.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420123</td>
      <td style="text-align:left;">dn42: <a href="https://lg.grmml.dn42">https://lg.grmml.dn42</a> <br /> Interactive (traceroute, BGP-map)</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420151</td>
      <td style="text-align:left;">ext: ssh bird-lg@dn42-uk-london0.dn42.bauen1.xyz <br /> restricted bird shell</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420181</td>
      <td style="text-align:left;">ext: <a href="https://lg.dn42.miegl.cz">https://lg.dn42.miegl.cz</a> <br /> dn42: <a href="http://lg.mgl.dn42">http://lg.mgl.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420184</td>
      <td style="text-align:left;">ext: <a href="http://peerfinder.polyno.me">http://peerfinder.polyno.me</a> <br /> dn42: <a href="http://peerfinder.polynome.dn42">http://peerfinder.polynome.dn42</a> <br /> Can be used as a distributed looking glass if you give it a dn42 address.</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420184</td>
      <td style="text-align:left;">dn42: <a href="http://dataviz.polynome.dn42/dn42/lastseen">http://dataviz.polynome.dn42/dn42/lastseen</a> <br /> Non-interactive "BGP last seen" service: keeps an history of previously announced BGP prefixes.</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420197</td>
      <td style="text-align:left;">ext: <a href="https://lg.n0emis.eu">https://lg.n0emis.eu</a> <br /> dn42: <a href="https://lg.n0emis.dn42">https://lg.n0emis.dn42</a> (soon)</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420200</td>
      <td style="text-align:left;">dn42: <a href="http://lg.punkt.dn42">http://lg.punkt.dn42</a> <br /> Interactive (traceroute, BGP-map)</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420300</td>
      <td style="text-align:left;">ext: <a href="http://lg-fr-rbx.wolke7.me">http://lg-fr-rbx.wolke7.me</a> <br /> dn42: <a href="http://lg-fr-rbx.wolke7.dn42">http://lg-fr-rbx.wolke7.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420304</td>
      <td style="text-align:left;">ext: <a href="https://lg.04d.co">https://lg.04d.co</a> <br /> dn42: <a href="https://lg.04dco.dn42">https://lg.04dco.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420321</td>
      <td style="text-align:left;">dn42: <a href="http://lg.dn42">http://lg.dn42</a> <br /> Interactive (traceroute, BGP-map)</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420341</td>
      <td style="text-align:left;">dn42: <a href="https://lg.hachiman.dn42">https://lg.hachiman.dn42</a> <br /> Interactive (traceroute, BGP-map)</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420458</td>
      <td style="text-align:left;">ext: <a href="https://lg.huajinet.org">https://lg.huajinet.org</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420812</td>
      <td style="text-align:left;">dn42: <a href="https://lg.jan.dn42">https://lg.jan.dn42</a> <br /> Interactive (traceroute, BGP-map)</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420827</td>
      <td style="text-align:left;">ext: <a href="https://lg.llyn.lorkep.trade">https://lg.llyn.lorkep.trade</a> <br /> dn42: <a href="https://lg.lorkep.dn42">https://lg.lorkep.dn42</a> <br /> Interactive (traceroute, BGP-map) <br /> IPv6 only</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420927</td>
      <td style="text-align:left;">ext: <a href="https://lg.dn42.liki.link">https://lg.dn42.liki.link</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242420977</td>
      <td style="text-align:left;">ext: <a href="https://lg.moerail.ml">https://lg.moerail.ml</a> <br /> dn42: <a href="http://lg.moerail.dn42">http://lg.moerail.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421022</td>
      <td style="text-align:left;">ext: <a href="https://lg.bsdrocker.com">https://lg.bsdrocker.com</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421050</td>
      <td style="text-align:left;">ext: <a href="https://lg.dn42.napshome.net">https://lg.dn42.napshome.net</a> <br /> dn42: <a href="http://lg.napshome.dn42">http://lg.napshome.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421055</td>
      <td style="text-align:left;">dn42: <a href="http://lg.tmwawpl.dn42">http://lg.tmwawpl.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421092</td>
      <td style="text-align:left;">dn42: <a href="http://lg.erg.dn42">http://lg.erg.dn42</a> <br /> Interactive (traceroute, BGP-map)</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421099</td>
      <td style="text-align:left;">ext: <a href="https://lg.owensresearch.org">https://lg.owensresearch.org</a> <br /> dn42: <a href="https://lg.owensresearch.dn42">https://lg.owensresearch.dn42</a> <br /> BGP Route, BGP Community, BGP AS Path, Ping, and Traceroute</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421146</td>
      <td style="text-align:left;">ext: <a href="https://lg.amcforum.wiki">https://lg.amcforum.wiki</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421166</td>
      <td style="text-align:left;">dn42: <a href="http://lg.alcatrash.dn42">http://lg.alcatrash.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421224</td>
      <td style="text-align:left;">dn42: <a href="http://lg.bit.dn42">http://lg.bit.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421231</td>
      <td style="text-align:left;">dn42: <a href="http://lg.caesia.dn42">http://lg.caesia.dn42</a> <br /> ext: <a href="https://lg.caesia.net">https://lg.caesia.net</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421331<br />4242421332<br />207268</td>
      <td style="text-align:left;">ext: <a href="https://lg.strexp.net">https://lg.strexp.net</a> <br /> dn42: <a href="http://lg.nia.dn42">http://lg.nia.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421588</td>
      <td style="text-align:left;">dn42: <a href="http://lg.tech9computers.dn42">http://lg.tech9computers.dn42</a> <br /> Interactive (traceroute, BGP-map)</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421780</td>
      <td style="text-align:left;">ext: <a href="https://lg.sfsarfe.com">https://lg.sfsarfe.com</a> <br /> dn42: <a href="http://lg.sfsarfe.dn42">http://lg.sfsarfe.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421816</td>
      <td style="text-align:left;">ext: <a href="https://lg.dn42.potat0.cc">https://lg.dn42.potat0.cc</a> <br /> dn42: <a href="http://lg.potat0.dn42">http://lg.potat0.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421869</td>
      <td style="text-align:left;">ext: <a href="https://lg.usman.network">https://lg.usman.network</a> <br /> dn42: <a href="http://lg.usman.dn42">http://lg.usman.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421876</td>
      <td style="text-align:left;">dn42: <a href="https://lg.potato.dn42">https://lg.potato.dn42</a> <br /> ext: <a href="https://lg.dn42.ac.cn">https://lg.dn42.ac.cn</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242421926</td>
      <td style="text-align:left;">dn42: <a href="https://lg.zhaofeng.dn42">https://lg.zhaofeng.dn42</a> <br /> ext: <a href="https://lg.naive.network">https://lg.naive.network</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422024</td>
      <td style="text-align:left;">ext: <a href="http://lg.dn42.gcc.ac.cn">http://lg.dn42.gcc.ac.cn</a> <br /> Interactive (ping, traceroute, BGP-map)</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422164</td>
      <td style="text-align:left;">ext: <a href="https://lg.xiaoxi654.xyz">https://lg.xiaoxi654.xyz</a> <br /> dn42: <a href="https://lg.xiaoxi654.dn42">https://lg.xiaoxi654.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422206</td>
      <td style="text-align:left;">ext: <a href="https://lg.dn42.est-it.de">https://lg.dn42.est-it.de</a> <br /> dn42: <a href="https://lg.techanit.dn42">https://lg.techanit.dn42</a> <br /> IPv4 and IPv6</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422237</td>
      <td style="text-align:left;">ext: <a href="https://lg.dn42.munsternet.eu">https://lg.dn42.munsternet.eu</a> <br /> dn42: <a href="http://lg.munsternet.dn42">http://lg.munsternet.dn42</a> <br /> IPv6 only</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422341</td>
      <td style="text-align:left;">ext: <a href="https://lg.dn42.zotan.network">https://lg.dn42.zotan.network</a> <br /> dn42: <a href="https://lg.zotan.dn42">https://lg.zotan.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422342</td>
      <td style="text-align:left;">dn42: <a href="http://lg.gbe.dn42">http://lg.gbe.dn42</a> <br /> Semi-interactive (no traceroute, no ping)</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422428</td>
      <td style="text-align:left;">ext: <a href="https://lg.0l.de">https://lg.0l.de</a> <br /> IPv4 and IPv6</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422475</td>
      <td style="text-align:left;">ext: <a href="https://heimdall.prevarinite.net">https://heimdall.prevarinite.net</a> <br /> dn42: <a href="https://heimdall.pvn.dn42">https://heimdall.pvn.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422506</td>
      <td style="text-align:left;">dn42: <a href="http://www.as4242422506.dn42">http://www.as4242422506.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422547</td>
      <td style="text-align:left;">ext: <a href="https://lg.lantian.pub">https://lg.lantian.pub</a> <br /> dn42: <a href="http://lg.lantian.dn42">http://lg.lantian.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422596</td>
      <td style="text-align:left;">ext: <a href="https://lg.chaox.ro">https://lg.chaox.ro</a> <br /> dn42: <a href="http://lg.chaox.dn42">http://lg.chaox.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422633</td>
      <td style="text-align:left;">dn42: <a href="http://lg.eb.dn42">http://lg.eb.dn42</a> <br /> ext: <a href="https://lg.eastbnd.com">https://lg.eastbnd.com</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422700</td>
      <td style="text-align:left;">dn42: <a href="http://lg.gotroot.dn42">http://lg.gotroot.dn42</a> <br /> ext: <a href="http://dn42.gotroot.ca">http://dn42.gotroot.ca</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242422904</td>
      <td style="text-align:left;">ext: <a href="https://lg.doxz.net">https://lg.doxz.net</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242423078</td>
      <td style="text-align:left;">ext: <a href="https://lg.hexanet.dev">https://lg.hexanet.dev</a> <br /> dn42: <a href="http://lg.hex.dn42">http://lg.hex.dn42</a> <br /> Interactive (traceroute, BGP-map) <br /> IPv6 only</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242423315</td>
      <td style="text-align:left;">ext: <a href="http://lg.unknownts.tk">http://lg.unknownts.tk</a> <br /> dn42: <a href="http://unknownts.dn42">http://unknownts.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242423411</td>
      <td style="text-align:left;">ext: <a href="https://lg.dn42.goldlineit.org">https://lg.dn42.goldlineit.org</a> <br /> dn42: <a href="http://lg.goldlineit.dn42">http://lg.goldlineit.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242423735</td>
      <td style="text-align:left;">ext: <a href="https://lg.dn42.cperrin.xyz">https://lg.dn42.cperrin.xyz</a> <br /> dn42: <a href="http://lg.cperrin.dn42">http://lg.cperrin.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242423827</td>
      <td style="text-align:left;">ext: <a href="https://sky.nullroute.eu.org/dn42/lg">https://sky.nullroute.eu.org/dn42/lg</a> <br /> dn42: <a href="http://lg.nullroute.dn42">http://lg.nullroute.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242423868</td>
      <td style="text-align:left;">ext: <a href="http://lg-dn42.chimon.org">http://lg-dn42.chimon.org</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242423905</td>
      <td style="text-align:left;">ext: <a href="https://dn42-svc.weiti.org/ulg">https://dn42-svc.weiti.org/ulg</a> <br /> dn42: <a href="https://lg.weiti.dn42">https://lg.weiti.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242423905</td>
      <td style="text-align:left;">ext: <a href="http://zeus.nowhere.ws/dn42/routes.cgi">http://zeus.nowhere.ws/dn42/routes.cgi</a> <br /> dn42: <a href="http://zeus.nihilus.dn42/dn42/routes.cgi">http://zeus.nihilus.dn42/dn42/routes.cgi</a> <br /> Non-interactive (route listing only).</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242423955</td>
      <td style="text-align:left;">dn42: <a href="http://lg.flo.dn42">http://lg.flo.dn42</a>
</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242423973</td>
      <td style="text-align:left;">dn42: <a href="http://lg.technopoint.dn42">http://lg.technopoint.dn42</a> <br /> (traceroute, BGP-map) IPv4 only.</td>
    </tr>
    <tr>
      <td style="text-align:center;">4242423993</td>
      <td style="text-align:left;">ext: <a href="https://lg.2f30.org">https://lg.2f30.org</a> <br /> IPv4 only.</td>
    </tr>
  </tbody>
</table>


	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/Policies" rel="nofollow">Policies</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
      <li><a href="/Links" rel="nofollow">Links</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
      <li><a href="/howto/GeoFeed" rel="nofollow">GeoFeed</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/dns/Overview" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">ROA + RPKI</a></li>
      <li><a href="/services/exchanges/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Pingables" rel="nofollow">Pingables</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/ca/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>, <a href="https://iedon.net/post/24" rel="nofollow">IEDON-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>, <a href="https://dn42.jp/" rel="nofollow">dn42.jp</a> (wiki-go)</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="services/Looking-Glasses.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/services/Looking-Glasses.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
