<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-309be032396e783b13a47df58f389b7c8e11c2b2d42640560b874f677c25f6e5.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">

  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'services/Distributed-Wiki.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-f05401ee374f0c7f48fc2bc08e30b4f4db705861fd5895ed70998683b383bfb5.js" type="text/javascript"></script>
  

  <title>Distributed-Wiki</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Distributed-Wiki</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/services/Distributed-Wiki.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <a class="btn btn-sm" id="minibutton-home" href="/">
      Home
    </a>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/overview"
          id="minibutton-overview"
        >
          Overview
        </a>

        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/latest_changes"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </a>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          href="/gollum/history/services/Distributed-Wiki.md/"
          id="minibutton-history"
        >
          History
        </a>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Distributed-Wiki
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/services/">services</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="this-page-is-outdated-and-need-update" href="#this-page-is-outdated-and-need-update"></a>this page is outdated and need update</h1>

<p>The idea is to deploy mirrors across dn42 using <a href="https://en.wikipedia.org/wiki/Anycast">anycast</a> addressing (BGP), thus providing redundancy, load-balancing and improved access times to the wiki. Sites are powered by <a href="https://github.com/gollum/gollum">gollum</a> which has no native SSL support, so Nginx acts as a reverse proxy and handles the encryption.
The local webserver is monitored with a simple <a href="/services/Distributed-Wiki#exabgp_watchdog-script">shell script</a> working <a href="Distributed-Wiki#exabgp">in conjunction</a> with <a href="https://github.com/Exa-Networks/exabgp">ExaBGP</a>, announcing/withdrawing the assigned route if the service is up/down.</p>

<h2><a class="anchor" id="prerequisites" href="#prerequisites"></a>Prerequisites</h2>

<ul>
<li>Stable 24/7 connection to dn42.</li>
<li>Stable host machine, present in dn42.</li>
<li>
<p>Solid networking/sysadmin skills (to keep the system as a whole stable).</p>

<p>In contrast with the general spirit in dn42, this service should NOT be deployed by unskilled members for the purpose of learning and exploring - since it is the primary source of information related to the project, it should not be used as a playground. </p>
</li>
<li>
<p>Software:</p>

<ul>
<li><a href="https://en.wikipedia.org/wiki/Git_(software)">Git</a></li>
<li><a href="https://github.com/gollum/gollum">gollum</a></li>
<li><a href="https://en.wikipedia.org/wiki/Nginx">Nginx</a></li>
<li><a href="https://github.com/Exa-Networks/exabgp">ExaBGP</a></li>
</ul>

<p>It's recommended to use a debian distro on the host machine, where most of the above software can be installed using package manager(s) with ease. On some distros (RHEL based for example) it might not be an easy task.</p>
</li>
</ul>

<h2><a class="anchor" id="network" href="#network"></a>Network</h2>

<ul>
<li>Install wiki anycast IP addresses <code>172.23.0.80/32</code> and <code>fd42:d42:d42:80::1/64</code> on the system</li>
<li>Assign a unicast IP address to be used by Nginx</li>
<li>Establish connectivity to the dn42 network</li>
</ul>

<h2><a class="anchor" id="data-replication" href="#data-replication"></a>Data replication</h2>

<p>Site files are stored in a local <a href="https://en.wikipedia.org/wiki/Distributed_revision_control">DVCS</a> repository (Git) on each node and replicated through a central server hosted by <a href="https://io.nixnodes.net?t=person&amp;l=XUU-DN42">XUU-DN42</a>. 
Since gollum is built on top of Git, it is not overly complicated to keep the local site in sync with others, each site only triggers periodic pulls/pushes from/to the Git server. </p>

<h3><a class="anchor" id="setup-the-repo" href="#setup-the-repo"></a>Setup the repo</h3>

<ul>
<li>
<p>Clone the dn42 wiki repo:</p>

<p><code>git clone git@git.dn42.dev:wiki/wiki.git &lt;path&gt;</code></p>
</li>
<li><p>Contact <a href="https://io.nixnodes.net?t=person&amp;l=XUU-DN42">XUU-DN42</a> and ask for write access to the repo</p></li>
<li>
<p>Setup cron for periodic pull/push jobs for the repo (simple example):</p>

<ul>
<li>
<strong>wiki-sync.sh</strong>:</li>
</ul>

<pre class="highlight"><code><span class="c">#!/bin/bash</span>

<span class="nv">WIKI_PATH</span><span class="o">=</span>&lt;repo path&gt;
<span class="nv">GIT</span><span class="o">=</span>/usr/bin/git

<span class="nb">cd</span> <span class="s2">"</span><span class="k">${</span><span class="nv">WIKI_PATH</span><span class="k">}</span><span class="s2">"</span>
<span class="k">${</span><span class="nv">GIT</span><span class="k">}</span> push
<span class="k">${</span><span class="nv">GIT</span><span class="k">}</span> pull

<span class="nb">exit </span>0</code></pre>

<ul>
<li>
<strong>Cron entry</strong>:</li>
</ul>

<p><code>*/10 * * * * &lt;path&gt;/wiki-sync.sh &amp;&gt; /dev/null</code></p>

<p>Running in 10 minute intervals is reasonable, if you choose to change this, please keep it in the range from 5 to 15 minutes.</p>
</li>
</ul>

<h2><a class="anchor" id="gollum" href="#gollum"></a>gollum</h2>

<ul>
<li>Install <a href="https://github.com/gollum/gollum">gollum</a>
</li>
<li>
<p>Start two gollum instances, read-only and read/write on <code>127.0.0.1</code>:</p>

<p>Read/write (SSL only):</p>

<pre><code>RACK_ENV=production gollum --css --host 127.0.0.1  --port 4568 &lt;path&gt;
</code></pre>

<p>Read-only:</p>

<pre><code>RACK_ENV=production gollum --css --host 127.0.0.1  --port 4567 --no-edit &lt;path&gt;
</code></pre>

<p>Set <code>&lt;path&gt;</code> to the location where wiki Git repo was cloned. </p>
</li>
</ul>

<h2><a class="anchor" id="nginx-reverse-proxy" href="#nginx-reverse-proxy"></a>Nginx reverse proxy</h2>

<h3><a class="anchor" id="ssl" href="#ssl"></a>SSL</h3>

<ul>
<li>Setup your maintainer object according to <a href="/services/Automatic-CA">Automatic CA</a>
</li>
<li>Generate a <a href="/services/Certificate-Authority">CSR</a> and send DNS Key Pin to <a href="mailto:xuu@sour.is">xuu@sour.is</a>: </li>
<li>&lt;AS&gt; is the as number with the prefix <code>as</code> like <code>as64737-ca.wiki.dn42</code>
</li>
</ul>

<pre class="highlight"><code>./ca.dn42 tls-gen <span class="se">\</span>
   &lt;AS&gt;-&lt;CC&gt;<span class="o">(</span>-&lt;UID&gt;<span class="o">)</span>.wiki.dn42 <span class="se">\</span>
   EXAMPLE-MNT <span class="se">\</span>
   mail@example.com <span class="se">\</span>
   DNS:&lt;AS&gt;-&lt;CC&gt;<span class="o">(</span>-&lt;ID&gt;<span class="o">)</span>.wiki.dn42,DNS:wiki.dn42,DNS:www.wiki.dn42,DNS:internal.dn42,DNS:www.internal.dn42</code></pre>

<p>Wait for a reply and then sign the certificate:</p>

<p><code>./ca.dn42 tls-sign wiki.dn42 MIC92-MNT</code></p>

<h4><a class="anchor" id="header" href="#header"></a>Header</h4>

<h5><a class="anchor" id="site-identification" href="#site-identification"></a>Site identification</h5>

<p>A custom header <code>X-SiteID</code> identifies the site you're connecting to:</p>

<ul>
<li>
<code>add_header X-SiteID   '&lt;AS&gt;-&lt;ISO country code&gt;';</code>

<ul>
<li>&lt;AS&gt; is the as number prefixed with <code>as</code> like <code>as64737</code>
</li>
</ul>
</li>
</ul>

<h5><a class="anchor" id="enabling-hpkp" href="#enabling-hpkp"></a>Enabling <a href="https://en.wikipedia.org/wiki/HTTP_Public_Key_Pinning">HPKP</a>
</h5>

<ul>
<li>
<p>Extract base64 encoded SPKI fingerprint from private key <code>wiki.key</code>:</p>

<pre lang="sh" xml:lang="sh" xml:lang="sh"><code>openssl rsa -in wiki.key -outform der -pubout | openssl dgst -sha256 -binary | openssl enc -base64
</code></pre>
</li>
<li>
<p>Configure Nginx to send the fingerprint in header (SSL block):</p>

<pre lang="conf" xml:lang="conf" xml:lang="conf"><code>add_header Public-Key-Pins  pin-sha256="&lt;primary&gt;"; pin-sha256="&lt;backup&gt;"; max-age=5184000; includeSubDomains';
</code></pre>

<ul>
<li>
<code>&lt;primary&gt;</code> - the fingerprint extracted from <code>wiki.key</code>
</li>
<li>
<code>&lt;backup&gt;</code>  - the CA fingerprint: <code>of00RDinhPeVRNnXm1jXQDagktOL75qQo1pT+xc7VIE=</code>
</li>
</ul>

<p>Read more about this <a href="https://developer.mozilla.org/en-US/docs/Web/Security/Public_Key_Pinning">here</a>.</p>
</li>
</ul>

<h4><a class="anchor" id="domains" href="#domains"></a>Domains</h4>

<p>The proxy should accept the following domain names:</p>

<ul>
<li>internal.dn42</li>
<li>wiki.dn42</li>
</ul>

<p>Nginx should listen on a unicast address as well, so your site can be reached exclusively. Assign an IP address for the occasion and send it to <a href="https://io.nixnodes.net?t=person&amp;l=XUU-DN42">XUU-DN42</a> including your AS <code>&lt;aut-num&gt;</code> and the country code <code>&lt;CC&gt;</code> where your site is located. A forward DNS record will be created, pointing to the unicast IP address:</p>

<ul>
<li>
<code>&lt;aut-num&gt;</code>-<code>&lt;CC&gt;</code><code>(-&lt;UID&gt;)</code>.wiki.dn42 </li>
</ul>

<h4><a class="anchor" id="config-example" href="#config-example"></a>Config example</h4>

<pre class="highlight"><code><span class="n">ssl_protocols</span>  <span class="n">TLSv1</span>.<span class="m">2</span> <span class="n">TLSv1</span>.<span class="m">1</span> <span class="n">TLSv1</span>;
<span class="n">ssl_session_cache</span> <span class="n">shared</span>:<span class="n">SSL</span>:<span class="m">2</span><span class="n">m</span>;

<span class="n">ssl_ciphers</span>   <span class="n">ECDHE</span>-<span class="n">RSA</span>-<span class="n">AES128</span>-<span class="n">GCM</span>-<span class="n">SHA256</span>:<span class="n">ECDHE</span>-<span class="n">ECDSA</span>-<span class="n">AES128</span>-<span class="n">GCM</span>-<span class="n">SHA256</span>:<span class="n">ECDHE</span>-<span class="n">RSA</span>-<span class="n">AES256</span>-<span class="n">GCM</span>-<span class="n">SHA384</span>:<span class="n">ECDHE</span>-<span class="n">ECDSA</span>-<span class="n">AES256</span>-<span class="n">GCM</span>-<span class="n">SHA384</span>:<span class="n">DHE</span>-<span class="n">RSA</span>-<span class="n">AES128</span>-<span class="n">GCM</span>-<span class="n">SHA256</span>:<span class="n">DHE</span>-<span class="n">DSS</span>-<span class="n">AES128</span>-<span class="n">GCM</span>-<span class="n">SHA256</span>:<span class="n">kEDH</span>+<span class="n">AESGCM</span>:<span class="n">ECDHE</span>-<span class="n">RSA</span>-<span class="n">AES128</span>-<span class="n">SHA256</span>:<span class="n">ECDHE</span>-<span class="n">ECDSA</span>-<span class="n">AES128</span>-<span class="n">SHA256</span>:<span class="n">ECDHE</span>-<span class="n">RSA</span>-<span class="n">AES128</span>-<span class="n">SHA</span>:<span class="n">ECDHE</span>-<span class="n">ECDSA</span>-<span class="n">AES128</span>-<span class="n">SHA</span>:<span class="n">ECDHE</span>-<span class="n">RSA</span>-<span class="n">AES256</span>-<span class="n">SHA384</span>:<span class="n">ECDHE</span>-<span class="n">ECDSA</span>-<span class="n">AES256</span>-<span class="n">SHA384</span>:<span class="n">ECDHE</span>-<span class="n">RSA</span>-<span class="n">AES256</span>-<span class="n">SHA</span>:<span class="n">ECDHE</span>-<span class="n">ECDSA</span>-<span class="n">AES256</span>-<span class="n">SHA</span>:<span class="n">DHE</span>-<span class="n">RSA</span>-<span class="n">AES128</span>-<span class="n">SHA256</span>:<span class="n">DHE</span>-<span class="n">RSA</span>-<span class="n">AES128</span>-<span class="n">SHA</span>:<span class="n">DHE</span>-<span class="n">DSS</span>-<span class="n">AES128</span>-<span class="n">SHA256</span>:<span class="n">DHE</span>-<span class="n">RSA</span>-<span class="n">AES256</span>-<span class="n">SHA256</span>:<span class="n">DHE</span>-<span class="n">DSS</span>-<span class="n">AES256</span>-<span class="n">SHA</span>:<span class="n">DHE</span>-<span class="n">RSA</span>-<span class="n">AES256</span>-<span class="n">SHA</span>:<span class="n">AES128</span>-<span class="n">GCM</span>-<span class="n">SHA256</span>:<span class="n">AES256</span>-<span class="n">GCM</span>-<span class="n">SHA384</span>:<span class="n">AES128</span>-<span class="n">SHA256</span>:<span class="n">AES256</span>-<span class="n">SHA256</span>:<span class="n">AES128</span>-<span class="n">SHA</span>:<span class="n">AES256</span>-<span class="n">SHA</span>:<span class="n">AES</span>:<span class="n">CAMELLIA</span>:<span class="n">DES</span>-<span class="n">CBC3</span>-<span class="n">SHA</span>:!<span class="n">aNULL</span>:!<span class="n">eNULL</span>:!<span class="n">EXPORT</span>:!<span class="n">DES</span>:!<span class="n">RC4</span>:!<span class="n">MD5</span>:!<span class="n">PSK</span>:!<span class="n">aECDH</span>:!<span class="n">EDH</span>-<span class="n">DSS</span>-<span class="n">DES</span>-<span class="n">CBC3</span>-<span class="n">SHA</span>:!<span class="n">EDH</span>-<span class="n">RSA</span>-<span class="n">DES</span>-<span class="n">CBC3</span>-<span class="n">SHA</span>:!<span class="n">KRB5</span>-<span class="n">DES</span>-<span class="n">CBC3</span>-<span class="n">SHA</span>;

<span class="n">ssl_prefer_server_ciphers</span>   <span class="n">on</span>;

<span class="n">upstream</span> <span class="n">wiki</span> { <span class="n">server</span> <span class="m">127</span>.<span class="m">0</span>.<span class="m">0</span>.<span class="m">1</span>:<span class="m">4567</span>; }

<span class="n">server</span> { 
        <span class="n">server_name</span> <span class="n">internal</span>.<span class="n">dn42</span> <span class="n">wiki</span>.<span class="n">dn42</span> <span class="n">as</span>&lt;<span class="n">aut</span>-<span class="n">num</span>&gt;-&lt;<span class="n">cc</span>&gt;.<span class="n">wiki</span>.<span class="n">dn42</span>;

        <span class="n">listen</span> <span class="m">172</span>.<span class="m">23</span>.<span class="m">0</span>.<span class="m">80</span>:<span class="m">80</span> <span class="n">default</span>;
        <span class="n">listen</span> [<span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">80</span>::<span class="m">1</span>]:<span class="m">80</span> <span class="n">default</span>;
        <span class="n">listen</span> &lt;<span class="n">unicast</span> <span class="n">ipv4</span>&gt; <span class="m">80</span>;
        <span class="n">listen</span> [&lt;<span class="n">unicast</span> <span class="n">ipv6</span>&gt;]:<span class="m">80</span>;

        <span class="n">add_header</span> <span class="n">X</span>-<span class="n">SiteID</span>                   <span class="s1">'&lt;aut-num&gt;-&lt;cc&gt;'</span>;

        <span class="n">location</span> / {
                <span class="n">proxy_pass</span> <span class="n">http</span>://<span class="n">wiki</span>;
        }
}

<span class="n">upstream</span> <span class="n">wikirw</span> { <span class="n">server</span> <span class="m">127</span>.<span class="m">0</span>.<span class="m">0</span>.<span class="m">1</span>:<span class="m">4568</span>; }


<span class="n">server</span> { 
        <span class="n">server_name</span> <span class="n">internal</span>.<span class="n">dn42</span> <span class="n">wiki</span>.<span class="n">dn42</span> <span class="n">as</span>&lt;<span class="n">aut</span>-<span class="n">num</span>&gt;-&lt;<span class="n">cc</span>&gt;.<span class="n">wiki</span>.<span class="n">dn42</span>;

        <span class="n">listen</span> <span class="m">172</span>.<span class="m">23</span>.<span class="m">0</span>.<span class="m">80</span>:<span class="m">443</span> <span class="n">ssl</span> <span class="n">default</span>;
        <span class="n">listen</span> [<span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">80</span>::<span class="m">1</span>]:<span class="m">443</span> <span class="n">ssl</span> <span class="n">default</span>;
        <span class="n">listen</span> &lt;<span class="n">unicast</span> <span class="n">ipv4</span>&gt; <span class="m">443</span> <span class="n">ssl</span>;
        <span class="n">listen</span> [&lt;<span class="n">unicast</span> <span class="n">ipv6</span>&gt;]:<span class="m">443</span> <span class="n">ssl</span>;

	<span class="n">ssl</span> <span class="n">on</span>;
        <span class="n">ssl_certificate</span>      &lt;<span class="n">path</span>&gt;/<span class="n">ssl</span>.<span class="n">crt</span>;  
        <span class="n">ssl_certificate_key</span>  &lt;<span class="n">path</span>&gt;/<span class="n">ssl</span>.<span class="n">key</span>;

        <span class="n">add_header</span> <span class="n">strict</span>-<span class="n">transport</span>-<span class="n">security</span>  <span class="s2">"max-age=5184000; includeSubDomains"</span>;
        <span class="n">add_header</span> <span class="n">Public</span>-<span class="n">Key</span>-<span class="n">Pins</span>            <span class="s1">'pin-sha256="&lt;primary-pin&gt;";pin-sha256="&lt;backup-pin&gt;";  max-age=5184000; includeSubDomains'</span>;
        <span class="n">add_header</span> <span class="n">X</span>-<span class="n">SiteID</span>                   <span class="s1">'&lt;aut-num&gt;-&lt;cc&gt;'</span>;

        <span class="n">location</span> / {
                <span class="n">proxy_pass</span> <span class="n">http</span>://<span class="n">wikirw</span>;
        }
}
</code></pre>

<h2><a class="anchor" id="exabgp" href="#exabgp"></a>ExaBGP</h2>

<h3><a class="anchor" id="announcing" href="#announcing"></a>Announcing</h3>

<p>The prefix AS-PATH should show the announcement is originating from your AS. After peering ExaBGP to the nearest speaker(s), check if the prefix is routing properly inside your network. Try not to blackhole the passing traffic (e.g. no static routes to <code>172.23.0.80/32</code>). Test the whole thing by shutting down nginx/gollum and watch what happens.</p>

<h4><a class="anchor" id="configuration" href="#configuration"></a>Configuration</h4>

<pre class="highlight"><code><span class="c"># exabgp.conf
</span>
<span class="n">group</span> <span class="n">gollum</span>-<span class="n">watchdog</span> {
  <span class="n">neighbor</span> &lt;<span class="n">peer1</span>&gt; {
    <span class="n">router</span>-<span class="n">id</span> <span class="n">x</span>.<span class="n">x</span>.<span class="n">x</span>.<span class="n">x</span>;
    <span class="n">local</span>-<span class="n">address</span> &lt;<span class="n">source</span>-<span class="n">address</span>&gt;;
    <span class="n">local</span>-<span class="n">as</span> &lt;<span class="n">ownas</span>&gt;;
    <span class="n">peer</span>-<span class="n">as</span> &lt;<span class="n">peeras</span>&gt;;
  }

  <span class="c">## (example ipv4) peer with one of our iBGP speakers:
</span>  <span class="n">neighbor</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">0</span>.<span class="m">1</span> {
    <span class="n">router</span>-<span class="n">id</span> <span class="m">172</span>.<span class="m">23</span>.<span class="m">0</span>.<span class="m">80</span>;
    <span class="n">local</span>-<span class="n">address</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">0</span>.<span class="m">2</span>;
    <span class="n">local</span>-<span class="n">as</span> <span class="m">123456</span>;
    <span class="n">peer</span>-<span class="n">as</span> <span class="m">123456</span>;
  }

  <span class="c">## (example ipv6) peer with one of our iBGP speakers:
</span>  <span class="n">neighbor</span> <span class="n">fd42</span>:<span class="m">4992</span>:<span class="m">6</span><span class="n">a6d</span>::<span class="m">1</span> {
    <span class="n">router</span>-<span class="n">id</span> <span class="m">172</span>.<span class="m">23</span>.<span class="m">0</span>.<span class="m">80</span>;
    <span class="n">local</span>-<span class="n">address</span> <span class="n">fd42</span>:<span class="m">4992</span>:<span class="m">6</span><span class="n">a6d</span>::<span class="m">2</span>;
    <span class="n">local</span>-<span class="n">as</span> <span class="m">123456</span>;
    <span class="n">peer</span>-<span class="n">as</span> <span class="m">123456</span>;
  }

  <span class="c">## ...
</span>
  <span class="n">process</span> <span class="n">watch</span>-<span class="n">gollum</span> {
     <span class="n">run</span> &lt;<span class="n">path</span>&gt;/<span class="n">gollum</span>-<span class="n">watchdog</span>.<span class="n">sh</span>;
  }
}
</code></pre>

<h4><a class="anchor" id="watchdog-script" href="#watchdog-script"></a>Watchdog script</h4>

<p>Watchdog runs in an infinite loop, sending the appropriate commands to stdout. <a href="https://github.com/Exa-Networks/exabgp">ExaBGP</a> attaches to the process' stdout and listens for instructions. Watchdog sends either a route announce or widthdraw.</p>

<p>Run <code>gollum-watchdog.sh</code> in a shell first to validate it's working:</p>

<pre class="highlight"><code><span class="c">#!/bin/bash</span>

<span class="nv">CURL</span><span class="o">=</span>curl

<span class="c">## url's to check (all listed must be alive to send announce)</span>
<span class="nv">URL</span><span class="o">=(</span><span class="s2">"http://172.23.0.80"</span> <span class="s2">"https://172.23.0.80"</span> <span class="s2">"http://[fd42:d42:d42:80::1]"</span> <span class="s2">"https://[fd42:d42:d42:80::1]"</span><span class="o">)</span>

<span class="nv">ROUTE</span><span class="o">=</span><span class="s1">'172.23.0.80/32'</span>
<span class="c">## the anycast v6 route (/64 due to prefix size limits)</span>
<span class="nv">ROUTE6</span><span class="o">=</span><span class="s1">'fd42:d42:d42:80::/64'</span>

<span class="c">## the next-hop we'll be advertising to neighbor(s)</span>
<span class="nv">NEXTHOP</span><span class="o">=</span><span class="s1">'&lt;source-address&gt;'</span> 
<span class="nv">NEXTHOP6</span><span class="o">=</span><span class="s1">'&lt;source-address-v6&gt;'</span>

<span class="c">## regex match this keyword against HTTP response from curl</span>
<span class="nv">VALIDATE_KEYWORD</span><span class="o">=</span><span class="s1">'gollum'</span>

<span class="nv">INTERVAL</span><span class="o">=</span>60

<span class="c">###########################</span>

<span class="nv">RUN_STATE</span><span class="o">=</span>0             

check_urls<span class="o">()</span> <span class="o">{</span>          
        <span class="k">for </span>url <span class="k">in</span> <span class="s2">"</span><span class="k">${</span><span class="nv">URL</span><span class="p">[@]</span><span class="k">}</span><span class="s2">"</span><span class="p">;</span> <span class="k">do</span>

                <span class="c">## workaround curl errno 23 when piping</span>
                <span class="nv">http_response</span><span class="o">=</span><span class="sb">`</span><span class="k">${</span><span class="nv">CURL</span><span class="k">}</span> <span class="nt">--insecure</span> <span class="nt">-g</span> <span class="nt">-s</span> <span class="nt">-L</span> <span class="nt">-o</span> - <span class="s2">"</span><span class="k">${</span><span class="nv">url</span><span class="k">}</span><span class="s2">"</span><span class="sb">`</span>

                <span class="nb">echo</span> <span class="s2">"</span><span class="k">${</span><span class="nv">http_response</span><span class="k">}</span><span class="s2">"</span> | egrep <span class="nt">-q</span> <span class="s2">"</span><span class="k">${</span><span class="nv">VALIDATE_KEYWORD</span><span class="k">}</span><span class="s2">"</span> <span class="o">||</span> <span class="o">{</span>
                        <span class="k">return </span>1
                <span class="o">}</span>

                <span class="c">## add more checks</span>

        <span class="k">done
        return </span>0
<span class="o">}</span>

<span class="k">while</span> <span class="o">[</span> 1 <span class="o">]</span><span class="p">;</span> <span class="k">do
        if</span> <span class="o">[</span> <span class="k">${</span><span class="nv">RUN_STATE</span><span class="k">}</span> <span class="nt">-eq</span> 0 <span class="o">]</span><span class="p">;</span> <span class="k">then
                </span>check_urls <span class="o">&amp;&amp;</span> <span class="o">{</span>
                        <span class="nv">RUN_STATE</span><span class="o">=</span>1
                        <span class="nb">echo</span> <span class="s2">"announce route </span><span class="k">${</span><span class="nv">ROUTE</span><span class="k">}</span><span class="s2"> next-hop </span><span class="k">${</span><span class="nv">NEXTHOP</span><span class="k">}</span><span class="s2">"</span>
                        <span class="nb">echo</span> <span class="s2">"announce route </span><span class="k">${</span><span class="nv">ROUTE6</span><span class="k">}</span><span class="s2"> next-hop </span><span class="k">${</span><span class="nv">NEXTHOP6</span><span class="k">}</span><span class="s2">"</span>
                <span class="o">}</span>       
        <span class="k">else    
                </span>check_urls <span class="o">||</span> <span class="o">{</span>
                        <span class="nv">RUN_STATE</span><span class="o">=</span>0
                        <span class="nb">echo</span> <span class="s2">"withdraw route </span><span class="k">${</span><span class="nv">ROUTE</span><span class="k">}</span><span class="s2"> next-hop </span><span class="k">${</span><span class="nv">NEXTHOP</span><span class="k">}</span><span class="s2">"</span>
                        <span class="nb">echo</span> <span class="s2">"withdraw route </span><span class="k">${</span><span class="nv">ROUTE6</span><span class="k">}</span><span class="s2"> next-hop </span><span class="k">${</span><span class="nv">NEXTHOP6</span><span class="k">}</span><span class="s2">"</span>
                <span class="o">}</span>       
        <span class="k">fi

        </span><span class="nb">sleep</span> <span class="k">${</span><span class="nv">INTERVAL</span><span class="k">}</span>

<span class="k">done    

</span><span class="nb">exit </span>0</code></pre>

<h4><a class="anchor" id="run" href="#run"></a>Run</h4>

<p>Normally SIGUSR1 to the exabgp process triggers a configuration update, but at occasion the process might need to be restarted - since its gracefull shutdown can be glitchy , this might be a bit difficult. Sending SIGKILL to the child(ren) and immediately after, the parent, does the job (quick-and-dirty). </p>

<p><code>USAGE: /etc/exabgp/run.sh [start|stop|restart]</code></p>

<pre class="highlight"><code><span class="c">#!/bin/bash</span>

<span class="nv">PID_FILE</span><span class="o">=</span>/var/run/exaBGP/exabgp_PID

<span class="c">######################################</span>

<span class="nv">EXABGP</span><span class="o">=</span>&lt;path&gt;/sbin/exabgp
<span class="nv">EXA_LOG</span><span class="o">=</span>/var/log/exabgp.log
<span class="nv">CONF</span><span class="o">=</span>/etc/exabgp/exabgp.conf


start<span class="o">()</span> <span class="o">{</span>
	<span class="o">[</span> <span class="nt">-f</span> <span class="k">${</span><span class="nv">PID_FILE</span><span class="k">}</span> <span class="o">]</span> <span class="o">&amp;&amp;</span> <span class="o">{</span>
		<span class="nb">echo</span> <span class="s2">"WARNING: </span><span class="sb">`</span><span class="nb">cat</span> <span class="k">${</span><span class="nv">PID_FILE</span><span class="k">}</span><span class="sb">`</span><span class="s2">: exabgp already running"</span><span class="p">;</span> <span class="k">return </span>1
	<span class="o">}</span>
	<span class="k">${</span><span class="nv">EXABGP</span><span class="k">}</span> <span class="k">${</span><span class="nv">CONF</span><span class="k">}</span> &amp;&gt; <span class="k">${</span><span class="nv">EXA_LOG</span><span class="k">}</span> &amp;
	<span class="nv">cpid</span><span class="o">=</span><span class="nv">$!</span>
	<span class="o">[</span> <span class="k">${</span><span class="nv">cpid</span><span class="k">}</span> <span class="nt">-eq</span> 0 <span class="o">]</span> <span class="o">&amp;&amp;</span> <span class="o">{</span>
		<span class="nb">echo</span> <span class="s2">"ERROR: could not start process"</span><span class="p">;</span> <span class="k">return </span>1

	<span class="o">}</span>
        <span class="nb">echo</span> <span class="k">${</span><span class="nv">cpid</span><span class="k">}</span> <span class="o">&gt;</span> <span class="k">${</span><span class="nv">PID_FILE</span><span class="k">}</span>
<span class="o">}</span>

stop<span class="o">(){</span>
	<span class="o">[</span> <span class="nt">-f</span> <span class="k">${</span><span class="nv">PID_FILE</span><span class="k">}</span> <span class="o">]</span> <span class="o">||</span> <span class="k">return </span>1 
	pkill <span class="nt">-9</span> <span class="nt">-P</span> <span class="si">$(</span><span class="nb">cat</span> <span class="k">${</span><span class="nv">PID_FILE</span><span class="k">}</span><span class="si">)</span>
        <span class="nb">kill</span> <span class="nt">-9</span>  <span class="si">$(</span><span class="nb">cat</span> <span class="k">${</span><span class="nv">PID_FILE</span><span class="k">}</span><span class="si">)</span>
	<span class="nb">rm</span> <span class="nt">-f</span> <span class="k">${</span><span class="nv">PID_FILE</span><span class="k">}</span>
<span class="o">}</span>

<span class="k">case</span> <span class="k">${</span><span class="nv">1</span><span class="k">}</span> <span class="k">in
    </span>start <span class="p">)</span>
	start
    <span class="p">;;</span>
    stop <span class="p">)</span>
	stop
   <span class="p">;;</span>
    restart <span class="p">)</span>
	stop
	<span class="nb">sleep </span>1
	start
   <span class="p">;;</span>
<span class="k">esac</span>

<span class="nb">exit </span>0</code></pre>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
<li>
<p><a href="/Home" rel="nofollow">Home</a></p>

<ul>
<li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
<li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
<li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
<li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
<li><a href="/FAQ" rel="nofollow">FAQ</a></li>
</ul>
</li>
<li>
<p>How-To</p>

<ul>
<li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
<li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
<li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
<li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
<li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
<li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
<li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
<li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
<li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
<li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
<li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
<li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
<li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
<li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
<li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
<li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
<li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
<li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
</ul>
</li>
<li>
<p>Services</p>

<ul>
<li><a href="/services/IRC" rel="nofollow">IRC</a></li>
<li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
<li><a href="/services/DNS" rel="nofollow">DNS</a></li>
<li><a href="/services/IX-Collection" rel="nofollow">IX Collection</a></li>
<li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
<li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
<li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
<li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
<li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
<li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
<li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
</ul>
</li>
<li>
<p>Internal</p>

<ul>
<li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
<li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
<li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
<li>
<a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a><br />
</li>
<li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
</ul>
</li>
<li>
<p>Historical</p>

<ul>
<li><a href="/historical/Bird" rel="nofollow">Bird 1</a></li>
<li><a href="/historical/Quagga" rel="nofollow">Quagga</a></li>
</ul>
</li>
<li>
<p>External Tools</p>

<ul>
<li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
<li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
</ul>
</li>
</ul>

<hr />

	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a> | Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a></p>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="services/Distributed-Wiki.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/services/Distributed-Wiki.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
