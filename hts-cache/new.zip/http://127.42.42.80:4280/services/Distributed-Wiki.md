<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'services/Distributed-Wiki.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Distributed-Wiki</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Distributed-Wiki</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/services/Distributed-Wiki.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/services/Distributed-Wiki.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Distributed-Wiki
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/services/">services</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="distributed-wiki" href="#distributed-wiki"></a>Distributed Wiki</h1>

<p>This wiki is mirrored by multiple operators across both the public internet and on dn42.
Current operators providing the wiki service can be found on the page footer.</p>

<h2><a class="anchor" id="hosting-the-wiki" href="#hosting-the-wiki"></a>Hosting the wiki</h2>

<p>For hosting the wiki one will need to decide whether they desire to host a public internet mirror, join the wiki.dn42 anycast or both.
The idea is to deploy mirrors across dn42 using <a href="https://en.wikipedia.org/wiki/Anycast">anycast</a> addressing (BGP), thus providing redundancy, load-balancing and improved access times to the wiki.</p>

<h2><a class="anchor" id="prerequisites" href="#prerequisites"></a>Prerequisites</h2>

<ul>
  <li>Stable 24/7 connection to dn42.</li>
  <li>Stable host machine, present in dn42.</li>
  <li>
    <p>Solid networking/sysadmin skills (to keep the system as a whole stable).</p>

    <p>In contrast with the general spirit in dn42, this service should NOT be deployed by unskilled members for the purpose of learning and exploring - since it is the primary source of information related to the project, it should not be used as a playground.</p>
  </li>
  <li>Wiki Software (choose one):
    <ul>
      <li>
<a href="https://github.com/iedon/dn42-wiki-go">dn42-wiki-go</a>  (Recommended)</li>
      <li><a href="https://git.dn42.dev/wiki/wiki-ng">wiki-ng</a></li>
      <li><a href="https://github.com/gollum/gollum">gollum</a></li>
    </ul>
  </li>
  <li>Other Software:
    <ul>
      <li><a href="https://en.wikipedia.org/wiki/Git_(software)">Git</a></li>
      <li><a href="https://en.wikipedia.org/wiki/Nginx">Nginx</a></li>
      <li><a href="https://github.com/Exa-Networks/exabgp">ExaBGP</a></li>
    </ul>

    <p>It's recommended to use a debian distro on the host machine, where most of the above software can be installed using package manager(s) with ease. On some distros (RHEL based for example) it might not be an easy task.</p>
  </li>
</ul>

<p>The local webserver is to be monitored with a simple <a href="/services/Distributed-Wiki#watchdog-script">shell script</a> working <a href="/services/Distributed-Wiki/#exabgp">in conjunction</a> with <a href="https://github.com/Exa-Networks/exabgp">ExaBGP</a>, announcing/withdrawing the assigned route if the service is up/down.
Nginx acts as a reverse proxy and handles the encryption.</p>

<h2><a class="anchor" id="network" href="#network"></a>Network</h2>

<ul>
  <li>Install wiki anycast IP addresses <code>172.23.0.80/32</code> and <code>fd42:d42:d42:80::1/64</code> on the system</li>
  <li>Assign a unicast IP address to be used by Nginx</li>
  <li>Establish connectivity to the dn42 network</li>
</ul>

<h2><a class="anchor" id="data-replication" href="#data-replication"></a>Data replication</h2>

<p>Site files are stored in a local <a href="https://en.wikipedia.org/wiki/Distributed_revision_control">DVCS</a> repository (Git) on each node and replicated through a central server.
Since the wiki is hosted on top of Git, it is not overly complicated to keep the local site in sync with others, each site only triggers periodic pulls/pushes from/to the Git server.</p>

<h3><a class="anchor" id="setup-the-repo" href="#setup-the-repo"></a>Setup the repo</h3>

<ul>
  <li>
    <p>Clone the dn42 wiki repo:</p>

    <p><code>git clone git@git.dn42.dev:wiki/wiki.git &lt;path&gt;</code></p>
  </li>
  <li>
    <p>Setup cron for periodic pull/push jobs for the repo (simple example):</p>
  </li>
  <li>
    <p><strong>wiki-sync.sh</strong>:</p>

    <div class="language-sh highlighter-rouge">
<div class="highlight"><pre class="highlight"><code><span class="c">#!/bin/bash</span>
    
<span class="nv">WIKI_PATH</span><span class="o">=</span>&lt;repo path&gt;
<span class="nv">GIT</span><span class="o">=</span>/usr/bin/git
    
<span class="nb">cd</span> <span class="s2">"</span><span class="k">${</span><span class="nv">WIKI_PATH</span><span class="k">}</span><span class="s2">"</span>
<span class="k">${</span><span class="nv">GIT</span><span class="k">}</span> push
<span class="k">${</span><span class="nv">GIT</span><span class="k">}</span> pull
    
<span class="nb">exit </span>0
</code></pre></div>    </div>
  </li>
  <li>
    <p><strong>Cron entry</strong>:</p>
  </li>
</ul>

<p><code>*/10 * * * * &lt;path&gt;/wiki-sync.sh &amp;&gt; /dev/null</code></p>

<p>Running in 10 minute intervals is reasonable, if you choose to change this, please keep it in the range from 5 to 15 minutes. Also consider using dn42notifyd to get a callbacks instead.</p>

<h2><a class="anchor" id="nginx-reverse-proxy" href="#nginx-reverse-proxy"></a>Nginx reverse proxy</h2>

<h3><a class="anchor" id="ssl" href="#ssl"></a>SSL</h3>

<ul>
  <li>Generate an SSL certificate using the main Certificate authority using a method that supports anycasted IP addresses.</li>
</ul>

<h4><a class="anchor" id="header" href="#header"></a>Header</h4>

<h5><a class="anchor" id="site-identification" href="#site-identification"></a>Site identification</h5>

<p>A custom header <code>X-SiteID</code> identifies the site you're connecting to:</p>

<ul>
  <li>
<code>add_header X-SiteID   '&lt;AS&gt;-&lt;ISO country code&gt;';</code>
    <ul>
      <li>&lt;AS&gt; is the as number prefixed with <code>as</code> like <code>as64737</code>
</li>
    </ul>
  </li>
</ul>

<h5><a class="anchor" id="enabling-hpkp" href="#enabling-hpkp"></a>Enabling <a href="https://en.wikipedia.org/wiki/HTTP_Public_Key_Pinning">HPKP</a>
</h5>

<ul>
  <li>
    <p>Extract base64 encoded SPKI fingerprint from private key <code>wiki.key</code>:</p>

    <div class="language-sh highlighter-rouge">
<div class="highlight"><pre class="highlight"><code>openssl rsa <span class="nt">-in</span> wiki.key <span class="nt">-outform</span> der <span class="nt">-pubout</span> | openssl dgst <span class="nt">-sha256</span> <span class="nt">-binary</span> | openssl enc <span class="nt">-base64</span>
</code></pre></div>    </div>
  </li>
  <li>
    <p>Configure Nginx to send the fingerprint in header (SSL block):</p>

    <div class="language-conf highlighter-rouge">
<div class="highlight"><pre class="highlight"><code><span class="n">add_header</span> <span class="n">Public</span>-<span class="n">Key</span>-<span class="n">Pins</span>  <span class="n">pin</span>-<span class="n">sha256</span>=<span class="s2">"&lt;primary&gt;"</span>; <span class="n">pin</span>-<span class="n">sha256</span>=<span class="s2">"&lt;backup&gt;"</span>; <span class="n">max</span>-<span class="n">age</span>=<span class="m">5184000</span>; <span class="n">includeSubDomains</span><span class="err">'</span>;
</code></pre></div>    </div>
  </li>
  <li>
<code>&lt;primary&gt;</code> - the fingerprint extracted from <code>wiki.key</code>
</li>
  <li>
<code>&lt;backup&gt;</code>  - the CA fingerprint: <code>of00RDinhPeVRNnXm1jXQDagktOL75qQo1pT+xc7VIE=</code>
</li>
</ul>

<p>Read more about this <a href="https://developer.mozilla.org/en-US/docs/Web/Security/Public_Key_Pinning">here</a>.</p>

<h4><a class="anchor" id="domains" href="#domains"></a>Domains</h4>

<p>The proxy should accept the following domain names:</p>

<ul>
  <li>internal.dn42</li>
  <li>wiki.dn42</li>
</ul>

<h4><a class="anchor" id="config-example" href="#config-example"></a>Config example</h4>

<pre class="highlight"><code><span class="n">ssl_protocols</span>  <span class="n">TLSv1</span>.<span class="m">2</span> <span class="n">TLSv1</span>.<span class="m">1</span> <span class="n">TLSv1</span>;
<span class="n">ssl_session_cache</span> <span class="n">shared</span>:<span class="n">SSL</span>:<span class="m">2</span><span class="n">m</span>;

<span class="n">ssl_ciphers</span>   <span class="n">ECDHE</span>-<span class="n">RSA</span>-<span class="n">AES128</span>-<span class="n">GCM</span>-<span class="n">SHA256</span>:<span class="n">ECDHE</span>-<span class="n">ECDSA</span>-<span class="n">AES128</span>-<span class="n">GCM</span>-<span class="n">SHA256</span>:<span class="n">ECDHE</span>-<span class="n">RSA</span>-<span class="n">AES256</span>-<span class="n">GCM</span>-<span class="n">SHA384</span>:<span class="n">ECDHE</span>-<span class="n">ECDSA</span>-<span class="n">AES256</span>-<span class="n">GCM</span>-<span class="n">SHA384</span>:<span class="n">DHE</span>-<span class="n">RSA</span>-<span class="n">AES128</span>-<span class="n">GCM</span>-<span class="n">SHA256</span>:<span class="n">DHE</span>-<span class="n">DSS</span>-<span class="n">AES128</span>-<span class="n">GCM</span>-<span class="n">SHA256</span>:<span class="n">kEDH</span>+<span class="n">AESGCM</span>:<span class="n">ECDHE</span>-<span class="n">RSA</span>-<span class="n">AES128</span>-<span class="n">SHA256</span>:<span class="n">ECDHE</span>-<span class="n">ECDSA</span>-<span class="n">AES128</span>-<span class="n">SHA256</span>:<span class="n">ECDHE</span>-<span class="n">RSA</span>-<span class="n">AES128</span>-<span class="n">SHA</span>:<span class="n">ECDHE</span>-<span class="n">ECDSA</span>-<span class="n">AES128</span>-<span class="n">SHA</span>:<span class="n">ECDHE</span>-<span class="n">RSA</span>-<span class="n">AES256</span>-<span class="n">SHA384</span>:<span class="n">ECDHE</span>-<span class="n">ECDSA</span>-<span class="n">AES256</span>-<span class="n">SHA384</span>:<span class="n">ECDHE</span>-<span class="n">RSA</span>-<span class="n">AES256</span>-<span class="n">SHA</span>:<span class="n">ECDHE</span>-<span class="n">ECDSA</span>-<span class="n">AES256</span>-<span class="n">SHA</span>:<span class="n">DHE</span>-<span class="n">RSA</span>-<span class="n">AES128</span>-<span class="n">SHA256</span>:<span class="n">DHE</span>-<span class="n">RSA</span>-<span class="n">AES128</span>-<span class="n">SHA</span>:<span class="n">DHE</span>-<span class="n">DSS</span>-<span class="n">AES128</span>-<span class="n">SHA256</span>:<span class="n">DHE</span>-<span class="n">RSA</span>-<span class="n">AES256</span>-<span class="n">SHA256</span>:<span class="n">DHE</span>-<span class="n">DSS</span>-<span class="n">AES256</span>-<span class="n">SHA</span>:<span class="n">DHE</span>-<span class="n">RSA</span>-<span class="n">AES256</span>-<span class="n">SHA</span>:<span class="n">AES128</span>-<span class="n">GCM</span>-<span class="n">SHA256</span>:<span class="n">AES256</span>-<span class="n">GCM</span>-<span class="n">SHA384</span>:<span class="n">AES128</span>-<span class="n">SHA256</span>:<span class="n">AES256</span>-<span class="n">SHA256</span>:<span class="n">AES128</span>-<span class="n">SHA</span>:<span class="n">AES256</span>-<span class="n">SHA</span>:<span class="n">AES</span>:<span class="n">CAMELLIA</span>:<span class="n">DES</span>-<span class="n">CBC3</span>-<span class="n">SHA</span>:!<span class="n">aNULL</span>:!<span class="n">eNULL</span>:!<span class="n">EXPORT</span>:!<span class="n">DES</span>:!<span class="n">RC4</span>:!<span class="n">MD5</span>:!<span class="n">PSK</span>:!<span class="n">aECDH</span>:!<span class="n">EDH</span>-<span class="n">DSS</span>-<span class="n">DES</span>-<span class="n">CBC3</span>-<span class="n">SHA</span>:!<span class="n">EDH</span>-<span class="n">RSA</span>-<span class="n">DES</span>-<span class="n">CBC3</span>-<span class="n">SHA</span>:!<span class="n">KRB5</span>-<span class="n">DES</span>-<span class="n">CBC3</span>-<span class="n">SHA</span>;

<span class="n">ssl_prefer_server_ciphers</span>   <span class="n">on</span>;

<span class="n">upstream</span> <span class="n">wiki</span> { <span class="n">server</span> <span class="m">127</span>.<span class="m">0</span>.<span class="m">0</span>.<span class="m">1</span>:<span class="m">4567</span>; }

<span class="n">server</span> { 
        <span class="n">server_name</span> <span class="n">internal</span>.<span class="n">dn42</span> <span class="n">wiki</span>.<span class="n">dn42</span> <span class="n">as</span>&lt;<span class="n">aut</span>-<span class="n">num</span>&gt;-&lt;<span class="n">cc</span>&gt;.<span class="n">wiki</span>.<span class="n">dn42</span>;

        <span class="n">listen</span> <span class="m">172</span>.<span class="m">23</span>.<span class="m">0</span>.<span class="m">80</span>:<span class="m">80</span> <span class="n">default</span>;
        <span class="n">listen</span> [<span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">80</span>::<span class="m">1</span>]:<span class="m">80</span> <span class="n">default</span>;
        <span class="n">listen</span> &lt;<span class="n">unicast</span> <span class="n">ipv4</span>&gt; <span class="m">80</span>;
        <span class="n">listen</span> [&lt;<span class="n">unicast</span> <span class="n">ipv6</span>&gt;]:<span class="m">80</span>;

        <span class="n">add_header</span> <span class="n">X</span>-<span class="n">SiteID</span>                   <span class="s1">'&lt;aut-num&gt;-&lt;cc&gt;'</span>;

        <span class="n">location</span> / {
                <span class="n">proxy_pass</span> <span class="n">http</span>://<span class="n">wiki</span>;
        }
}

<span class="n">upstream</span> <span class="n">wikirw</span> { <span class="n">server</span> <span class="m">127</span>.<span class="m">0</span>.<span class="m">0</span>.<span class="m">1</span>:<span class="m">4568</span>; }


<span class="n">server</span> { 
        <span class="n">server_name</span> <span class="n">internal</span>.<span class="n">dn42</span> <span class="n">wiki</span>.<span class="n">dn42</span> <span class="n">as</span>&lt;<span class="n">aut</span>-<span class="n">num</span>&gt;-&lt;<span class="n">cc</span>&gt;.<span class="n">wiki</span>.<span class="n">dn42</span>;

        <span class="n">listen</span> <span class="m">172</span>.<span class="m">23</span>.<span class="m">0</span>.<span class="m">80</span>:<span class="m">443</span> <span class="n">ssl</span> <span class="n">default</span>;
        <span class="n">listen</span> [<span class="n">fd42</span>:<span class="n">d42</span>:<span class="n">d42</span>:<span class="m">80</span>::<span class="m">1</span>]:<span class="m">443</span> <span class="n">ssl</span> <span class="n">default</span>;
        <span class="n">listen</span> &lt;<span class="n">unicast</span> <span class="n">ipv4</span>&gt; <span class="m">443</span> <span class="n">ssl</span>;
        <span class="n">listen</span> [&lt;<span class="n">unicast</span> <span class="n">ipv6</span>&gt;]:<span class="m">443</span> <span class="n">ssl</span>;

	<span class="n">ssl</span> <span class="n">on</span>;
        <span class="n">ssl_certificate</span>      &lt;<span class="n">path</span>&gt;/<span class="n">ssl</span>.<span class="n">crt</span>;  
        <span class="n">ssl_certificate_key</span>  &lt;<span class="n">path</span>&gt;/<span class="n">ssl</span>.<span class="n">key</span>;

        <span class="n">add_header</span> <span class="n">strict</span>-<span class="n">transport</span>-<span class="n">security</span>  <span class="s2">"max-age=5184000; includeSubDomains"</span>;
        <span class="n">add_header</span> <span class="n">Public</span>-<span class="n">Key</span>-<span class="n">Pins</span>            <span class="s1">'pin-sha256="&lt;primary-pin&gt;";pin-sha256="&lt;backup-pin&gt;";  max-age=5184000; includeSubDomains'</span>;
        <span class="n">add_header</span> <span class="n">X</span>-<span class="n">SiteID</span>                   <span class="s1">'&lt;aut-num&gt;-&lt;cc&gt;'</span>;

        <span class="n">location</span> / {
                <span class="n">proxy_pass</span> <span class="n">http</span>://<span class="n">wikirw</span>;
        }
}
</code></pre>

<h2><a class="anchor" id="exabgp" href="#exabgp"></a>ExaBGP</h2>

<h3><a class="anchor" id="announcing" href="#announcing"></a>Announcing</h3>

<p>The prefix AS-PATH should show the announcement is originating from your AS. After peering ExaBGP to the nearest speaker(s), check if the prefix is routing properly inside your network. Try not to blackhole the passing traffic (e.g. no static routes to <code>172.23.0.80/32</code>). Test the whole thing by shutting down nginx/gollum and watch what happens.</p>

<h4><a class="anchor" id="configuration" href="#configuration"></a>Configuration</h4>

<pre class="highlight"><code><span class="c"># exabgp.conf
</span>
<span class="n">group</span> <span class="n">gollum</span>-<span class="n">watchdog</span> {
  <span class="n">neighbor</span> &lt;<span class="n">peer1</span>&gt; {
    <span class="n">router</span>-<span class="n">id</span> <span class="n">x</span>.<span class="n">x</span>.<span class="n">x</span>.<span class="n">x</span>;
    <span class="n">local</span>-<span class="n">address</span> &lt;<span class="n">source</span>-<span class="n">address</span>&gt;;
    <span class="n">local</span>-<span class="n">as</span> &lt;<span class="n">ownas</span>&gt;;
    <span class="n">peer</span>-<span class="n">as</span> &lt;<span class="n">peeras</span>&gt;;
  }

  <span class="c">## (example ipv4) peer with one of our iBGP speakers:
</span>  <span class="n">neighbor</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">0</span>.<span class="m">1</span> {
    <span class="n">router</span>-<span class="n">id</span> <span class="m">172</span>.<span class="m">23</span>.<span class="m">0</span>.<span class="m">80</span>;
    <span class="n">local</span>-<span class="n">address</span> <span class="m">172</span>.<span class="m">22</span>.<span class="m">0</span>.<span class="m">2</span>;
    <span class="n">local</span>-<span class="n">as</span> <span class="m">123456</span>;
    <span class="n">peer</span>-<span class="n">as</span> <span class="m">123456</span>;
  }

  <span class="c">## (example ipv6) peer with one of our iBGP speakers:
</span>  <span class="n">neighbor</span> <span class="n">fd42</span>:<span class="m">4992</span>:<span class="m">6</span><span class="n">a6d</span>::<span class="m">1</span> {
    <span class="n">router</span>-<span class="n">id</span> <span class="m">172</span>.<span class="m">23</span>.<span class="m">0</span>.<span class="m">80</span>;
    <span class="n">local</span>-<span class="n">address</span> <span class="n">fd42</span>:<span class="m">4992</span>:<span class="m">6</span><span class="n">a6d</span>::<span class="m">2</span>;
    <span class="n">local</span>-<span class="n">as</span> <span class="m">123456</span>;
    <span class="n">peer</span>-<span class="n">as</span> <span class="m">123456</span>;
  }

  <span class="c">## ...
</span>
  <span class="n">process</span> <span class="n">watch</span>-<span class="n">gollum</span> {
     <span class="n">run</span> &lt;<span class="n">path</span>&gt;/<span class="n">gollum</span>-<span class="n">watchdog</span>.<span class="n">sh</span>;
  }
}
</code></pre>

<h4><a class="anchor" id="watchdog-script" href="#watchdog-script"></a>Watchdog script</h4>

<p>Watchdog runs in an infinite loop, sending the appropriate commands to stdout. <a href="https://github.com/Exa-Networks/exabgp">ExaBGP</a> attaches to the process' stdout and listens for instructions. Watchdog sends either a route announce or widthdraw.</p>

<p>Run <code>gollum-watchdog.sh</code> in a shell first to validate it's working:</p>

<pre class="highlight"><code><span class="c">#!/bin/bash</span>

<span class="nv">CURL</span><span class="o">=</span>curl

<span class="c">## url's to check (all listed must be alive to send announce)</span>
<span class="nv">URL</span><span class="o">=(</span><span class="s2">"http://172.23.0.80"</span> <span class="s2">"https://172.23.0.80"</span> <span class="s2">"http://[fd42:d42:d42:80::1]"</span> <span class="s2">"https://[fd42:d42:d42:80::1]"</span><span class="o">)</span>

<span class="nv">ROUTE</span><span class="o">=</span><span class="s1">'172.23.0.80/32'</span>
<span class="c">## the anycast v6 route (/64 due to prefix size limits)</span>
<span class="nv">ROUTE6</span><span class="o">=</span><span class="s1">'fd42:d42:d42:80::/64'</span>

<span class="c">## the next-hop we'll be advertising to neighbor(s)</span>
<span class="nv">NEXTHOP</span><span class="o">=</span><span class="s1">'&lt;source-address&gt;'</span> 
<span class="nv">NEXTHOP6</span><span class="o">=</span><span class="s1">'&lt;source-address-v6&gt;'</span>

<span class="c">## regex match this keyword against HTTP response from curl</span>
<span class="nv">VALIDATE_KEYWORD</span><span class="o">=</span><span class="s1">'gollum'</span>

<span class="nv">INTERVAL</span><span class="o">=</span>60

<span class="c">###########################</span>

<span class="nv">RUN_STATE</span><span class="o">=</span>0             

check_urls<span class="o">()</span> <span class="o">{</span>          
        <span class="k">for </span>url <span class="k">in</span> <span class="s2">"</span><span class="k">${</span><span class="nv">URL</span><span class="p">[@]</span><span class="k">}</span><span class="s2">"</span><span class="p">;</span> <span class="k">do</span>

                <span class="c">## workaround curl errno 23 when piping</span>
                <span class="nv">http_response</span><span class="o">=</span><span class="sb">`</span><span class="k">${</span><span class="nv">CURL</span><span class="k">}</span> <span class="nt">--insecure</span> <span class="nt">-g</span> <span class="nt">-s</span> <span class="nt">-L</span> <span class="nt">-o</span> - <span class="s2">"</span><span class="k">${</span><span class="nv">url</span><span class="k">}</span><span class="s2">"</span><span class="sb">`</span>

                <span class="nb">echo</span> <span class="s2">"</span><span class="k">${</span><span class="nv">http_response</span><span class="k">}</span><span class="s2">"</span> | egrep <span class="nt">-q</span> <span class="s2">"</span><span class="k">${</span><span class="nv">VALIDATE_KEYWORD</span><span class="k">}</span><span class="s2">"</span> <span class="o">||</span> <span class="o">{</span>
                        <span class="k">return </span>1
                <span class="o">}</span>

                <span class="c">## add more checks</span>

        <span class="k">done
        return </span>0
<span class="o">}</span>

<span class="k">while</span> <span class="o">[</span> 1 <span class="o">]</span><span class="p">;</span> <span class="k">do
        if</span> <span class="o">[</span> <span class="k">${</span><span class="nv">RUN_STATE</span><span class="k">}</span> <span class="nt">-eq</span> 0 <span class="o">]</span><span class="p">;</span> <span class="k">then
                </span>check_urls <span class="o">&amp;&amp;</span> <span class="o">{</span>
                        <span class="nv">RUN_STATE</span><span class="o">=</span>1
                        <span class="nb">echo</span> <span class="s2">"announce route </span><span class="k">${</span><span class="nv">ROUTE</span><span class="k">}</span><span class="s2"> next-hop </span><span class="k">${</span><span class="nv">NEXTHOP</span><span class="k">}</span><span class="s2">"</span>
                        <span class="nb">echo</span> <span class="s2">"announce route </span><span class="k">${</span><span class="nv">ROUTE6</span><span class="k">}</span><span class="s2"> next-hop </span><span class="k">${</span><span class="nv">NEXTHOP6</span><span class="k">}</span><span class="s2">"</span>
                <span class="o">}</span>       
        <span class="k">else    
                </span>check_urls <span class="o">||</span> <span class="o">{</span>
                        <span class="nv">RUN_STATE</span><span class="o">=</span>0
                        <span class="nb">echo</span> <span class="s2">"withdraw route </span><span class="k">${</span><span class="nv">ROUTE</span><span class="k">}</span><span class="s2"> next-hop </span><span class="k">${</span><span class="nv">NEXTHOP</span><span class="k">}</span><span class="s2">"</span>
                        <span class="nb">echo</span> <span class="s2">"withdraw route </span><span class="k">${</span><span class="nv">ROUTE6</span><span class="k">}</span><span class="s2"> next-hop </span><span class="k">${</span><span class="nv">NEXTHOP6</span><span class="k">}</span><span class="s2">"</span>
                <span class="o">}</span>       
        <span class="k">fi

        </span><span class="nb">sleep</span> <span class="k">${</span><span class="nv">INTERVAL</span><span class="k">}</span>

<span class="k">done    

</span><span class="nb">exit </span>0</code></pre>

<h4><a class="anchor" id="run" href="#run"></a>Run</h4>

<p>Normally SIGUSR1 to the exabgp process triggers a configuration update, but at occasion the process might need to be restarted - since its gracefull shutdown can be glitchy , this might be a bit difficult. Sending SIGKILL to the child(ren) and immediately after, the parent, does the job (quick-and-dirty).</p>

<p><code>USAGE: /etc/exabgp/run.sh [start|stop|restart]</code></p>

<pre class="highlight"><code><span class="c">#!/bin/bash</span>

<span class="nv">PID_FILE</span><span class="o">=</span>/var/run/exaBGP/exabgp_PID

<span class="c">######################################</span>

<span class="nv">EXABGP</span><span class="o">=</span>&lt;path&gt;/sbin/exabgp
<span class="nv">EXA_LOG</span><span class="o">=</span>/var/log/exabgp.log
<span class="nv">CONF</span><span class="o">=</span>/etc/exabgp/exabgp.conf


start<span class="o">()</span> <span class="o">{</span>
	<span class="o">[</span> <span class="nt">-f</span> <span class="k">${</span><span class="nv">PID_FILE</span><span class="k">}</span> <span class="o">]</span> <span class="o">&amp;&amp;</span> <span class="o">{</span>
		<span class="nb">echo</span> <span class="s2">"WARNING: </span><span class="sb">`</span><span class="nb">cat</span> <span class="k">${</span><span class="nv">PID_FILE</span><span class="k">}</span><span class="sb">`</span><span class="s2">: exabgp already running"</span><span class="p">;</span> <span class="k">return </span>1
	<span class="o">}</span>
	<span class="k">${</span><span class="nv">EXABGP</span><span class="k">}</span> <span class="k">${</span><span class="nv">CONF</span><span class="k">}</span> &amp;&gt; <span class="k">${</span><span class="nv">EXA_LOG</span><span class="k">}</span> &amp;
	<span class="nv">cpid</span><span class="o">=</span><span class="nv">$!</span>
	<span class="o">[</span> <span class="k">${</span><span class="nv">cpid</span><span class="k">}</span> <span class="nt">-eq</span> 0 <span class="o">]</span> <span class="o">&amp;&amp;</span> <span class="o">{</span>
		<span class="nb">echo</span> <span class="s2">"ERROR: could not start process"</span><span class="p">;</span> <span class="k">return </span>1

	<span class="o">}</span>
        <span class="nb">echo</span> <span class="k">${</span><span class="nv">cpid</span><span class="k">}</span> <span class="o">&gt;</span> <span class="k">${</span><span class="nv">PID_FILE</span><span class="k">}</span>
<span class="o">}</span>

stop<span class="o">(){</span>
	<span class="o">[</span> <span class="nt">-f</span> <span class="k">${</span><span class="nv">PID_FILE</span><span class="k">}</span> <span class="o">]</span> <span class="o">||</span> <span class="k">return </span>1 
	pkill <span class="nt">-9</span> <span class="nt">-P</span> <span class="si">$(</span><span class="nb">cat</span> <span class="k">${</span><span class="nv">PID_FILE</span><span class="k">}</span><span class="si">)</span>
        <span class="nb">kill</span> <span class="nt">-9</span>  <span class="si">$(</span><span class="nb">cat</span> <span class="k">${</span><span class="nv">PID_FILE</span><span class="k">}</span><span class="si">)</span>
	<span class="nb">rm</span> <span class="nt">-f</span> <span class="k">${</span><span class="nv">PID_FILE</span><span class="k">}</span>
<span class="o">}</span>

<span class="k">case</span> <span class="k">${</span><span class="nv">1</span><span class="k">}</span> <span class="k">in
    </span>start <span class="p">)</span>
	start
    <span class="p">;;</span>
    stop <span class="p">)</span>
	stop
   <span class="p">;;</span>
    restart <span class="p">)</span>
	stop
	<span class="nb">sleep </span>1
	start
   <span class="p">;;</span>
<span class="k">esac</span>

<span class="nb">exit </span>0</code></pre>

<h2><a class="anchor" id="setting-up-the-wiki-software" href="#setting-up-the-wiki-software"></a>Setting up the wiki software</h2>
<p>See the documentation below for both gollum and dn42-wiki-go.</p>

<h2><a class="anchor" id="gollum" href="#gollum"></a>gollum</h2>

<ul>
  <li>Install <a href="https://github.com/gollum/gollum">gollum</a>
</li>
  <li>
    <p>Start two gollum instances, read-only and read/write on <code>127.0.0.1</code>:</p>

    <p>Read/write (SSL only):
</p><pre class="highlight"><code>RACK_ENV=production gollum --css --host 127.0.0.1  --port 4568 &lt;path&gt;</code></pre>
Read-only:
<pre class="highlight"><code>RACK_ENV=production gollum --css --host 127.0.0.1  --port 4567 --no-edit &lt;path&gt;</code></pre>

    <p>Set <code>&lt;path&gt;</code> to the location where wiki Git repo was cloned.</p>
  </li>
</ul>

<h2><a class="anchor" id="dn42-wiki-go" href="#dn42-wiki-go"></a>dn42-wiki-go</h2>

<h3><a class="anchor" id="introduction" href="#introduction"></a>Introduction</h3>

<p><a href="https://github.com/iedon/dn42-wiki-go">dn42-wiki-go</a> is a lightweight, Git-backed wiki engine designed for DN42. It is based on <a href="https://git.dn42.dev/wiki/wiki-ng">wiki-ng</a>, aims to replace the old Gollum-based DN42 distributed wiki.</p>

<p>It can serve pages live through its built-in Go HTTP server or generate a fully static HTML export for external hosting. All content is stored in a Git repository, making it easy to replicate across nodes or run in disconnected environments.</p>

<h3><a class="anchor" id="live-version" href="#live-version"></a>Live Version</h3>
<ul>
  <li>
<a href="https://wiki.dn42/">https://wiki.dn42/</a> (DN42 Access)</li>
  <li>
<a href="https://dn42.jp/">https://dn42.jp/</a> (Clearnet)</li>
</ul>

<p><img src="/services/images/iedon-dn42-wiki-go.png" alt="Screenshot of iEdon DN42 Wiki Go" /></p>

<h3><a class="anchor" id="operating-modes" href="#operating-modes"></a>Operating Modes</h3>

<p>You can run <code>dn42-wiki-go</code> in three different ways:</p>

<ol>
  <li>
    <p><strong>Run static build once then exit (<code>--build</code> or <code>live=false</code>)</strong><br />
The App renders all Markdown files into HTML under outputDir and exits.<br />
Best for setups where your own cron job handles Git sync and file publishing.</p>
  </li>
  <li>
    <p><strong>Live mode without reverse proxy (<code>live=true</code>)</strong><br />
The built-in HTTP server directly serves pages, assets, and APIs.<br />
Suitable for simple deployments.</p>
  </li>
  <li>
    <p><strong>Live mode behind a reverse proxy</strong><br />
The reverse proxy (nginx, Caddy, HAProxy, etc.) serves the generated files, and only API endpoints are forwarded to the App.<br />
See <code>config.example.json</code> for example configs and <code>nginx-vhost.conf</code> for a reverse-proxy reference.</p>

    <p><strong>Recommended for production and anycast nodes</strong>.</p>
  </li>
</ol>

<h3><a class="anchor" id="features" href="#features"></a>Features</h3>

<ul>
  <li>Live mode with automatic Markdown rendering and scheduled Git pull/push.</li>
  <li>Static mode for fully pre-built HTML exports.</li>
  <li>Optional in-browser editor with commit metadata (author, message prefix, remote IP).</li>
  <li>Webhook endpoints for remote pull/push triggers and optional polling integration(see <code>dn42notifyd</code>).</li>
  <li>Themeable templates and bundled UI assets.</li>
  <li>Designed for distributed, multi-node and anycast environments.</li>
</ul>

<h3><a class="anchor" id="quick-start" href="#quick-start"></a>Quick Start</h3>

<p>Pre-built binaries are available in the <a href="https://github.com/iedon/dn42-wiki-go/releases">GitHub releases</a>.</p>

<p>Please do not forget to clone the repository to copy <code>config.example.json</code>(to <code>config.json</code>) and the <code>template</code> folder. They should be put together in the same production directory.</p>

<h4><a class="anchor" id="manual-build" href="#manual-build"></a>Manual Build</h4>

<ol>
  <li>Install Go 1.24+ and ensure the git executable is available in PATH.</li>
  <li>Copy the example config:
cp config.example.json config.json
Then edit the settings you need.</li>
  <li>Build for your platform (example: Linux amd64):
<pre class="highlight"><code><span class="nb">export </span><span class="nv">GOOS</span><span class="o">=</span>linux
<span class="nb">export </span><span class="nv">GOARCH</span><span class="o">=</span>amd64
./build.sh</code></pre></li>
</ol>

<p>Determine which user is used to run <code>dn42-wiki-go</code>, then create <code>~/.gitconfig</code> for this user, which will be used by <code>git</code>.</p>

<p>For example:</p>

<pre class="highlight"><code><span class="nn">[user]</span>
        <span class="py">email</span> <span class="p">=</span> <span class="s">noreply@dn42.jp    </span>
        <span class="py">name</span> <span class="p">=</span> <span class="s">IEDON.DN42 Wiki Mirror(116)</span></code></pre>

<p>To create the isolated, low-privileged user <code>dn42-wiki-go</code>, you may run:
</p><pre class="highlight"><code><span class="c"># This user cannot log in or get a shell.</span>
<span class="c"># This user has /opt/dn42-wiki-go as working directory.</span>
<span class="c"># No default home folder created automatically.</span>
<span class="nb">sudo </span>useradd <span class="nt">-r</span> <span class="nt">-s</span> /usr/sbin/nologin <span class="nt">-d</span> /opt/dn42-wiki-go <span class="nt">-M</span> dn42-wiki-go</code></pre>

<p>Both systemd socket enabler and UNIX domain socket are supported, check example configuration files: <code>dn42-wiki-go.socket</code> and <code>dn42-wiki-go.service</code>.</p>

<p>If you would like to use with Docker: <code>Dockerfile</code> and <code>docker-compose.yml</code> are also provided, bind proper directories and map <code>config.json</code> for the App to use, then you are all set.</p>

<h3><a class="anchor" id="webhook-endpoints" href="#webhook-endpoints"></a>Webhook Endpoints</h3>

<p>When <code>webhook.enabled</code> = true, the server exposes:</p>

<ul>
  <li>
    <p>GET | POST /api/webhook/pull<br />
Runs git pull and rebuilds the cached HTML.</p>
  </li>
  <li>
    <p>GET | POST /api/webhook/push<br />
Pushes local commits to the remote.</p>
  </li>
</ul>

<p>If <code>webhook.secret</code> is set, requests must include an Authorization header that matches the secret.
If <code>webhook.secret</code> is empty, a random secret will be generated on startup to secure the endpoint (used for polling).</p>

<h4><a class="anchor" id="polling-integration" href="#polling-integration"></a>Polling Integration</h4>

<p>When <code>webhook.polling.enabled</code> = true, the server registers with a remote notify service and triggers <code>/api/webhook/pull</code> whenever a refresh completes.</p>

<p>This is compatible with <code>dn42notifyd</code> and similar tools.</p>

<h3><a class="anchor" id="configuration-reference" href="#configuration-reference"></a>Configuration Reference</h3>

<p>All settings are provided through a JSON file. Below is a concise reference of all options.</p>

<h4><a class="anchor" id="runtime" href="#runtime"></a>Runtime</h4>

<ul>
  <li>
    <p><code>live</code> <em>(bool, default <code>false</code>)</em>:<br />
true -&gt; run HTTP server and render on demand.<br />
false -&gt; render once to outputDir and exit.</p>
  </li>
  <li>
    <p><code>editable</code> <em>(bool, default <code>false</code>)</em>:<br />
Enables in-browser editing and write operations.</p>
  </li>
  <li>
    <p><code>listen</code> <em>(string, default <code>":8080"</code>)</em>:<br />
TCP address (host:port) or UNIX socket (unix:/path).</p>

    <p>Advanced: See example systemd files <code>dn42-wiki-go.socket</code> and <code>dn42-wiki-go.service</code> in the repository.</p>
  </li>
  <li>
    <p><code>baseUrl</code> <em>(string, optional)</em>:<br />
URL prefix when hosting under a subdirectory.</p>
  </li>
  <li>
    <p><code>siteName</code> <em>(string, default <code>"DN42 Wiki Go"</code>)</em>:<br />
Display name of the wiki.</p>
  </li>
</ul>

<h4><a class="anchor" id="git" href="#git"></a>Git</h4>
<ul>
  <li>
<code>git.binPath</code> <em>(string, default <code>git</code>)</em>: Path to the Git executable.</li>
  <li>
<code>git.remote</code> <em>(string, default empty)</em>: Remote URL. Leave empty for standalone/local repositories.</li>
  <li>
<code>git.localDirectory</code> <em>(string, default <code>./repo</code>)</em>: Directory where the wiki repository is cloned or initialised.</li>
  <li>
<code>git.pullIntervalSec</code> <em>(int, default <code>3600</code>)</em>: Seconds between background <code>git pull</code> operations in live mode. Disabled if no remote is set.</li>
  <li>
<code>git.author</code> <em>(string, default <code>"Anonymous &lt;anonymous@localhost&gt;"</code>)</em>: Author string used for commits generated by the application.</li>
  <li>
<code>git.commitMessagePrefix</code> <em>(string, default empty)</em>: Optional prefix prepended verbatim to commit messages supplied by users.</li>
  <li>
<code>git.commitMessageAppendRemoteAddr</code> <em>(string, default empty)</em>: Optional suffix appended when a request carries a remote address. If the value contains <code>%s</code> it is treated as a <code>fmt</code> format string; otherwise it is concatenated.</li>
</ul>

<h4><a class="anchor" id="webhook" href="#webhook"></a>Webhook</h4>
<ul>
  <li>
<code>webhook.enabled</code> <em>(bool, default <code>false</code>)</em>: Expose webhook endpoints on the main HTTP server.</li>
  <li>
<code>webhook.secret</code> <em>(string, default empty)</em>: Shared secret expected in the <code>Authorization</code> header. If empty, a random secret is generated on startup.</li>
  <li>
<code>webhook.polling.enabled</code> <em>(bool, default <code>false</code>)</em>: Keep a registration active with the remote notification service and trigger periodic pulls.</li>
  <li>
<code>webhook.polling.endpoint</code> <em>(string, default empty)</em>: URL of the notification service (eg. Usage with <a href="https://git.dn42.dev/dn42/dn42notifyd">dn42notifyd</a>: <code>https://git.dn42/dn42notify/poll</code>).</li>
  <li>
<code>webhook.polling.callbackUrl</code> <em>(string, default empty)</em>: Public URL for <code>/api/webhook/pull</code>. Required when <code>webhook.polling.enabled</code> is <code>true</code>.</li>
  <li>
<code>webhook.polling.pollingIntervalSec</code> <em>(int, default <code>3600</code>)</em>: Seconds between refresh attempts. Must be positive when polling is enabled.</li>
  <li>
<code>webhook.polling.skipRemoteCert</code> <em>(bool, default <code>false</code>)</em>: Insecure: Skip TLS verification.</li>
</ul>

<h4><a class="anchor" id="paths-and-templating" href="#paths-and-templating"></a>Paths and templating</h4>
<ul>
  <li>
<code>outputDir</code> <em>(string, default <code>./dist</code>)</em>: Destination directory for static builds or asset exports.</li>
  <li>
<code>templateDir</code> <em>(string, default <code>./template</code>)</em>: Location of layout templates and static assets bundled into the server/UI.</li>
  <li>
<code>homeDoc</code> <em>(string, default <code>Home.md</code>)</em>: Repository document to treat as the home page. Normalised to a <code>.md</code> path relative to the repo root.</li>
  <li>
<code>privatePagesPrefix</code> <em>(array of strings, default empty)</em>: Request to routes started with these prefixes will be blocked.</li>
</ul>

<h4><a class="anchor" id="layout-and-footer" href="#layout-and-footer"></a>Layout and footer</h4>
<ul>
  <li>
<code>ignoreHeader</code> <em>(bool, default <code>false</code>)</em>: Skip loading <code>_Header.md</code> when <code>true</code>. Leave <code>false</code> to include the fragment when present.</li>
  <li>
<code>ignoreFooter</code> <em>(bool, default <code>false</code>)</em>: Skip <code>_Footer.md</code> when <code>true</code>; otherwise render it if available.</li>
  <li>
<code>serverFooter</code> <em>(string, default empty)</em>: Markdown snippet rendered into the global footer at runtime.</li>
</ul>

<h4><a class="anchor" id="tls" href="#tls"></a>TLS</h4>
<ul>
  <li>
<code>enableTLS</code> <em>(bool, default <code>false</code>)</em>: Serve HTTPS using the provided certificate and key.</li>
  <li>
<code>tlsCert</code> <em>(string)</em>: Path to the TLS certificate. Required only when <code>enableTLS</code> is true.</li>
  <li>
<code>tlsKey</code> <em>(string)</em>: Path to the TLS private key. Required when <code>enableTLS</code> is true.</li>
</ul>

<h4><a class="anchor" id="logging-and-client-ip-handling" href="#logging-and-client-ip-handling"></a>Logging and client IP handling</h4>
<ul>
  <li>
<code>logLevel</code> <em>(string, default <code>info</code>)</em>: Minimum log level (<code>debug</code>, <code>info</code>, <code>warn</code>, or <code>error</code>).</li>
  <li>
<code>trustedProxies</code> <em>(array of strings, default empty)</em>: CIDR blocks or literal IPs that are trusted to populate <code>X-Forwarded-For</code>.</li>
  <li>
<code>trustedRemoteAddrLevel</code> <em>(int, default <code>1</code>)</em>: Number of additional trusted hops to peel off when deriving the end-user IP from the forwarded chain. Values less than <code>1</code> are coerced to <code>1</code> during load.</li>
</ul>

<h3><a class="anchor" id="notes" href="#notes"></a>Notes</h3>

<ul>
  <li>live = true requires write access to the Git repo for local commits.</li>
  <li>With no remote configured, <code>dn42-wiki-go</code> initializes a local-only repository.</li>
  <li>Template changes require restarting the server or rebuilding static output.</li>
</ul>


	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
  <li>
<a href="/Home" rel="nofollow">Home</a>
    <ul>
      <li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
      <li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
      <li><a href="/Address-Space" rel="nofollow">Address Space</a></li>
      <li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
      <li><a href="/Interconnections" rel="nofollow">Interconnections</a></li>
      <li><a href="/Policies" rel="nofollow">Policies</a></li>
      <li><a href="/FAQ" rel="nofollow">FAQ</a></li>
      <li><a href="/Links" rel="nofollow">Links</a></li>
    </ul>
  </li>
  <li>How-To
    <ul>
      <li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
      <li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
      <li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
      <li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
      <li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
      <li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
      <li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
      <li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
      <li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
      <li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
      <li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
      <li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
      <li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
      <li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
      <li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
      <li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
      <li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
      <li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
      <li><a href="/howto/GeoFeed" rel="nofollow">GeoFeed</a></li>
      <li><a href="/howto/Telephony-Asterisk" rel="nofollow">Telephony (Asterisk)</a></li>
    </ul>
  </li>
  <li>Services
    <ul>
      <li><a href="/services/IRC" rel="nofollow">IRC</a></li>
      <li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
      <li><a href="/services/dns/Overview" rel="nofollow">DNS</a></li>
      <li><a href="/services/RPKI" rel="nofollow">ROA + RPKI</a></li>
      <li><a href="/services/exchanges/IX-Collection" rel="nofollow">IX Collection</a></li>
      <li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
      <li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
      <li><a href="/services/Pingables" rel="nofollow">Pingables</a></li>
      <li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
      <li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
      <li><a href="/services/ca/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
      <li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
    </ul>
  </li>
  <li>Internal
    <ul>
      <li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
      <li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
      <li><a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a></li>
    </ul>
  </li>
  <li>External Tools
    <ul>
      <li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
      <li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
      <li><a href="https://git.dn42.dev/dn42/registry" rel="nofollow">Registry</a></li>
    </ul>
  </li>
</ul>

<hr />


	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="services/Distributed-Wiki.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/services/Distributed-Wiki.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
