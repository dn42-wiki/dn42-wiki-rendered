<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-e224b375d824f0171fc926d624dc0887bf453db83f485b1992bc0859c4110e3e.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">


  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'services/Repository-Mirrors.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-05adca32f8f4f3effe10f8f4cf26dfd6a419ba986bce60d3f51a97e4055d4113.js" type="text/javascript"></script>


  
  <script>
  var mermaid_conf = {
    startOnLoad: true,
    securityLevel: 'sandbox'
  };
  </script>
  


  <script src="/gollum/assets/gollum.mermaid-ccc590b7d9655deec94c9975f25d74fbe38f703c927e26cf81169d63fea7cd50.js" type="text/javascript"></script>
  <script>
    mermaid.initialize(mermaid_conf);
  </script>
  
  <title>Repository-Mirrors</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>Repository-Mirrors</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/services/Repository-Mirrors.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <button class="btn btn-sm" id="minibutton-home" 
      onclick="window.location.href='/';"
    >
      Home
    </button>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block input-sm" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/overview';"
          id="minibutton-overview"
        >
          Overview
        </button>

        <button
          class="btn BtnGroup-item btn-sm"
          onclick="window.location.href='/gollum/latest_changes';"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </button>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <button
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          onclick="window.location.href='/gollum/history/services/Repository-Mirrors.md/';"
          id="minibutton-history"
        >
          History
        </button>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    Repository-Mirrors
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/services/">services</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="repository-mirrors" href="#repository-mirrors"></a>Repository Mirrors</h1>

<p>There are some mirrors available in DN42. All mirrors are subdomains of "mirror.dn42". DNS Round-Robin is set up for Load Balancing.</p>

<h2><a class="anchor" id="mirror-ano-org-dn42" href="#mirror-ano-org-dn42"></a>mirror.ano-org.dn42</h2>

<p>Proxy to multiple repositories:</p>

<ul>
  <li>
<a href="http://mirror.ano-org.dn42/debian">http://mirror.ano-org.dn42/debian</a>: deb.debian.org/debian</li>
  <li>
<a href="http://mirror.ano-org.dn42/debsec">http://mirror.ano-org.dn42/debsec</a>: security.debian.org/debian-security</li>
  <li>
<a href="http://mirror.ano-org.dn42/ubuntu">http://mirror.ano-org.dn42/ubuntu</a>: archive.ubuntu.com/ubuntu</li>
  <li>
<a href="http://mirror.ano-org.dn42/ubsec">http://mirror.ano-org.dn42/ubsec</a>: security.ubuntu.com/ubuntu</li>
  <li>
<a href="http://mirror.ano-org.dn42/proxmox">http://mirror.ano-org.dn42/proxmox</a>: download.proxmox.com/debian</li>
  <li>
<a href="http://mirror.ano-org.dn42/grafana">http://mirror.ano-org.dn42/grafana</a>: packages.grafana.com/oss/deb</li>
  <li>
<a href="http://mirror.ano-org.dn42/rpi">http://mirror.ano-org.dn42/rpi</a>: archive.raspberrypi.org/debian</li>
</ul>

<p>Other repos can be added on request, contact glueckself@hackint on IRC or send a mail to <a href="mailto:noc@ano-org.sml.name">noc@ano-org.sml.name</a></p>

<h2><a class="anchor" id="ubuntu" href="#ubuntu"></a>Ubuntu</h2>
<p><strong><a href="http://mirror.dn42/ubuntu">http://mirror.dn42/ubuntu</a></strong></p>

<p>Hosted by:</p>
<ul>
  <li>mephisto</li>
</ul>

<h2><a class="anchor" id="mirror-yandex-ru-proxy" href="#mirror-yandex-ru-proxy"></a>mirror.yandex.ru proxy</h2>
<p><strong><a href="http://172.23.158.41/">http://172.23.158.41/</a></strong>
<strong><a href="http://[fd91:9191:9191:3::1]/">http://[fd91:9191:9191:3::1]/</a></strong></p>

<p>Hosted by:</p>
<ul>
  <li>ne-vlezay80</li>
</ul>

<h2><a class="anchor" id="mirrors-nia-dn42-ipv6-only" href="#mirrors-nia-dn42-ipv6-only"></a>mirrors.nia.dn42 (IPv6 Only)</h2>

<p><a href="https://os.ewe.moe/download">eweOS</a>:</p>
<ul>
  <li>
<a href="http://mirrors.nia.dn42/eweos/">http://mirrors.nia.dn42/eweos/</a>: Official Mirror in DN42</li>
  <li>
<a href="http://mirrors.nia.dn42/eweos-images/">http://mirrors.nia.dn42/eweos-images/</a>: Official Mirror in DN42</li>
</ul>

<h2><a class="anchor" id="mirror-z-dn42" href="#mirror-z-dn42"></a>mirror.z.dn42</h2>

<p>Not hosting repositories itself, it collects other mirrors</p>

<ul>
  <li>Dynamic page: <strong><a href="http://mirror.z.dn42/">http://mirror.z.dn42/</a></strong>
</li>
  <li>Static page: <strong><a href="http://mirror.z.dn42/_/">http://mirror.z.dn42/_/</a></strong>
</li>
</ul>

<h2><a class="anchor" id="mirrors-leziblog-dn42" href="#mirrors-leziblog-dn42"></a>mirrors.leziblog.dn42</h2>

<p>Notes:</p>
<ul>
  <li>Local repository, hosted by <a href="mailto:lezi@leziblog.dn42">LeZi</a>
</li>
  <li>Synchronize with the upstream every day at 00:00 UTC.</li>
  <li>Supports <code>https</code>, <code>rsync</code>
    <ul>
      <li>https: <code>https://mirrors.leziblog.dn42</code>
</li>
      <li>rsync: <code>rsync://rsync.mirrors.leziblog.dn42</code>
</li>
    </ul>
  </li>
</ul>

<p>Ubuntu:</p>
<ul>
  <li>
<a href="http://mirrors.leziblog.dn42/ubuntu/">http://mirrors.leziblog.dn42/ubuntu/</a>: archive.ubuntu.com/ubuntu</li>
  <li>
<a href="http://mirrors.leziblog.dn42/ubuntu-ports/">http://mirrors.leziblog.dn42/ubuntu-ports/</a>: ports.ubuntu.com</li>
</ul>

<p>OpenWrt:</p>
<ul>
  <li>
<a href="http://mirrors.leziblog.dn42/openwrt/">http://mirrors.leziblog.dn42/openwrt/</a>: downloads.openwrt.org</li>
</ul>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <p class="gollum-error">Failed to render page: conflicting chdir during another chdir block</p>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <table>
  <tbody>
    <tr>
      <td>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a>, <a href="https://iedon.net/post/24" rel="nofollow">IEDON-MNT</a>
</td>
      <td>Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a>, <a href="https://dn42.jp/" rel="nofollow">dn42.jp</a> (wiki-go)</td>
    </tr>
  </tbody>
</table>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="services/Repository-Mirrors.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/services/Repository-Mirrors.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
