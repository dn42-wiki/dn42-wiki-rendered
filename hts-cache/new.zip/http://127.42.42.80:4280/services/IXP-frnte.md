<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-type" content="text/html;charset=utf-8">
  <meta name="MobileOptimized" content="width">
  <meta name="HandheldFriendly" content="true">
  <meta name="viewport" content="width=device-width">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/app-309be032396e783b13a47df58f389b7c8e11c2b2d42640560b874f677c25f6e5.css" media="all">
  <link rel="stylesheet" type="text/css" href="/gollum/assets/print-512498c368be0d3fb1ba105dfa84289ae48380ec9fcbef948bd4e23b0b095bfb.css" media="print">

  <link rel="stylesheet" type="text/css" href="/custom.css" media="all">
  

  <script>
  var criticMarkup = '';
	var baseUrl = '';
  var showLocalTime = false;
	var uploadDest = 'uploads';
	var perPageUploads = '';
	if (perPageUploads == 'true') {
	  uploadDest = uploadDest + window.location.pathname.replace(/.*gollum\/[-\w]+\//, "/").replace(/\.[^/.]+$/, "").replace(baseUrl, "")
	}
	  var pageFullPath = 'services/IXP-frnte.md';
    var pageFormat   = 'markdown';

  </script>
  <script src="/gollum/assets/app-f05401ee374f0c7f48fc2bc08e30b4f4db705861fd5895ed70998683b383bfb5.js" type="text/javascript"></script>
  

  <title>IXP-frnte</title>
</head>
<body>
<div class="container-lg clearfix">
<div id="wiki-wrapper" class="page">
<div id="head">
	<nav class="TableObject
            actions
            border-bottom
            border-md-0
            p-2
            pt-lg-4
            px-lg-0
            overflow-x-scroll">
  <div class="TableObject-item hide-lg hide-xl">
    <details class="details-reset details-overlay">
      <summary class="btn btn-invisible" aria-haspopup="true">
        <span aria-label="Open menu">☰</span>
      </summary>
    
      <div class="SelectMenu mx-sm-2">
        <div class="SelectMenu-modal">
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Current Page</h2>
            <div>IXP-frnte</div>
          </div>
    
            <a
              class="SelectMenu-item"
              href="/gollum/history/services/IXP-frnte.md"
              role="menuitem"
            >
              <span>History</span>
            </a>
    
    
          <div class="SelectMenu-divider py-3">
            <h2 class="h6">Main Menu</h2>
          </div>
    
          <div class="SelectMenu-list">
            <a class="SelectMenu-item" role="menuitem" href="/">
              Home
            </a>
    
              <a class="SelectMenu-item" role="menuitem" href="/gollum/overview">
                Overview
              </a>
    
              <a
                class="SelectMenu-item"
                href="/gollum/latest_changes"
                role="menuitem"
              >
                Latest Changes
              </a>
          </div>
        </div>
      </div>
    </details>
  </div>

  <div class="TableObject-item hide-sm hide-md">
    <a class="btn btn-sm" id="minibutton-home" href="/">
      Home
    </a>
  </div>

  <div
    class="TableObject-item TableObject-item--primary px-2"
    
  >
    <form class="search-form" action="/gollum/search" method="get" id="search-form">
    	<input type="text" class="form-control input-block" name="q" id="search-query" placeholder="Search" aria-label="Search site" autocomplete="off">
    </form>  </div>

  <div class="TableObject-item hide-sm hide-md">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/overview"
          id="minibutton-overview"
        >
          Overview
        </a>

        <a
          class="btn BtnGroup-item btn-sm"
          href="/gollum/latest_changes"
          id="minibutton-latest-changes"
        >
          Latest Changes
        </a>
    </div>
  </div>

  <div class="TableObject-item px-2">
    <div class="BtnGroup d-flex">
        <a
          class="btn BtnGroup-item btn-sm hide-sm hide-md"
          href="/gollum/history/services/IXP-frnte.md/"
          id="minibutton-history"
        >
          History
        </a>

    </div>
  </div>

</nav>

</div>

<div id="wiki-content" class="px-2 px-lg-0">
  <h1 class="header-title text-center text-md-left pt-4">
    IXP-frnte
  </h1>
	<div class="breadcrumb"><nav aria-label="Breadcrumb"><ol>
<li class="breadcrumb-item"><a href="/gollum/overview/services/">services</a></li>
</ol></nav></div>

	<div class="has-header has-footer has-sidebar has-rightbar">
	  <div id="wiki-body" class="gollum-markdown-content">
	    <div id="wiki-header" class="gollum-markdown-content">
	      <div id="header-content" class="markdown-body">
	        <p><a href="/" rel="nofollow"><img src="/dn42.png" alt="dn42" /></a></p>

	      </div>
	    </div>
	    <div class="main-content clearfix container-lg">
	      <div class="markdown-body  float-md-left col-md-9" >
	        
	        <h1><a class="anchor" id="the-ixp-frnte" href="#the-ixp-frnte"></a>The IXP frnte</h1>

<p>An IXP is a collection point for Internet providers. This can be physical or virtual. In a physical IXP, several Internet providers place servers in a data center and connect them to each other.</p>

<p>In a virtual IXP, the servers are not "real". They are not physically connected with cables, but for example via a VPN.</p>

<p>In dn42 almost all connections are virtual. One builds on the Internet and creates virtual links between the single nodes. In IXP frnte, all providers have virtual machines, which are connected to each other. Due to the large number of providers in IXP, it is possible to reach them easily and with low latency. However, the large number also leads to the fact that no direct peerings are established within an IXP, instead route servers are used. This receives and coordinates all routes of the providers and sends out appropriate routes. This way, many indirect peerings can be established.</p>

<h2><a class="anchor" id="current-participants" href="#current-participants"></a>Current participants</h2>

<table>
<thead>
<tr>
<th>Name</th>
<th>AS</th>
<th>Route server</th>
<th>IRC</th>
</tr>
</thead>
<tbody>
<tr>
<td>Bandura's network</td>
<td>4242422923</td>
<td>4242421081</td>
<td>mark22k</td>
</tr>
</tbody>
</table>

<h2><a class="anchor" id="history-and-origin" href="#history-and-origin"></a>History and origin</h2>

<p>In dn42 and in the Anonet there was the UCIS IXP for a long time. However, this is no longer actively operated.</p>

<p>Members of the LGP Corp have now created a new IXP in dn42. This is the IXP frnte. It is located in France near Nantes and has two separate internet connections. This article describes how to enter the IXP and set up peering with the current route server.</p>

<h2><a class="anchor" id="join-the-ixp" href="#join-the-ixp"></a>Join the IXP</h2>

<h3><a class="anchor" id="1-request-the-infrastructure" href="#1-request-the-infrastructure"></a>1. Request the infrastructure</h3>

<p>LGP Corp provides virtual machines free of charge to any AS operator or anyone who wants to experiment with networks. There are no costs! The VM's can be configured and linked together as desired. The VM's can be connected to each other via a VLAN. Furthermore, an internet connection is available with two ISPs, depending on your choice. The virtual machine gets a public IPv6 and if necessary IPv4 over NAT to be able to access important resources like GitHub.<br />
It is best to create a diagram of your network and send it to the LGP Corp.<br />
The LGP Corp or the responsible admin for the IXP can be reached in <strong>IRC</strong> on hackint.org under <strong>toinux</strong>. Send the diagram to them and discuss further details.<br />
Furthermore, all virtual machines are put into a common VLAN. This causes that one can reach all providers at the IXP without problems.</p>

<h3><a class="anchor" id="2-proxmox-login-and-vm-setup" href="#2-proxmox-login-and-vm-setup"></a>2. Proxmox Login and VM Setup</h3>

<p>After that you will receive your access data for the Proxmox portal from the LGP Corp. Under which you can set up your VM's. The portal can be reached under <a href="https://pve.home.lgp-corp.fr/"><strong>https://pve.home.lgp-corp.fr/</strong></a>. Select "Proxmox VE authentication server" as "Realm". It also offers a VNC monitor to work directly on the server. For the setup under SSH an IPv6 connectivity to the internet is required. If you only have an IPv4, you can get an IPv6 for free from Hurricane Electric at <a href="https://tunnelbroker.net/">https://tunnelbroker.net/</a>.</p>

<h3><a class="anchor" id="3-configure-vlan" href="#3-configure-vlan"></a>3. Configure VLAN</h3>

<p>An internal IPv6 Range has been requested for the IXP: <code>fde0:93fa:7a0:2::/64</code> (<a href="https://explorer.dn42.dev/#/inet6num/fde0:93fa:7a0:2::_64">fde0:93fa:7a0:2::/64 on explorer</a>)</p>

<p>The following is the assignment policy:<br />
<code>fde0:93fa:7a0:2:0:&lt;asn32|high16|hex&gt;:&lt;asn32|low16|hex&gt;:1/64</code><br />
For example, if you have the ASN 4242421080, you get the range <code>fde0:93fa:7a0:2:0:fcde:3558:1/64</code><br />
It should be noted that only the last block may be changed. So you get a practical IPv6 range of <code>fde0:93fa:7a0:2:0:fcde:3558:/112</code>.<br />
A Ruby script to calculate the IPv6 can be found on <a href="https://gist.github.com/marek22k/494cf9c4d269867f23f2c3577e1780ef">ixp_frnte_dn42_prefix.rb on GitHub Gist</a>.</p>

<p>An example configuration for Debian based Linux distributions would be:  </p>

<pre class="highlight"><code>iface ensXX inet6 static
    address fde0:93fa:7a0:2:0:fcde:3558:1/64</code></pre>

<p>Here <code>ensXX</code> is the dn42 VLAN interface. This can be determined by comparing the MAC address of the interface with the MAC address of the dn42 VLAN in Proxmox. The MAC address can be determined on Linux with <code>ip l</code>:</p>

<pre class="highlight"><code>ensXX: &lt;BROADCAST,MULTICAST,UP,LOWER_UP&gt; mtu
    1500 qdisc pfifo_fast state UP mode DEFAULT group
    default qlen 1000
    <span class="nb">link</span>/ether MAC brd ff:ff:ff:ff:ff:ff</code></pre>

<p><code>MAC</code> would be the MAC address. After that you can activate the interface with ifup or a reboot of the VM.<br />
Of course there are other configuration possibilities. This is only an example for Debian-based Linux distributions.</p>

<h3><a class="anchor" id="4-connect-to-the-route-server" href="#4-connect-to-the-route-server"></a>4. Connect to the Route Server</h3>

<p>There can be several Route Servers (RS) on one IXP. However, on the IXP frnte there is currently only one, which is operated by jlu5 (operator of the highdef network).
IPv6: fde0:93fa:7a0:2:0:fcde:3559:1
ASN: 4242421081</p>

<p>You can now enter this configuration into your routing daemon and it will connect to the RS. You should keep in mind that the RS itself does not forward any traffic, but is only responsible for the coordination. Therefore the AS path must not necessarily start with the AS of the RS.</p>

<p>An example configuration for bird2 would be the following:</p>

<pre class="highlight"><code><span class="n">protocol</span> <span class="n">bgp</span> <span class="n">ixp_rs</span> <span class="n">from</span> <span class="n">dnpeers</span> {
    <span class="n">neighbor</span> <span class="n">fde0</span>:<span class="m">93</span><span class="n">fa</span>:<span class="m">7</span><span class="n">a0</span>:<span class="m">2</span>:<span class="m">0</span>:<span class="n">fcde</span>:<span class="m">3559</span>:<span class="m">1</span> <span class="n">as</span> <span class="m">4242421081</span>;
    
    <span class="n">enable</span> <span class="n">extended</span> <span class="n">messages</span> <span class="n">on</span>;
    <span class="n">direct</span>;
    <span class="n">enforce</span> <span class="n">first</span> <span class="n">as</span> <span class="n">off</span>;
    
    <span class="n">ipv4</span> {
    	<span class="n">extended</span> <span class="n">next</span> <span class="n">hop</span>;
    };
}</code></pre>

<p><strong>What does this configuration do?</strong></p>

<p>First we create a new BGP session (<code>protocol bgp</code>). This is based on the dnpeers template which can be found in the standard Bird2 configuration in the <a href="/howto/Bird2">wiki</a>. We name this session "ixp_rs". However, this is only an internal name and can be replaced with another one.</p>

<p>After that we determine with whom we want to have the session. This would be the RS. Therefore we put IPv6 address and ASN there.</p>

<p>Furthermore, we allow larger BGP messages. Thus, instead of 4096 bytes, a whole 65535 bytes are transmitted in one message. This is especially useful because an RS has to announce a lot of routes.</p>

<p>With <code>direct</code> we indicate that the RS is directly connected to our server and no routing via third parties has to be performed. In our case, the RS is connected to us via the dn42 VLAN.</p>

<p>The next line has the effect that the ASN of the RS does not necessarily have to be the next hop for routing. This is important because we do not route the traffic via the RS, but via the respective peers. These have an ASN that differs from the ASN of the RS.</p>

<p>Since the dn42 VLAN <em>only</em> supports IPv6, any IPv4 traffic must also go over IPv6. If you do not have or do not want to use IPv4, you can ignore this part of the configuration.</p>

<p>Finally we save the bird2 configuration and load the new configuration with <code>birdc configure</code>.</p>

<h3><a class="anchor" id="5-check-if-it-works" href="#5-check-if-it-works"></a>5. Check if it works</h3>

<p>There are now a few things to check:<br />
Once you can see if the BGP session is esablished. In Bird you can do this with <code>birdc show protocols all ixp_rs</code>.<br />
Furthermore, you can display different routes (in case of bird with <code>birdc show route for [ip address]</code>) or perform a traceroute.<br />
One can also try to ping the IP of some at the IXP. From the latency you can also see if everything is working:  </p>

<ul>
<li>  Bandura's pingable:

<ul>
<li>  <code>172.22.149.224</code>
</li>
<li>  <code>fd04:234e:fc31::</code>
</li>
</ul>
</li>
</ul>

	      </div>
          <div id="wiki-sidebar" class="Box Box--condensed float-md-left col-md-3">
	        <div id="sidebar-content" class="gollum-markdown-content markdown-body px-4">
	          <ul>
<li>
<p><a href="/Home" rel="nofollow">Home</a></p>

<ul>
<li><a href="/howto/Getting-Started" rel="nofollow">Getting Started</a></li>
<li><a href="/howto/Registry-Authentication" rel="nofollow">Registry Authentication</a></li>
<li><a href="/howto/Address-Space" rel="nofollow">Address Space</a></li>
<li><a href="/howto/BGP-communities" rel="nofollow">BGP communities</a></li>
<li><a href="/FAQ" rel="nofollow">FAQ</a></li>
</ul>
</li>
<li>
<p>How-To</p>

<ul>
<li><a href="/howto/wireguard" rel="nofollow">Wireguard</a></li>
<li><a href="/howto/openvpn" rel="nofollow">Openvpn</a></li>
<li><a href="/howto/IPsec-with-PublicKeys" rel="nofollow">IPsec With Public Keys</a></li>
<li><a href="/howto/tinc" rel="nofollow">Tinc</a></li>
<li><a href="/howto/GRE-on-FreeBSD" rel="nofollow">GRE on FreeBSD</a></li>
<li><a href="/howto/GRE-on-OpenBSD" rel="nofollow">GRE on OpenBSD</a></li>
<li><a href="/howto/IPv6-Multicast" rel="nofollow">IPv6 Multicast (PIM-SM)</a></li>
<li><a href="/howto/multicast" rel="nofollow">SSM Multicast</a></li>
<li><a href="/howto/mpls" rel="nofollow">MPLS</a></li>
<li><a href="/howto/Bird2" rel="nofollow">Bird2</a></li>
<li><a href="/howto/frr" rel="nofollow">FRRouting</a></li>
<li><a href="/howto/OpenBGPD" rel="nofollow">OpenBGPD</a></li>
<li><a href="/howto/mikrotik" rel="nofollow">Mikrotik RouterOS</a></li>
<li><a href="/howto/EdgeOS-Config" rel="nofollow">EdgeRouter</a></li>
<li><a href="/howto/Static-routes-on-Windows" rel="nofollow">Static routes on Windows</a></li>
<li><a href="/howto/networksettings" rel="nofollow">Universal Network Requirements</a></li>
<li><a href="/howto/vyos1.4.x" rel="nofollow">VyOS</a></li>
<li><a href="/howto/nixos" rel="nofollow">NixOS</a></li>
</ul>
</li>
<li>
<p>Services</p>

<ul>
<li><a href="/services/IRC" rel="nofollow">IRC</a></li>
<li><a href="/services/Whois" rel="nofollow">Whois registry</a></li>
<li><a href="/services/DNS" rel="nofollow">DNS</a></li>
<li><a href="/services/IX-Collection" rel="nofollow">IX Collection</a></li>
<li><a href="/services/Clearnet-Domains" rel="nofollow">Public DNS</a></li>
<li><a href="/services/Looking-Glasses" rel="nofollow">Looking Glasses</a></li>
<li><a href="/services/Automatic-Peering" rel="nofollow">Automatic Peering</a></li>
<li><a href="/services/Repository-Mirrors" rel="nofollow">Repository Mirrors</a></li>
<li><a href="/services/Distributed-Wiki" rel="nofollow">Distributed Wiki</a></li>
<li><a href="/services/Certificate-Authority" rel="nofollow">Certificate Authority</a></li>
<li><a href="/services/Route-Collector" rel="nofollow">Route Collector</a></li>
</ul>
</li>
<li>
<p>Internal</p>

<ul>
<li><a href="/internal/Internal-Services" rel="nofollow">Internal services</a></li>
<li><a href="/internal/Interconnections" rel="nofollow">Interconnections</a></li>
<li><a href="/internal/APIs" rel="nofollow">APIs</a></li>
<li>
<a href="/internal/ShowAndTell" rel="nofollow">Show and Tell</a><br />
</li>
<li><a href="/internal/Historical-Services" rel="nofollow">Historical services</a></li>
</ul>
</li>
<li>
<p>Historical</p>

<ul>
<li><a href="/historical/Bird" rel="nofollow">Bird 1</a></li>
<li><a href="/historical/Quagga" rel="nofollow">Quagga</a></li>
</ul>
</li>
<li>
<p>External Tools</p>

<ul>
<li><a href="https://paste.dn42.us" rel="nofollow">Paste Board</a></li>
<li><a href="https://git.dn42.dev" rel="nofollow">Git Repositories</a></li>
</ul>
</li>
</ul>

<hr />

	        </div>
	      </div>
	    </div>
	  </div>
	  <div id="wiki-footer" class="gollum-markdown-content my-2">
	    <div id="footer-content" class="Box Box-condensed markdown-body px-4">
	      <p>Hosted by: <a href="mailto:dn42@burble.com" rel="nofollow">BURBLE-MNT</a>, <a href="mailto:nurtic-vibe@grmml.net" rel="nofollow">GRMML-MNT</a>, <a href="mailto:xuu@dn42.us" rel="nofollow">XUU-MNT</a>, <a href="mailto:janeric@ortgies.it" rel="nofollow">JAN-MNT</a>, <a href="mailto:lare@lare.cc" rel="nofollow">LARE-MNT</a>, <a href="mailto:danny@saru.moe" rel="nofollow">SARU-MNT</a>, <a href="mailto:androw95220@gmail.com" rel="nofollow">ANDROW-MNT</a>, <a href="mailto:dn42@mk16.de" rel="nofollow">MARK22K-MNT</a> | Accessible via: <a href="https://wiki.dn42" rel="nofollow">dn42</a>, <a href="https://dn42.dev/" rel="nofollow">dn42.dev</a>, <a href="https://dn42.eu/" rel="nofollow">dn42.eu</a>, <a href="https://wiki.dn42.us/" rel="nofollow">wiki.dn42.us</a>, <a href="https://dn42.de/" rel="nofollow">dn42.de</a> (IPv6-only), <a href="https://dn42.cc/" rel="nofollow">dn42.cc</a> (wiki-ng), <a href="https://dn42.wiki/" rel="nofollow">dn42.wiki</a>, <a href="https://dn42.pp.ua/" rel="nofollow">dn42.pp.ua</a>, <a href="https://dn42.obl.ong/" rel="nofollow">dn42.obl.ong</a></p>

	    </div>
	  </div>


	</div>


	<div id="footer" class="pt-4">
		  <p id="last-edit"><div class="dotted-spinner hidden"></div> <a id="page-info-toggle" data-pagepath="services/IXP-frnte.md">When was this page last modified?</a></p>
	</div>


</div>

<form name="rename" method="POST" action="/gollum/rename/services/IXP-frnte.md">
  <input type="hidden" name="rename"/>
  <input type="hidden" name="message"/>
</form>

</div>
</div>
</body>
</html>
